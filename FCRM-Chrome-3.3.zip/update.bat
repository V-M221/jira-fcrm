@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
if errorlevel 1 (
  echo.
  echo Update failed. See the message above.
  pause
  exit /b 1
)
echo.
echo Please reload the extension at chrome://extensions and refresh Jira.
pause

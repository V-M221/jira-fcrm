/**
 * Ozon Bank · Jira FCRM Structure Chrome Extension (Manifest V3 — v3.0)
 *
 * Строго для доски: https://jit.o3.ru/secure/RapidBoard.jspa?rapidView=9349&projectKey=FCRM
 *
 * Что реализовано в v3.0:
 * 1. СТРОГИЙ ФИЛЬТР СПРИНТОВ ДОСКИ FCRM (#9349): чужие спринты смежных команд с 0 задач (TXCTRL_VED_REQ, PFM B2C, Loan Factoring, HOGWARTS_CD, CRM_CORE, CRM_BO, CS, Collection и др.), у которых originBoardId != 9349 и нет задач FCRM, полностью скрыты! Отображаются только реальные спринты вашей доски (Product Dicsvery, #Разработка..., Бэклог FCRM).
 * 2. РЕАЛЬНОЕ СОХРАНЕНИЕ И УДАЛЕНИЕ СВЯЗЕЙ В JIRA REST API: при нажатии «+ Выбрать» / «✓ Привязана» в блоке «Задача проекта» (labels = fcrm_umb_epic), «+ Добавить» в «В проекте» или «✕» отправляются реальные запросы POST /rest/api/2/issueLink и DELETE /rest/api/2/issueLink/{id} с автоматическим определением типа связи Jira (Задача проекта / В проекте / Relates).
 * 3. Строго единая высота всех строк таблицы (28px): ячейки связей рендерятся строго в 1 линию с бейджем «+N ещё ▾».
 * 4. 100% соответствие шрифтов и верстки превью AI Studio (Inter, Plus Jakarta Sans, JetBrains Mono), Описание задачи, Приоритет и реальные компоненты/спринты у связанных задач.
 */
(function () {
  'use strict';

  const CONFIG = {
  "boardUrl": "https://jit.o3.ru/secure/RapidBoard.jspa?rapidView=9349&projectKey=FCRM#",
  "rapidViewId": "9349",
  "projectKey": "FCRM",
  "epicFieldId": "customfield_10006",
  "sprintFieldId": "customfield_10004",
  "customerFieldId": "customfield_14201",
  "linkTypeProjectTask": "Задача проекта",
  "linkTypeInProject": "В проекте",
  "showSummary": true,
  "showEpic": true,
  "showComponent": true,
  "showAssignee": true,
  "showAuthor": true,
  "showCustomer": true,
  "showCreatedAt": true,
  "showSprint": true,
  "showProjectTaskLinks": true,
  "showInProjectLinks": true,
  "compactMode": true,
  "widenColumns": true,
  "columnMinWidthPx": 340,
  "autoRefreshIntervalSec": 60
};
  const renderStructuredAnswer = function structuredAnswer(source, kind = 'result', markup) {
    const text = String(source || '');
    const escape = (value) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const read = (tag) => Array.from(text.matchAll(new RegExp('<' + tag + '>([\\s\\S]*?)</' + tag + '>', 'gi'))).map(match => match[1].trim()).filter(Boolean).join('\n\n');
    const headingStyle = 'display:block;padding:9px 12px;border-left:3px solid #005bff;border-radius:5px;background:rgba(0,150,255,.1);font-size:15px;font-weight:700;line-height:1.4;';
    const body = (content) => markup ? markup(content) : escape(content);
    const section = (title, content, collapsed = false) => !content ? '' : collapsed
        ? '<details style="margin:18px 0;"><summary style="' + headingStyle + 'cursor:pointer;">' + title + '</summary><div style="white-space:pre-wrap;margin-top:10px;">' + body(content) + '</div></details>'
        : '<section style="margin:18px 0;"><strong style="' + headingStyle + '">' + title + '</strong><div style="white-space:pre-wrap;margin-top:10px;">' + body(content) + '</div></section>';
    const created = /^FCRM-[0-9]+$/i.exec(read('created_issue'))?.[0];
    if (kind === 'thread') {
        const issueTitle = read('created_issue_title');
        const issue = created ? '<a target="_blank" rel="noopener noreferrer" style="color:#005bff;font-weight:700;" href="/browse/' + encodeURIComponent(created) + '">' + escape(created) + '</a>' + (issueTitle ? ' — ' + escape(issueTitle) : '') : '';
        const issueSection = issue ? '<section style="margin:16px 0;"><strong style="' + headingStyle + '">Созданная задача</strong><div style="margin-top:8px;">' + issue + '</div></section>' : '';
        return issueSection + section('Описание', read('result_description') || read('result_summary')) + section('Связи', read('result_links')) + section('Ошибки', read('result_errors')) || section('Итог', text);
    }
    let html = created ? '<section style="margin:18px 0;"><strong style="' + headingStyle + '">Созданная задача</strong><div style="margin-top:10px;"><a target="_blank" rel="noopener noreferrer" style="color:#459bff;font-weight:700;font-size:15px;" href="/browse/' + encodeURIComponent(created) + '">' + escape(created) + '</a></div></section>' : '';
    html += section('Предложенное название', read('jira_summary'));
    html += section('Описание', read('jira_description'));
    const summary = read('result_summary');
    const details = read('result_details');
    html += section(kind === 'links' ? 'Краткий итог' : 'Итог', summary);
    html += section('Детальный итог', details);
    html += section('Ошибки', read('result_errors'));
    html += section('Предложения и вопросы', read('jira_notes'));
    html += section('Рассуждения', read('result_reasoning'), true);
    const remainder = text.replace(/<(created_issue|jira_summary|jira_description|jira_notes|result_summary|result_details|result_errors|result_reasoning)>[\s\S]*?<\/\1>/gi, '').trim();
    if (remainder)
        html += section(html ? 'Дополнительный ответ' : 'Итог', remainder);
    return html || section('Итог', 'DeepSeek не вернул содержательный ответ');
};
  const renderAnswerMarkup = function answerMarkup(source) {
    const escape = (value) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const inline = (value) => value.split(/(\[[^\]\n]+\]\(https?:\/\/[^\s)]+\)|\[[^\]\n]+\|https?:\/\/[^\s\]]+\]|https?:\/\/[^\s<>]+|\*\*[^*\n]+\*\*|\*[^*\n]+\*|`[^`\n]+`)/gi).map(part => {
        const link = /^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/i.exec(part) || /^\[([^\]|\n]+)\|(https?:\/\/[^\s\]]+)\]$/i.exec(part);
        if (link || /^https?:\/\//i.test(part)) {
            return '<a target="_blank" rel="noopener noreferrer" href="' + escape(link ? link[2] : part) + '">' + escape(link ? link[1] : part) + '</a>';
        }
        if (part.startsWith('**') && part.endsWith('**'))
            return '<strong>' + escape(part.slice(2, -2)) + '</strong>';
        if (part.startsWith('*') && part.endsWith('*'))
            return '<strong>' + escape(part.slice(1, -1)) + '</strong>';
        if (part.startsWith('`') && part.endsWith('`'))
            return '<code>' + escape(part.slice(1, -1)) + '</code>';
        return escape(part);
    }).join('');
    const blocks = [];
    const jiraWiki = /^h[1-6]\.\s/m.test(source);
    let list = '';
    for (const line of source.split(/\r?\n/)) {
        const candidate = /^\s*(?:([-*#])|\d+[.)])\s+(.+)/.exec(line);
        const item = candidate && (candidate[1] !== '#' || jiraWiki) ? candidate : null;
        const next = item ? (item[1] && item[1] !== '#' ? 'ul' : 'ol') : '';
        if (next !== list) {
            if (list)
                blocks.push('</' + list + '>');
            if (next)
                blocks.push('<' + next + '>');
            list = next;
        }
        if (item)
            blocks.push('<li>' + inline(item[2]) + '</li>');
        else if (line.trim()) {
            const heading = /^(?:#{1,6}\s+(.+)|\*\*(.+)\*\*|h[1-6]\.\s+(.+))$/.exec(line.trim());
            blocks.push(heading ? '<h3>' + inline(heading[1] || heading[2] || heading[3]) + '</h3>' : '<p>' + inline(line) + '</p>');
        }
    }
    if (list)
        blocks.push('</' + list + '>');
    return blocks.join('');
};

  function isTargetBoardPage() {
    const path = window.location.pathname || '';
    if (!path.includes('/secure/RapidBoard.jspa')) {
      return false;
    }
    const params = new URLSearchParams(window.location.search);
    const rv = params.get('rapidView');
    const pk = params.get('projectKey');
    if (rv && String(rv) !== String(CONFIG.rapidViewId) && String(rv) !== '6197') {
      return false;
    }
    if (!rv && pk && String(pk).toUpperCase() !== String(CONFIG.projectKey).toUpperCase()) {
      return false;
    }
    const viewMode = params.get('view');
    if (viewMode === 'manage' || viewMode === 'reporting') {
      return false;
    }
    return true;
  }

  if (!isTargetBoardPage()) {
    return;
  }

  function ensureGoogleFontsLoaded() {
    if (!document.getElementById('ozon-ext-google-fonts')) {
      const link = document.createElement('link');
      link.id = 'ozon-ext-google-fonts';
      link.rel = 'stylesheet';
      link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600;700&family=Plus+Jakarta+Sans:wght@600;700&display=swap';
      document.head.appendChild(link);
    }
    if (!document.getElementById('ozon-ext-runtime-styles')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'ozon-ext-runtime-styles';
      styleEl.textContent = "/* ============================================================================\n   Ozon Bank Design System — Jira Structure Extension for jit.o3.ru (v3.2)\n   Target ONLY: https://jit.o3.ru/secure/RapidBoard.jspa?rapidView=9349&projectKey=FCRM\n   ============================================================================ */\n\n@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600;700&family=Plus+Jakarta+Sans:wght@600;700&display=swap');\n\n:root {\n  --ozon-font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;\n  --ozon-font-display: 'Plus Jakarta Sans', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;\n  --ozon-font-mono: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;\n  --ozon-label-action: #005BFF;\n  --ozon-label-action-hover-veil: rgba(0, 91, 255, 0.08);\n  --ozon-label-action-active-veil: rgba(0, 91, 255, 0.16);\n  --ozon-layer-surface: #F2F4F8;\n  --ozon-graphic-accent-primary: #E11D68;\n  --ozon-graphic-secondary: #1E293B;\n  --ozon-negative-bg: #FBECE9;\n  --ozon-negative-text: #D9381E;\n  --ozon-navy: #071026;\n  --ozon-border: #E2E8F0;\n}\n\n@keyframes ozon-skeleton-shimmer {\n  0% { background-position: 200% 0; }\n  100% { background-position: -200% 0; }\n}\n\n@keyframes ozon-spin {\n  to { transform: rotate(360deg); }\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .ozon-ext-section-head { transition: background-color 140ms ease, color 140ms ease; }\n  .ozon-ext-btn, .ozon-ext-search-select-trigger, .ozon-ext-toolbar-trigger { transition: background-color 140ms ease, border-color 140ms ease, color 140ms ease; }\n}\n\n.ozon-ext-skeleton {\n  background: linear-gradient(90deg, #EEF2F6 25%, #E2E8F0 50%, #EEF2F6 75%) !important;\n  background-size: 200% 100% !important;\n  animation: ozon-skeleton-shimmer 1.2s infinite linear !important;\n  border-radius: 5px !important;\n  display: inline-block;\n}\n\n.ozon-ext-spinner {\n  display: inline-block;\n  width: 13px;\n  height: 13px;\n  border: 2px solid rgba(0, 91, 255, 0.22);\n  border-top-color: #005BFF;\n  border-radius: 50%;\n  animation: ozon-spin 0.65s linear infinite;\n  flex-shrink: 0;\n}\n\n#ozon-structure-toggle-btn {\n  display: inline-flex !important;\n  align-items: center !important;\n  gap: 6px !important;\n  padding: 5px 12px !important;\n  margin-left: 10px !important;\n  background-color: #E5F0FF !important;\n  color: #005BFF !important;\n  font-family: var(--ozon-font-sans) !important;\n  font-size: 12px !important;\n  font-weight: 700 !important;\n  border: none !important;\n  border-radius: 8px !important;\n  cursor: pointer !important;\n  transition: background-color 120ms ease !important;\n  z-index: 9999 !important;\n}\n\n#ozon-structure-toggle-btn:hover {\n  background-color: #D0E3FF !important;\n}\n\n#ozon-structure-toggle-btn.active {\n  background-color: #005BFF !important;\n  color: #FFFFFF !important;\n}\n\n#ozon-structure-root {\n  position: fixed !important;\n  top: 40px !important;\n  left: 0 !important;\n  right: 0 !important;\n  bottom: 0 !important;\n  z-index: 9990 !important;\n  background: #F5F7FA !important;\n  color: #071026 !important;\n  font-family: var(--ozon-font-sans) !important;\n  font-size: 12px !important;\n  line-height: 1.35 !important;\n  -webkit-font-smoothing: antialiased !important;\n  -moz-osx-font-smoothing: grayscale !important;\n  display: flex !important;\n  flex-direction: column !important;\n  overflow: hidden !important;\n  box-sizing: border-box !important;\n}\n\n#ozon-structure-root *,\n#ozon-structure-root *::before,\n#ozon-structure-root *::after {\n  box-sizing: border-box;\n  font-family: var(--ozon-font-sans);\n}\n\n#ozon-structure-root .ozon-mono {\n  font-family: var(--ozon-font-mono) !important;\n  font-variant-numeric: tabular-nums !important;\n}\n\n#ozon-structure-root select option {\n  background-color: #FFFFFF !important;\n  color: #071026 !important;\n  font-weight: 500 !important;\n  padding: 4px 8px !important;\n}\n\n.ozon-ext-header-bar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 6px 12px;\n  background: #FFFFFF;\n  border-bottom: 1px solid #E2E8F0;\n  flex-shrink: 0;\n}\n\n.ozon-ext-filter-bar {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 6px 12px;\n  background: #FFFFFF;\n  border-bottom: 1px solid #E2E8F0;\n  flex-shrink: 0;\n}\n\n.ozon-ext-filter-select {\n  appearance: none !important;\n  -webkit-appearance: none !important;\n  background-color: #F5F7FA !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%2364748B' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n  background-repeat: no-repeat !important;\n  background-position: right 7px center !important;\n  color: #071026 !important;\n  border: 1px solid #E2E8F0 !important;\n  border-radius: 8px !important;\n  padding: 4px 22px 4px 8px !important;\n  font-size: 11.5px !important;\n  font-weight: 500 !important;\n  height: 26px !important;\n  max-width: 195px !important;\n  cursor: pointer !important;\n  outline: none !important;\n  text-overflow: ellipsis !important;\n}\n\n.ozon-ext-filter-select:hover {\n  border-color: #CBD5E1 !important;\n  background-color: #EEF2F6 !important;\n}\n\n.ozon-ext-filter-select:focus {\n  border-color: #005BFF !important;\n  background-color: #FFFFFF !important;\n  box-shadow: 0 0 0 3px rgba(0,91,255,.10) !important;\n}\n.ozon-ext-toolbar-combo { position:relative; min-width:142px; max-width:245px; }\n.ozon-ext-toolbar-trigger { display:flex; align-items:center; justify-content:space-between; gap:10px; width:100%; height:30px; padding:5px 10px; border:1px solid #E2E8F0; border-radius:9px; background:#fff; color:#071026; box-shadow:0 1px 2px rgba(7,16,38,.04); font:500 11.5px var(--ozon-font-sans); cursor:pointer; }\n.ozon-ext-toolbar-trigger:hover,.ozon-ext-toolbar-trigger[aria-expanded=\"true\"] { border-color:#a8bbd2; background:#f8fbff; }\n.ozon-ext-toolbar-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }\n.ozon-ext-toolbar-chevron,.ozon-ext-search-select-caret { position:relative; display:inline-flex; align-items:center; justify-content:center; align-self:center; width:14px; height:20px; flex:0 0 14px; color:#64748b; line-height:0; font-size:0; }\n.ozon-ext-toolbar-chevron::before,.ozon-ext-search-select-caret::before { content:\"\"; width:7px; height:7px; border-right:1.8px solid currentColor; border-bottom:1.8px solid currentColor; transform:translateY(-1px) rotate(45deg); }\n.ozon-ext-toolbar-popover { z-index:10030; left:0; right:auto; top:calc(100% + 4px); min-width:100%; width:max-content; max-width:340px; padding:5px; }\n.ozon-ext-toolbar-popover input { width:100%; margin-bottom:4px; }\n.ozon-ext-toolbar-popover .ozon-ext-combo-item { display:block !important; width:100%; border:0; background:transparent; text-align:left; }\n#ozon-structure-root .ozon-ext-toolbar-popover .ozon-dev-filter-list { scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-ext-toolbar-popover .ozon-dev-filter-list::-webkit-scrollbar { width:6px;height:6px; }\n#ozon-structure-root .ozon-ext-toolbar-popover .ozon-dev-filter-list::-webkit-scrollbar-track { background:transparent; }\n#ozon-structure-root .ozon-ext-toolbar-popover .ozon-dev-filter-list::-webkit-scrollbar-thumb { background:#A8B5C5;border-radius:8px; }\n.ozon-ext-epic-filter-popover { width:440px!important;max-width:calc(100vw - 32px)!important; }\n.ozon-ext-epic-filter-popover .ozon-ext-combo-item { height:auto!important;min-height:30px;white-space:normal!important;overflow:visible!important;text-overflow:clip!important;overflow-wrap:anywhere;line-height:1.45!important; }\n.ozon-ext-epic-picker-popover { width:440px!important;max-width:calc(100vw - 32px)!important; }\n.ozon-ext-combo-item.ozon-ext-epic-option { display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:4px!important;height:auto!important;white-space:normal!important; }\n.ozon-ext-epic-option .ozon-ext-epic-option-title { white-space:normal!important;overflow:visible!important;overflow-wrap:anywhere;line-height:1.45;color:#071026; }\n.ozon-ext-toolbar-empty { padding:8px 10px; color:#64748b; font-size:11px; }\n.ozon-ext-search-select { position:relative; width:100%; min-width:0; }\n.ozon-ext-search-select-trigger { display:flex; align-items:center; justify-content:space-between; gap:8px; width:100%; min-width:0; height:30px; padding:5px 10px; border:1px solid #CBD5E1; border-radius:8px; background:#F8FAFC; color:#071026; font:500 11.5px var(--ozon-font-sans); text-align:left; cursor:pointer; }\n.ozon-ext-search-select-trigger:hover,.ozon-ext-search-select-trigger[aria-expanded=\"true\"] { border-color:#005BFF; background:#fff; box-shadow:0 0 0 2px rgba(0,91,255,.08); }\n.ozon-ext-field-grid .ozon-ext-search-select-trigger,.ozon-ext-field-grid .ozon-ext-sb-combo-trigger { height:30px!important; min-height:30px!important; padding:5px 10px!important; border:1px solid #E2E8F0!important; border-radius:9px!important; background:#fff!important; color:#071026!important; box-shadow:0 1px 2px rgba(7,16,38,.04)!important; font:500 11.5px var(--ozon-font-sans)!important; }\n.ozon-ext-field-grid .ozon-ext-search-select-trigger:hover,.ozon-ext-field-grid .ozon-ext-search-select-trigger[aria-expanded=\"true\"],.ozon-ext-field-grid .ozon-ext-sb-combo-trigger:hover { border-color:#a8bbd2!important; background:#f8fbff!important; box-shadow:0 0 0 2px rgba(0,91,255,.08)!important; }\n.ozon-ext-field-grid input[type=\"text\"] { min-height:30px!important; border:1px solid #E2E8F0!important; border-radius:9px!important; background:#fff!important; box-shadow:0 1px 2px rgba(7,16,38,.04)!important; font:500 11.5px var(--ozon-font-sans)!important; }\n.ozon-ext-search-select.workflow { width:auto; min-width:115px; flex:none; }\n.ozon-ext-search-select.workflow .ozon-ext-search-select-trigger { width:auto; min-width:115px; height:26px; border-radius:999px; padding:3px 10px; background:#F8FAFC; }\n.ozon-ext-search-select-value { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; min-width:0; }\n.ozon-ext-search-select-popover { width:100% !important; min-width:220px !important; max-width:min(380px,calc(100vw - 24px)) !important; max-height:320px !important; padding:6px !important; }\n.ozon-ext-search-select-popover .ozon-ext-combo-list { max-height:260px !important; }\n.ozon-ext-search-select.compact { width:100%; }\n.ozon-ext-search-select.compact .ozon-ext-search-select-trigger { height:22px; padding:1px 6px; border-color:transparent; border-radius:5px; background:transparent; font-size:10.5px; }\n.ozon-ext-search-select.compact .ozon-ext-search-select-trigger:hover,.ozon-ext-search-select.compact .ozon-ext-search-select-trigger[aria-expanded=\"true\"] { border-color:rgba(0,91,255,.3); background:#fff; }\n.ozon-ext-search-select.compact .ozon-ext-search-select-popover { width:280px !important; min-width:250px !important; }\n.ozon-ext-search-select-option { display:flex !important; width:100%; border:0; background:transparent; text-align:left; }\n.ozon-ext-search-select-empty { padding:8px 10px; color:#64748b; font-size:11px; }\n.ozon-ext-load-progress { min-width:220px; flex:1; max-width:520px; }\n.ozon-ext-load-progress-track { height:6px; margin-top:6px; overflow:hidden; border-radius:99px; background:#E8EEF7; }\n.ozon-ext-load-progress-fill { height:100%; width:var(--load-progress,5%); border-radius:99px; background:linear-gradient(90deg,#005BFF,#60A5FA); transition:width .35s ease; }\n.ozon-ext-sprint-progress-cell { padding:5px 12px 7px !important; }\n.ozon-ext-cell-singleline:has(.ozon-ext-search-select) { overflow:visible !important; }\n.ozon-ext-filter-bar > div:first-child { gap:7px !important; }\n.ozon-ext-filter-select { min-width:132px !important; height:30px !important; padding:5px 30px 5px 10px !important; border-radius:9px !important; background-color:#fff !important; box-shadow:0 1px 2px rgba(7,16,38,.04); transition:border-color .15s,box-shadow .15s,background-color .15s; }\n.ozon-ext-filter-select:hover { border-color:#a8bbd2 !important; background-color:#f8fbff !important; }\n.ozon-ext-filter-bar input[type=\"text\"] { height:30px !important; border-radius:9px !important; background:#fff !important; box-shadow:0 1px 2px rgba(7,16,38,.04); }\n.ozon-ext-filter-bar .ozon-ext-btn { min-height:30px !important; border-radius:9px !important; box-shadow:0 1px 2px rgba(7,16,38,.04); }\n.ozon-ext-sprint-load { padding:7px 9px 9px; color:#64748b; font-size:10px; }\n.ozon-ext-sprint-load-track { height:4px; margin-top:5px; overflow:hidden; border-radius:9px; background:#e8eef7; }\n.ozon-ext-sprint-load-fill { height:100%; width:var(--sprint-load,12%); border-radius:9px; background:linear-gradient(90deg,#005bff,#60a5fa); transition:width .25s ease; }\n\n#ozon-structure-root input[type=\"text\"],\n#ozon-structure-root input[type=\"search\"],\n#ozon-structure-root textarea {\n  background-color: #F5F7FA !important;\n  color: #071026 !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 8px !important;\n  padding: 4px 10px !important;\n  font-size: 11.5px !important;\n  font-family: var(--ozon-font-sans) !important;\n  line-height: 1.4 !important;\n  box-shadow: none !important;\n  outline: none !important;\n}\n\n#ozon-structure-root input[type=\"text\"]::placeholder,\n#ozon-structure-root textarea::placeholder {\n  color: #64748B !important;\n}\n\n#ozon-structure-root input[type=\"text\"]:focus,\n#ozon-structure-root input[type=\"search\"]:focus,\n#ozon-structure-root textarea:focus {\n  background-color: #FFFFFF !important;\n  border-color: #005BFF !important;\n  box-shadow: 0 0 0 2px rgba(0, 91, 255, 0.16) !important;\n  outline: none !important;\n  outline-offset: 0 !important;\n}\n\n.ozon-ext-workspace {\n  flex: 1 1 0% !important;\n  min-height: 0 !important;\n  height: 100% !important;\n  max-height: 100% !important;\n  display: flex !important;\n  overflow: hidden !important;\n  background: #FFFFFF !important;\n  position: relative !important;\n}\n\n.ozon-ext-table-pane {\n  flex: 1 1 0% !important;\n  min-height: 0 !important;\n  height: 100% !important;\n  max-height: 100% !important;\n  overflow: auto !important;\n  overflow-anchor: none !important;\n  background: #FFFFFF !important;\n}\n\n#ozon-ext-table-pane {\n  scrollbar-width: auto !important;\n  scrollbar-color: auto !important;\n}\n#ozon-ext-table-pane::-webkit-scrollbar {\n  width: 6px;\n  height: 6px;\n}\n#ozon-ext-table-pane::-webkit-scrollbar-track,\n#ozon-ext-table-pane::-webkit-scrollbar-corner {\n  background: transparent;\n}\n#ozon-ext-table-pane::-webkit-scrollbar-thumb {\n  background: rgba(7, 16, 38, 0.14);\n  border-radius: 3px;\n}\n#ozon-ext-table-pane::-webkit-scrollbar-thumb:hover {\n  background: rgba(0, 91, 255, 0.45);\n}\n\n.ozon-ext-table {\n  table-layout: fixed !important;\n  border-collapse: collapse !important;\n  font-size: 11.5px !important;\n  user-select: none;\n  margin: 0 !important;\n}\n\n.ozon-ext-table th {\n  position: sticky !important;\n  top: 0 !important;\n  z-index: 20 !important;\n  background: #F1F5F9 !important;\n  color: #334155 !important;\n  font-size: 11px !important;\n  font-weight: 700 !important;\n  text-align: left !important;\n  padding: 6px 10px 6px 8px !important;\n  height: 29px !important;\n  border-bottom: 1px solid #CBD5E1 !important;\n  border-right: 1px solid #E2E8F0 !important;\n  white-space: nowrap !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n}\n\n.ozon-ext-col-resizer {\n  position: absolute !important;\n  top: 0 !important;\n  right: 0 !important;\n  bottom: 0 !important;\n  width: 6px !important;\n  cursor: col-resize !important;\n  z-index: 35 !important;\n  background: transparent;\n  transition: background-color 100ms ease;\n}\n\n.ozon-ext-col-resizer:hover,\n.ozon-ext-col-resizer.active {\n  background: #005BFF !important;\n}\n\n.ozon-ext-sprint-row {\n  background: #F8FAFC !important;\n  border-bottom: 1px solid #E2E8F0 !important;\n  height: 30px !important;\n  cursor: pointer !important;\n  transition: background-color 110ms ease;\n}\n\n.ozon-ext-sprint-row:hover {\n  background: #F1F5F9 !important;\n}\n\n.ozon-ext-sprint-row td {\n  padding: 4px 12px 4px 10px !important;\n  height: 30px !important;\n  font-size: 12px !important;\n  vertical-align: middle !important;\n}\n\n.ozon-ext-comp-group-row {\n  background: #FAFBFD !important;\n  border-bottom: 1px solid #E2E8F0 !important;\n  height: 26px !important;\n  cursor: pointer !important;\n  transition: background-color 110ms ease;\n}\n\n.ozon-ext-comp-group-row:hover {\n  background: #F1F5F9 !important;\n}\n\n.ozon-ext-comp-group-row td {\n  padding: 2px 12px 2px 28px !important;\n  border-left: 3px solid #CBD5E1 !important;\n  height: 26px !important;\n  font-size: 11px !important;\n  color: #334155 !important;\n  vertical-align: middle !important;\n}\n\n/* СТРОГО ЕДИНАЯ ВЫСОТА ВСЕХ СТРОК ЗАДАЧ (28px) */\n.ozon-ext-task-row {\n  height: 28px !important;\n  max-height: 28px !important;\n  min-height: 28px !important;\n  border-bottom: 1px solid #E2E8F0 !important;\n  cursor: pointer !important;\n  background: #FFFFFF !important;\n  transition: background-color 100ms ease;\n}\n.ozon-ext-task-row.completed:not(.selected) > td,.ozon-ext-subrow.completed > td { background-color:#EFFBF3!important; }\n.ozon-ext-task-row.completed:not(.selected):hover > td,.ozon-ext-subrow.completed:hover > td { background-color:#E0F5E8!important; }\n.ozon-ext-task-row.completed.selected > td { background-color:#DDF4E5!important; }\n.ozon-ext-status-summary { display:inline-flex;align-items:center;gap:8px;flex-wrap:wrap; }\n.ozon-ext-status-count { color:#64748B;font-size:10px;font-weight:400;white-space:nowrap; }\n.ozon-ext-status-count + .ozon-ext-status-count::before { content:'·';margin-right:8px;color:#CBD5E1; }\n.ozon-ext-view-tabs { display:flex;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid #E2E8F0;background:#fff;flex-shrink:0; }\n.ozon-ext-view-tabs button { border:1px solid transparent;border-radius:8px;padding:6px 12px;background:transparent;color:#64748B;font:600 12px var(--ozon-font-sans);cursor:pointer; }\n.ozon-ext-view-tabs button[aria-selected=\"true\"] { color:#005BFF;background:#E5F0FF; }\n.ozon-product-filter-hint {font-size:11px;color:#64748b;} .ozon-strategy-dashboard { display:flex;flex-direction:column;flex:1;min-height:0;min-width:0;background:#fff;color:#071026;font:400 11.5px var(--ozon-font-sans); }\n.ozon-strategy-actions { display:flex;align-items:center;gap:10px; }\n.ozon-strategy-description { padding:8px 12px;color:#64748b;border-bottom:1px solid #e2e8f0; }\n.ozon-strategy-scroll { flex:1;min-height:0;overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n.ozon-strategy-table { width:100%;min-width:0;table-layout:fixed;border-collapse:collapse;font:inherit; }\n.ozon-strategy-table th,.ozon-strategy-table td { height:28px;padding:0 6px;text-align:left;border-bottom:1px solid #e2e8f0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }\n.ozon-strategy-table th { position:sticky;top:0;z-index:2;background:#eef3f8;color:#475569;font-weight:600; }\n\n.ozon-strategy-table th .ozon-dev-col-resizer {position:absolute;right:0;top:0;bottom:0;width:8px;cursor:col-resize;z-index:3}.ozon-strategy-filters {flex-wrap:wrap}.ozon-strategy-table tbody tr:hover td { background:#f5f9ff; }.ozon-strategy-table .ozon-strategy-group td { background:#f1f5f9;font-weight:700; }\n.ozon-strategy-table a { color:#005bff;text-decoration:none; }.ozon-strategy-type,.ozon-strategy-key { display:flex;align-items:center;gap:5px;min-width:0; }.ozon-strategy-type span { overflow:hidden;text-overflow:ellipsis; }\n.ozon-strategy-table tbody tr.ozon-strategy-depth-1 td {background:#edf4ff;}\n#ozon-ext-tbody tr.ozon-tree-depth-1:not(.completed):not(.selected) > td,.ozon-dev-table tbody tr.ozon-tree-depth-1:not(.ozon-dev-completed):not(.ozon-dev-no-epic) > td {background-color:#edf4ff;}\n#ozon-ext-tbody tr.ozon-tree-depth-1:not(.completed):not(.selected):hover > td,.ozon-dev-table tbody tr.ozon-tree-depth-1:not(.ozon-dev-completed):not(.ozon-dev-no-epic):hover > td {background-color:#e4efff;}\n.ozon-strategy-indent {display:inline-block;box-sizing:border-box;color:#7692b7;text-align:right;padding-right:4px;vertical-align:middle;overflow:hidden;white-space:nowrap;}\n.ozon-strategy-epic-relation {display:inline-flex;align-items:center;border-radius:4px;padding:1px 4px;background:#edf2ff;color:#526ab2;font-size:10px;line-height:16px;}\n.ozon-strategy-copy-key,.ozon-strategy-link-button {display:inline-flex;align-items:center;justify-content:center;width:19px;height:19px;min-width:19px;padding:0;border:0;border-radius:5px;background:transparent;color:#71849d;cursor:pointer;font-size:13px;line-height:1;}\n.ozon-strategy-copy-key:hover,.ozon-strategy-link-button:hover {background:#e4efff;color:#005bff;}\n.ozon-strategy-unlink {float:right;border:0;border-radius:5px;background:#fff0ee;color:#d92d20;cursor:pointer;padding:3px 7px;line-height:1.3;}\n.ozon-strategy-unlink:hover {background:#ffded9;}\n.ozon-strategy-sprint-edit {cursor:pointer;padding:4px 2px;border-radius:5px}.ozon-strategy-sprint-edit:hover {background:#eaf3ff}.ozon-strategy-sprint-edit:focus-visible {outline:2px solid #005bff;outline-offset:-2px}.ozon-strategy-sprint-locked {color:#94a3b8}\n.ozon-strategy-toggle,.ozon-strategy-toggle-spacer { display:inline-flex;align-items:center;justify-content:center;flex:0 0 18px;width:18px;height:20px;border:0;background:transparent;color:#005bff;cursor:pointer; }\n.ozon-strategy-descendant-count {flex:none;display:inline-flex;align-items:center;justify-content:center;min-width:18px;padding:1px 5px;border-radius:9px;background:#e8f0fc;color:#526b8c;font-size:10px;line-height:16px;font-weight:600;}\n.ozon-strategy-warning { color:#b45309;font-size:10px;margin-left:6px; }\n.ozon-strategy-type img {width:14px;height:14px;object-fit:contain;flex:none}.ozon-strategy-type .ozon-ext-type-pill {min-width:0}.ozon-strategy-sprint {display:flex;align-items:center;gap:4px;min-width:0}.ozon-strategy-sprint > span:first-child {overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ozon-strategy-sprint .ozon-ext-badge {margin-left:auto;flex:none}.ozon-strategy-linked-themes {flex:none;padding:12px 0;color:#071026}.ozon-strategy-linked-themes strong {font-size:12px}.ozon-strategy-linked-themes p {margin:8px 0;color:#71839b}.ozon-strategy-linked-list {max-height:180px;overflow:auto;margin-top:8px}.ozon-strategy-linked-item {padding:7px 8px;border-bottom:1px solid #e3eaf2}.ozon-strategy-linked-title {margin-top:4px;line-height:1.4;overflow-wrap:anywhere}.ozon-strategy-component-edit {display:flex;align-items:center;gap:6px;width:100%;min-width:0;border:0;background:transparent;color:#071026;font:inherit;text-align:left;cursor:pointer;padding:4px 2px}.ozon-strategy-component-edit span:first-child {min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}.ozon-strategy-component-edit span:last-child {color:#90a2b8}.ozon-strategy-component-edit:hover {background:#eaf3ff;border-radius:5px}.ozon-strategy-component-edit:focus-visible {outline:2px solid #005bff;outline-offset:-2px;border-radius:5px}.ozon-strategy-epic-value {min-width:0;overflow:hidden;flex:1}.ozon-strategy-editor-options {overflow:auto;min-height:0}.ozon-strategy-editor-options button {display:flex;gap:8px;align-items:center;width:100%;text-align:left}.ozon-strategy-notice {display:flex;align-items:center;justify-content:space-between;gap:12px;margin:4px 12px;padding:7px 10px;border:1px solid #dbe4ef;border-radius:8px;color:#334155;background:#f7faff}.ozon-strategy-message { padding:20px;color:#64748b; }\n\n.ozon-strategy-filters { display:flex;gap:8px;padding:8px 12px; }.ozon-strategy-filters input,.ozon-strategy-filters select,#ozon-strategy-label-input { border:1px solid #d5e1ef;border-radius:8px;background:white;color:#071026;padding:7px 10px;font:inherit;min-width:180px; }\n.ozon-strategy-labels { display:flex;align-items:center;gap:4px;overflow:auto;scrollbar-width:thin; }.ozon-strategy-label { display:inline-flex;align-items:center;gap:3px;padding:2px 5px;border-radius:5px;background:#eff4f9;color:#475569; }.ozon-strategy-label button { border:0;background:transparent;color:#64748b;cursor:pointer; }.ozon-strategy-table tr[data-strategy-expandable=\"true\"] { cursor:pointer; }\n.ozon-strategy-table {border-collapse:separate;border-spacing:0}.ozon-strategy-table .ozon-strategy-task-header {position:sticky;left:0;z-index:5}.ozon-strategy-table .ozon-strategy-task-cell {position:sticky;left:0;z-index:1;background:#fff;overflow:visible;box-shadow:3px 0 6px #0710260d}.ozon-strategy-table tbody tr.ozon-strategy-depth-1 .ozon-strategy-task-cell {background:#edf4ff}.ozon-strategy-table tbody tr:hover .ozon-strategy-task-cell {background:#f5f9ff}.ozon-strategy-task-line {display:flex;align-items:center;gap:6px;min-width:0}.ozon-strategy-task-line .ozon-strategy-type,.ozon-strategy-task-line .ozon-strategy-key {flex:none}.ozon-strategy-task-summary {min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ozon-strategy-context td {color:#8190a3}.ozon-strategy-context-label,.ozon-strategy-legend {font-size:10px;color:#71839b}.ozon-strategy-relation {font-size:10px;padding:2px 4px;border-radius:4px;background:#e7effb;color:#526b8c}.ozon-strategy-copy-menu {position:relative;flex:none}.ozon-strategy-copy-menu summary {display:flex;align-items:center;cursor:pointer;color:#71849d;list-style:none}.ozon-strategy-copy-menu summary::-webkit-details-marker {display:none}.ozon-strategy-copy-options {position:absolute;top:100%;left:0;z-index:10;width:150px;padding:4px;background:#fff;border:1px solid #dbe4ef;border-radius:8px;box-shadow:0 5px 18px #07102626}.ozon-strategy-copy-options button {display:block;width:100%;padding:7px;border:0;border-radius:4px;background:#fff;color:#071026;text-align:left;cursor:pointer}.ozon-strategy-copy-options button:hover {background:#eaf3ff}.ozon-strategy-theme-scope {display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 0;color:#64748b}.ozon-strategy-theme-row {display:flex;align-items:flex-start}.ozon-strategy-theme-toggle,.ozon-strategy-theme-toggle-space {flex:none;width:20px;height:28px;border:0;background:transparent;color:#005bff;cursor:pointer}.ozon-strategy-theme-row .ozon-strategy-theme-option {min-width:0;flex:1}\n.ozon-strategy-table td:has(.ozon-strategy-copy-menu[open]) {overflow:visible;z-index:20}.ozon-strategy-copy-menu .ozon-strategy-copy-options {position:fixed;z-index:100;box-sizing:border-box}\n.ozon-dev-priority-edit { border:1px solid transparent;border-radius:5px;padding:2px;background:transparent;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto; }\n.ozon-dev-priority-edit:hover,.ozon-dev-priority-edit:focus-visible { background:#e5f0ff;border-color:#80adff;outline:none; }\n\n.ozon-dev-dashboard { display:flex;flex-direction:column;flex:1;min-height:0;min-width:0;background:#fff;color:#071026;font:400 11.5px var(--ozon-font-sans); }\n.ozon-dev-dashboard a { color:#005BFF;text-decoration:none; }\n.ozon-dev-controls { display:flex;align-items:center;justify-content:flex-start!important;flex-wrap:wrap;gap:6px!important;padding:6px 12px;border-bottom:1px solid #E2E8F0; }\n.ozon-dev-controls .ozon-ext-toolbar-combo { min-width:142px;max-width:245px; }\n.ozon-dev-controls .ozon-dev-grouping-control { width:142px;max-width:142px; }\n.ozon-dev-header-actions { display:flex;align-items:center;gap:10px;margin-left:auto; }\n.ozon-dev-help { position:relative; }\n.ozon-dev-help>button { width:26px;height:26px;padding:4px!important;display:flex;align-items:center;justify-content:center; }\n.ozon-dev-help>button svg { display:block;width:18px!important;height:18px!important;min-width:18px;flex-shrink:0; }\n.ozon-dev-help [role=\"tooltip\"] { display:none;position:absolute;right:0;top:calc(100% + 6px);width:390px;max-width:calc(100vw - 32px);max-height:calc(100vh - 160px);overflow:auto;padding:12px 14px;border:1px solid #E2E8F0;border-radius:10px;background:#fff;color:#475569;box-shadow:0 4px 18px rgba(25,47,68,.12);font:400 11px/1.5 var(--ozon-font-sans);z-index:120; }\n.ozon-dev-help:hover [role=\"tooltip\"],.ozon-dev-help:focus-within [role=\"tooltip\"] { display:block; }\n.ozon-dev-help [role=\"tooltip\"] p { margin:8px 0 0; }\n.ozon-dev-popover { top:calc(100% + 6px);left:0;right:auto;padding:8px;min-width:100%; }\n.ozon-dev-popover .ozon-ext-combo-item { display:block;width:100%;text-align:left;cursor:pointer; }\n#ozon-structure-root .ozon-dev-popover, #ozon-structure-root .ozon-dev-popover * { scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-dev-popover::-webkit-scrollbar, #ozon-structure-root .ozon-dev-popover *::-webkit-scrollbar { width:6px;height:6px; }\n#ozon-structure-root .ozon-dev-popover::-webkit-scrollbar-thumb, #ozon-structure-root .ozon-dev-popover *::-webkit-scrollbar-thumb { background:#A8B5C5;border-radius:8px; }\n#ozon-structure-root .ozon-ext-epic-picker-popover { position:fixed!important;top:0!important;right:0!important;left:auto!important;bottom:0!important;width:min(560px,100vw)!important;min-width:0!important;max-width:100vw!important;height:100vh!important;max-height:100vh!important;z-index:2147483001!important;border-radius:0!important;padding:20px!important;box-shadow:-8px 0 28px #07102633!important;overflow:hidden!important; }\n#ozon-structure-root .ozon-ext-epic-picker-popover #ozon-table-combo-list { flex:1 1 0!important;min-height:0!important;max-height:none!important;overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-dev-popover button.ozon-ext-combo-item { appearance:none;border:0!important;box-shadow:none!important;background:transparent;color:#071026;border-radius:6px!important;font:400 11.5px var(--ozon-font-sans);padding:6px 8px;min-height:30px; }\n#ozon-structure-root .ozon-dev-popover button.ozon-ext-combo-item:hover,#ozon-structure-root .ozon-dev-popover button.ozon-ext-combo-item.active { background:#E5F0FF;color:#005BFF; }\n#ozon-structure-root .ozon-dev-team-popover { width:180px!important;min-width:180px!important;max-width:180px!important; }\n.ozon-dev-column-menu { width:340px;max-height:65vh;overflow:auto; }\n.ozon-dev-column-label { flex:1; }\n.ozon-dev-column-child { padding-left:20px;border-left:2px solid #E2E8F0;margin-left:8px; }\n.ozon-dev-col-resizer { position:absolute;right:-3px;top:0;bottom:0;width:7px;cursor:col-resize;touch-action:none;z-index:4; }\n.ozon-dev-col-resizer:hover,.ozon-dev-col-resizer:focus-visible { background:#005BFF;outline:0; }\n.ozon-dev-table thead tr:nth-child(2) th { top:30px; }\n.ozon-dev-table th { padding-right:12px; }\n.ozon-dev-sp-parent { text-align:center!important;border-bottom:1px solid #CBD5E1!important; }\n.ozon-dev-point-pair { white-space:nowrap; }\n.ozon-dev-points-divider { color:#94A3B8;font-weight:400; }\n.ozon-dev-point-percent { color:#64748B;font-size:10px;font-weight:400;margin-left:3px; }\n.ozon-dev-burned { color:#039855; }\n.ozon-dev-sprints { width:440px;max-width:calc(100vw - 32px); }\n.ozon-dev-sprints input[type=\"search\"] { width:100%;margin-bottom:8px; }\n.ozon-dev-sprint-list { max-height:300px;overflow:auto; }\n.ozon-dev-sprint-option { display:flex;gap:8px;align-items:center;padding:6px;border-radius:6px;cursor:pointer; }\n.ozon-dev-sprint-option:hover { background:#F1F6FF; }\n.ozon-dev-sprint-option > span:not(.ozon-ext-badge) { flex:1;white-space:normal; }\n.ozon-dev-sprint-option input { accent-color:#005BFF;flex-shrink:0; }\n.ozon-sprint-current {display:flex;flex-direction:column;gap:5px;padding:12px;margin:0 0 12px;border-radius:8px;background:#f3f7fc;color:#667b93}.ozon-sprint-current strong {color:#071026;font-weight:600}.ozon-component-editor {font:400 12px/1.4 var(--ozon-font-sans,Arial,sans-serif)!important;color:#071026!important;gap:0!important;padding:20px!important}\n.ozon-component-editor .component-editor-head {display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}\n.ozon-component-editor .component-editor-head strong {font-size:13px;font-weight:700}\n.ozon-component-editor .component-editor-context {margin:-10px 0 14px;color:#64748b;font-size:12px;line-height:1.4;overflow-wrap:anywhere}\n.ozon-component-editor .component-editor-close {display:grid;place-items:center;width:30px;height:30px;padding:0;border:0;border-radius:8px;background:#f0f3f8;color:#41566f;cursor:pointer;font-size:15px}\n.ozon-component-editor .component-editor-close:hover {background:#e5f0ff;color:#005bff}\n.ozon-component-editor .component-editor-search {position:relative;display:flex;align-items:center;margin-bottom:14px}\n.ozon-component-editor .component-editor-search svg {position:absolute;left:11px;width:16px;height:16px;color:#93a4b8;pointer-events:none}\n.ozon-component-editor .component-editor-search input {box-sizing:border-box;width:100%;height:36px;padding:0 10px 0 34px;border:1px solid #d6e0ec;border-radius:8px;background:#fff;color:#071026;font:inherit;outline:none}\n.ozon-component-editor .component-editor-search input:focus {border-color:#005bff;box-shadow:0 0 0 1px #005bff}\n.ozon-component-editor .component-editor-caption {display:flex;justify-content:space-between;align-items:center;margin:0 0 8px;color:#64748b;font-size:11px}\n.ozon-component-editor .component-editor-list {overflow:auto;flex:1;min-height:0;scrollbar-width:thin;scrollbar-color:#a8b5c5 transparent}\n.ozon-component-editor .component-editor-list::-webkit-scrollbar {width:6px}.ozon-component-editor .component-editor-list::-webkit-scrollbar-thumb {background:#a8b5c5;border-radius:8px}\n.ozon-component-editor .component-editor-option {display:flex;align-items:center;gap:10px;min-height:38px;box-sizing:border-box;padding:8px 10px;margin:2px 4px 2px 0;border-radius:7px;cursor:pointer;color:#071026;transition:background .15s}\n.ozon-component-editor .component-editor-option:hover {background:#f1f6ff}.ozon-component-editor .component-editor-option.is-selected {background:#eaf3ff;color:#005bff;font-weight:600}\n.ozon-component-editor button.component-editor-option {width:calc(100% - 4px);border:0;background:transparent;text-align:left;font:inherit}.ozon-component-editor button.component-editor-option:hover {background:#f1f6ff}.ozon-component-editor button.component-editor-option.is-selected {background:#eaf3ff;color:#005bff;font-weight:600}.ozon-component-editor button.component-editor-option:focus-visible {outline:2px solid #005bff;outline-offset:-2px}.ozon-component-editor button.component-editor-option > span:first-child {flex:1;min-width:0}.ozon-component-editor .component-editor-list {overflow-x:hidden}.ozon-component-editor .component-editor-option input {appearance:none;-webkit-appearance:none;display:grid;place-content:center;width:16px;height:16px;min-width:16px;margin:0;padding:0;border:1px solid #a8b5c5;border-radius:4px;background:#fff;cursor:pointer}\n.ozon-priority-editor button.component-editor-option {justify-content:flex-start}.ozon-priority-editor button.component-editor-option > span.ozon-dev-priority:first-child {flex:0 0 auto}\n.ozon-component-editor .component-editor-option input:checked {border-color:#005bff;background:#005bff}.ozon-component-editor .component-editor-option input:checked::after {content:\"\";width:7px;height:4px;border-left:2px solid #fff;border-bottom:2px solid #fff;transform:rotate(-45deg) translate(1px,-1px)}\n.ozon-component-editor .component-editor-option input:focus-visible {outline:2px solid #005bff;outline-offset:2px}\n.ozon-component-editor .component-editor-footer {display:flex;justify-content:flex-end;gap:8px;padding-top:14px;margin-top:12px;border-top:1px solid #e4ebf3}\n.ozon-component-editor .component-editor-button {min-height:32px;padding:0 13px;border:1px solid #d6e0ec;border-radius:8px;background:#fff;color:#005bff;font:600 12px var(--ozon-font-sans,Arial,sans-serif);cursor:pointer}\n.ozon-component-editor .component-editor-button:hover {background:#f1f6ff}.ozon-component-editor .component-editor-button.primary {border-color:#005bff;background:#005bff;color:#fff}.ozon-component-editor .component-editor-button.primary:hover {background:#004dd6}.ozon-component-editor .component-editor-button:disabled {opacity:.55;cursor:wait}\n.ozon-dev-popover-footer { display:flex;justify-content:space-between;gap:8px;border-top:1px solid #EEF2F6;padding-top:8px; }\n.ozon-dev-content,.ozon-dev-table-scroll { flex:1;min-height:0;overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n.ozon-dev-content { display:flex;min-width:0;overflow:hidden; }\n.ozon-dev-table-scroll { min-width:0;width:100%; }\n.ozon-dev-table { max-width:none!important; }\n.ozon-dev-table tfoot td { position:sticky;bottom:0;z-index:3;background:#eef3fa;border-top:1px solid #cad7e7;font-weight:600; }\n.ozon-dev-table .ozon-dev-filler td { padding:0!important;border:0!important;background:#fff!important; }\n.ozon-dev-settings .ozon-dev-column-child { margin-left:20px;padding-left:12px;border-left:2px solid #d6e3f3; }\n.ozon-dev-content>.ozon-dev-empty { flex:1;min-width:0; }\n.ozon-dev-empty { padding:28px 20px;color:#64748B; }\n.ozon-dev-empty strong { color:#334155; }\n.ozon-dev-error { margin:10px 16px;padding:10px 12px;background:#FFF0EE;color:#B42318;border-radius:8px; }\n.ozon-dev-filter-list { max-height:280px;overflow:auto; }\n.ozon-dev-filter-list .ozon-ext-combo-item { white-space:normal;text-align:left;height:auto;overflow-wrap:anywhere; }\n#ozon-structure-root .ozon-dev-sprints, #ozon-structure-root .ozon-dev-epic-filter-sidebar { min-width:0!important;transform:none!important;position:fixed!important;top:0!important;right:0!important;left:auto!important;bottom:0!important;width:min(560px,100vw)!important;max-width:100vw!important;height:100vh!important;max-height:100vh!important;z-index:2147483001!important;border-radius:0!important;padding:20px!important;display:flex!important;flex-direction:column!important;gap:8px;box-sizing:border-box;box-shadow:-8px 0 28px #07102633!important; }\n#ozon-structure-root .ozon-dev-epic-filter-sidebar .ozon-dev-filter-list { flex:1;min-height:0;max-height:none;overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-dev-sprints .ozon-dev-sprint-list { flex:1;min-height:0;max-height:none;overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-dev-epic-filter-sidebar .ozon-dev-filter-list .ozon-ext-combo-item:has(.ozon-dev-option-title) { display:grid!important;grid-template-columns:max-content max-content minmax(0,1fr);gap:4px 8px!important;align-items:center;padding:9px 10px!important; }\n#ozon-structure-root .ozon-dev-epic-filter-sidebar .ozon-dev-option-title { grid-column:1 / -1;white-space:normal;overflow-wrap:anywhere;line-height:1.4; }\n#ozon-structure-root .ozon-dev-epic-filter-sidebar .ozon-dev-option-components { justify-self:start;padding:2px 6px;border-radius:5px;background:#F1F5F9;color:#52647A;font-size:10.5px; }\n#ozon-structure-root .ozon-dev-epic-filter-sidebar .ozon-ext-badge { justify-self:start;width:max-content; }\n#ozon-structure-root .ozon-dev-filter-list .ozon-ext-combo-item { white-space:normal!important;overflow-wrap:anywhere;height:auto!important; }\n#ozon-structure-root .ozon-dev-controls .ozon-dev-popover { max-width:calc(100vw - 24px)!important; }\n#ozon-structure-root aside.ozon-dev-editor { position:fixed!important;top:50%!important;left:50%!important;right:auto!important;bottom:auto!important;transform:translate(-50%,-50%)!important;width:min(980px,calc(100vw - 32px))!important;min-width:0!important;max-width:calc(100vw - 32px)!important;max-height:84vh!important;overflow:hidden!important;display:flex!important;flex-direction:column!important;z-index:10100!important;box-sizing:border-box!important; }\n#ozon-structure-root aside.ozon-dev-editor { top:0!important;right:0!important;bottom:0!important;left:auto!important;transform:none!important;width:min(560px,100vw)!important;max-height:100vh!important;height:100vh!important;border-radius:0!important;padding:20px!important;box-shadow:-8px 0 28px #07102633!important; }\n#ozon-structure-root aside.ozon-dev-editor { z-index:2147483001!important; }\n#ozon-structure-root .ozon-dev-editor-options { flex:1;max-height:none;min-height:0; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) .ozon-dev-editor-head { order:0; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) .ozon-dev-link-sprint-picker { order:1; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) #ozon-dev-editor-search { order:2; margin-top:8px; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) #ozon-dev-editor-message { order:3; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) .ozon-dev-menu-hint { order:4; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) #ozon-dev-editor-results { order:5; }\n#ozon-structure-root .ozon-dev-editor:has(.ozon-dev-link-sprint-picker) #ozon-dev-editor-busy { order:6; }\n#ozon-structure-root .ozon-dev-link-sprint-picker .ozon-dev-editor-options { max-height:220px; flex:none; }\n\n#ozon-structure-root .ozon-dev-editor-options .ozon-ext-combo-item { display:flex;align-items:center;gap:7px;padding:7px 8px!important; }\n#ozon-structure-root .ozon-dev-editor-options .ozon-mono,#ozon-structure-root .ozon-dev-editor-options .ozon-ext-badge { flex:0 0 auto;white-space:nowrap!important; }\n#ozon-structure-root .ozon-dev-option-title { flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap!important; }\n#ozon-structure-root .ozon-dev-editor-options .ozon-ext-combo-item { flex-wrap:nowrap; }\n#ozon-structure-root .ozon-dev-epic-options .ozon-ext-combo-item:has(.ozon-dev-option-title) { display:grid!important;grid-template-columns:max-content max-content minmax(0,1fr);gap:4px 8px!important;align-items:center!important;padding:9px 10px!important; }\n#ozon-structure-root .ozon-dev-epic-options .ozon-ext-combo-item > .ozon-ext-badge { justify-self:start;align-self:center;width:max-content; }\n#ozon-structure-root .ozon-dev-epic-options .ozon-dev-option-title { grid-column:1 / -1;white-space:normal!important;overflow:visible!important;overflow-wrap:anywhere;line-height:1.4; }\n#ozon-structure-root .ozon-dev-epic-options .ozon-dev-option-components { grid-column:3;grid-row:1;justify-self:start;align-self:center;max-width:100%;padding:2px 6px;border-radius:5px;background:#F1F5F9;color:#52647A;font-size:10.5px;white-space:normal;overflow-wrap:anywhere; }\n#ozon-structure-root .ozon-dev-team-option { display:grid!important;grid-template-columns:16px minmax(0,1fr)!important;align-items:center;gap:9px;min-height:34px;padding:6px 10px;border-bottom:1px solid #EEF2F6;color:#071026;cursor:pointer;box-sizing:border-box;width:100%; }\n#ozon-structure-root .ozon-dev-team-option:hover { background:#F1F6FF; }\n#ozon-structure-root .ozon-dev-team-option>input[type=\"checkbox\"] { display:block!important;width:16px!important;min-width:16px!important;max-width:16px!important;height:16px!important;margin:0!important;padding:0!important;justify-self:start;flex:none!important; }\n#ozon-structure-root .ozon-dev-team-name { display:block;min-width:0;width:100%;color:#071026!important;font-size:12px!important;line-height:18px!important;white-space:nowrap!important; }\n#ozon-structure-root #ozon-dev-editor-search,#ozon-structure-root #ozon-dev-link-sprint-search { direction:ltr;text-align:left; }\n\n.ozon-dev-editor-head { display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px; }\n.ozon-dev-editor-options { max-height:min(480px,60vh);overflow:auto;overscroll-behavior:contain;margin-top:6px; }\n#ozon-structure-root .ozon-dev-editor-options button { width:100%;border:0;background:transparent;text-align:left;white-space:normal!important;height:auto!important;font:400 11.5px var(--ozon-font-sans); }\n#ozon-structure-root .ozon-strategy-editor-options button.ozon-ext-combo-item {appearance:none!important;border:0!important;box-shadow:none!important;background:transparent!important;color:#071026!important;cursor:pointer!important;}\n#ozon-structure-root .ozon-strategy-editor-options button.ozon-ext-combo-item:hover,#ozon-structure-root .ozon-strategy-editor-options button.ozon-ext-combo-item:focus-visible {background:#E5F0FF!important;color:#005BFF!important;}\n#ozon-structure-root .ozon-strategy-editor-options button.ozon-ext-combo-item.active {background:#E5F0FF!important;color:#005BFF!important;box-shadow:inset 3px 0 #005bff!important;font-weight:600;}\n#ozon-structure-root .ozon-strategy-editor-options .ozon-strategy-theme-option {border-left:2px solid #dbe7f6!important;border-radius:0!important;}\n.ozon-dev-cell-edit { display:flex!important;align-items:center;gap:5px;width:100%;max-width:100%;min-width:0;cursor:pointer;border-radius:6px; }\n.ozon-dev-cell-edit:hover { background:#E5F0FF; }\n.ozon-dev-cell-edit>.ozon-ext-toolbar-chevron { flex-shrink:0;margin-left:auto; }\n.ozon-dev-cell-edit>.ozon-dev-epic-inline { flex:1;min-width:0; }\n.ozon-dev-stream-edit { display:inline-flex!important;align-items:center;gap:8px;border:1px solid #DCE3EB!important;border-radius:6px;padding:1px 6px!important;color:#005BFF!important;background:#fff!important;font-size:10px!important;flex-shrink:0; }\n.ozon-dev-stream-edit.is-empty { color:#D92D20!important;border-color:#F5B8B3!important;background:#FFF3F2!important; }\n.ozon-dev-stream-edit.is-empty .ozon-ext-toolbar-chevron { border-color:#D92D20!important; }\n.ozon-dev-header-settings { display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;margin-left:4px;padding:0;border:0;border-radius:6px;background:transparent;color:#708198;cursor:pointer;vertical-align:middle; }\n.ozon-dev-header-settings:hover,.ozon-dev-header-settings:focus-visible { color:#005BFF;background:#E5F0FF; }\n.ozon-dev-group-option { display:flex;align-items:center;gap:6px;padding:6px 0; }\n.ozon-dev-group-option label { display:flex;align-items:center;gap:8px;flex:1; }\n.ozon-dev-menu-hint { color:#64748B;font-size:11px;margin:4px 0 8px; }\n.ozon-dev-epic-inline,.ozon-dev-task-key,.ozon-dev-task-title,.ozon-dev-indicators { display:flex;align-items:center;gap:5px;min-width:0; }\n.ozon-dev-epic-inline { width:100%; }\n.ozon-dev-epic-inline a,.ozon-dev-epic-inline .ozon-ext-badge,.ozon-dev-task-key a { flex-shrink:0;white-space:nowrap!important; }\n.ozon-dev-ellipsis { min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }\n.ozon-dev-task-title>.ozon-dev-ellipsis { flex:1; }\n.ozon-dev-indicators,.ozon-dev-priority { flex-shrink:0; }\n.ozon-dev-indicator { display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:6px;flex-shrink:0; }\n.ozon-dev-indicator.absent { color:#94A3B8;background:#F1F5F9; }\n.ozon-dev-indicator.done { color:#039855;background:#DCFCE7; }\n.ozon-dev-indicator.active { color:#005BFF;background:#E5F0FF; }\n.ozon-dev-indicator.missing { color:#D92D20;background:#FFF0EE; }\n#ozon-structure-root .ozon-ext-ip-table-row > .ozon-ext-ip-table-secondary[hidden] { display:none!important; }\n.ozon-dev-table { width:100%;min-width:1985px;border-collapse:collapse;table-layout:fixed;font:400 11.5px var(--ozon-font-sans); }\n.ozon-dev-table th { position:sticky;top:0;z-index:2;background:#F1F5F9;text-align:left;font-size:11px;color:#475569;height:30px; }\n.ozon-dev-table th,.ozon-dev-table td { border-bottom:1px solid #E2E8F0;border-right:1px solid #EEF2F6;padding:0 6px;vertical-align:middle;white-space:nowrap;height:28px;overflow:hidden;text-overflow:ellipsis; }\n.ozon-dev-table td>div { max-width:100%;overflow:hidden; }\n.ozon-dev-table .ozon-ext-badge { white-space:nowrap; }\n.ozon-dev-table .ozon-dev-sprint td { background:#F8FAFC;font-weight:600;height:30px;padding:4px 10px; }\n.ozon-dev-table .ozon-dev-group-line { display:flex;align-items:center;gap:6px;min-height:22px; }\n.ozon-dev-table .ozon-dev-group .ozon-ext-badge { flex-shrink:0; }\n.ozon-dev-table .ozon-dev-group .ozon-ext-status-summary { flex-wrap:nowrap; }\n.ozon-dev-table .ozon-dev-epic td { background:#FAFBFD;font-size:11px;height:26px; }\n.ozon-dev-table .ozon-dev-completed td { background:#EFFBF3; }\n.ozon-dev-table .ozon-dev-no-epic td { background:#FFF1F0; }\n.ozon-dev-table .ozon-dev-project td { background:#FAFBFD;font-weight:600;height:26px; }\n.ozon-dev-table .ozon-dev-related td { background:#F8FAFC;font-size:11px;height:28px; }\n.ozon-dev-table [data-dev-row] { cursor:pointer;transition:background-color 110ms ease; }\n.ozon-dev-table .ozon-dev-group:hover>td { background:#F1F5F9; }\n.ozon-dev-table .ozon-dev-task:hover>td { background:#F2F4F8; }\n.ozon-dev-table .ozon-dev-completed:hover>td { background:#E0F5E8; }\n.ozon-dev-table .ozon-dev-no-epic:hover>td { background:#FFE4E2; }\n.ozon-dev-table .ozon-dev-group .ozon-ext-status-summary { margin-left:10px;font-weight:400; }\n.ozon-dev-table .ozon-dev-link-toggle { width:16px;flex-shrink:0;color:#005BFF; }\n.ozon-dev-table button { border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;padding:0 5px 0 0;text-align:left; }\n#ozon-structure-root .ozon-dev-table .ozon-dev-link-toggle[aria-expanded=\"true\"] { box-shadow:none!important;border-color:transparent!important; }\n.ozon-dev-sprint .ozon-ext-group-total { margin-left:10px; }\n.ozon-dev-points { font-variant-numeric:tabular-nums; }\n.ozon-ext-group-total { color:#64748B;font-size:10px;font-weight:400;white-space:nowrap; }\n.ozon-ext-table-epic-line { display:flex;align-items:center;gap:5px;min-width:0;font-size:10px; }\n.ozon-ext-table-epic-line a { color:#005BFF;text-decoration:none;flex-shrink:0; }\n.ozon-ext-table-epic-line .ozon-ext-badge { flex:0 0 auto!important;max-width:none!important;overflow:visible!important;text-overflow:clip!important;white-space:nowrap;font-size:9px;padding:0 4px; }\n.ozon-ext-table-epic-line .epic-title { flex:1 1 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0; }\n#ozon-structure-root .ozon-ext-cell-combo-trigger[data-action=\"open-table-epic-combo\"] { border:0!important;box-shadow:none!important;background:transparent!important;border-radius:6px!important;padding:0 4px!important; }\n#ozon-structure-root .ozon-ext-cell-combo-trigger[data-action=\"open-table-epic-combo\"]:hover { background:#E5F0FF!important; }\n.ozon-ext-epic-project-tag { flex-shrink:0;color:#64748B;border:1px solid #E2E8F0;border-radius:4px;padding:0 3px;font-size:9px;line-height:16px; }\n.ozon-ext-sprint-row > td > div > div:first-child,.ozon-ext-comp-group-row > td > div > div:first-child { flex-wrap:wrap;min-width:0; }\n\n.ozon-ext-task-row:hover:not(:has(.ozon-ext-inner-ctrl:hover)) {\n  background: #F2F4F8 !important;\n}\n\n.ozon-ext-task-row.selected {\n  background: #EBF3FF !important;\n}\n\n.ozon-ext-task-row td {\n  padding: 0 6px !important;\n  height: 28px !important;\n  max-height: 28px !important;\n  line-height: 28px !important;\n  border-right: 1px solid #EEF2F6 !important;\n  white-space: nowrap !important;\n  overflow: visible !important;\n  font-size: 11.5px !important;\n  vertical-align: middle !important;\n  color: #071026 !important;\n  position: relative;\n}\n\n.ozon-ext-cell-singleline {\n  display: flex !important;\n  align-items: center !important;\n  gap: 5px !important;\n  height: 26px !important;\n  max-height: 26px !important;\n  width: 100% !important;\n  overflow: hidden !important;\n  white-space: nowrap !important;\n  text-overflow: ellipsis !important;\n}\n\n.ozon-ext-subrow {\n  background: #FAFBFD !important;\n  border-bottom: 1px solid #E2E8F0 !important;\n  height: 28px !important;\n  max-height: 28px !important;\n}\n\n.ozon-ext-subrow:hover {\n  background: #F1F5F9 !important;\n}\n\n.ozon-ext-subrow td {\n  padding: 0 6px !important;\n  height: 28px !important;\n  max-height: 28px !important;\n  line-height: 28px !important;\n  border-right: 1px solid #EEF2F6 !important;\n  white-space: nowrap !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  font-size: 11px !important;\n  vertical-align: middle !important;\n  color: #334155 !important;\n}\n\n/* Нейтральный тег типа связи («Задача проекта» / «В проекте»), чтобы не путать со статусами */\n.ozon-ext-link-type-tag {\n  display: inline-flex !important;\n  align-items: center !important;\n  gap: 4px !important;\n  padding: 0 6px !important;\n  height: 18px !important;\n  line-height: 16px !important;\n  border-radius: 4px !important;\n  background: #F8FAFC !important;\n  color: #64748B !important;\n  border: 1px solid #CBD5E1 !important;\n  font-size: 9.5px !important;\n  font-weight: 600 !important;\n  white-space: nowrap !important;\n  flex-shrink: 0 !important;\n}\n\n.ozon-ext-inline-select {\n  appearance: none !important;\n  -webkit-appearance: none !important;\n  -moz-appearance: none !important;\n  background-image: none !important;\n  width: 100% !important;\n  max-width: 100% !important;\n  height: 22px !important;\n  line-height: 20px !important;\n  font-size: 11px !important;\n  font-weight: 500 !important;\n  color: #071026 !important;\n  background-color: transparent !important;\n  border: 1px solid transparent !important;\n  border-radius: 5px !important;\n  padding: 0 4px !important;\n  cursor: pointer !important;\n  outline: none !important;\n  box-shadow: none !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\n\n.ozon-ext-inline-select.comp-bold {\n  font-weight: 600 !important;\n  color: #071026 !important;\n}\n\n.ozon-ext-inline-select.sprint-muted {\n  color: #475569 !important;\n  font-variant-numeric: tabular-nums !important;\n}\n\n.ozon-ext-inline-select:hover {\n  background-color: rgba(0, 91, 255, 0.08) !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%23005BFF' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n  background-repeat: no-repeat !important;\n  background-position: right 4px center !important;\n  padding-right: 16px !important;\n  border-color: rgba(0, 91, 255, 0.25) !important;\n  color: #005BFF !important;\n}\n\n/* Ячейка с кликабельным Input-Select Popover в таблице */\n.ozon-ext-cell-combo-trigger {\n  position: relative !important;\n  display: flex !important;\n  align-items: center !important;\n  justify-content: space-between !important;\n  gap: 5px !important;\n  width: 100% !important;\n  height: 22px !important;\n  line-height: 20px !important;\n  padding: 0 5px !important;\n  border-radius: 5px !important;\n  border: 1px solid transparent !important;\n  overflow: visible !important;\n  white-space: nowrap !important;\n  cursor: pointer !important;\n}\n\n.ozon-ext-cell-combo-trigger:hover {\n  background-color: rgba(0, 91, 255, 0.08) !important;\n  border-color: rgba(0, 91, 255, 0.25) !important;\n}\n\n/* Кнопка открытия сайдбара деталей задачи в строке списка */\n.ozon-ext-open-sb-btn {\n  display: inline-flex !important;\n  align-items: center !important;\n  justify-content: center !important;\n  gap: 3px !important;\n  height: 19px !important;\n  line-height: 17px !important;\n  padding: 0 6px !important;\n  margin-left: auto !important;\n  border-radius: 5px !important;\n  border: 1px solid #CBD5E1 !important;\n  background: #F8FAFC !important;\n  color: #005BFF !important;\n  font-size: 10px !important;\n  font-weight: 700 !important;\n  cursor: pointer !important;\n  flex-shrink: 0 !important;\n  transition: all 100ms ease !important;\n}\n\n.ozon-ext-open-sb-btn:hover {\n  background: #E5F0FF !important;\n  border-color: #005BFF !important;\n}\n\n.ozon-ext-open-sb-btn.active {\n  background: #005BFF !important;\n  border-color: #005BFF !important;\n  color: #FFFFFF !important;\n}\n\n/* Всплывающий Input-Select Popover для ячеек таблицы и полей сайдбара */\n.ozon-ext-combo-popover {\n  position: absolute !important;\n  top: calc(100% + 4px) !important;\n  left: 0 !important;\n  z-index: 99999 !important;\n  width: 340px !important;\n  background: #FFFFFF !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 10px !important;\n  box-shadow: 0 12px 32px rgba(7, 16, 38, 0.18) !important;\n  padding: 8px !important;\n  display: flex !important;\n  flex-direction: column !important;\n  gap: 6px !important;\n  line-height: 1.4 !important;\n  white-space: normal !important;\n}\n\n.ozon-ext-combo-popover input:is([type=\"text\"],[type=\"search\"]) {\n  width: 100% !important;\n  height: 30px !important;\n  padding: 5px 10px !important;\n  font-size: 12px !important;\n  line-height: 1.4 !important;\n  margin: 0 !important;\n  background: #F8FAFC !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 7px !important;\n  outline: none !important;\n  box-shadow: none !important;\n}\n\n.ozon-ext-combo-popover input:is([type=\"text\"],[type=\"search\"]):focus {\n  background: #FFFFFF !important;\n  border-color: #005BFF !important;\n  box-shadow: 0 0 0 2px rgba(0, 91, 255, 0.15) !important;\n  outline: none !important;\n}\n\n.ozon-ext-combo-list {\n  max-height: 235px !important;\n  overflow-y: auto !important;\n  display: flex !important;\n  flex-direction: column !important;\n  gap: 2px !important;\n  padding: 2px 2px 2px 0 !important;\n}\n\n.ozon-ext-combo-item {\n  padding: 6px 10px !important;\n  min-height: 28px !important;\n  line-height: 18px !important;\n  border-radius: 6px !important;\n  font-size: 11.5px !important;\n  color: #071026 !important;\n  cursor: pointer !important;\n  display: flex !important;\n  align-items: center !important;\n  gap: 8px !important;\n  flex-shrink: 0 !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\n\n.ozon-ext-combo-item:hover,\n.ozon-ext-combo-item.active {\n  background: #E5F0FF !important;\n  color: #005BFF !important;\n}\n\n/* Input-Select в сайдбаре */\n.ozon-ext-sb-combo {\n  position: relative !important;\n  width: 100% !important;\n}\n\n.ozon-ext-sb-combo-trigger {\n  display: flex !important;\n  align-items: center !important;\n  justify-content: space-between !important;\n  gap: 6px !important;\n  width: 100% !important;\n  min-height: 28px !important;\n  padding: 4px 10px !important;\n  background: #F8FAFC !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 8px !important;\n  font-size: 12px !important;\n  line-height: 1.35 !important;\n  cursor: pointer !important;\n}\n\n.ozon-ext-sb-combo-trigger:hover {\n  border-color: #005BFF !important;\n  background: #FFFFFF !important;\n}\n\n.ozon-ext-sb-combo-dropdown {\n  max-height: 185px !important;\n  overflow-y: auto !important;\n  background: #FFFFFF !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 8px !important;\n  margin-top: 4px !important;\n  box-shadow: 0 6px 18px rgba(7, 16, 38, 0.1) !important;\n}\n\n.ozon-ext-inline-input {\n  width: 100% !important;\n  height: 22px !important;\n  line-height: 20px !important;\n  font-size: 11px !important;\n  font-weight: 600 !important;\n  color: #004ED6 !important;\n  background: transparent !important;\n  border: 1px solid transparent !important;\n  border-radius: 5px !important;\n  padding: 0 4px !important;\n  outline: none !important;\n  box-shadow: none !important;\n  text-overflow: ellipsis !important;\n}\n\n.ozon-ext-inline-input.is-empty {\n  color: #94A3B8 !important;\n  font-weight: 400 !important;\n}\n\n.ozon-ext-inline-input:hover {\n  background: rgba(0, 91, 255, 0.08) !important;\n  border-color: rgba(0, 91, 255, 0.25) !important;\n  color: #071026 !important;\n}\n\n.ozon-ext-inline-input:focus {\n  background: #FFFFFF !important;\n  border-color: #005BFF !important;\n  color: #071026 !important;\n  font-weight: 500 !important;\n}\n\n.ozon-ext-status-select {\n  appearance: none !important;\n  -webkit-appearance: none !important;\n  -moz-appearance: none !important;\n  width: 100% !important;\n  max-width: 100% !important;\n  height: 20px !important;\n  line-height: 18px !important;\n  font-size: 10.5px !important;\n  font-weight: 600 !important;\n  border-radius: 5px !important;\n  padding: 0 14px 0 6px !important;\n  cursor: pointer !important;\n  outline: none !important;\n  border: 1px solid transparent !important;\n  background-repeat: no-repeat !important;\n  background-position: right 4px center !important;\n  text-overflow: ellipsis !important;\n}\n\n.ozon-ext-status-select option {\n  background-color: #FFFFFF !important;\n  color: #071026 !important;\n  font-weight: 500 !important;\n}\n\n.ozon-ext-status-select.status-progress {\n  background-color: #E5F0FF !important;\n  color: #005BFF !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='9' viewBox='0 0 24 24' fill='none' stroke='%23005BFF' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n}\n\n.ozon-ext-status-select.status-done {\n  background-color: #DCFCE7 !important;\n  color: #15803D !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='9' viewBox='0 0 24 24' fill='none' stroke='%2315803D' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n}\n\n.ozon-ext-status-select.status-review {\n  background-color: #FEF3C7 !important;\n  color: #B45309 !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='9' viewBox='0 0 24 24' fill='none' stroke='%23B45309' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n}\n\n.ozon-ext-status-select.status-todo {\n  background-color: #F1F5F9 !important;\n  color: #475569 !important;\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='9' viewBox='0 0 24 24' fill='none' stroke='%23475569' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\") !important;\n}\n\n.ozon-ext-status-select:hover {\n  border-color: rgba(0, 91, 255, 0.4) !important;\n}\n\n.ozon-ext-more-links-pill {\n  display: inline-flex !important;\n  align-items: center !important;\n  padding: 0 5px !important;\n  height: 17px !important;\n  line-height: 17px !important;\n  border-radius: 4px !important;\n  background: #E5F0FF !important;\n  color: #005BFF !important;\n  font-family: var(--ozon-font-mono) !important;\n  font-size: 10px !important;\n  font-weight: 700 !important;\n  border: none !important;\n  cursor: pointer !important;\n  flex-shrink: 0 !important;\n}\n\n.ozon-ext-more-links-pill:hover {\n  background: #D0E3FF !important;\n}\n\n.ozon-ext-btn {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n  padding: 4px 10px;\n  height: 26px;\n  background-color: #E5F0FF;\n  color: #005BFF;\n  font-size: 11px;\n  font-weight: 600;\n  border-radius: 8px;\n  border: none;\n  cursor: pointer;\n  transition: background-color 120ms ease;\n  text-decoration: none;\n  white-space: nowrap;\n}\n\n.ozon-ext-btn:hover {\n  background-color: #D0E3FF;\n}\n\n.ozon-ext-btn-surface {\n  background-color: #F2F4F8;\n  color: #071026;\n}\n\n.ozon-ext-btn-surface:hover {\n  background-color: #E2E8F0;\n}\n\n.ozon-ext-btn-negative {\n  background-color: #FBECE9;\n  color: #D9381E;\n}\n\n.ozon-ext-btn-negative:hover {\n  background-color: #F7D8D2;\n}\n\n.ozon-ext-status-chip {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  min-height: 26px;\n  padding: 3px 11px;\n  border: 1px solid #DCE4F0;\n  border-radius: 999px;\n  background: #FFFFFF;\n  color: #005BFF;\n  font-size: 10.5px;\n  font-weight: 600;\n  line-height: 1.2;\n  cursor: pointer;\n  transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease;\n}\n.ozon-ext-status-chip:hover {\n  border-color: #93C5FD;\n  background: #F4F8FF;\n}\n\n.ozon-ext-badge {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  padding: 1px 6px;\n  border-radius: 5px;\n  font-size: 10.5px;\n  font-weight: 600;\n  line-height: 1.35;\n  white-space: nowrap;\n}\n\n.ozon-ext-badge-progress {\n  background: #E5F0FF;\n  color: #005BFF;\n}\n\n.ozon-ext-badge-done {\n  background: #DCFCE7;\n  color: #15803D;\n}\n\n.ozon-ext-badge-todo {\n  background: #F1F5F9;\n  color: #475569;\n}\n\n.ozon-ext-badge-review {\n  background: #FEF3C7;\n  color: #B45309;\n}\n\n.ozon-ext-badge-critical {\n  background: #FEE2E2;\n  color: #DC2626;\n}\n\n.ozon-ext-resizer-bar {\n  width: 6px;\n  background: #E2E8F0;\n  cursor: col-resize;\n  flex-shrink: 0;\n  position: relative;\n  z-index: 25;\n  transition: background-color 120ms ease;\n}\n\n.ozon-ext-resizer-bar:hover,\n.ozon-ext-resizer-bar.active {\n  background: #005BFF;\n}\n\n.ozon-ext-sidebar {\n  background: #FFFFFF !important;\n  border-left: 1px solid #E2E8F0 !important;\n  display: flex !important;\n  flex-direction: column !important;\n  height: 100% !important;\n  min-height: 0 !important;\n  max-height: 100% !important;\n  overflow-y: auto !important;\n  overflow-anchor: none !important;\n  flex-shrink: 0 !important;\n  box-shadow: -4px 0 16px rgba(7, 16, 38, 0.05) !important;\n}\n#ozon-structure-root #ozon-ext-sidebar-panel { position:fixed!important;right:0!important;top:0!important;bottom:0!important;height:100vh!important;max-height:100vh!important;z-index:100000!important; }\n#ozon-structure-root #ozon-ext-sidebar-resizer { position:fixed!important;top:0;bottom:0;height:100vh;z-index:100001; }\n\n.ozon-ext-sidebar-header {\n  position: sticky;\n  top: 0;\n  z-index: 10;\n  background: #F8FAFC;\n  border-bottom: 1px solid #E2E8F0;\n  padding: 10px 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n}\n\n.ozon-ext-sidebar-body {\n  padding: 12px 14px 28px 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n\n.ozon-ext-field-grid {\n  display: grid;\n  grid-template-columns: 118px 1fr;\n  gap: 8px 10px;\n  align-items: start;\n  font-size: 12px;\n}\n\n.ozon-ext-field-label {\n  color: #64748B;\n  font-size: 11.5px;\n  font-weight: 600;\n  padding-top: 5px;\n}\n\n.ozon-ext-sidebar select {\n  width: 100%;\n  background-color: #F8FAFC !important;\n  color: #071026 !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 8px !important;\n  padding: 4px 8px !important;\n  font-size: 12px !important;\n  font-weight: 500 !important;\n  outline: none !important;\n  cursor: pointer !important;\n}\n\n.ozon-ext-sidebar select:focus {\n  border-color: #005BFF !important;\n  background-color: #FFFFFF !important;\n}\n\n.ozon-ext-section-card {\n  border: 1px solid #E2E8F0;\n  border-radius: 10px;\n  background: #FFFFFF;\n  overflow: visible;\n}\n\n.ozon-ext-section-head {\n  box-sizing: border-box;\n  min-height: 40px;\n  padding: 8px 12px;\n  background: #F8FAFC;\n  border-bottom: 1px solid #E2E8F0;\n  border-radius: 10px 10px 0 0;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #071026;\n  cursor: pointer;\n  user-select: none;\n  transition: background-color 110ms ease;\n}\n\n.ozon-ext-section-head:hover {\n  background: #F1F5F9;\n}\n\n.ozon-ext-section-head.collapsed {\n  border-bottom: none;\n  border-radius: 10px;\n}\n#ozon-structure-root .ozon-sb-description-preview.is-compact {max-height:132px;overflow:hidden;position:relative}\n#ozon-structure-root .ozon-sb-description-preview.is-compact::after {content:'';position:absolute;left:0;right:0;bottom:0;height:24px;background:linear-gradient(transparent,#fff);pointer-events:none}\n#ozon-structure-root .ozon-sb-description-more {margin:0 12px 10px}\n#ozon-structure-root .ozon-sb-link-add {height:24px;padding:2px 8px;font-size:10px;white-space:nowrap}\n\n/* Форматированное описание задачи (Jira Wiki / Markdown) */\n.ozon-ext-desc-rendered {\n  font-size: 12px !important;\n  line-height: 1.52 !important;\n  color: #071026 !important;\n  word-break: break-word !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-heading {\n  font-size: 12.5px !important;\n  font-weight: 700 !important;\n  color: #071026 !important;\n  margin: 10px 0 4px 0 !important;\n  padding-bottom: 2px !important;\n  border-bottom: 1px solid #EEF2F6 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-heading:first-child {\n  margin-top: 0 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-p {\n  margin: 0 0 6px 0 !important;\n  color: #1E293B !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-li {\n  display: flex !important;\n  align-items: flex-start !important;\n  gap: 6px !important;\n  margin: 2px 0 3px 4px !important;\n  color: #1E293B !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-bullet {\n  color: #005BFF !important;\n  font-weight: 700 !important;\n  flex-shrink: 0 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-num {\n  color: #005BFF !important;\n  font-family: var(--ozon-font-mono) !important;\n  font-size: 11px !important;\n  font-weight: 700 !important;\n  min-width: 16px !important;\n  flex-shrink: 0 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-hr {\n  border: none !important;\n  border-top: 1px solid #E2E8F0 !important;\n  margin: 8px 0 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-code {\n  background: #F8FAFC !important;\n  border: 1px solid #E2E8F0 !important;\n  border-radius: 6px !important;\n  padding: 6px 8px !important;\n  margin: 6px 0 !important;\n  font-family: var(--ozon-font-mono) !important;\n  font-size: 11px !important;\n  overflow-x: auto !important;\n  white-space: pre-wrap !important;\n  color: #0F172A !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-inline-code {\n  background: #F1F5F9 !important;\n  border: 1px solid #E2E8F0 !important;\n  border-radius: 4px !important;\n  padding: 1px 4px !important;\n  font-family: var(--ozon-font-mono) !important;\n  font-size: 11px !important;\n  color: #0F172A !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-quote {\n  border-left: 3px solid #005BFF !important;\n  background: #F8FAFC !important;\n  padding: 5px 10px !important;\n  margin: 6px 0 !important;\n  color: #334155 !important;\n  border-radius: 0 6px 6px 0 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-issue-pill {\n  display: inline-flex !important;\n  align-items: center !important;\n  gap: 3px !important;\n  padding: 0 5px !important;\n  border-radius: 4px !important;\n  background: #E5F0FF !important;\n  color: #005BFF !important;\n  font-family: var(--ozon-font-mono) !important;\n  font-size: 11px !important;\n  font-weight: 700 !important;\n  text-decoration: none !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-issue-pill:hover {\n  background: #D0E3FF !important;\n  text-decoration: underline !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-link {\n  color: #005BFF !important;\n  text-decoration: none !important;\n  font-weight: 500 !important;\n}\n\n.ozon-ext-desc-rendered .ozon-desc-link:hover {\n  text-decoration: underline !important;\n}\n\n/* Компактная строка связанной задачи с иконкой и чёткой лесенкой вложенности (Уровень 1 → 2 → 3 → 4) */\n.ozon-ext-link-group-header {\n  padding: 5px 12px 5px 26px !important;\n  background: #F8FAFC;\n  border-bottom: 1px solid #E2E8F0;\n  border-left: 3px solid #CBD5E1;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 10.5px;\n  font-weight: 700;\n  color: #334155;\n  cursor: pointer;\n}\n\n.ozon-ext-link-group-header:hover {\n  background: #F1F5F9;\n}\n\n.ozon-ext-link-compact-row {\n  padding: 6px 12px 6px 42px !important;\n  border-bottom: 1px solid #EEF2F6;\n  border-left: 3px solid #E2E8F0;\n  background: #FFFFFF;\n  display: flex;\n  flex-direction: column;\n  gap: 5px;\n}\n\n.ozon-ext-link-compact-row.ozon-ext-pt-level2 {\n  padding: 6px 12px 6px 26px !important;\n  border-left: 3px solid #CBD5E1;\n}\n\n.ozon-ext-sidebar { scrollbar-width:thin!important; scrollbar-color:#a8b5c5 transparent!important; container-type:inline-size; }\n.ozon-ext-ip-row .ozon-ext-ip-fields { display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:6px!important;padding-left:22px!important;align-items:center;margin-top:6px; }\n.ozon-ext-ip-row .ozon-ext-sb-combo-trigger > span:first-child { white-space:normal!important;overflow-wrap:anywhere; }\n.ozon-ip-column-resizer { position:absolute;right:0;top:0;bottom:0;width:7px;cursor:col-resize;touch-action:none; }\n.ozon-ext-ip-table-head>span { position:relative; }\n#ozon-structure-root .ozon-dev-table button.ozon-ext-btn { border:1px solid #D5E0EF;background:#fff;color:#005BFF;border-radius:8px;padding:4px 10px;font:500 11px var(--ozon-font-body,sans-serif);min-height:26px;text-align:center; }\n#ozon-structure-root .ozon-ext-search-select-caret,#ozon-structure-root .ozon-ext-toolbar-chevron { width:18px;min-width:18px;height:18px; }\n#ozon-structure-root .ozon-ext-sb-combo svg { width:16px;min-width:16px;height:16px; }\n.ozon-ext-product-settings { position:fixed!important;top:0!important;right:0!important;bottom:0!important;left:auto!important;width:390px!important;max-width:100vw!important;height:100vh!important;z-index:2147483645!important;box-sizing:border-box!important;display:flex!important;flex-direction:column;gap:16px;padding:20px;background:#fff;box-shadow:-8px 0 32px #07102620;overflow:auto; }\n.ozon-ext-product-settings .ozon-ext-toolbar-combo { width:100%; }\n.ozon-ext-product-settings .ozon-ext-toolbar-trigger { width:100%; }\n.ozon-dev-settings { position:fixed;right:0;top:0;bottom:0;width:390px;max-width:100vw;background:#fff;box-shadow:-8px 0 32px #07102620;z-index:2147483645;display:flex;flex-direction:column;padding:20px;gap:16px;overflow:auto;animation:ozon-settings-enter .18s ease-out; }\n.ozon-dev-settings footer { margin-top:auto;display:flex;gap:8px;position:sticky;bottom:-20px;background:#fff;padding:12px 0; }\n.ozon-dev-settings .ozon-dev-group-option { display:flex;align-items:center;gap:8px;min-height:34px; }\n.ozon-dev-settings .ozon-dev-group-option label,.ozon-dev-settings .ozon-dev-column-label { flex:1; }\n.ozon-dev-settings select { width:100%;height:32px;border:1px solid #D5E0EF;border-radius:8px;padding:0 10px;color:#071026;background:#fff;font:inherit; }\n#ozon-structure-root .ozon-dev-settings .ozon-ext-combo-popover { padding:6px!important;background:#fff!important;border:1px solid #dbe4ef!important;border-radius:10px!important;box-shadow:0 8px 24px #0710261c!important; }\n#ozon-structure-root .ozon-dev-settings .ozon-ext-combo-popover button.ozon-ext-combo-item { appearance:none!important;display:block!important;width:100%!important;min-height:32px!important;height:auto!important;padding:7px 10px!important;border:0!important;border-radius:6px!important;background:transparent!important;box-shadow:none!important;color:#071026!important;text-align:left!important;font:400 12px var(--ozon-font-sans)!important;cursor:pointer; }\n#ozon-structure-root .ozon-dev-settings .ozon-ext-combo-popover button.ozon-ext-combo-item:hover,#ozon-structure-root .ozon-dev-settings .ozon-ext-combo-popover button.ozon-ext-combo-item:focus-visible,#ozon-structure-root .ozon-dev-settings .ozon-ext-combo-popover button.ozon-ext-combo-item.active { background:#E5F0FF!important;color:#005BFF!important; }\n@keyframes ozon-settings-enter { from { transform:translateX(100%); } to { transform:translateX(0); } }\n\n#ozon-structure-root .ozon-ext-ip-table-row { min-height:36px!important; }\n#ozon-structure-root .ozon-ext-ip-table-row>div { height:36px;justify-content:flex-start; }\n#ozon-structure-root .ozon-ext-ip-table-row .ozon-ext-search-select-trigger { height:28px!important;min-height:28px!important;max-height:28px!important;padding:2px 8px!important;line-height:20px!important;box-sizing:border-box; }\n#ozon-structure-root .ozon-ext-ip-task-cell { justify-content:flex-start!important;gap:5px!important;flex-wrap:nowrap!important; }\n#ozon-structure-root .ozon-ext-ip-task-cell>.ozon-ext-type-pill,#ozon-structure-root .ozon-ext-ip-task-cell>span[title^=\"Приоритет\"] { flex:0 0 auto!important; }\n#ozon-structure-root .ozon-ext-ip-task-cell>.ozon-ip-summary { flex:1 1 auto;min-width:0; }\n.ozon-ext-ip-epic-cell { overflow:hidden;white-space:nowrap;text-overflow:ellipsis; }\n#ozon-structure-root #ozon-sb-comp-trigger svg,#ozon-structure-root #ozon-sb-epic-trigger svg { width:18px!important;height:18px!important;min-width:18px!important;flex:0 0 18px!important; }\n[data-ticket-search-run] { margin-left:8px!important; }\n.ozon-dev-settings.ozon-dev-settings-stable { animation:none!important; }\n\n\n#ozon-structure-root .ozon-dev-team-popover { min-width:240px!important;width:260px!important;max-width:calc(100vw - 24px)!important; }\n#ozon-structure-root .ozon-dev-sprint-option { display:flex!important;justify-content:flex-start!important;gap:9px!important;width:100%;box-sizing:border-box; }\n#ozon-structure-root .ozon-dev-sprint-option input { width:16px!important;min-width:16px!important;height:16px!important;margin:0!important;flex:0 0 16px!important; }\n#ozon-structure-root .ozon-dev-sprint-option>span:not(.ozon-ext-badge) { display:block;min-width:0;flex:1;white-space:normal; }\n#ozon-structure-root .ozon-dev-editor,#ozon-structure-root .ozon-dev-editor-options { scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n#ozon-structure-root .ozon-dev-editor::-webkit-scrollbar,#ozon-structure-root .ozon-dev-editor-options::-webkit-scrollbar { width:6px;height:6px; }\n#ozon-structure-root .ozon-dev-editor::-webkit-scrollbar-thumb,#ozon-structure-root .ozon-dev-editor-options::-webkit-scrollbar-thumb { background:#A8B5C5;border-radius:8px;border:0; }\n#ozon-structure-root .ozon-ext-ip-table-viewport { overflow-x:clip!important;overflow-y:visible;max-width:100%;min-width:0; }\n#ozon-structure-root .ozon-ext-ip-table-body { min-width:0!important;width:100%;max-width:100%; }\n#ozon-structure-root .ozon-ext-ip-table-head>span { overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0; }\n#ozon-structure-root .ozon-ext-ip-table-row>div { padding-left:4px;padding-right:4px;overflow:hidden; }\n#ozon-structure-root .ozon-ext-ip-table-row>.ozon-ext-sb-combo { overflow:visible; }\n#ozon-structure-root .ozon-ext-ip-table-row .ozon-ext-search-select-trigger { width:100%;min-width:0!important;gap:3px;padding-left:5px!important;padding-right:5px!important; }\n#ozon-structure-root .ozon-ext-ip-table-row .ozon-ext-search-select-trigger > .ozon-ext-badge { margin-left:auto;flex-shrink:0; }\n#ozon-structure-root .ozon-ext-ip-task-cell { flex-wrap:nowrap!important;height:36px!important;min-height:36px;padding-top:0;padding-bottom:0; }\n#ozon-structure-root .ozon-ext-ip-task-cell>.ozon-ip-summary { flex:1 1 auto;min-width:0;white-space:nowrap!important;display:block;overflow:hidden;text-overflow:ellipsis;line-height:20px; }\n#ozon-structure-root #ozon-ext-sidebar-panel .ozon-ext-ip-table-row { min-height:36px!important; }\n#ozon-structure-root .ozon-ext-ip-action-cell { flex-wrap:wrap;gap:2px!important; }\n#ozon-structure-root .ozon-link-actions { position:relative;display:inline-flex;flex-shrink:0; }\n#ozon-structure-root .ozon-link-actions summary { list-style:none;cursor:pointer;color:#005BFF;padding:2px 6px;border-radius:6px;background:#E5F0FF; }\n#ozon-structure-root .ozon-link-actions summary::-webkit-details-marker { display:none; }\n#ozon-structure-root .ozon-link-actions-menu { position:fixed;z-index:2147483647;right:20px;min-width:170px;padding:6px;background:white;border:1px solid #D5E0EF;border-radius:8px;box-shadow:0 8px 24px #07102633; }\n#ozon-structure-root .ozon-link-actions-menu button { display:block;width:100%;border:0!important;background:#fff!important;color:#071026!important;text-align:left;padding:7px;border-radius:5px;cursor:pointer;font:inherit; }\n#ozon-structure-root .ozon-link-actions-menu button:hover { background:#E5F0FF!important;color:#005BFF!important; }\n#ozon-structure-root .ozon-link-actions-menu button[data-action=\"delete-link\"] { color:#D92D20!important; }\n#ozon-structure-root .ozon-link-actions-menu button[data-action=\"delete-link\"]:hover { background:#FFF1EF!important; }\n#ozon-structure-root .ozon-ext-ip-table-row .ozon-ext-ip-action-cell .ozon-ext-btn { min-width:18px!important;width:18px!important;padding:0!important; }\n#ozon-structure-root .ozon-ext-ip-table-body input { min-width:0!important; }\n#ozon-structure-root .ozon-ext-attributes-columns { display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;gap:12px 18px!important; }\n#ozon-structure-root .ozon-ext-attribute-field { display:grid;grid-template-columns:112px minmax(0,1fr);align-items:center;gap:8px;min-width:0; }\n#ozon-structure-root .ozon-ext-attribute-field>.ozon-ext-field-label { margin:0;min-width:0; }\n#ozon-structure-root .ozon-ext-attribute-field>div { min-width:0; }\n#ozon-structure-root .ozon-ext-attribute-labels { grid-column:1/-1; }\n#ozon-structure-root .ozon-sb-labels { display:flex;align-items:center;gap:5px;flex-wrap:wrap;min-height:30px;min-width:0; }\n#ozon-structure-root .ozon-sb-label-chip { display:inline-flex;align-items:center;gap:4px;max-width:100%;overflow-wrap:anywhere; }\n#ozon-structure-root .ozon-sb-label-remove { border:0;background:transparent;color:#64748b;cursor:pointer;font-size:15px;line-height:1;padding:0 2px; }\n#ozon-structure-root .ozon-sb-label-form { display:inline-flex;align-items:center;gap:5px;max-width:100%; }\n#ozon-structure-root .ozon-sb-label-form input { width:165px;min-width:80px; }\n#ozon-structure-root .ozon-sb-label-error { flex-basis:100%;color:#d92d20;font-size:11px; }\n\n.ozon-ext-ip-table-viewport { overflow:auto;scrollbar-width:thin;scrollbar-color:#A8B5C5 transparent; }\n.ozon-ext-ip-table-body { min-width:var(--ozon-ip-width,1220px); }\n.ozon-ext-ip-table-head,.ozon-ext-ip-table-row { display:grid!important;grid-template-columns:var(--ozon-ip-columns,360px 240px 125px 200px 245px 70px);align-items:center;gap:0!important; }\n.ozon-ext-ip-table-head { background:#F1F5F9;color:#475569;font-size:10px;font-weight:600;min-height:28px;position:sticky;top:0;z-index:1; }\n.ozon-ext-ip-table-head>span { padding:4px 6px;border-right:1px solid #E2E8F0; }\n#ozon-structure-root .ozon-ext-ip-table-row { padding:0!important;border:0!important;border-bottom:1px solid #E2E8F0!important;border-radius:0!important;background:#fff;min-height:28px; }\n.ozon-ext-ip-table-row:hover { background:#F2F4F8; }\n.ozon-ext-ip-table-row.completed { background:#EFFBF3!important; }\n.ozon-ext-ip-table-row>div { min-width:0;padding:0 6px;height:28px;display:flex;align-items:center;border-right:1px solid #EEF2F6; }\n.ozon-ext-ip-table-row .ozon-ext-search-select-trigger { height:24px!important;min-height:24px!important;font-size:11px!important;border-radius:6px!important; }\n.ozon-ext-ip-task-cell>.ozon-ip-summary { min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap!important; }\n.ozon-ext-ip-table-row>.ozon-ext-ip-table-secondary { grid-column:1/-1;height:auto;min-height:20px;border-top:1px solid #EEF2F6;padding-left:28px!important; }\n#ozon-structure-root button.ozon-ext-copy-ref { display:inline-flex;align-items:center;justify-content:center;flex:0 0 18px;width:18px;height:20px;border:0;background:transparent;color:#64748B;padding:2px;cursor:pointer;vertical-align:middle;border-radius:4px; }\n#ozon-structure-root button.ozon-ext-copy-ref:hover { color:#005BFF;background:#E5F0FF; }\n.ozon-ext-select-content { display:flex;align-items:center;gap:7px;min-width:0;flex:1; }\n.ozon-ext-select-content > .ozon-ext-select-text { min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1; }\n.ozon-ext-search-select-value:has(.ozon-ext-select-content) { flex:1; }\n.ozon-ext-link-compact-row:hover {\n  background: #FAFBFD;\n}\n\n.ozon-ext-link-icon-box {\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: #E5F0FF;\n  color: #005BFF;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n\n.ozon-ext-user-dropdown {\n  max-height: 175px !important;\n  overflow-y: auto !important;\n  background: #FFFFFF !important;\n  border: 1px solid #CBD5E1 !important;\n  border-radius: 8px !important;\n  margin-top: 4px !important;\n  box-shadow: 0 4px 12px rgba(7, 16, 38, 0.08) !important;\n}\n\n.ozon-ext-user-option {\n  padding: 6px 10px !important;\n  min-height: 28px !important;\n  line-height: 18px !important;\n  border-bottom: 1px solid #F1F5F9 !important;\n  display: flex !important;\n  align-items: center !important;\n  justify-content: space-between !important;\n  gap: 8px !important;\n  font-size: 11.5px !important;\n  cursor: pointer !important;\n  transition: background-color 100ms ease !important;\n}\n\n.ozon-ext-user-option:last-child {\n  border-bottom: none !important;\n}\n\n.ozon-ext-user-option:hover {\n  background: #E5F0FF !important;\n}\n\n.ozon-ext-type-pill { display:inline-flex;align-items:center;gap:5px;flex:none;white-space:nowrap;border:1px solid #dbe4ef;border-radius:5px;padding:1px 6px;background:white;color:#334155;font-size:10px;font-weight:600; }\n.ozon-ext-type-pill i { width:6px;height:6px;border-radius:50%; }\n.ozon-ext-status-trigger { display:flex;align-items:center;justify-content:space-between;gap:4px;position:relative;cursor:pointer;color:#475569; }\n.ozon-ext-status-trigger.status-progress { color:#005bff; }\n.ozon-ext-status-trigger.status-review { color:#b45309; }\n.ozon-ext-status-trigger.status-testing { color:#7c3aed; }\n.ozon-ext-status-trigger.status-done { color:#15803d; }\n.ozon-ext-header-bar > div:first-child { flex:1;flex-wrap:wrap; }\n.ozon-ext-header-bar strong { margin-right:auto; }\n.ozon-ext-header-bar #ozon-ext-show-all-sprints { margin-left:auto; }\n#ozon-structure-root .ozon-ext-sidebar { max-width:calc(100vw - 12px)!important; }\n.ozon-ext-sidebar-header { flex-wrap:wrap; }\n.ozon-ext-title-line { flex:0 0 100%;display:flex;align-items:center;gap:6px; }\n.ozon-ext-title-line #ozon-sb-summary:not(:focus) { background:transparent!important;border-color:transparent!important; }\n.ozon-ext-title-line #ozon-sb-summary { min-width:0;font-size:15px!important; }\n.ozon-ext-workflow { display:flex;align-items:center;gap:5px;flex-wrap:wrap; }\n.ozon-ext-workflow-label {font-size:11px;color:#64748b;font-weight:600;margin-right:2px}\n.ozon-ext-workflow-current {display:flex;align-items:center;gap:6px;margin-right:10px}\n.ozon-sidebar-draft-overlay {position:fixed;inset:0;z-index:2147483646;display:grid;place-items:center;background:#07102680;font:12px/1.5 Arial,sans-serif}\n.ozon-sidebar-draft-dialog {width:min(470px,calc(100vw - 32px));box-sizing:border-box;padding:20px;background:#fff;border-radius:12px;box-shadow:0 10px 40px #07102640;color:#071026}\n.ozon-sidebar-draft-dialog strong {font-size:15px}.ozon-sidebar-draft-dialog p {color:#526b8c}.ozon-sidebar-draft-dialog div {display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap}\n.ozon-sidebar-draft-dialog button {padding:8px 12px;border:1px solid #dbe4ef;border-radius:8px;color:#005bff;background:#fff;cursor:pointer}.ozon-sidebar-draft-dialog button.primary {background:#005bff;color:#fff;border-color:#005bff}\n.ozon-sidebar-more {position:relative}.ozon-sidebar-more summary {list-style:none;cursor:pointer;padding:4px 9px;border-radius:6px;background:#f0f3f8;color:#005bff;font-weight:700}.ozon-sidebar-more summary::-webkit-details-marker {display:none}.ozon-sidebar-more-menu {position:absolute;right:0;top:100%;z-index:20;min-width:180px;display:flex;flex-direction:column;gap:4px;padding:8px;background:#fff;border:1px solid #dbe4ef;border-radius:8px;box-shadow:0 8px 24px #07102626}.ozon-sidebar-more-menu button,.ozon-sidebar-more-menu a {width:auto!important;text-align:left!important}\n#ozon-ext-sidebar-panel {container-type:inline-size}\n@container (max-width: 720px) {\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-head {display:none!important}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row {display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;grid-auto-rows:auto;gap:2px!important;padding:6px!important;height:auto!important}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row>div {height:auto!important;min-height:26px;border:0;min-width:0}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row>.ozon-ext-ip-task-cell {grid-column:1;grid-row:1}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row>.ozon-ext-ip-action-cell {grid-column:2;grid-row:1}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row>.ozon-ext-sb-combo {grid-column:1/-1}\n  #ozon-ext-sidebar-panel .ozon-ext-ip-table-row>.ozon-ext-ip-table-secondary {grid-column:1/-1}\n}\n.ozon-ext-workflow > div { margin:0!important; }\n#ozon-sb-params-card { border-radius:12px; }\n#ozon-sb-description-card { margin:0 12px 12px;border:0;border-top:1px solid #e2e8f0; }\n#ozon-sb-description-card .ozon-ext-section-head { background:white;font-size:11px; }\n#ozon-sb-desc-preview { background:#f8fafc;border:1px solid #dbe4ef;border-radius:9px; }\n.ozon-ext-field-grid { grid-template-columns:minmax(100px,32%) minmax(0,1fr);align-items:center; }\n.ozon-ext-field-grid > .ozon-ext-field-label { padding-top:0;align-self:center; }\n.ozon-ext-obproject-value { padding:5px 10px;border:1px solid #E2E8F0;border-radius:9px;background:#fff; }\n.ozon-ext-obproject-value > a,.ozon-ext-obproject-value > .ozon-ext-badge { flex-shrink:0; }\n.ozon-ext-obproject-value > span:not(.ozon-ext-badge) { flex:1; }\n.ozon-ext-delivery-indicators { display:inline-flex;align-items:center;gap:3px;flex-shrink:0; }\n.ozon-ext-delivery-indicator { display:inline-flex;align-items:center;justify-content:center;width:21px;height:22px;border-radius:6px;flex-shrink:0; }\n.ozon-ext-delivery-indicator.absent { color:#94A3B8;background:#F1F5F9; }\n.ozon-ext-delivery-indicator.done { color:#008A52;background:#DCFCE7; }\n.ozon-ext-delivery-indicator.active { color:#005BFF;background:#E5F0FF; }\n#ozon-structure-root .ozon-ext-btn.ozon-ext-project-generation { width:24px;height:24px;padding:4px;flex-shrink:0; }\n#ozon-structure-root .ozon-ext-btn.ozon-ext-project-generation.linked { color:#008A52!important;background:#DCFCE7!important;border-color:#B5E8CA!important; }\n#ozon-structure-root .ozon-ext-btn.ozon-ext-project-generation.missing { color:#D92D20!important;background:#FFF0EE!important;border-color:#FFCCC7!important; }\n.ozon-ext-field-grid details summary { cursor:pointer;color:#005bff;font-size:10px; }\n.ozon-ext-sidebar-header .ozon-ext-btn-surface,.ozon-ext-filter-bar .ozon-ext-btn-surface { background:white!important;color:#005bff!important;border:1px solid #dbe4ef!important; }\n.ozon-ext-open-sb-btn:not(.active) { background:white!important;color:#475569!important;border-radius:6px!important; }\n.ozon-ext-create-overlay { position:fixed;inset:0;z-index:2147482000;background:rgba(15,23,42,.38);display:flex;align-items:center;justify-content:center;padding:18px; }\n.ozon-ext-create-dialog { width:min(520px,94vw);max-height:min(82vh,760px);overflow:auto;background:#fff;border:1px solid #dbe4ef;border-radius:12px;box-shadow:0 20px 55px rgba(7,16,38,.24);padding:18px;display:flex;flex-direction:column;gap:12px;color:#071026;font:13px Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; }\n.ozon-ext-create-dialog strong { font-size:15px; }\n.ozon-ext-create-dialog label { display:flex;flex-direction:column;gap:5px;color:#334155;font-size:11px;font-weight:650; }\n.ozon-ext-create-dialog input,.ozon-ext-create-dialog textarea { width:100%;box-sizing:border-box;min-height:34px;padding:7px 9px;border:1px solid #cbd5e1;border-radius:7px;background:#f8fafc;color:#071026;font:inherit;font-size:13px; }\n.ozon-ext-create-dialog textarea { resize:vertical;min-height:88px; }\n.ozon-ext-create-components { max-height:190px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;padding:5px;display:flex;flex-wrap:wrap;gap:5px; }\n.ozon-ext-create-caption { flex:0 0 100%;padding:4px 3px 1px;color:#64748b;font-size:10px;font-weight:700; }\n.ozon-ext-create-component { border:1px solid #dbe4ef;border-radius:999px;background:#fff;color:#334155;padding:5px 9px;font:inherit;font-size:11px;font-weight:600;cursor:pointer; }\n.ozon-ext-create-component.active { color:#005bff;border-color:#8cb8ff;background:#eaf2ff; }\n.ozon-ext-create-note { color:#64748b;font-size:11px; }\n.ozon-ext-create-error { border-radius:7px;background:#fff1f0;color:#b42318;padding:8px 10px;font-size:11px; }\n.ozon-ext-create-actions { display:flex;justify-content:flex-end;gap:7px;margin-top:2px; }\n.ozon-ext-create-menu { position:absolute!important;top:calc(100% + 5px)!important;right:0!important;z-index:10040!important;width:204px!important;max-width:min(204px,calc(100vw - 24px))!important;padding:6px!important;display:flex!important;flex-direction:column!important;gap:5px!important;background:#fff!important;border:1px solid #dbe4ef!important;border-radius:10px!important;box-shadow:0 8px 24px rgba(7,16,38,.16)!important; }\n.ozon-ext-create-menu button { display:flex!important;align-items:center!important;width:100%!important;min-height:32px!important;padding:6px 9px!important;border:1px solid #dbe4ef!important;border-radius:7px!important;background:#fff!important;color:#005bff!important;text-align:left!important;font:600 11px Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif!important;white-space:normal!important;cursor:pointer!important; }\n.ozon-ext-create-menu button:hover { background:#eaf2ff!important;border-color:#a8c7ff!important; }\n\n\n#ozon-structure-root #ozon-ext-sidebar-panel .ozon-ext-link-compact-row :is(.ozon-ext-search-select-trigger,.ozon-ext-sb-combo-trigger) {\n  height:30px!important;min-height:30px!important;padding:5px 10px!important;\n  border:1px solid #dce3eb!important;border-radius:9px!important;background:#fff!important;\n  box-shadow:none!important;font:500 11.5px var(--ozon-font-sans)!important;\n}\n#ozon-structure-root #ozon-ext-sidebar-panel .ozon-ext-link-compact-row [aria-expanded=\"true\"] {border-color:#005bff!important;box-shadow:inset 0 0 0 1px #005bff!important;}\n#ozon-structure-root #ozon-ext-sidebar-panel .ozon-ext-link-compact-row .ozon-ext-search-select-trigger > span:first-child {overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;}\n#ozon-structure-root #ozon-ext-sidebar-panel :is(input[type=\"text\"],input[type=\"search\"]) {\n  min-height:30px!important;border-radius:9px!important;border-color:#dce3eb!important;background-color:white!important;\n}\n/* OBI size 400 badges and dense board controls. */\n#ozon-structure-root :is(.ozon-ext-badge,.ozon-ext-type-pill) {\n  box-sizing:border-box; min-height:20px; min-width:20px; justify-content:center;\n  padding:2px 6px!important; border:0; border-radius:8px;\n  font:600 12px/16px Onest,var(--ozon-font-sans)!important;\n}\n#ozon-structure-root .ozon-ext-type-pill {background:#f2f4f7;}\n#ozon-structure-root .ozon-ext-badge-progress {background:rgba(0,150,255,.08);color:#005bff;}\n#ozon-structure-root :is(.ozon-ext-btn,.ozon-ext-open-sb-btn) {\n  border-radius:10px!important; font-weight:600; box-shadow:none!important;\n}\n#ozon-structure-root .ozon-ext-btn:not(.ozon-ext-btn-negative):not(.ozon-ext-btn-surface) {background-color:#e5f2ff;color:#005bff;}\n#ozon-structure-root :is(.ozon-ext-btn,.ozon-ext-open-sb-btn):hover:enabled {filter:brightness(.96);}\n#ozon-structure-root :is(.ozon-ext-btn,.ozon-ext-open-sb-btn):active:enabled {filter:brightness(.91);}\n#ozon-structure-root .ozon-ext-filter-bar button[aria-pressed] {border-radius:999px!important;padding-inline:12px;}\n#ozon-structure-root .ozon-ext-filter-bar button[aria-pressed=\"true\"] {color:#005bff;background:#e5f2ff;box-shadow:inset 0 0 0 1px #a4ccff!important;}\n#ozon-structure-root :is(.ozon-ext-field-grid,.ozon-ext-create-dialog) :is(input[type=\"text\"],textarea) {\n  box-sizing:border-box;border:1px solid #dce3eb!important;border-radius:10px!important;background-color:#fff!important;\n  padding:6px 10px; min-width:0; caret-color:#005bff;\n}\n#ozon-structure-root :is(.ozon-ext-field-grid,.ozon-ext-create-dialog) :is(input,textarea):focus {\n  border-color:#005bff!important;box-shadow:inset 0 0 0 1px #005bff!important;\n}\n#ozon-structure-root :is(button,input,textarea):focus-visible {outline:2px solid #ff007a!important;outline-offset:2px;}\n#ozon-structure-root .ozon-ext-btn:disabled {opacity:.45;cursor:default;}\n/* Compact density for the Jira board, with the states from the field spec. */\n#ozon-structure-root :is(.ozon-ext-toolbar-trigger,.ozon-ext-search-select-trigger,.ozon-ext-sb-combo-trigger,.ozon-ext-cell-combo-trigger,input[type=\"search\"]) {\n  box-sizing:border-box; background-color:white!important; border:1px solid #dce3eb!important;\n  border-radius:9px!important; box-shadow:none!important;\n}\n#ozon-structure-root :is(.ozon-ext-toolbar-trigger,.ozon-ext-search-select-trigger,.ozon-ext-sb-combo-trigger,.ozon-ext-cell-combo-trigger,input[type=\"search\"]):hover {border-color:#b8c4d0!important;}\n#ozon-structure-root :is([aria-expanded=\"true\"],input[type=\"search\"]:focus,.ozon-ext-sb-combo-trigger:has(~ .ozon-ext-combo-popover),.ozon-ext-cell-combo-trigger:has(~ .ozon-ext-combo-popover)) {border-color:#005bff!important;box-shadow:inset 0 0 0 1px #005bff!important;}\n#ozon-structure-root :is(.ozon-ext-toolbar-trigger,.ozon-ext-search-select-trigger,.ozon-ext-sb-combo-trigger,.ozon-ext-cell-combo-trigger):focus-visible {outline:2px solid #ff007a!important;outline-offset:2px;}\n/* Table cells are editable, but their controls share the borderless table appearance. */\n#ozon-structure-root .ozon-ext-table :is(.ozon-ext-search-select-trigger,.ozon-ext-cell-combo-trigger,.ozon-ext-sb-combo-trigger) { border-color:transparent!important;border-radius:5px!important;box-shadow:none!important;background:transparent!important; }\n#ozon-structure-root .ozon-ext-table :is(.ozon-ext-search-select-trigger,.ozon-ext-cell-combo-trigger,.ozon-ext-sb-combo-trigger):hover { background:#e5f0ff!important; }\n#ozon-structure-root .ozon-dev-sprint-value > .ozon-dev-ellipsis,#ozon-structure-root .ozon-ext-sprint-value > span:first-child { flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }\n#ozon-structure-root :is(.ozon-dev-sprint-value,.ozon-ext-sprint-value,.ozon-ext-sprint-select .ozon-ext-select-content) > .ozon-ext-badge { margin-left:auto;flex:0 0 auto; }\n#ozon-structure-root [data-action=\"pick-ip-sprint\"],#ozon-structure-root [data-dev-action=\"link-sprint-pick\"] { display:flex!important;align-items:center;gap:8px; }\n#ozon-structure-root [data-action=\"pick-ip-sprint\"] > .ozon-ext-badge,#ozon-structure-root [data-dev-action=\"link-sprint-pick\"] > .ozon-ext-badge { margin-left:auto;flex:0 0 auto; }\n#ozon-structure-root #ozon-dev-editor-panel[aria-label=\"Спринт задачи\"] .ozon-dev-editor-options > button { display:flex!important;align-items:center;gap:8px; }\n#ozon-structure-root #ozon-dev-editor-panel[aria-label=\"Спринт задачи\"] .ozon-dev-editor-options > button > .ozon-ext-badge { margin-left:auto;flex:0 0 auto; }\n#ozon-structure-root input[type=\"search\"] {\n  background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16' fill='none' stroke='%239aa6b2' stroke-width='2'%3E%3Ccircle cx='6.5' cy='6.5' r='4.5'/%3E%3Cpath d='m10 10 4 4'/%3E%3C/svg%3E\")!important;\n  background-position:left 9px center!important;background-repeat:no-repeat!important;padding-left:32px!important;caret-color:#005bff;\n}\n#ozon-structure-root input[type=\"search\"]::placeholder {color:#98a5b3;}\n#ozon-structure-root input[type=\"search\"]::-webkit-search-cancel-button {cursor:pointer;}\n#ozon-structure-root [aria-expanded=\"true\"] :is(.ozon-ext-toolbar-chevron,.ozon-ext-search-select-caret)::before {transform:translateY(1px) rotate(225deg);}\n#ozon-structure-root .ozon-ext-combo-popover {border-color:#edf1f5!important;box-shadow:0 4px 18px rgba(25,47,68,.09)!important;}\n#ozon-structure-root :is(input[type=\"search\"],.ozon-ext-search-select-trigger,.ozon-ext-toolbar-trigger):disabled {opacity:.45;cursor:default;}\n#ozon-structure-root .ozon-ext-ip-row :is(input[type=\"text\"],input[type=\"search\"],.ozon-ext-sb-combo-trigger) {min-height:30px!important;border:1px solid #dce3eb!important;border-radius:9px!important;background:#fff!important;font:500 11.5px var(--ozon-font-sans)!important;}\n#ozon-structure-root .ozon-ext-ip-row :is(input[type=\"text\"],input[type=\"search\"]):focus {border-color:#005bff!important;box-shadow:inset 0 0 0 1px #005bff!important;}\n#ozon-structure-root .ozon-ext-ip-row :is(input[type=\"text\"],input[type=\"search\"])::placeholder {color:#98a5b3!important;}\n\n/* The development view keeps its team links and build version visible regardless of the selected tab. */\n#ozon-structure-root .ozon-dev-header-actions { display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:8px; }\n#ozon-structure-root .ozon-dev-header-actions a { display:inline-flex;align-items:center;min-height:26px;padding:3px 8px;border-radius:7px;background:#F2F7FF;color:#005BFF;text-decoration:none;font:500 11px var(--ozon-font-sans);white-space:nowrap; }\n#ozon-structure-root .ozon-dev-header-actions a:hover { background:#E5F0FF;text-decoration:none; }\n#ozon-structure-root .ozon-dev-version { color:#64748B;font:500 10px var(--ozon-font-sans);white-space:nowrap; }\n#ozon-structure-root .ozon-dev-team-popover { min-width:240px!important;width:260px!important;max-width:calc(100vw - 24px)!important;padding:6px!important; }\n#ozon-structure-root .ozon-dev-team-option { display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:10px!important;min-height:38px!important;width:100%!important;padding:7px 10px!important;box-sizing:border-box!important;overflow:hidden!important; }\n#ozon-structure-root .ozon-dev-team-option input[type=\"checkbox\"],#ozon-structure-root .ozon-dev-sprint-option input[type=\"checkbox\"],#ozon-structure-root .ozon-dev-settings input[type=\"checkbox\"] { appearance:none!important;-webkit-appearance:none!important;display:inline-grid!important;place-content:center!important;width:16px!important;height:16px!important;min-width:16px!important;max-width:16px!important;margin:0!important;padding:0!important;border:1px solid #A8B5C5!important;border-radius:4px!important;background:#fff!important;flex:0 0 16px!important;cursor:pointer!important; }\n#ozon-structure-root .ozon-dev-team-option input[type=\"checkbox\"]:checked,#ozon-structure-root .ozon-dev-sprint-option input[type=\"checkbox\"]:checked,#ozon-structure-root .ozon-dev-settings input[type=\"checkbox\"]:checked { border-color:#005BFF!important;background:#005BFF!important; }\n#ozon-structure-root .ozon-dev-team-option input[type=\"checkbox\"]:checked::after,#ozon-structure-root .ozon-dev-sprint-option input[type=\"checkbox\"]:checked::after,#ozon-structure-root .ozon-dev-settings input[type=\"checkbox\"]:checked::after { content:\"\";width:7px;height:4px;border-left:2px solid #fff;border-bottom:2px solid #fff;transform:rotate(-45deg) translate(1px,-1px); }\n#ozon-structure-root .ozon-dev-team-option>.ozon-dev-team-name { display:block!important;position:static!important;inset:auto!important;flex:1 1 auto!important;min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;line-height:20px!important;text-align:left!important; }\n#ozon-structure-root .ozon-dev-team-popover>.ozon-ext-btn { display:flex!important;width:100%!important;justify-content:center!important;margin-top:6px!important; }\n#ozon-structure-root .ozon-dev-sprint-option { display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:9px!important;width:100%;box-sizing:border-box; }\n#ozon-structure-root .ozon-dev-settings label { display:flex;align-items:center;gap:8px; }\n#ozon-structure-root .ozon-dev-settings input[type=\"checkbox\"] { flex:0 0 16px!important; }\n\n";
      document.head.appendChild(styleEl);
    }
  }
  ensureGoogleFontsLoaded();

  const STORAGE_KEY_COL_WIDTHS = 'ozon_fcrm_col_widths_v31';
  const STORAGE_KEY_COL_ORDER = 'ozon_fcrm_col_order_v31';
  const STORAGE_KEY_SIDEBAR_W = 'ozon_fcrm_sidebar_width_v31';

  let tasks = [
  {
    "key": "FCRM-4890",
    "summary": "Единое окно верификации бенефициаров ЮЛ при открытии расчётного счёта",
    "issueType": "История",
    "epicKey": "FCRM-4100",
    "epicName": "Единый кредитный конвейер B2B",
    "component": "KYC-Verify",
    "assignee": {
      "name": "Алексей Смирнов",
      "login": "asmirnov",
      "role": "Senior Go Developer"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Дмитрий Волков",
      "department": "Дирекция кредитования МСБ"
    },
    "createdAt": "03.11.2026 10:15",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "in_progress",
    "priority": "Критический",
    "projectTaskLinks": [
      {
        "id": "pt-101",
        "key": "PROJ-1210",
        "summary": "Цифровой онбординг РКО за 5 минут",
        "status": "В работе",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-201",
        "key": "FCRM-4891",
        "summary": "Интеграция сервиса распознавания уставов и ЕГРЮЛ",
        "status": "В работе",
        "issueType": "Задача",
        "component": "KYC-OCR-Service",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      },
      {
        "id": "ip-202",
        "key": "FCRM-4893",
        "summary": "Чек-лист комплаенса в карточке лида FCRM",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "CRM-Frontend",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4888",
    "summary": "Пакетное изменение лимитов корпоративных карт в профиле холдинга",
    "issueType": "Задача",
    "epicKey": "FCRM-4120",
    "epicName": "Зарплатный проект и ЭДО Ozon Банк",
    "component": "Corp-Cards",
    "assignee": {
      "name": "Денис Новиков",
      "login": "dnovikov",
      "role": "Lead Frontend Engineer"
    },
    "author": {
      "name": "Ольга Павлова",
      "login": "opavlova"
    },
    "customer": {
      "name": "Сергей Кравцов",
      "department": "Дирекция транзакционного бизнеса"
    },
    "createdAt": "03.11.2026 09:42",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "todo",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-102",
        "key": "PROJ-1120",
        "summary": "Корпоративные карты Ozon Business Pro",
        "status": "В работе",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-203",
        "key": "FCRM-4889",
        "summary": "Асинхронная очередь применения лимитов в процессинге",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "Card-Processing-GW",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4885",
    "summary": "Дашборд просроченной задолженности селлеров с разбивкой по когортам DPD",
    "issueType": "Аналитика",
    "epicKey": "FCRM-4100",
    "epicName": "Единый кредитный конвейер B2B",
    "component": "Core-Scoring",
    "assignee": {
      "name": "Полина Орлова",
      "login": "porlova",
      "role": "System Analyst / Go Dev"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Дмитрий Волков",
      "department": "Дирекция кредитования МСБ"
    },
    "createdAt": "02.11.2026 17:30",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "review",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-103",
        "key": "PROJ-1042",
        "summary": "Запуск экспресс-овердрафта для селлеров Ozon до 30 млн ₽",
        "status": "В работе",
        "issueType": "Эпик"
      },
      {
        "id": "pt-104",
        "key": "PROJ-1195",
        "summary": "Раннее предупреждение дефолтов МСБ (Early Warning)",
        "status": "Открыто",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-204",
        "key": "FCRM-4886",
        "summary": "Витрина ClickHouse для расчёта DPD 1+, 7+, 30+",
        "status": "Готово",
        "issueType": "Задача",
        "component": "DWH-ClickHouse",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      },
      {
        "id": "ip-205",
        "key": "RISK-402",
        "summary": "Калибровка порогов стоп-факторов скоринга",
        "status": "Ревью",
        "issueType": "Аналитика",
        "component": "Core-Scoring",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4881",
    "summary": "Автоматическое формирование справки об открытых счетах с ЭЦП банка из окна тикета",
    "issueType": "Задача",
    "epicKey": "FCRM-4055",
    "epicName": "Омниканальный контакт-центр Банка",
    "component": "CRM-DocGen",
    "assignee": {
      "name": "Екатерина Лебедева",
      "login": "elebedeva",
      "role": "Backend Engineer"
    },
    "author": {
      "name": "Наталья Белова",
      "login": "nbelova"
    },
    "customer": {
      "name": "Анна Морозова",
      "department": "Департамент клиентского сервиса РКО"
    },
    "createdAt": "02.11.2026 14:10",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "in_progress",
    "priority": "Средний",
    "projectTaskLinks": [
      {
        "id": "pt-105",
        "key": "PROJ-980",
        "summary": "Премиальная линия поддержки Ozon Банк Бизнес",
        "status": "В работе",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-206",
        "key": "FCRM-4882",
        "summary": "Шаблон PDF со штампом УКЭП Озон Банка",
        "status": "Готово",
        "issueType": "Задача",
        "component": "Sign-Crypto-UI",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4879",
    "summary": "Уведомление комплаенс-офицера при совпадении реквизитов контрагента с перечнем Росфинмониторинга",
    "issueType": "Ошибка",
    "epicKey": "FCRM-3990",
    "epicName": "Антифрод и Финмониторинг FCRM",
    "component": "AntiFraud-UI",
    "assignee": {
      "name": "Артём Захаров",
      "login": "azakharov",
      "role": "Fullstack Developer"
    },
    "author": {
      "name": "Наталья Белова",
      "login": "nbelova"
    },
    "customer": {
      "name": "Виктор Громов",
      "department": "Служба финмониторинга и комплаенса"
    },
    "createdAt": "01.11.2026 19:05",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "testing",
    "priority": "Критический",
    "projectTaskLinks": [
      {
        "id": "pt-106",
        "key": "PROJ-895",
        "summary": "Автоматизация реабилитации клиентов по 115-ФЗ",
        "status": "Тестирование",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-207",
        "key": "FCRM-4880",
        "summary": "Вебсокет-алерт блокировки проводки в реальном времени",
        "status": "Тестирование",
        "issueType": "Задача",
        "component": "AntiFraud-UI",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      },
      {
        "id": "ip-208",
        "key": "SEC-3401",
        "summary": "Журналирование действий оператора комплаенса в SIEM",
        "status": "Готово",
        "issueType": "Задача",
        "component": "Security-Audit",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4875",
    "summary": "Калькулятор индивидуальной ставки эквайринга с учётом оборота на маркетплейсе Ozon",
    "issueType": "Эпик",
    "epicKey": "FCRM-4012",
    "epicName": "Торговый эквайринг и B2B СБП",
    "component": "Tariff-Engine",
    "assignee": {
      "name": "Полина Орлова",
      "login": "porlova",
      "role": "System Analyst / Go Dev"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Роман Титов",
      "department": "Дирекция эквайринга и платёжных сервисов"
    },
    "createdAt": "01.11.2026 12:48",
    "sprint": "FCRM Sprint 43 (11.11 – 25.11)",
    "status": "todo",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-107",
        "key": "PROJ-1005",
        "summary": "Снижение времени подключения B2B-эквайринга до 4 часов",
        "status": "В работе",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-209",
        "key": "FCRM-4876",
        "summary": "Интеграция API аналитики оборота селлера seller-metrics-v2",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "API-Gateway",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4844",
    "summary": "Синхронизация статусов валютного контроля ВЭД с карточкой сделки в FCRM",
    "epicKey": "FCRM-4150",
    "epicName": "Валютный контроль и ВЭД Контур",
    "component": "API-Gateway",
    "assignee": {
      "name": "Алексей Смирнов",
      "login": "asmirnov",
      "role": "Senior Go Developer"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Елена Кузнецова",
      "department": "Управление валютного контроля"
    },
    "createdAt": "30.10.2026 18:30",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "in_progress",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-8",
        "key": "PROJ-1155",
        "summary": "Цифровой ВЭД-ассистент для импортёров Ozon Global",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-12",
        "key": "FCRM-4846",
        "summary": "Парсинг ведомостей банковского контроля (ВБК) в формате XML ЦБ",
        "status": "В работе",
        "component": "VED-Parser",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      },
      {
        "id": "ip-13",
        "key": "FCRM-4849",
        "summary": "Уведомления о приближении срока предоставления СПД за 3 дня",
        "status": "Открыто",
        "component": "CRM-Routing",
        "sprint": "FCRM Sprint 43 (11.11 – 25.11)"
      }
    ]
  },
  {
    "key": "FCRM-4838",
    "summary": "Реализация массового подписания реестров зарплатного проекта через УКЭП в FCRM",
    "epicKey": "FCRM-4120",
    "epicName": "Зарплатный проект и ЭДО Ozon Банк",
    "component": "Sign-Crypto-UI",
    "assignee": {
      "name": "Денис Новиков",
      "login": "dnovikov",
      "role": "Lead Frontend Engineer"
    },
    "author": {
      "name": "Ольга Павлова",
      "login": "opavlova"
    },
    "customer": {
      "name": "Сергей Кравцов",
      "department": "Дирекция транзакционного бизнеса"
    },
    "createdAt": "29.10.2026 16:05",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "todo",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-4",
        "key": "PROJ-1120",
        "summary": "Масштабирование зарплатного проекта для корпоративных клиентов",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-6",
        "key": "FCRM-4839",
        "summary": "Поддержка плагина КриптоПро Browser Plug-in в модуле верификации",
        "status": "Открыто",
        "component": "Sign-Crypto-UI",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      },
      {
        "id": "ip-7",
        "key": "SEC-3310",
        "summary": "Аудит безопасности хранения хэшей откреплённых подписей PKCS#7",
        "status": "В работе",
        "component": "Security-Audit",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4821",
    "summary": "Интеграция витрины скоринга МСБ с внешним контуром БКИ в карточке клиента FCRM",
    "epicKey": "FCRM-4100",
    "epicName": "Единый кредитный конвейер B2B",
    "component": "Core-Scoring",
    "assignee": {
      "name": "Алексей Смирнов",
      "login": "asmirnov",
      "role": "Senior Go Developer"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Дмитрий Волков",
      "department": "Дирекция кредитования МСБ"
    },
    "createdAt": "24.10.2026 11:40",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "in_progress",
    "priority": "Критический",
    "projectTaskLinks": [
      {
        "id": "pt-1",
        "key": "PROJ-1042",
        "summary": "Запуск экспресс-овердрафта для селлеров Ozon до 30 млн ₽",
        "status": "В работе"
      },
      {
        "id": "pt-2",
        "key": "PROJ-1089",
        "summary": "Соответствие требованиям ЦБ РФ по расчёту ПДН ЮЛ (4 кв.)",
        "status": "Открыто"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-1",
        "key": "FCRM-4825",
        "summary": "Миграция схемы PostgreSQL для хранения истории ответов НБКИ/ОКБ",
        "status": "Готово",
        "component": "Core-Scoring",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      },
      {
        "id": "ip-2",
        "key": "FCRM-4831",
        "summary": "Отрисовка блока лимитов и риск-грейда в правой панели оператора CRM",
        "status": "В работе",
        "component": "CRM-Frontend",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      },
      {
        "id": "ip-3",
        "key": "BANK-9104",
        "summary": "Контракт gRPC шлюза scoring-adapter-v3",
        "status": "Ревью",
        "component": "API-Gateway",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4818",
    "summary": "Оптимизация SQL-запросов поиска по ИНН/КПП/ОГРН в базе 4.5 млн карточек ЮЛ",
    "epicKey": "FCRM-4055",
    "epicName": "Омниканальный контакт-центр Банка",
    "component": "Search-Index",
    "assignee": {
      "name": "Илья Морозов",
      "login": "imorozov",
      "role": "DBA / Backend Engineer"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Анна Морозова",
      "department": "Департамент клиентского сервиса РКО"
    },
    "createdAt": "23.10.2026 15:12",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "done",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-108",
        "key": "PROJ-980",
        "summary": "Премиальная линия поддержки Ozon Банк Бизнес",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-210",
        "key": "FCRM-4819",
        "summary": "Партиционирование таблицы fcrm_legal_entities по регионам",
        "status": "Готово",
        "component": "Search-Index",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4814",
    "summary": "Автоматическая маршрутизация обращений VIP-корпоратов по SLA 15 минут",
    "epicKey": "FCRM-4055",
    "epicName": "Омниканальный контакт-центр Банка",
    "component": "CRM-Routing",
    "assignee": {
      "name": "Екатерина Лебедева",
      "login": "elebedeva",
      "role": "Backend Engineer"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Анна Морозова",
      "department": "Департамент клиентского сервиса РКО"
    },
    "createdAt": "21.10.2026 09:15",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "review",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-3",
        "key": "PROJ-980",
        "summary": "Премиальная линия поддержки Ozon Банк Бизнес",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-4",
        "key": "FCRM-4815",
        "summary": "Настройка Kafka-топика fcrm.sla.escalation.events",
        "status": "Готово",
        "component": "CRM-Routing",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      },
      {
        "id": "ip-5",
        "key": "FCRM-4840",
        "summary": "Индикатор таймера SLA в хедере тикета FCRM",
        "status": "Тестирование",
        "component": "CRM-Frontend",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4808",
    "summary": "Конструктор шаблонов ответов операторам поддержки по спорам СБП B2B",
    "epicKey": "FCRM-4012",
    "epicName": "Торговый эквайринг и B2B СБП",
    "component": "CRM-Frontend",
    "assignee": {
      "name": "Денис Новиков",
      "login": "dnovikov",
      "role": "Lead Frontend Engineer"
    },
    "author": {
      "name": "Ольга Павлова",
      "login": "opavlova"
    },
    "customer": {
      "name": "Роман Титов",
      "department": "Дирекция эквайринга и платёжных сервисов"
    },
    "createdAt": "19.10.2026 13:20",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "testing",
    "priority": "Средний",
    "projectTaskLinks": [
      {
        "id": "pt-109",
        "key": "PROJ-1005",
        "summary": "Снижение времени подключения B2B-эквайринга до 4 часов",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-211",
        "key": "FCRM-4809",
        "summary": "Подстановка переменных {{merchant_id}} и {{trn_rrn}}",
        "status": "Готово",
        "component": "CRM-DocGen",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4799",
    "summary": "Модуль комплаенс-проверки 115-ФЗ: интерактивное дерево связанных контрагентов ИНН/ОГРН",
    "epicKey": "FCRM-3990",
    "epicName": "Антифрод и Финмониторинг FCRM",
    "component": "AntiFraud-UI",
    "assignee": {
      "name": "Артём Захаров",
      "login": "azakharov",
      "role": "Fullstack Developer"
    },
    "author": {
      "name": "Наталья Белова",
      "login": "nbelova"
    },
    "customer": {
      "name": "Виктор Громов",
      "department": "Служба финмониторинга и комплаенса"
    },
    "createdAt": "17.10.2026 14:22",
    "sprint": "FCRM Sprint 42 (28.10 – 11.11)",
    "status": "testing",
    "priority": "Критический",
    "projectTaskLinks": [
      {
        "id": "pt-5",
        "key": "PROJ-895",
        "summary": "Автоматизация реабилитации клиентов по 115-ФЗ в ЛК и CRM",
        "status": "Тестирование"
      },
      {
        "id": "pt-6",
        "key": "PROJ-912",
        "summary": "Единое досье юридического лица (KYC Граф)",
        "status": "В работе"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-8",
        "key": "FCRM-4802",
        "summary": "Экспорт заключения финмониторинга в PDF с водяным знаком",
        "status": "Готово",
        "component": "CRM-DocGen",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      },
      {
        "id": "ip-9",
        "key": "FCRM-4810",
        "summary": "Кэширование ответов ЕГРЮЛ/Контур.Фокус в Redis на 24 часа",
        "status": "Готово",
        "component": "AntiFraud-UI",
        "sprint": "FCRM Sprint 42 (28.10 – 11.11)"
      }
    ]
  },
  {
    "key": "FCRM-4782",
    "summary": "Унификация витрины тарифов эквайринга и СБП для менеджеров сопровождения FCRM",
    "epicKey": "FCRM-4012",
    "epicName": "Торговый эквайринг и B2B СБП",
    "component": "Tariff-Engine",
    "assignee": {
      "name": "Полина Орлова",
      "login": "porlova",
      "role": "System Analyst / Go Dev"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Роман Титов",
      "department": "Дирекция эквайринга и платёжных сервисов"
    },
    "createdAt": "12.10.2026 10:50",
    "sprint": "FCRM Sprint 41 (14.10 – 28.10)",
    "status": "done",
    "priority": "Средний",
    "projectTaskLinks": [
      {
        "id": "pt-7",
        "key": "PROJ-1005",
        "summary": "Снижение времени подключения B2B-эквайринга до 4 часов",
        "status": "Готово"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-10",
        "key": "FCRM-4785",
        "summary": "Валидатор MCC-кодов и расчёт индивидуальной ставки комиссии",
        "status": "Готово",
        "component": "Tariff-Engine",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      },
      {
        "id": "ip-11",
        "key": "FCRM-4788",
        "summary": "Автотесты сценария смены тарифного плана с 1-го числа месяца",
        "status": "Готово",
        "component": "QA-Automation",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      }
    ]
  },
  {
    "key": "FCRM-4774",
    "summary": "Журнал аудита просмотров персональных данных VIP-клиентов сотрудниками банка",
    "epicKey": "FCRM-3990",
    "epicName": "Антифрод и Финмониторинг FCRM",
    "component": "Security-Audit",
    "assignee": {
      "name": "Илья Морозов",
      "login": "imorozov",
      "role": "DBA / Backend Engineer"
    },
    "author": {
      "name": "Наталья Белова",
      "login": "nbelova"
    },
    "customer": {
      "name": "Виктор Громов",
      "department": "Служба финмониторинга и комплаенса"
    },
    "createdAt": "10.10.2026 16:40",
    "sprint": "FCRM Sprint 41 (14.10 – 28.10)",
    "status": "done",
    "priority": "Критический",
    "projectTaskLinks": [
      {
        "id": "pt-110",
        "key": "PROJ-912",
        "summary": "Единое досье юридического лица (KYC Граф)",
        "status": "Готово"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-212",
        "key": "SEC-3290",
        "summary": "Экспорт логов доступа в корпоративный Splunk/ELK",
        "status": "Готово",
        "component": "Security-Audit",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      }
    ]
  },
  {
    "key": "FCRM-4768",
    "summary": "Интеграция софтфона WebRTC в верхнюю панель оператора FCRM с записью звонков",
    "epicKey": "FCRM-4055",
    "epicName": "Омниканальный контакт-центр Банка",
    "component": "Telephony-UI",
    "assignee": {
      "name": "Денис Новиков",
      "login": "dnovikov",
      "role": "Lead Frontend Engineer"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Анна Морозова",
      "department": "Департамент клиентского сервиса РКО"
    },
    "createdAt": "08.10.2026 11:05",
    "sprint": "FCRM Sprint 41 (14.10 – 28.10)",
    "status": "done",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-111",
        "key": "PROJ-980",
        "summary": "Премиальная линия поддержки Ozon Банк Бизнес",
        "status": "Готово"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-213",
        "key": "FCRM-4770",
        "summary": "Автоматическое открытие карточки клиента по входящему ANI-номеру",
        "status": "Готово",
        "component": "Telephony-UI",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      }
    ]
  },
  {
    "key": "FCRM-4760",
    "summary": "Автоматический расчёт лимита факторинга для поставщиков Ozon Express",
    "epicKey": "FCRM-4100",
    "epicName": "Единый кредитный конвейер B2B",
    "component": "Core-Scoring",
    "assignee": {
      "name": "Алексей Смирнов",
      "login": "asmirnov",
      "role": "Senior Go Developer"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Дмитрий Волков",
      "department": "Дирекция кредитования МСБ"
    },
    "createdAt": "05.10.2026 14:55",
    "sprint": "FCRM Sprint 41 (14.10 – 28.10)",
    "status": "done",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-112",
        "key": "PROJ-1042",
        "summary": "Запуск экспресс-овердрафта для селлеров Ozon до 30 млн ₽",
        "status": "Готово"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-214",
        "key": "FCRM-4762",
        "summary": "Модель расчёта оборачиваемости дебиторской задолженности",
        "status": "Готово",
        "component": "Core-Scoring",
        "sprint": "FCRM Sprint 41 (14.10 – 28.10)"
      }
    ]
  },
  {
    "key": "FCRM-4901",
    "summary": "Поддержка мультивалютных контрактов в юанях (CNY) и дирхамах (AED) в модуле ВЭД",
    "issueType": "История",
    "epicKey": "FCRM-4150",
    "epicName": "Валютный контроль и ВЭД Контур",
    "component": "API-Gateway",
    "assignee": {
      "name": "Екатерина Лебедева",
      "login": "elebedeva",
      "role": "Backend Engineer"
    },
    "author": {
      "name": "Игорь Козлов",
      "login": "ikozlov"
    },
    "customer": {
      "name": "Елена Кузнецова",
      "department": "Управление валютного контроля"
    },
    "createdAt": "03.11.2026 16:20",
    "sprint": "Бэклог FCRM (Планирование Q4)",
    "status": "todo",
    "priority": "Средний",
    "projectTaskLinks": [
      {
        "id": "pt-113",
        "key": "PROJ-1155",
        "summary": "Цифровой ВЭД-ассистент для импортёров Ozon Global",
        "status": "Открыто",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-215",
        "key": "FCRM-4902",
        "summary": "Справочник кросс-курсов ЦБ для азиатских валют",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "FX-Rates-Core",
        "sprint": "Бэклог FCRM (Планирование Q4)"
      }
    ]
  },
  {
    "key": "FCRM-4904",
    "summary": "Реестр банковских гарантий 44-ФЗ / 223-ФЗ с контролем сроков действия в FCRM",
    "issueType": "Эпик",
    "epicKey": "FCRM-4100",
    "epicName": "Единый кредитный конвейер B2B",
    "component": "Guarantees-Core",
    "assignee": {
      "name": "Полина Орлова",
      "login": "porlova",
      "role": "System Analyst / Go Dev"
    },
    "author": {
      "name": "Мария Соколова",
      "login": "msokolova"
    },
    "customer": {
      "name": "Дмитрий Волков",
      "department": "Дирекция кредитования МСБ"
    },
    "createdAt": "03.11.2026 18:05",
    "sprint": "Бэклог FCRM (Планирование Q4)",
    "status": "todo",
    "priority": "Высокий",
    "projectTaskLinks": [
      {
        "id": "pt-114",
        "key": "PROJ-1230",
        "summary": "Цифровые банковские гарантии для госзакупок",
        "status": "Открыто",
        "issueType": "Эпик"
      }
    ],
    "inProjectLinks": [
      {
        "id": "ip-216",
        "key": "FCRM-4905",
        "summary": "Шлюз обмена с ЕИС Закупки",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "EIS-Adapter",
        "sprint": "Бэклог FCRM (Планирование Q4)"
      },
      {
        "id": "ip-217",
        "key": "FCRM-4906",
        "summary": "Печатная форма проекта гарантии в FCRM",
        "status": "Открыто",
        "issueType": "Задача",
        "component": "CRM-DocGen",
        "sprint": "Бэклог FCRM (Планирование Q4)"
      }
    ]
  }
];
  let umbCatalog = [
  {
    "id": "umb-1",
    "key": "PROJ-1042",
    "summary": "Запуск экспресс-овердрафта для селлеров Ozon до 30 млн ₽",
    "status": "В работе"
  },
  {
    "id": "umb-2",
    "key": "PROJ-1089",
    "summary": "Соответствие требованиям ЦБ РФ по расчёту ПДН ЮЛ (4 кв.)",
    "status": "Открыто"
  },
  {
    "id": "umb-3",
    "key": "PROJ-1210",
    "summary": "Цифровой онбординг РКО за 5 минут",
    "status": "В работе"
  },
  {
    "id": "umb-4",
    "key": "PROJ-1120",
    "summary": "Масштабирование зарплатного проекта и корпоративных карт Ozon Business Pro",
    "status": "В работе"
  },
  {
    "id": "umb-5",
    "key": "PROJ-1195",
    "summary": "Раннее предупреждение дефолтов МСБ (Early Warning System)",
    "status": "Открыто"
  },
  {
    "id": "umb-6",
    "key": "PROJ-980",
    "summary": "Премиальная линия поддержки Ozon Банк Бизнес (SLA 15 мин)",
    "status": "В работе"
  },
  {
    "id": "umb-7",
    "key": "PROJ-895",
    "summary": "Автоматизация реабилитации клиентов по 115-ФЗ в ЛК и CRM",
    "status": "Тестирование"
  },
  {
    "id": "umb-8",
    "key": "PROJ-912",
    "summary": "Единое досье юридического лица (KYC Граф)",
    "status": "В работе"
  },
  {
    "id": "umb-9",
    "key": "PROJ-1005",
    "summary": "Снижение времени подключения B2B-эквайринга и СБП до 4 часов",
    "status": "В работе"
  },
  {
    "id": "umb-10",
    "key": "PROJ-1155",
    "summary": "Цифровой ВЭД-ассистент для импортёров Ozon Global (CNY / AED)",
    "status": "В работе"
  },
  {
    "id": "umb-11",
    "key": "PROJ-1230",
    "summary": "Цифровые банковские гарантии 44-ФЗ / 223-ФЗ для госзакупок",
    "status": "Открыто"
  }
];
  let umbCatalogReady = false;
  let umbCatalogRequest = null;
  let isStructureVisible = true;
  let activeDashboardView = new URLSearchParams(window.location.search).get('rapidView') === '6197' ? 'development' : 'product';
  let productDashboardLoaded = false;
  const renderBadge = (function renderJiraBadge(escapedLabel, category) {
    const colors = { active: 'done', done: 'done', future: 'progress', indeterminate: 'progress', progress: 'progress', review: 'review' };
    const color = Object.hasOwn(colors, category) ? colors[category] : 'todo';
    return '<span class="ozon-ext-badge ozon-ext-badge-' + color + '" title="' + escapedLabel + '">' + escapedLabel + '</span>';
});
  const jiraPriorityService = (function createJiraPriorityService() {
    async function get(url) {
        const response = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!response.ok)
            throw new Error('Jira вернула HTTP ' + response.status);
        return response.json();
    }
    async function options(key) {
        const meta = await get('/rest/api/2/issue/' + encodeURIComponent(key) + '/editmeta');
        const field = meta.fields?.priority;
        if (!field)
            throw new Error('Приоритет недоступен для изменения в Jira');
        const values = Array.isArray(field.allowedValues) ? field.allowedValues : await get('/rest/api/2/priority');
        return values.filter((item) => item?.name).map((item) => ({ label: item.name, value: item.id ? { id: String(item.id) } : { name: item.name } }));
    }
    async function save(key, value) {
        const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), { method: 'PUT', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { priority: value } }) });
        if (!response.ok) {
            const data = await response.json().catch(() => ({}));
            throw new Error(Object.values(data.errors || {}).join(', ') || data.errorMessages?.join(', ') || 'Не удалось изменить приоритет (HTTP ' + response.status + ')');
        }
        const fresh = await get('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=priority');
        const priority = fresh.fields?.priority;
        if (!priority || (value.id ? String(priority.id) !== String(value.id) : priority.name !== value.name))
            throw new Error('Jira не подтвердила изменение приоритета');
        return priority;
    }
    function icon(name) {
        const text = String(name || 'Не указан');
        const high = /highest|blocker|critical|крит|блок|наивыс/i.test(text), raised = high || /high|высок/i.test(text), low = /low|низк/i.test(text);
        const path = raised ? '<path d="m6 14 6-6 6 6"/>' + (high ? '<path d="m6 19 6-6 6 6"/>' : '') : low ? '<path d="m6 8 6 6 6-6"/>' : '<path d="M5 10h14M5 15h14"/>';
        return '<span class="ozon-dev-priority" aria-hidden="true" style="color:' + (raised ? '#E5484D' : low ? '#005BFF' : '#D97706') + '"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' + path + '</svg></span>';
    }
    return { options, save, icon };
})();
  const bindLabelSuggestions = (function bindJiraLabelSuggestions(input) {
    if (!input || input.dataset.labelSuggestionsBound)
        return;
    input.dataset.labelSuggestionsBound = '1';
    const list = document.createElement('datalist');
    list.id = 'ozon-label-suggestions-' + Math.random().toString(36).slice(2);
    input.setAttribute('list', list.id);
    input.after(list);
    let timer;
    let sequence = 0;
    let controller;
    input.addEventListener('input', () => {
        const query = input.value.trim();
        const current = ++sequence;
        clearTimeout(timer);
        controller?.abort();
        list.replaceChildren();
        if (!query)
            return;
        timer = setTimeout(async () => {
            controller = new AbortController();
            try {
                const response = await fetch('/rest/api/1.0/labels/suggest?query=' + encodeURIComponent(query), {
                    credentials: 'same-origin', headers: { Accept: 'application/json' }, signal: controller.signal
                });
                if (!response.ok)
                    return;
                const raw = await response.text();
                let labels = [];
                try {
                    const data = JSON.parse(raw);
                    const suggestions = data?.suggestions || data?.suggestionListStruct?.suggestions || [];
                    labels = (Array.isArray(suggestions) ? suggestions : [suggestions]).map((item) => typeof item === 'string' ? item : item?.label).filter(Boolean);
                }
                catch (_) {
                    const xml = new DOMParser().parseFromString(raw, 'application/xml');
                    labels = Array.from(xml.querySelectorAll('suggestions > label')).map(node => node.textContent || '').filter(Boolean);
                }
                if (current !== sequence || !input.isConnected || input.value.trim() !== query)
                    return;
                [...new Set(labels)].forEach(label => { const option = document.createElement('option'); option.value = label; list.appendChild(option); });
            }
            catch (_) { /* A new label can still be entered if suggestions are unavailable. */ }
        }, 200);
    });
});
  const strategicDashboard = (function createStrategicDashboard(onRender, renderBadge, version, priorityService, configuredSprintField, actions) {
    const state = { issues: [], loading: false, loaded: false, error: '', notice: '', progress: '', expanded: new Set(), search: '', component: '', issueType: '', issueTypeOpen: false, sort: 'priority', sortOpen: false, hideCanceled: false, hideDone: false, onlyThemes: false, filterCollapsed: new Set(), filterComponents: [], filtersLoading: false, filtersReady: false, filtersError: '', componentOpen: false, componentQuery: '', settings: false, editor: null };
    const escape = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    const collator = new Intl.Collator('ru', { numeric: true, sensitivity: 'base' });
    const columnTitles = { task: 'Задача', status: 'Статус', component: 'Компонент', priority: 'Приоритет', sprint: 'Спринт', labels: 'Метки', epic: 'Epic Link', obproject: 'Эпик OBPROJECT' };
    const legacyOrder = ['type', 'key', 'summary', 'status', 'component', 'priority', 'sprint', 'labels', 'epic', 'obproject'];
    const defaultOrder = Object.keys(columnTitles);
    const defaultWidths = { task: 540, status: 115, component: 160, priority: 90, sprint: 180, labels: 150, epic: 200, obproject: 200 };
    const defaultHidden = ['labels'];
    const layout = { order: [...defaultOrder], widths: { ...defaultWidths }, hidden: [...defaultHidden] };
    try {
        const saved = JSON.parse(localStorage.getItem('ozon-strategy-columns-v1') || 'null');
        if (Array.isArray(saved?.order)) {
            const order = [...new Set(saved.order.filter((id) => typeof id === 'string' && id in columnTitles && id !== 'task'))];
            layout.order = ['task', ...order, ...defaultOrder.filter(id => id !== 'task' && !order.includes(id))];
        }
        if (Array.isArray(saved?.hidden)) {
            const hidden = saved.hidden.filter((id) => typeof id === 'string' && id in columnTitles && id !== 'task');
            layout.hidden = [...new Set(hidden)];
        }
        if (saved?.widths)
            defaultOrder.forEach(id => { const n = Number(saved.widths[id]); if (Number.isFinite(n) && n >= 60 && n <= 1000)
                layout.widths[id] = n; });
    }
    catch (_) { /* Settings remain in memory. */ }
    const saveLayout = () => { try {
        localStorage.setItem('ozon-strategy-columns-v1', JSON.stringify(layout));
    }
    catch (_) { /* Storage can be unavailable. */ } };
    const graphCache = new Map();
    const invalidateGraph = () => { graphCache.clear(); };
    let searchTimer = null;
    let outsideBound = false;
    let request = 0;
    let sprintField = configuredSprintField || '';
    let epicField = '';
    let epicNameField = '';
    let sprintOptionsCache = null;
    let epicCatalogPromise = null;
    const epicMetadata = new Map();
    const obprojectMetadata = new Map();
    const obprojectKeyOf = (value) => { const raw = value && typeof value === 'object' ? value.key || value.value || value.name || value.url || '' : value || ''; return String(raw).toUpperCase().match(/OBPROJECT-\d+/)?.[0] || ''; };
    async function loadObprojectMetadata(issues, generation) {
        const keys = [...new Set(issues.map(issue => obprojectKeyOf(issue.fields?.customfield_20100)).filter(Boolean))].filter(key => !obprojectMetadata.has(key));
        for (let i = 0; i < keys.length; i += 100) {
            try {
                const params = new URLSearchParams({ jql: 'key in (' + keys.slice(i, i + 100).join(',') + ')', fields: 'summary,status', maxResults: '100' });
                const response = await fetch('/rest/api/2/search?' + params.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
                if (!response.ok)
                    continue;
                const data = await response.json();
                if (!Array.isArray(data.issues))
                    continue;
                data.issues.forEach((issue) => { if (issue?.key)
                    obprojectMetadata.set(issue.key, { summary: issue.fields?.summary || '', status: issue.fields?.status?.name || '', category: issue.fields?.status?.statusCategory?.key || '' }); });
                if (generation === request)
                    onRender();
            }
            catch (_) { /* Ключ доступен и без деталей эпика. */ }
        }
    }
    let fieldsDiscovered = false;
    const priorityIcon = (name) => priorityService?.icon ? priorityService.icon(name) : '';
    function parseSprint(value) {
        if (value && typeof value === 'object')
            return { ...value, state: String(value.state || '').toLowerCase() };
        if (typeof value !== 'string')
            return null;
        const get = (name) => new RegExp('(?:\\[|,)' + name + '=([^,\\]]*)').exec(value)?.[1];
        return get('id') ? { id: get('id'), name: get('name'), state: String(get('state') || '').toLowerCase(), startDate: get('startDate') } : null;
    }
    function sprintValue(fields) {
        const asArray = (value) => value == null ? [] : Array.isArray(value) ? value : [value];
        const history = [...asArray(fields[sprintField]), ...asArray(fields.sprint), ...asArray(fields.closedSprints)].map(parseSprint).filter((item) => item?.name);
        return history.sort((a, b) => { const x = Date.parse(a.startDate || ''), y = Date.parse(b.startDate || ''); return Number.isFinite(x) && Number.isFinite(y) && x !== y ? x - y : Number(a.id) - Number(b.id); }).at(-1);
    }
    async function loadEditableSprints() {
        if (sprintOptionsCache)
            return sprintOptionsCache;
        const all = [];
        let start = 0;
        while (true) {
            const board = String(actions?.boardId || '9349');
            const params = new URLSearchParams({ state: 'active,future', startAt: String(start), maxResults: '50' });
            const response = await fetch('/rest/agile/1.0/board/' + encodeURIComponent(board) + '/sprint?' + params.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
            if (!response.ok)
                throw new Error('Не удалось загрузить спринты: HTTP ' + response.status);
            const data = await response.json();
            if (!Array.isArray(data.values))
                throw new Error('Jira вернула некорректный список спринтов');
            all.push(...data.values.filter((sprint) => sprint?.id && sprint.name && (!sprint.originBoardId || String(sprint.originBoardId) === board) && /^(active|future)$/i.test(sprint.state || '')));
            start += data.values.length;
            if (!data.values.length || data.isLast === true || (Number.isFinite(Number(data.total)) && start >= Number(data.total)))
                break;
        }
        sprintOptionsCache = all.sort((a, b) => (String(a.state).toLowerCase() === 'active' ? 0 : 1) - (String(b.state).toLowerCase() === 'active' ? 0 : 1) || collator.compare(a.name, b.name));
        return sprintOptionsCache;
    }
    async function saveSprint(key, sprint) {
        const issue = state.issues.find(item => item.key === key);
        if (!issue)
            throw new Error('Задача больше не найдена в таблице');
        if (/^(epic|эпик)$/i.test(issue.fields?.issuetype?.name || ''))
            throw new Error('Для эпиков нельзя изменить спринт');
        const url = sprint ? '/rest/agile/1.0/sprint/' + encodeURIComponent(sprint.id) + '/issue' : '/rest/agile/1.0/backlog/issue';
        const response = await fetch(url, { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ issues: [key] }) });
        if (!response.ok)
            throw new Error('Не удалось изменить спринт: HTTP ' + response.status);
        try {
            const params = new URLSearchParams({ fields: ['sprint', 'closedSprints', sprintField].filter(Boolean).join(',') });
            const fresh = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?' + params.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
            if (!fresh.ok)
                throw new Error('Ошибка чтения');
            const data = await fresh.json();
            if (!data.fields || (data.key && data.key !== key))
                throw new Error('Некорректный ответ');
            const updated = { ...issue.fields, ...data.fields };
            const raw = [...(Array.isArray(updated[sprintField]) ? updated[sprintField] : updated[sprintField] ? [updated[sprintField]] : []), ...(Array.isArray(updated.sprint) ? updated.sprint : updated.sprint ? [updated.sprint] : [])].map(parseSprint).filter(Boolean);
            if (sprint && !raw.some((item) => String(item.id) === String(sprint.id)))
                throw new Error('Спринт ещё не появился');
            if (!sprint && raw.some((item) => /^(active|future)$/i.test(item.state || '')))
                throw new Error('Задача ещё в спринте');
            issue.fields = updated;
            invalidateGraph();
            actions?.notify?.('Спринт задачи ' + key + ' обновлён.');
        }
        catch (_) {
            actions?.notify?.('Jira приняла изменение спринта задачи ' + key + ', но проверить его не удалось. Обновите задачи.');
        }
    }
    function typeHtml(node) {
        const url = String(node.typeIcon || '');
        const icon = /^(?:https?:\/\/|\/)/i.test(url) ? '<img src="' + escape(url) + '" alt="">' : '<span style="color:#005BFF">●</span>';
        return '<span class="ozon-ext-type-pill">' + icon + ' ' + escape(node.type) + '</span>';
    }
    async function prepareFilters() {
        if (state.filtersLoading || state.filtersReady)
            return;
        state.filtersLoading = true;
        state.filtersError = '';
        onRender();
        try {
            const response = await fetch('/rest/api/2/project/FCRM/components', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
            if (!response.ok)
                throw new Error('HTTP ' + response.status);
            const data = await response.json();
            if (!Array.isArray(data))
                throw new Error('Некорректный ответ Jira');
            state.filterComponents = data.map((item) => item.name).filter(Boolean);
            state.filtersReady = true;
        }
        catch (error) {
            state.filtersError = 'Не удалось загрузить компоненты: ' + (error?.message || 'ошибка Jira');
        }
        finally {
            state.filtersLoading = false;
            onRender();
        }
    }
    async function load() {
        if (state.loading)
            return;
        const current = ++request;
        state.loading = true;
        state.error = '';
        state.notice = '';
        state.progress = 'Загружаем задачи проекта FCRM…';
        onRender();
        try {
            if (!fieldsDiscovered) {
                try {
                    const response = await fetch('/rest/api/2/field', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
                    if (response.ok) {
                        const fields = await response.json();
                        sprintField = fields.find((field) => String(field.schema?.custom || '').includes('gh-sprint'))?.id || fields.find((field) => /^(sprint|спринт)$/i.test(String(field.name || '').trim()))?.id || sprintField;
                        epicField = fields.find((field) => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-epic-link')?.id || fields.find((field) => /^(epic link|ссылка на эпик)$/i.test(String(field.name || field.untranslatedName || '').trim()))?.id || '';
                        epicNameField = fields.find((field) => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-epic-label')?.id || '';
                        fieldsDiscovered = true;
                    }
                }
                catch (_) { /* Other data is still available. */ }
            }
            const issues = [];
            const seen = new Set();
            let start = 0, total = Infinity;
            while (start < total) {
                const query = new URLSearchParams({ jql: 'project = FCRM ORDER BY key ASC', fields: ['summary', 'issuetype', 'status', 'components', 'labels', 'issuelinks', 'priority', 'created', 'sprint', 'closedSprints', 'epic', 'customfield_20100', epicField, sprintField].filter(Boolean).join(','), startAt: String(start), maxResults: '100' });
                const response = await fetch('/rest/api/2/search?' + query.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
                if (!response.ok)
                    throw new Error('Jira вернула HTTP ' + response.status);
                const data = await response.json();
                if (!Array.isArray(data.issues) || !Number.isFinite(Number(data.total)))
                    throw new Error('Jira вернула неполный список задач');
                total = Number(data.total);
                if (!data.issues.length && start < total)
                    throw new Error('Jira вернула неполную страницу задач');
                data.issues.forEach((issue) => { if (/^FCRM-\d+$/i.test(String(issue?.key || '')) && !seen.has(issue.key)) {
                    seen.add(issue.key);
                    issues.push(issue);
                } });
                start += data.issues.length;
                state.progress = 'Загружено ' + Math.min(start, total) + ' из ' + total + ' задач…';
                if (current !== request)
                    return;
                onRender();
            }
            if (current !== request)
                return;
            state.issues = issues;
            invalidateGraph();
            state.loaded = true;
            state.expanded.clear();
            void loadObprojectMetadata(issues, current);
        }
        catch (error) {
            if (current === request)
                state.error = error?.message || 'Не удалось загрузить задачи';
        }
        finally {
            if (current === request) {
                state.loading = false;
                state.progress = '';
                onRender();
            }
        }
    }
    function buildGraph(onlyThemes = false, includeEpic = false) {
        const cacheKey = [onlyThemes, includeEpic, state.hideCanceled, state.hideDone, state.sort].join('|');
        if (graphCache.has(cacheKey))
            return graphCache.get(cacheKey);
        const nodes = new Map();
        const allIssuesByKey = new Map(state.issues.map(issue => [issue.key, issue]));
        state.issues.forEach(raw => {
            const f = raw.fields || {};
            if (onlyThemes && !(f.labels || []).some((label) => String(label).toLowerCase() === 'fcrm_umb_epic'))
                return;
            const isCanceled = /cancel|отмен|отклон|rejected/i.test(String(f.status?.name || ''));
            if ((state.hideCanceled && isCanceled) || (state.hideDone && !isCanceled && (f.status?.statusCategory?.key === 'done' || /^(готово|закрыт[ао]?|done|closed)$/i.test(String(f.status?.name || '').trim()))))
                return;
            nodes.set(raw.key, { key: raw.key, summary: f.summary || raw.key, type: f.issuetype?.name || 'Задача', typeIcon: f.issuetype?.iconUrl || '', sprint: sprintValue(f), status: f.status?.name || 'Не указан', category: f.status?.statusCategory?.key || '', componentNames: (f.components || []).map((component) => component.name).filter(Boolean), components: (f.components || []).map((component) => component.name).filter(Boolean).join(', ') || 'Без компонента', priority: f.priority?.name || 'Не указан', created: f.created || '', obproject: '', epicKey: String((typeof f[epicField] === 'string' ? f[epicField] : f[epicField]?.key || f[epicField]?.value) || f.epic?.key || ''), labels: Array.isArray(f.labels) ? f.labels : [], thematic: (f.labels || []).some((label) => String(label).toLowerCase() === 'fcrm_umb_epic'), parents: new Set(), missingParents: new Set(), children: new Set(), links: f.issuelinks || [] });
        });
        nodes.forEach(node => { const raw = allIssuesByKey.get(node.key); const source = /^(epic|эпик)$/i.test(node.type) ? raw : allIssuesByKey.get(node.epicKey); node.obproject = obprojectKeyOf(source?.fields?.customfield_20100); });
        nodes.forEach(node => node.links.forEach((link) => {
            const inward = Boolean(link.inwardIssue);
            const target = inward ? link.inwardIssue : link.outwardIssue;
            const direction = inward ? link.type?.inward : link.type?.outward;
            if (!target?.key || !/^FCRM-\d+$/i.test(target.key) || !/задача проекта|project task/i.test(String(direction || '')))
                return;
            if (!nodes.has(target.key)) {
                if (!allIssuesByKey.has(target.key))
                    node.missingParents.add(target.key);
                return;
            }
            node.parents.add(target.key);
            nodes.get(target.key).children.add(node.key);
        }));
        if (includeEpic)
            nodes.forEach(node => {
                const epic = nodes.get(node.epicKey);
                if (!epic || epic.key === node.key || !/^(epic|эпик)$/i.test(epic.type))
                    return;
                node.parents.add(epic.key);
                epic.children.add(node.key);
            });
        const rank = (name) => /highest|blocker|critical|крит|блок|наивыс/i.test(name) ? 0 : /high|высок/i.test(name) ? 1 : /medium|normal|standard|средн|стандарт|обычн/i.test(name) ? 2 : /low|низк/i.test(name) ? 3 : 4;
        const compare = (a, b) => { const x = nodes.get(a), y = nodes.get(b); const dateX = Date.parse(x.created), dateY = Date.parse(y.created); const order = state.sort === 'created' ? (Number.isFinite(dateY) ? dateY : 0) - (Number.isFinite(dateX) ? dateX : 0) : rank(x.priority) - rank(y.priority); return order || collator.compare(x.summary, y.summary) || collator.compare(a, b); };
        const roots = [...nodes.values()].filter(node => !node.parents.size).map(node => node.key).sort(compare);
        const visited = new Set();
        const mark = (start) => { const pending = [start]; while (pending.length) {
            const key = pending.pop();
            if (visited.has(key))
                continue;
            visited.add(key);
            nodes.get(key).children.forEach((child) => pending.push(child));
        } };
        roots.forEach(mark);
        const cycles = [];
        [...nodes.keys()].filter(key => !visited.has(key)).sort(compare).forEach(key => { if (!visited.has(key)) {
            cycles.push(key);
            mark(key);
        } });
        const graph = { nodes, roots, cycles, compare };
        graphCache.set(cacheKey, graph);
        return graph;
    }
    function html() {
        const header = '<header class="ozon-ext-header-bar"><strong>Стратегическое планирование FCRM</strong><div class="ozon-strategy-actions"><span class="ozon-dev-version">v' + escape(version) + '</span></div></header>';
        const availableComponents = [...new Set([...state.filterComponents, ...state.issues.flatMap((issue) => (issue.fields?.components || []).map((component) => component.name).filter(Boolean))])].sort((a, b) => collator.compare(a, b));
        const componentOptions = [{ value: '', label: 'Все компоненты' }, { value: '__none__', label: 'Без компонента' }, ...availableComponents.map((name) => ({ value: name, label: name }))];
        const chosen = componentOptions.find(option => option.value === state.component)?.label || 'Все компоненты';
        const componentCombo = '<div class="ozon-ext-toolbar-combo"><button type="button" class="ozon-ext-toolbar-trigger" data-strategy-action="component-menu" aria-expanded="' + state.componentOpen + '" aria-label="Фильтр по компоненту"><span class="ozon-ext-toolbar-label">Компонент: ' + escape(chosen) + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.componentOpen ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover"><input id="ozon-strategy-component-search" type="search" placeholder="Поиск компонента…" value="' + escape(state.componentQuery) + '"><div class="ozon-dev-filter-list">' + componentOptions.filter(option => option.label.toLowerCase().includes(state.componentQuery.trim().toLowerCase())).map(option => '<button type="button" class="ozon-ext-combo-item ' + (state.component === option.value ? 'active' : '') + '" data-strategy-action="component-pick" data-value="' + escape(option.value) + '">' + escape(option.label) + '</button>').join('') + '</div></div>' : '') + '</div>';
        const issueTypes = [...new Set(state.issues.map((issue) => String(issue.fields?.issuetype?.name || 'Задача')))].sort((a, b) => collator.compare(a, b));
        const typeCombo = '<div class="ozon-ext-toolbar-combo"><button type="button" class="ozon-ext-toolbar-trigger" data-strategy-action="type-menu" aria-expanded="' + state.issueTypeOpen + '" aria-label="Фильтр по типу задачи"><span class="ozon-ext-toolbar-label">Тип задачи: ' + escape(state.issueType || 'Все') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.issueTypeOpen ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover"><div class="ozon-dev-filter-list">' + [{ value: '', label: 'Все' }, ...issueTypes.map(value => ({ value, label: value }))].map(option => '<button type="button" class="ozon-ext-combo-item ' + (state.issueType === option.value ? 'active' : '') + '" data-strategy-action="type-pick" data-value="' + escape(option.value) + '">' + escape(option.label) + '</button>').join('') + '</div></div>' : '') + '</div>';
        const filters = '<div class="ozon-strategy-filters"><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="settings-open"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 7h16M4 17h16M8 4v6M16 14v6"/></svg> Настройки</button><button type="button" class="ozon-ext-btn" data-strategy-action="reload" ' + (state.loading ? 'disabled' : '') + '>' + (state.loaded ? 'Обновить задачи' : 'Загрузить задачи') + '</button><input id="ozon-strategy-search" type="search" placeholder="Поиск по ключу или названию" aria-label="Поиск по ключу или названию" value="' + escape(state.search) + '">' + componentCombo + typeCombo + '<div class="ozon-ext-toolbar-combo"><button type="button" class="ozon-ext-toolbar-trigger" data-strategy-action="sort-menu" aria-expanded="' + state.sortOpen + '"><span class="ozon-ext-toolbar-label">Сортировка: ' + (state.sort === 'created' ? 'Сначала новые' : 'Приоритет') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.sortOpen ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover"><button class="ozon-ext-combo-item" data-strategy-action="sort-pick" data-value="priority">Приоритет</button><button class="ozon-ext-combo-item" data-strategy-action="sort-pick" data-value="created">Дата: сначала новые</button></div>' : '') + '</div><button type="button" class="ozon-ext-btn ' + (state.hideCanceled ? '' : 'ozon-ext-btn-surface') + '" data-strategy-action="hide-canceled" aria-pressed="' + state.hideCanceled + '">Скрыть отменённые</button><button type="button" class="ozon-ext-btn ' + (state.hideDone ? '' : 'ozon-ext-btn-surface') + '" data-strategy-action="hide-done" aria-pressed="' + state.hideDone + '">Скрыть выполненные</button><button type="button" class="ozon-ext-btn ' + (state.onlyThemes ? '' : 'ozon-ext-btn-surface') + '" data-strategy-action="only-themes" aria-pressed="' + state.onlyThemes + '">Только тематики</button>' + ((state.search || state.component || state.issueType || state.onlyThemes || state.hideCanceled || state.hideDone) ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="reset-filters">Сбросить фильтры</button>' : '') + (state.loaded ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="create">+ Создать тематику</button>' : '') + '</div>' + (state.notice && !actions?.notify ? '<div class="ozon-strategy-notice" role="status">' + escape(state.notice) + ' <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="dismiss-notice" aria-label="Закрыть уведомление">✕</button></div>' : '') + (state.filtersError ? '<div class="ozon-strategy-message" role="alert">' + escape(state.filtersError) + ' <button type="button" class="ozon-ext-btn" data-strategy-action="retry-filters">Повторить</button></div>' : '');
        const visibleColumns = layout.order.filter(id => !layout.hidden.includes(id));
        const settings = state.settings ? '<aside class="ozon-dev-settings ozon-dev-settings-stable ozon-strategy-settings" role="dialog" aria-label="Настройки таблицы"><header class="ozon-dev-editor-head"><strong>Настройки таблицы</strong><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-cancel" data-strategy-action="settings-close" aria-label="Закрыть">✕</button></header><strong>Порядок столбцов</strong><p class="ozon-dev-menu-hint">Ширину можно менять за границу заголовка таблицы.</p><div>' + layout.order.map((id, index) => '<div class="ozon-dev-group-option"><label class="ozon-dev-column-label"><input type="checkbox" data-strategy-column-visible="' + id + '" ' + (!layout.hidden.includes(id) ? 'checked' : '') + ' ' + (id === 'task' || (!layout.hidden.includes(id) && visibleColumns.length === 1) ? 'disabled' : '') + '> ' + escape(columnTitles[id]) + '</label><button class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="column-move" data-column="' + id + '" data-direction="-1" aria-label="Поднять ' + escape(columnTitles[id]) + '" ' + (index <= 1 ? 'disabled' : '') + '>↑</button><button class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="column-move" data-column="' + id + '" data-direction="1" aria-label="Опустить ' + escape(columnTitles[id]) + '" ' + (index === 0 || index === layout.order.length - 1 ? 'disabled' : '') + '>↓</button></div>').join('') + '</div><footer><button class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="columns-reset">По умолчанию</button><button class="ozon-ext-btn" data-strategy-action="settings-close">Готово</button></footer></aside>' : '';
        if (state.loading)
            return '<section class="ozon-strategy-dashboard">' + header + filters + '<div class="ozon-strategy-message" role="status">' + escape(state.progress) + Array.from({ length: 8 }, () => '<div class="ozon-ext-skeleton" style="height:25px;margin:10px 0"></div>').join('') + '</div>' + settings + '</section>';
        if (state.error)
            return '<section class="ozon-strategy-dashboard">' + header + filters + '<div class="ozon-strategy-message" role="alert">Не удалось загрузить все задачи FCRM: ' + escape(state.error) + '. <button type="button" class="ozon-ext-btn" data-strategy-action="reload">Повторить</button></div>' + settings + '</section>';
        if (!state.loaded)
            return '<section class="ozon-strategy-dashboard">' + header + filters + '<div class="ozon-strategy-message">Выберите фильтры и нажмите «Загрузить задачи». Для сохранения иерархии загружаются все задачи FCRM.</div>' + settings + '</section>';
        const { nodes, roots, cycles, compare } = buildGraph(state.onlyThemes, true);
        const filter = state.search.trim().toLowerCase();
        const filtering = Boolean(filter || state.component || state.issueType);
        const relevant = new Set();
        const matches = new Set();
        if (filtering) {
            const pending = [];
            nodes.forEach((node) => { if ((!filter || (node.key + ' ' + node.summary).toLowerCase().includes(filter)) && (!state.component || (state.component === '__none__' ? !node.componentNames.length : node.componentNames.includes(state.component))) && (!state.issueType || node.type === state.issueType)) {
                pending.push(node.key);
                matches.add(node.key);
            } });
            while (pending.length) {
                const key = pending.pop();
                if (relevant.has(key))
                    continue;
                relevant.add(key);
                nodes.get(key).parents.forEach((parent) => pending.push(parent));
            }
        }
        const visible = (key) => !filtering || relevant.has(key);
        const descendantCounts = new Map();
        const countDescendants = (key) => {
            if (descendantCounts.has(key))
                return descendantCounts.get(key);
            const seen = new Set([key]);
            const pending = [...nodes.get(key).children];
            while (pending.length) {
                const child = pending.pop();
                if (seen.has(child) || !visible(child))
                    continue;
                seen.add(child);
                nodes.get(child).children.forEach((next) => pending.push(next));
            }
            const count = seen.size - 1;
            descendantCounts.set(key, count);
            return count;
        };
        const rootThemes = roots.filter(key => visible(key) && (nodes.get(key).thematic || nodes.get(key).children.size));
        const unlinked = roots.filter(key => visible(key) && !nodes.get(key).thematic && !nodes.get(key).children.size);
        const renderGroup = (title, keys) => {
            if (!keys.length)
                return '';
            let result = '<tr class="ozon-strategy-group"><td colspan="' + visibleColumns.length + '">' + escape(title) + ' <span class="ozon-ext-group-total">' + keys.length + '</span></td></tr>';
            const pending = keys.slice().reverse().map(key => ({ key, path: key, ancestors: new Set(), depth: 0 }));
            while (pending.length) {
                const item = pending.pop();
                const node = nodes.get(item.key);
                const cycle = item.ancestors.has(item.key);
                const parentKey = item.path.split('|').at(-2) || '';
                const epicRelation = Boolean(parentKey && node.epicKey === parentKey);
                const projectRelation = Boolean(parentKey && node.links.some((link) => { const inward = Boolean(link.inwardIssue); const target = inward ? link.inwardIssue : link.outwardIssue; const direction = inward ? link.type?.inward : link.type?.outward; return target?.key === parentKey && /задача проекта|project task/i.test(String(direction || '')); }));
                const contextOnly = filtering && !matches.has(item.key);
                const children = [...node.children].filter((key) => visible(key)).sort(compare);
                const expanded = !cycle && state.expanded.has(item.path);
                const toggle = children.length && !cycle ? '<button type="button" class="ozon-strategy-toggle" data-strategy-action="toggle" data-path="' + escape(item.path) + '" aria-expanded="' + expanded + '" aria-label="' + (expanded ? 'Свернуть ' : 'Развернуть ') + escape(node.key) + '">' + (expanded ? '▾' : '▸') + '</button>' : '<span class="ozon-strategy-toggle-spacer"></span>';
                const category = node.category === 'done' ? 'done' : node.category === 'indeterminate' ? 'progress' : 'todo';
                const epic = node.epicKey ? (nodes.get(node.epicKey) || epicMetadata.get(node.epicKey)) : null;
                const epicValue = node.epicKey ? '<div class="ozon-dev-epic-inline"><a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(node.epicKey) + '" target="_blank" rel="noopener noreferrer">' + escape(node.epicKey) + '</a>' + (epic ? ' ' + renderBadge(escape(epic.status), epic.category === 'done' ? 'done' : epic.category === 'indeterminate' ? 'progress' : 'todo') + ' <span title="' + escape(epic.summary) + '">' + escape(epic.summary) + '</span>' : '') + '</div>' : '—';
                const ob = obprojectMetadata.get(node.obproject);
                const obCell = node.obproject ? '<div class="ozon-dev-epic-inline"><a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(node.obproject) + '" target="_blank" rel="noopener noreferrer">' + escape(node.obproject) + '</a>' + (ob?.status ? renderBadge(escape(ob.status), ob.category === 'done' ? 'done' : ob.category === 'indeterminate' ? 'progress' : 'todo') : '') + (ob?.summary ? '<span title="' + escape(ob.summary) + '">' + escape(ob.summary) + '</span>' : '') + '</div>' : '—';
                const epicCell = '<div class="ozon-dev-cell-edit ozon-dev-epic-inline"><span class="ozon-strategy-epic-value">' + epicValue + '</span><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="edit-epic" data-key="' + escape(node.key) + '" aria-label="Изменить эпик ' + escape(node.key) + '">▾</button></div>';
                const rowHtml = '<tr class="ozon-strategy-depth-' + (item.depth % 2) + '" data-strategy-path="' + escape(item.path) + '" data-strategy-expandable="' + Boolean(children.length && !cycle) + '"><td><div class="ozon-strategy-type" style="padding-left:' + (Math.min(item.depth, 40) * 18 + 8) + 'px">' + toggle + typeHtml(node) + '</div></td><td><div class="ozon-strategy-key"><a href="https://jit.o3.ru/browse/' + encodeURIComponent(node.key) + '" target="_blank" rel="noopener noreferrer" class="ozon-mono">' + escape(node.key) + '</a><details class="ozon-strategy-copy-menu"><summary aria-label="Копировать ' + escape(node.key) + '" title="Копировать"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h4"/></svg></summary><div class="ozon-strategy-copy-options"><button type="button" data-strategy-action="copy" data-key="' + escape(node.key) + '">Ссылка и название</button><button type="button" data-strategy-action="copy-key" data-key="' + escape(node.key) + '">Только ключ</button></div></details><button type="button" class="ozon-strategy-link-button" data-strategy-action="link" data-key="' + escape(node.key) + '" title="Связать с тематикой" aria-label="Связать ' + escape(node.key) + ' с тематикой">⛓</button></div></td><td><span class="ozon-strategy-indent" style="width:' + (Math.min(item.depth, 8) * 12) + 'px" aria-hidden="true">' + (item.depth ? '↳' : '') + '</span>' + (epicRelation ? '<span class="ozon-strategy-epic-relation" title="Задача входит в эпик по Epic Link">Epic Link</span> ' : '') + (node.thematic ? '<span class="ozon-ext-badge ozon-ext-badge-progress">Тематика</span> ' : '') + '<span title="' + escape(node.summary) + '">' + escape(node.summary) + '</span> <button type="button" class="ozon-ext-inner-ctrl ozon-ext-open-sb-btn" data-strategy-action="details" data-key="' + escape(node.key) + '">Детали</button>' + (cycle ? ' <span class="ozon-strategy-warning">Циклическая связь</span>' : '') + (node.missingParents.size ? ' <span class="ozon-strategy-warning" title="' + escape([...node.missingParents].join(', ')) + '">Тематика недоступна</span>' : '') + '</td><td>' + renderBadge(escape(node.status), category) + '</td><td><button type="button" class="ozon-strategy-component-edit" data-strategy-action="edit-component" data-key="' + escape(node.key) + '" aria-label="Изменить компонент ' + escape(node.key) + '" title="' + escape(node.components) + '"><span>' + escape(node.components) + '</span><span aria-hidden="true">▾</span></button></td><td><button type="button" class="ozon-dev-priority-edit" data-strategy-action="priority" data-key="' + escape(node.key) + '" title="Приоритет: ' + escape(node.priority) + '" aria-label="Изменить приоритет ' + escape(node.key) + '">' + priorityIcon(node.priority) + '</button></td><td><div class="ozon-strategy-sprint ' + (/^(epic|эпик)$/i.test(node.type) ? 'ozon-strategy-sprint-locked' : 'ozon-strategy-sprint-edit') + '" ' + (/^(epic|эпик)$/i.test(node.type) ? 'title="У эпиков нельзя изменить спринт"' : 'role="button" tabindex="0" data-strategy-action="edit-sprint" data-key="' + escape(node.key) + '" aria-label="Изменить спринт ' + escape(node.key) + '"') + '>' + (node.sprint?.name ? '<span title="' + escape(node.sprint.name) + '">' + escape(node.sprint.name) + '</span>' + renderBadge(node.sprint.state === 'active' ? 'Активный' : node.sprint.state === 'future' ? 'Будущий' : 'Прошедший', node.sprint.state === 'active' ? 'done' : node.sprint.state === 'future' ? 'progress' : 'todo') : '—') + '</div></td><td><div class="ozon-strategy-labels">' + node.labels.map((label) => '<span class="ozon-strategy-label">' + escape(label) + '<button type="button" data-strategy-action="remove-label" data-key="' + escape(node.key) + '" data-label="' + escape(label) + '" aria-label="Удалить метку ' + escape(label) + '">×</button></span>').join('') + '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-strategy-action="labels" data-key="' + escape(node.key) + '" aria-label="Добавить метку">+</button></div></td><td>' + epicCell + '</td><td>' + obCell + '</td></tr>';
                const cells = rowHtml.match(/<td>[\s\S]*?<\/td>/g) || [];
                const inner = (index) => (cells[index] || '').replace(/^<td>|<\/td>$/g, '');
                const descendantCount = children.length && !cycle ? countDescendants(node.key) : 0;
                const countHtml = descendantCount ? '<span class="ozon-strategy-descendant-count" title="Уникальные вложенные задачи с учётом фильтров" aria-label="Вложенных задач: ' + descendantCount + '">' + descendantCount + '</span>' : '';
                const taskCell = '<td class="ozon-strategy-task-cell"><div class="ozon-strategy-task-line">' + '<span style="padding-left:' + (Math.min(item.depth, 40) * 18 + 8) + 'px">' + toggle + '</span>' + inner(1) + typeHtml(node) + inner(5) + '<div class="ozon-strategy-task-summary">' + inner(2).replace(/<span class="ozon-strategy-indent"[^>]*>[^<]*<\/span>/, '') + (projectRelation ? ' <span class="ozon-strategy-relation" title="Связь «Задача проекта»">Задача проекта</span>' : '') + (contextOnly ? ' <span class="ozon-strategy-context-label">Родитель для контекста</span>' : '') + '</div>' + countHtml + '</div></td>';
                result += rowHtml.slice(0, rowHtml.indexOf('<td>')).replace('" data-strategy-path=', (contextOnly ? ' ozon-strategy-context' : '') + '" data-strategy-path=') + visibleColumns.map(id => id === 'task' ? taskCell : cells[legacyOrder.indexOf(id)] || '').join('') + '</tr>';
                if (expanded) {
                    const ancestors = new Set(item.ancestors);
                    ancestors.add(item.key);
                    children.reverse().forEach((key) => pending.push({ key, path: item.path + '|' + key, ancestors, depth: item.depth + 1 }));
                }
            }
            return result;
        };
        const rows = renderGroup('Тематики и их задачи', rootThemes) + renderGroup('Без тематики', unlinked) + renderGroup('Циклические связи', cycles.filter(visible));
        const editor = state.editor;
        const currentComponents = state.issues.find(issue => issue.key === editor?.key)?.fields?.components || [];
        const componentSelected = (option) => currentComponents.some(item => (item.id && option.id && String(item.id) === String(option.id)) || (item.name && item.name === option.name));
        const linkedThemesHtml = () => {
            const current = editor && nodes.get(editor.key);
            const linked = new Map();
            (current?.links || []).forEach((link) => {
                const inward = Boolean(link.inwardIssue), target = inward ? link.inwardIssue : link.outwardIssue;
                const direction = inward ? link.type?.inward : link.type?.outward;
                if (!target?.key || !/задача проекта|project task/i.test(String(direction || '')))
                    return;
                const existing = nodes.get(target.key), fields = target.fields || {};
                linked.set(target.key, { ...(existing || { key: target.key, summary: fields.summary || '', status: fields.status?.name || '', category: fields.status?.statusCategory?.key || '' }), linkId: link.id || '' });
            });
            const entries = [...linked.values()].sort((a, b) => collator.compare(a.summary || a.key, b.summary || b.key));
            return '<div class="ozon-strategy-linked-themes"><strong>Установленные связи «Задача проекта»</strong>' + (entries.length ? '<div class="ozon-strategy-linked-list">' + entries.map((item) => '<div class="ozon-strategy-linked-item"><div><a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(item.key) + '" target="_blank" rel="noopener noreferrer">' + escape(item.key) + '</a>' + (item.status ? ' ' + renderBadge(escape(item.status), item.category === 'done' ? 'done' : item.category === 'indeterminate' ? 'progress' : 'todo') : '') + '<button type="button" class="ozon-strategy-unlink" data-strategy-action="unlink-theme" data-key="' + escape(item.key) + '" data-id="' + escape(item.linkId) + '" aria-label="Удалить связь с ' + escape(item.key) + '" title="Удалить связь" ' + (editor.busy ? 'disabled' : '') + '>✕</button></div><div class="ozon-strategy-linked-title">' + escape(item.summary || 'Название недоступно') + '</div></div>').join('') + '</div>' : '<p>Связей пока нет</p>') + '</div>';
        };
        const themeOptionsHtml = () => {
            const options = editor?.options || [];
            const byKey = new Map(options.map((item) => [item.key, item]));
            const query = String(editor?.query || '').trim().toLowerCase();
            const visible = new Set();
            const pending = options.filter(item => !query || (item.key + ' ' + item.summary).toLowerCase().includes(query)).map(item => item.key);
            while (pending.length) {
                const key = pending.pop();
                if (visible.has(key))
                    continue;
                visible.add(key);
                (byKey.get(key)?.parents || []).forEach((parent) => { if (byKey.has(parent))
                    pending.push(parent); });
            }
            const children = new Map();
            const roots = [];
            options.forEach(item => { if (!visible.has(item.key))
                return; const parents = [...(item.parents || [])].filter((key) => key !== item.key && visible.has(key) && byKey.has(key)); if (!parents.length)
                roots.push(item.key); parents.forEach((parent) => { if (!children.has(parent))
                children.set(parent, []); children.get(parent).push(item.key); }); });
            const covered = new Set();
            const cover = (key) => { const stack = [key]; while (stack.length) {
                const current = stack.pop();
                if (covered.has(current))
                    continue;
                covered.add(current);
                stack.push(...(children.get(current) || []));
            } };
            roots.forEach(cover);
            options.forEach(item => { if (visible.has(item.key) && !covered.has(item.key)) {
                roots.push(item.key);
                cover(item.key);
            } });
            let result = '';
            const renderTree = (root) => { const stack = [{ key: root, depth: 0, ancestors: new Set() }]; while (stack.length) {
                const entry = stack.pop();
                if (entry.ancestors.has(entry.key))
                    continue;
                const item = byKey.get(entry.key);
                if (!item)
                    continue;
                const descendants = (children.get(entry.key) || []).filter(key => !entry.ancestors.has(key));
                const open = Boolean(query) || !editor.collapsed?.has(entry.key);
                const indent = Math.min(entry.depth, 8) * 14;
                result += '<div class="ozon-strategy-theme-row" style="margin-left:' + indent + 'px;width:calc(100% - ' + indent + 'px)">' + (descendants.length ? '<button type="button" class="ozon-strategy-theme-toggle" data-strategy-action="theme-toggle" data-key="' + escape(item.key) + '" aria-expanded="' + open + '" aria-label="' + (open ? 'Свернуть ' : 'Развернуть ') + escape(item.key) + '">' + (open ? '▾' : '▸') + '</button>' : '<span class="ozon-strategy-theme-toggle-space"></span>') + '<button type="button" class="ozon-ext-combo-item ozon-strategy-theme-option" data-strategy-action="save-link" data-strategy-match="' + (!query || (item.key + ' ' + item.summary).toLowerCase().includes(query)) + '" data-key="' + escape(item.key) + '" ' + (editor.busy ? 'disabled' : '') + '><span class="ozon-mono">' + escape(item.key) + '</span>' + renderBadge(escape(item.status), item.category === 'done' ? 'done' : item.category === 'indeterminate' ? 'progress' : 'todo') + '<span class="ozon-dev-option-components">' + escape(item.components) + '</span><span class="ozon-dev-option-title">' + escape(item.summary) + '</span></button></div>';
                if (open) {
                    const ancestors = new Set(entry.ancestors);
                    ancestors.add(entry.key);
                    descendants.slice().reverse().forEach(key => stack.push({ key, depth: entry.depth + 1, ancestors }));
                }
            } };
            roots.forEach(renderTree);
            return result || '<div class="ozon-ext-toolbar-empty">Тематики не найдены</div>';
        };
        const currentPriority = editor?.kind === 'priority' ? state.issues.find(item => item.key === editor.key)?.fields?.priority : null;
        const currentSprint = editor?.kind === 'sprint' ? sprintValue(state.issues.find(item => item.key === editor.key)?.fields || {}) : null;
        const panel = !editor ? '' : '<aside class="ozon-dev-editor ozon-ext-combo-popover" role="dialog" aria-label="Редактирование задачи"><div class="ozon-dev-editor-head"><strong>' + (editor.kind === 'priority' ? 'Приоритет' : editor.kind === 'component' ? 'Компонент задачи' : editor.kind === 'sprint' ? 'Спринт задачи' : editor.kind === 'epic' ? 'Эпик задачи' : editor.kind === 'link' ? 'Связать с тематикой' : editor.kind === 'create' ? 'Создать тематику' : 'Добавить метку') + (editor.key ? ' · ' + escape(editor.key) : '') + '</strong><button type="button" class="ozon-ext-btn" data-strategy-action="close-editor">✕</button></div>' + (editor.kind === 'sprint' ? '<div class="ozon-sprint-current"><span>Текущий спринт</span><strong>' + escape(currentSprint?.name || 'Бэклог') + '</strong></div>' : editor.kind === 'priority' ? '<div class="ozon-sprint-current"><span>Текущий приоритет</span><strong>' + priorityIcon(currentPriority?.name || '') + ' ' + escape(currentPriority?.name || 'Не указан') + '</strong></div>' : '') + (editor.error ? '<p role="alert" class="ozon-dev-error">' + escape(editor.error) + '</p>' : '') + (editor.loading ? '<p role="status">Загрузка…</p>' : editor.kind === 'sprint' ? '<input id="ozon-strategy-sprint-search" type="search" dir="ltr" placeholder="Поиск спринта…" aria-label="Поиск спринта" value="' + escape(editor.query || '') + '"><div class="ozon-dev-editor-options ozon-strategy-editor-options"><button type="button" class="ozon-ext-combo-item" data-strategy-action="save-sprint" data-id="" ' + (editor.busy ? 'disabled' : '') + '>Бэклог</button>' + editor.options.filter((sp) => !editor.query || sp.name.toLowerCase().includes(editor.query.toLowerCase())).map((sp) => '<button type="button" class="ozon-ext-combo-item" data-strategy-action="save-sprint" data-id="' + escape(sp.id) + '" ' + (editor.busy ? 'disabled' : '') + '><span>' + escape(sp.name) + '</span>' + renderBadge(String(sp.state).toLowerCase() === 'active' ? 'Активный' : 'Будущий', String(sp.state).toLowerCase() === 'active' ? 'done' : 'progress') + '</button>').join('') + '</div>' : editor.kind === 'component' ? '<input id="ozon-strategy-component-editor-search" type="search" dir="ltr" placeholder="Поиск компонента…" aria-label="Поиск компонента задачи" value="' + escape(editor.query || '') + '"><div class="ozon-dev-editor-options ozon-strategy-editor-options"><button type="button" class="ozon-ext-combo-item ' + (!currentComponents.length ? 'active' : '') + '" aria-pressed="' + !currentComponents.length + '" data-strategy-action="save-component" data-id="" ' + (editor.busy ? 'disabled' : '') + '>Без компонента</button>' + editor.options.filter((option) => !editor.query || String(option.name).toLowerCase().includes(editor.query.toLowerCase())).map((option) => '<button type="button" class="ozon-ext-combo-item ' + (componentSelected(option) ? 'active' : '') + '" aria-pressed="' + componentSelected(option) + '" data-strategy-action="save-component" data-id="' + escape(option.id) + '" ' + (editor.busy ? 'disabled' : '') + '>' + escape(option.name) + '</button>').join('') + '</div>' : editor.kind === 'epic' ? '<input id="ozon-strategy-epic-search" type="search" dir="ltr" placeholder="Поиск по ключу или названию…" value="' + escape(editor.query || '') + '"><div class="ozon-dev-editor-options ozon-dev-epic-options ozon-strategy-editor-options"><button type="button" class="ozon-ext-combo-item" data-strategy-action="save-epic" data-key="" ' + (editor.busy ? 'disabled' : '') + '>Без эпика</button>' + editor.options.map((item) => '<button type="button" class="ozon-ext-combo-item" data-strategy-action="save-epic" data-key="' + escape(item.key) + '" ' + (editor.busy ? 'disabled' : '') + '><span class="ozon-mono">' + escape(item.key) + '</span>' + renderBadge(escape(item.status), item.category === 'done' ? 'done' : item.category === 'indeterminate' ? 'progress' : 'todo') + '<span class="ozon-dev-option-title">' + escape(item.summary) + '</span><span class="ozon-dev-option-components">' + escape(item.components) + '</span></button>').join('') + (editor.searching ? '<p role="status">Загрузка…</p>' : '') + '</div>' : editor.kind === 'priority' ? '<div class="ozon-dev-editor-options ozon-strategy-editor-options">' + editor.options.map((option, index) => '<button type="button" class="ozon-ext-combo-item ' + ((String(option.value) === String(currentPriority?.id) || option.label === currentPriority?.name) ? 'active' : '') + '" aria-pressed="' + (String(option.value) === String(currentPriority?.id) || option.label === currentPriority?.name) + '" data-strategy-action="save-priority" data-index="' + index + '" ' + (editor.busy ? 'disabled' : '') + '>' + priorityIcon(option.label) + escape(option.label) + '</button>').join('') + '</div>' : editor.kind === 'link' ? linkedThemesHtml() + '<div class="ozon-strategy-theme-scope"><span>' + (currentComponents.length ? 'Компоненты задачи: ' + escape(currentComponents.map((item) => item.name).filter(Boolean).join(', ')) : 'У задачи не указан компонент') + '</span><button type="button" class="ozon-ext-btn ' + (editor.allComponents ? '' : 'ozon-ext-btn-surface') + '" data-strategy-action="theme-scope" aria-pressed="' + Boolean(editor.allComponents) + '">Все компоненты</button></div><input id="ozon-strategy-link-search" type="search" dir="ltr" aria-label="Поиск тематики" placeholder="Поиск по ключу или названию…" value="' + escape(editor.query || '') + '"><div class="ozon-dev-editor-options ozon-dev-epic-options ozon-strategy-editor-options">' + themeOptionsHtml() + '</div>' : editor.kind === 'create' ? '<form id="ozon-strategy-create-form"><label>Название<input id="ozon-strategy-create-name" required value="' + escape(editor.summary || '') + '"></label><label>Компонент<select id="ozon-strategy-create-component" required><option value="">Выберите компонент</option>' + editor.options.map((item) => '<option value="' + escape(item.id) + '" ' + (String(item.id) === String(editor.componentId || '') ? 'selected' : '') + '>' + escape(item.name) + '</option>').join('') + '</select></label><button type="submit" class="ozon-ext-btn" ' + (editor.busy ? 'disabled' : '') + '>Создать</button></form>' : '<form id="ozon-strategy-label-form"><input id="ozon-strategy-label-input" placeholder="Название метки" aria-label="Название метки" required><button type="submit" class="ozon-ext-btn" ' + (editor.busy ? 'disabled' : '') + '>Добавить</button></form>') + '</aside>';
        return '<section class="ozon-strategy-dashboard">' + header + filters + '<div class="ozon-strategy-description">Все задачи FCRM · ' + (filtering ? matches.size : nodes.size) + ' задач' + (filtering ? ' по фильтрам · Родительские строки показаны для контекста' : '') + '. Задача может отображаться в нескольких тематиках. <span class="ozon-strategy-legend">Связи: <span class="ozon-strategy-relation">Задача проекта</span> <span class="ozon-strategy-epic-relation">Epic Link</span></span></div><div class="ozon-strategy-scroll"><table class="ozon-strategy-table" style="width:max(100%,' + visibleColumns.reduce((sum, id) => sum + layout.widths[id], 0) + 'px)"><colgroup>' + visibleColumns.map(id => '<col data-strategy-col="' + id + '" style="width:' + layout.widths[id] + 'px">').join('') + '</colgroup><thead><tr>' + visibleColumns.map(id => '<th' + (id === 'task' ? ' class="ozon-strategy-task-header"' : '') + '>' + escape(columnTitles[id]) + '<span class="ozon-dev-col-resizer" role="separator" aria-orientation="vertical" aria-label="Изменить ширину: ' + escape(columnTitles[id]) + '" tabindex="0" data-strategy-resize="' + id + '"></span></th>').join('') + '</tr></thead><tbody>' + (rows || '<tr><td colspan="' + visibleColumns.length + '">Задачи FCRM не найдены</td></tr>') + '</tbody></table></div>' + panel + settings + '</section>';
    }
    async function linkTheme(sourceKey, targetKey) {
        const theme = state.issues.find(item => item.key === targetKey);
        const themeName = theme?.fields?.summary ? targetKey + ' «' + theme.fields.summary + '»' : targetKey;
        const linked = await actions.link(sourceKey, targetKey);
        if (!linked)
            throw new Error('Не удалось установить связь в Jira');
        // Once Jira accepted the link, do not offer to repeat the write if the refresh fails.
        try {
            const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(sourceKey) + '?fields=issuelinks', { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
            if (!response.ok)
                throw new Error('HTTP ' + response.status);
            const data = await response.json();
            if (data.key && data.key !== sourceKey)
                throw new Error('Jira вернула другую задачу');
            const links = data.fields?.issuelinks;
            if (!Array.isArray(links))
                throw new Error('Jira не вернула связи');
            const hasLink = links.some((link) => { const inward = Boolean(link.inwardIssue); const target = inward ? link.inwardIssue : link.outwardIssue; const direction = inward ? link.type?.inward : link.type?.outward; return target?.key === targetKey && /задача проекта|project task/i.test(String(direction || '')); });
            if (!hasLink)
                throw new Error('Jira ещё не вернула новую связь');
            const issue = state.issues.find(item => item.key === sourceKey);
            if (!issue)
                throw new Error('Задача больше не найдена в таблице');
            issue.fields.issuelinks = links;
            invalidateGraph();
            state.notice = 'Связь ' + sourceKey + ' с тематикой ' + themeName + ' сохранена.';
        }
        catch (_) {
            state.notice = 'Связь ' + sourceKey + ' с тематикой ' + themeName + ' создана, но не удалось обновить её в таблице. Нажмите «Обновить задачи», чтобы проверить данные Jira.';
        }
        actions?.notify?.(state.notice);
    }
    async function unlinkTheme(sourceKey, targetKey, linkId) {
        const issue = state.issues.find(item => item.key === sourceKey);
        if (!issue)
            throw new Error('Задача больше не найдена в таблице');
        const matches = (link) => { const inward = Boolean(link.inwardIssue); const target = inward ? link.inwardIssue : link.outwardIssue; const direction = inward ? link.type?.inward : link.type?.outward; return target?.key === targetKey && /задача проекта|project task/i.test(String(direction || '')); };
        if (!linkId) {
            const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(sourceKey) + '?fields=issuelinks', { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
            if (!response.ok)
                throw new Error('Не удалось получить связь из Jira');
            const data = await response.json();
            const found = (data.fields?.issuelinks || []).filter(matches);
            if (found.length !== 1 || !found[0].id)
                throw new Error('Не удалось однозначно определить связь для удаления');
            linkId = String(found[0].id);
        }
        const response = await fetch('/rest/api/2/issueLink/' + encodeURIComponent(linkId), { method: 'DELETE', credentials: 'same-origin', headers: { Accept: 'application/json' } });
        if (!response.ok)
            throw new Error('Не удалось удалить связь: Jira вернула HTTP ' + response.status);
        issue.fields.issuelinks = (issue.fields.issuelinks || []).filter((link) => !(String(link.id || '') === linkId || (!link.id && matches(link))));
        try {
            const updated = await fetch('/rest/api/2/issue/' + encodeURIComponent(sourceKey) + '?fields=issuelinks', { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
            if (updated.ok) {
                const data = await updated.json();
                if (Array.isArray(data.fields?.issuelinks) && !data.fields.issuelinks.some((link) => String(link.id || "") === linkId))
                    issue.fields.issuelinks = data.fields.issuelinks;
            }
        }
        catch (_) { /* Удаление уже подтверждено Jira. */ }
        invalidateGraph();
        actions?.notify?.('Связь ' + sourceKey + ' с тематикой ' + targetKey + ' удалена.');
    }
    function themeCandidates(key, allComponents) {
        const graph = buildGraph();
        const current = graph.nodes.get(key);
        const descendants = new Set(), pending = [key];
        while (pending.length) {
            const next = pending.pop();
            if (descendants.has(next))
                continue;
            descendants.add(next);
            graph.nodes.get(next)?.children.forEach((child) => pending.push(child));
        }
        return [...graph.nodes.values()].filter((item) => item.thematic && !descendants.has(item.key) && !current?.parents.has(item.key) && (allComponents || (current?.componentNames.length ? item.componentNames.some((name) => current.componentNames.includes(name)) : !item.componentNames.length))).sort((a, b) => collator.compare(a.summary, b.summary));
    }
    let epicSearchSerial = 0, epicSearchTimer = null;
    async function searchEpic(editor) {
        const serial = ++epicSearchSerial;
        editor.searching = true;
        editor.error = '';
        try {
            if (!epicCatalogPromise) {
                epicCatalogPromise = (async () => {
                    const jql = 'project in (OBPROJECT, FCRM) AND issuetype = Epic ORDER BY updated DESC';
                    const fields = ['summary', 'status', 'components', 'issuetype', 'labels', epicNameField].filter(Boolean).join(',');
                    const page = async (startAt) => { const params = new URLSearchParams({ jql, fields, maxResults: '100', startAt: String(startAt) }); const response = await fetch('/rest/api/2/search?' + params.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' } }); if (!response.ok)
                        throw new Error('Не удалось загрузить эпики (HTTP ' + response.status + ')'); const data = await response.json(); if (!Array.isArray(data.issues))
                        throw new Error('Некорректный ответ Jira'); return data; };
                    const first = await page(0), result = [...first.issues], total = Number(first.total || 0);
                    for (let start = 100; start < total; start += 500) {
                        const offsets = Array.from({ length: 5 }, (_, i) => start + i * 100).filter(offset => offset < total);
                        const pages = await Promise.all(offsets.map(page));
                        pages.forEach(data => result.push(...data.issues));
                    }
                    return result;
                })().catch(error => { epicCatalogPromise = null; throw error; });
            }
            const data = await epicCatalogPromise, query = String(editor.query || '').trim().toLocaleLowerCase();
            if (serial !== epicSearchSerial || state.editor !== editor)
                return;
            data.forEach((item) => { if (item.key)
                epicMetadata.set(item.key, { summary: item.fields?.summary || item.key, status: item.fields?.status?.name || 'Не указан', category: item.fields?.status?.statusCategory?.key || '' }); });
            editor.options = data.filter((item) => item.key !== editor.key && /^(epic|эпик)$/i.test(item.fields?.issuetype?.name || '') && (!query || [item.key, item.fields?.summary, epicNameField ? item.fields?.[epicNameField] : '', ...(item.fields?.labels || [])].some(value => String(value || '').toLocaleLowerCase().includes(query)))).slice(0, 100).map((item) => ({ key: item.key, summary: item.fields?.summary || item.key, status: item.fields?.status?.name || 'Не указан', category: item.fields?.status?.statusCategory?.key || '', components: (item.fields?.components || []).map((c) => c.name).join(', ') || 'Без компонента' }));
        }
        catch (error) {
            if (serial === epicSearchSerial && state.editor === editor)
                editor.error = error.message;
        }
        finally {
            if (serial === epicSearchSerial && state.editor === editor) {
                editor.searching = false;
                const input = document.getElementById('ozon-strategy-epic-search');
                const focused = document.activeElement === input, pos = input?.selectionStart;
                onRender();
                const next = document.getElementById('ozon-strategy-epic-search');
                if (focused && next) {
                    next.focus({ preventScroll: true });
                    if (pos != null)
                        next.setSelectionRange(pos, pos);
                }
            }
        }
    }
    async function saveEpic(key, value) {
        if (!epicField)
            throw new Error('Не найдено поле Epic Link в Jira. Обновите задачи.');
        const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), { method: 'PUT', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { [epicField]: value || null } }) });
        if (!response.ok)
            throw new Error('Не удалось изменить Epic Link (HTTP ' + response.status + ')');
        const check = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=' + encodeURIComponent(epicField), { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!check.ok)
            throw new Error('Не удалось проверить Epic Link в Jira');
        const data = await check.json();
        if (!data.fields || !Object.prototype.hasOwnProperty.call(data.fields, epicField))
            throw new Error('Jira не вернула Epic Link');
        const raw = data.fields[epicField], actual = typeof raw === 'string' ? raw : raw?.key || raw?.value || '';
        if (actual !== value)
            throw new Error('Jira не подтвердила изменение Epic Link');
        const issue = state.issues.find(item => item.key === key);
        if (issue) {
            issue.fields[epicField] = raw;
            delete issue.fields.epic;
            invalidateGraph();
        }
    }
    async function saveComponent(key, id) {
        const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), { method: 'PUT', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { components: id ? [{ id }] : [] } }) });
        if (!response.ok)
            throw new Error('Не удалось изменить компонент (HTTP ' + response.status + ')');
        const check = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=components', { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!check.ok)
            throw new Error('Не удалось проверить компонент в Jira');
        const data = await check.json(), components = data.fields?.components;
        if (!Array.isArray(components) || (id ? components.length !== 1 || String(components[0].id) !== id : components.length !== 0))
            throw new Error('Jira не подтвердила изменение компонента');
        const issue = state.issues.find(item => item.key === key);
        if (issue) {
            issue.fields.components = components;
            invalidateGraph();
        }
    }
    async function changeLabel(key, label, operation) {
        if (!label || /\s/.test(label))
            throw new Error('Введите метку без пробелов');
        const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), { method: 'PUT', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ update: { labels: [{ [operation]: label }] } }) });
        if (!response.ok)
            throw new Error('Не удалось изменить метку (HTTP ' + response.status + ')');
        const fresh = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=labels', { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
        if (!fresh.ok)
            throw new Error('Не удалось проверить метки в Jira');
        const data = await fresh.json();
        const labels = data.fields?.labels;
        if (!Array.isArray(labels) || labels.includes(label) !== (operation === 'add'))
            throw new Error('Jira не подтвердила изменение метки');
        const issue = state.issues.find(item => item.key === key);
        if (issue) {
            issue.fields.labels = labels;
            invalidateGraph();
        }
    }
    function bind(root) {
        root.querySelectorAll('.ozon-strategy-copy-menu').forEach(menu => {
            menu.addEventListener('toggle', () => {
                if (!menu.open)
                    return;
                root.querySelectorAll('.ozon-strategy-copy-menu[open]').forEach(other => { if (other !== menu)
                    other.open = false; });
                const trigger = menu.querySelector('summary'), options = menu.querySelector('.ozon-strategy-copy-options');
                if (!trigger || !options)
                    return;
                const rect = trigger.getBoundingClientRect(), width = options.offsetWidth, height = options.offsetHeight;
                options.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8)) + 'px';
                options.style.top = Math.max(8, rect.bottom + height + 4 <= window.innerHeight ? rect.bottom + 4 : rect.top - height - 4) + 'px';
            });
        });
        root.querySelector('.ozon-strategy-scroll')?.addEventListener('scroll', () => root.querySelectorAll('.ozon-strategy-copy-menu[open]').forEach(menu => { menu.open = false; }), { passive: true });
        const search = root.querySelector('#ozon-strategy-search');
        search?.addEventListener('input', () => { state.search = search.value; state.expanded.clear(); clearTimeout(searchTimer); searchTimer = setTimeout(() => { const current = document.getElementById('ozon-strategy-search'); if (!current || current.value !== state.search)
            return; const focused = document.activeElement === current, start = current.selectionStart, end = current.selectionEnd; onRender(); const next = document.getElementById('ozon-strategy-search'); if (focused && next) {
            next.focus({ preventScroll: true });
            if (start !== null && end !== null)
                next.setSelectionRange(start, end);
        } }, 180); });
        root.querySelector('#ozon-strategy-component-search')?.addEventListener('input', event => { const input = event.target; const position = input.selectionStart; state.componentQuery = input.value; onRender(); const next = document.getElementById('ozon-strategy-component-search'); next?.focus({ preventScroll: true }); if (next && position !== null)
            next.setSelectionRange(position, position); });
        if (!outsideBound && typeof document !== 'undefined') {
            outsideBound = true;
            document.addEventListener('pointerdown', event => { if (!event.target?.closest('.ozon-strategy-copy-menu'))
                document.querySelectorAll('.ozon-strategy-copy-menu[open]').forEach(menu => { menu.open = false; }); if ((!state.componentOpen && !state.issueTypeOpen) || event.target?.closest('.ozon-ext-toolbar-combo'))
                return; setTimeout(() => { if (state.componentOpen || state.issueTypeOpen) {
                state.componentOpen = false;
                state.issueTypeOpen = false;
                onRender();
            } }, 0); }, true);
        }
        root.querySelectorAll('[data-strategy-column-visible]').forEach(input => input.addEventListener('change', () => { const id = input.dataset.strategyColumnVisible || ''; if (!(id in columnTitles) || id === 'task')
            return; layout.hidden = input.checked ? layout.hidden.filter(item => item !== id) : [...layout.hidden, id]; saveLayout(); onRender(); }));
        root.querySelectorAll('[data-strategy-resize]').forEach(handle => {
            const id = handle.dataset.strategyResize;
            const apply = (width) => { layout.widths[id] = Math.max(60, Math.min(1000, Math.round(width))); const table = root.querySelector('.ozon-strategy-table'); const col = root.querySelector('col[data-strategy-col="' + id + '"]'); if (col)
                col.style.width = layout.widths[id] + 'px'; if (table)
                table.style.width = 'max(100%, ' + layout.order.filter(key => !layout.hidden.includes(key)).reduce((sum, key) => sum + layout.widths[key], 0) + 'px)'; };
            handle.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); const start = event.clientX, width = handle.parentElement?.getBoundingClientRect().width || layout.widths[id]; const move = (next) => apply(width + next.clientX - start); const stop = () => { document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', stop); document.removeEventListener('pointercancel', stop); saveLayout(); }; document.addEventListener('pointermove', move); document.addEventListener('pointerup', stop); document.addEventListener('pointercancel', stop); });
            handle.addEventListener('keydown', event => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                apply((handle.parentElement?.getBoundingClientRect().width || layout.widths[id]) + (event.key === 'ArrowLeft' ? -10 : 10));
                saveLayout();
            } });
        });
        const toggle = (path) => { const set = state.expanded; set.has(path) ? set.delete(path) : set.add(path); onRender(); };
        root.querySelectorAll('[data-strategy-path][data-strategy-expandable="true"]').forEach(row => row.addEventListener('click', event => { if (event.target.closest('button,a,input,select,details,summary'))
            return; toggle(row.dataset.strategyPath || ''); }));
        root.querySelectorAll('[data-strategy-action="edit-sprint"]').forEach(cell => cell.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            cell.click();
        } }));
        actions?.bindLabelSuggestions?.(root.querySelector('#ozon-strategy-label-input'));
        root.querySelector('#ozon-strategy-label-form')?.addEventListener('submit', async (event) => { event.preventDefault(); const editor = state.editor; if (!editor || editor.busy)
            return; const input = root.querySelector('#ozon-strategy-label-input'); const label = input?.value.trim() || ''; editor.busy = true; try {
            await changeLabel(editor.key, label, 'add');
            state.editor = null;
        }
        catch (error) {
            editor.error = error.message;
        }
        finally {
            editor.busy = false;
            onRender();
        } });
        root.querySelector('#ozon-strategy-sprint-search')?.addEventListener('input', event => { const input = event.target; const pos = input.selectionStart; if (!state.editor || state.editor.kind !== 'sprint')
            return; state.editor.query = input.value; onRender(); const next = document.getElementById('ozon-strategy-sprint-search'); next?.focus({ preventScroll: true }); if (next && pos !== null)
            next.setSelectionRange(pos, pos); });
        root.querySelector('#ozon-strategy-component-editor-search')?.addEventListener('input', event => { const input = event.target; const pos = input.selectionStart; if (!state.editor || state.editor.kind !== 'component')
            return; state.editor.query = input.value; onRender(); const next = document.getElementById('ozon-strategy-component-editor-search'); next?.focus({ preventScroll: true }); if (next && pos !== null)
            next.setSelectionRange(pos, pos); });
        root.querySelector('#ozon-strategy-epic-search')?.addEventListener('input', event => { const input = event.target, editor = state.editor; if (!editor || editor.kind !== 'epic')
            return; editor.query = input.value; ++epicSearchSerial; clearTimeout(epicSearchTimer); epicSearchTimer = setTimeout(() => searchEpic(editor), 300); });
        root.querySelector('#ozon-strategy-link-search')?.addEventListener('keydown', event => { if (event.key !== 'Enter')
            return; const options = [...root.querySelectorAll('[data-strategy-action="save-link"][data-strategy-match="true"]')]; const keys = new Set(options.map(option => option.dataset.key)); if (keys.size === 1 && options[0] && !options[0].disabled) {
            event.preventDefault();
            options[0].click();
        } });
        root.querySelector('#ozon-strategy-link-search')?.addEventListener('input', event => { const input = event.target; const pos = input.selectionStart; state.editor.query = input.value; onRender(); const next = document.getElementById('ozon-strategy-link-search'); next?.focus({ preventScroll: true }); if (next && pos !== null)
            next.setSelectionRange(pos, pos); });
        root.querySelector('#ozon-strategy-create-form')?.addEventListener('submit', async (event) => { event.preventDefault(); const editor = state.editor; if (!editor || editor.busy)
            return; editor.summary = (root.querySelector('#ozon-strategy-create-name')?.value || '').trim(); editor.componentId = root.querySelector('#ozon-strategy-create-component')?.value || ''; if (!editor.summary || !editor.componentId) {
            editor.error = 'Укажите название и компонент';
            onRender();
            return;
        } editor.busy = true; editor.error = ''; onRender(); try {
            const result = await actions.create(editor.summary, editor.componentId);
            if (!result?.key)
                throw new Error('Jira не вернула ключ созданной тематики');
            state.editor = null;
            await load();
        }
        catch (error) {
            editor.error = error.message;
        }
        finally {
            editor.busy = false;
            onRender();
        } });
        root.querySelectorAll('[data-strategy-action]').forEach(button => button.addEventListener('click', async (event) => {
            event.stopPropagation();
            if (button.dataset.strategyAction === 'component-menu') {
                state.componentOpen = !state.componentOpen;
                state.issueTypeOpen = false;
                state.sortOpen = false;
                state.componentQuery = '';
                onRender();
                if (state.componentOpen)
                    document.getElementById('ozon-strategy-component-search')?.focus({ preventScroll: true });
                return;
            }
            if (button.dataset.strategyAction === 'type-menu') {
                state.issueTypeOpen = !state.issueTypeOpen;
                state.componentOpen = false;
                state.sortOpen = false;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'type-pick') {
                state.issueType = button.dataset.value || '';
                state.issueTypeOpen = false;
                state.expanded.clear();
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'component-pick') {
                state.component = button.dataset.value || '';
                state.componentOpen = false;
                state.componentQuery = '';
                state.expanded.clear();
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'details') {
                const node = buildGraph().nodes.get(button.dataset.key || '');
                if (node)
                    actions?.details?.(node);
                return;
            }
            if (button.dataset.strategyAction === 'sort-menu') {
                state.sortOpen = !state.sortOpen;
                state.issueTypeOpen = false;
                state.componentOpen = false;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'sort-pick') {
                state.sort = button.dataset.value === 'created' ? 'created' : 'priority';
                state.sortOpen = false;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'hide-canceled') {
                state.hideCanceled = !state.hideCanceled;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'hide-done') {
                state.hideDone = !state.hideDone;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'reset-filters') {
                state.search = '';
                state.component = '';
                state.issueType = '';
                state.onlyThemes = false;
                state.hideCanceled = false;
                state.hideDone = false;
                state.expanded.clear();
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'only-themes') {
                state.onlyThemes = !state.onlyThemes;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'settings-open' || button.dataset.strategyAction === 'settings-close') {
                state.settings = button.dataset.strategyAction === 'settings-open';
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'column-move') {
                const index = layout.order.indexOf(button.dataset.column || ''), next = index + Number(button.dataset.direction);
                if (index > 0 && next > 0 && next < layout.order.length) {
                    [layout.order[index], layout.order[next]] = [layout.order[next], layout.order[index]];
                    saveLayout();
                }
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'columns-reset') {
                layout.order = [...defaultOrder];
                layout.widths = { ...defaultWidths };
                layout.hidden = [...defaultHidden];
                saveLayout();
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'dismiss-notice') {
                state.notice = '';
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'reload') {
                await load();
                return;
            }
            if (button.dataset.strategyAction === 'retry-filters') {
                await prepareFilters();
                return;
            }
            if (button.dataset.strategyAction === 'toggle') {
                toggle(button.dataset.path || '');
                return;
            }
            if (button.dataset.strategyAction === 'close-editor') {
                if (!state.editor?.busy)
                    state.editor = null;
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'create') {
                const editor = { kind: 'create', key: '', loading: true, busy: false, error: '', options: [], summary: '', componentId: '' };
                state.editor = editor;
                onRender();
                try {
                    editor.options = await actions.components();
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.loading = false;
                    if (state.editor === editor)
                        onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'link') {
                const key = button.dataset.key || '';
                state.editor = { kind: 'link', key, loading: false, busy: false, error: '', query: '', allComponents: false, collapsed: new Set(), options: themeCandidates(key, false) };
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'theme-scope') {
                const editor = state.editor;
                if (!editor || editor.kind !== 'link')
                    return;
                editor.allComponents = !editor.allComponents;
                editor.options = themeCandidates(editor.key, editor.allComponents);
                editor.collapsed = new Set();
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'theme-toggle') {
                const editor = state.editor;
                if (!editor || editor.kind !== 'link')
                    return;
                const key = button.dataset.key || '';
                editor.collapsed ||= new Set();
                editor.collapsed.has(key) ? editor.collapsed.delete(key) : editor.collapsed.add(key);
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'save-link') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                editor.busy = true;
                editor.error = '';
                onRender();
                try {
                    await linkTheme(editor.key, button.dataset.key || '');
                    if (state.editor === editor)
                        state.editor = null;
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'unlink-theme') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                editor.busy = true;
                editor.error = '';
                onRender();
                try {
                    await unlinkTheme(editor.key, button.dataset.key || '', button.dataset.id || '');
                    if (state.editor === editor)
                        editor.options = themeCandidates(editor.key, Boolean(editor.allComponents));
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'edit-sprint') {
                const issue = state.issues.find(item => item.key === button.dataset.key);
                if (!issue || /^(epic|эпик)$/i.test(issue.fields?.issuetype?.name || ''))
                    return;
                const editor = { kind: 'sprint', key: button.dataset.key || '', loading: true, busy: false, error: '', query: '', options: [] };
                state.editor = editor;
                onRender();
                try {
                    editor.options = await loadEditableSprints();
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.loading = false;
                    if (state.editor === editor)
                        onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'save-sprint') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                const id = button.dataset.id || '';
                const sprint = id ? editor.options.find((sp) => String(sp.id) === id) : null;
                if (id && !sprint)
                    return;
                editor.busy = true;
                editor.error = '';
                onRender();
                try {
                    await saveSprint(editor.key, sprint);
                    if (state.editor === editor)
                        state.editor = null;
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'edit-component') {
                const editor = { kind: 'component', key: button.dataset.key || '', loading: true, busy: false, error: '', query: '', options: [] };
                state.editor = editor;
                onRender();
                try {
                    editor.options = await actions.components();
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.loading = false;
                    if (state.editor === editor)
                        onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'save-component') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                editor.busy = true;
                editor.error = '';
                onRender();
                try {
                    await saveComponent(editor.key, button.dataset.id || '');
                    if (state.editor === editor)
                        state.editor = null;
                    actions?.notify?.('Компонент задачи ' + editor.key + ' обновлён.');
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'edit-epic') {
                const editor = { kind: 'epic', key: button.dataset.key || '', loading: false, searching: true, busy: false, error: '', query: '', options: [] };
                state.editor = editor;
                onRender();
                await searchEpic(editor);
                return;
            }
            if (button.dataset.strategyAction === 'save-epic') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                editor.busy = true;
                editor.error = '';
                onRender();
                try {
                    await saveEpic(editor.key, button.dataset.key || '');
                    if (state.editor === editor)
                        state.editor = null;
                    actions?.notify?.('Epic Link задачи ' + editor.key + ' обновлён.');
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'priority' || button.dataset.strategyAction === 'labels') {
                const editor = { kind: button.dataset.strategyAction, key: button.dataset.key || '', loading: button.dataset.strategyAction === 'priority', busy: false, error: '', options: [] };
                state.editor = editor;
                onRender();
                if (editor.kind === 'priority') {
                    try {
                        editor.options = await priorityService.options(editor.key);
                    }
                    catch (error) {
                        editor.error = error.message;
                    }
                    finally {
                        editor.loading = false;
                        if (state.editor === editor)
                            onRender();
                    }
                }
                return;
            }
            if (button.dataset.strategyAction === 'save-priority') {
                const editor = state.editor;
                if (!editor || editor.busy)
                    return;
                const option = editor.options[Number(button.dataset.index)];
                if (!option)
                    return;
                editor.busy = true;
                onRender();
                try {
                    const priority = await priorityService.save(editor.key, option.value);
                    const issue = state.issues.find(item => item.key === editor.key);
                    if (issue) {
                        issue.fields.priority = priority;
                        invalidateGraph();
                    }
                    state.editor = null;
                }
                catch (error) {
                    editor.error = error.message;
                }
                finally {
                    editor.busy = false;
                    onRender();
                }
                return;
            }
            if (button.dataset.strategyAction === 'remove-label') {
                button.setAttribute('disabled', '');
                try {
                    await changeLabel(button.dataset.key || '', button.dataset.label || '', 'remove');
                }
                catch (error) {
                    state.editor = { kind: 'labels', key: button.dataset.key || '', error: error.message, busy: false, loading: false, options: [] };
                }
                onRender();
                return;
            }
            if (button.dataset.strategyAction === 'copy' || button.dataset.strategyAction === 'copy-key') {
                const key = button.dataset.key || '';
                const issue = state.issues.find(item => item.key === key);
                const url = 'https://jit.o3.ru/browse/' + key;
                try {
                    const title = issue?.fields?.summary || '';
                    const text = button.dataset.strategyAction === 'copy-key' ? key : '[' + key + '](' + url + ') ' + title;
                    if (button.dataset.strategyAction === 'copy' && window.ClipboardItem && navigator.clipboard.write) {
                        try {
                            await navigator.clipboard.write([new ClipboardItem({ 'text/plain': new Blob([text], { type: 'text/plain' }), 'text/html': new Blob(['<a href="' + url + '">' + escape(key) + '</a> ' + escape(title)], { type: 'text/html' }) })]);
                        }
                        catch (_) {
                            await navigator.clipboard.writeText(text);
                        }
                    }
                    else
                        await navigator.clipboard.writeText(text);
                    button.title = 'Скопировано';
                    button.closest('details')?.removeAttribute('open');
                    actions?.notify?.('Скопировано');
                }
                catch (_) {
                    button.title = 'Не удалось скопировать';
                }
            }
        }));
    }
    return { html, bind, load, prepareFilters, getState: () => state, buildGraph, invalidateGraph, linkTheme, unlinkTheme, saveEpic, saveComponent, loadEditableSprints, saveSprint };
})(() => { if (activeDashboardView === 'strategy') renderStructure(); }, renderBadge, "3.5.156", jiraPriorityService, CONFIG.sprintFieldId, { boardId:CONFIG.rapidViewId, components:()=>loadIssueCreateComponents(CONFIG.projectKey), create:(summary,componentId)=>createIssueFromSidebar({kind:'epic',projectKey:CONFIG.projectKey,summary,componentId}), link:(source,target)=>createIssueLinkInJira(source,target,'projectTask',true,true), notify:(message)=>{ const update=showLinksSnackbar(message); update(message); }, details:openSharedFcrmDetails, bindLabelSuggestions });
  async function openSharedFcrmDetails(link) {
    if (!/^FCRM-[0-9]+$/i.test(link.key)) return;
    if (isSidebarOpen && selectedTaskKey !== link.key && !await confirmSidebarExit()) return;
    if (!tasks.some(task => task.key === link.key)) tasks.push({
      key:link.key,summary:link.summary || link.key,description:'',status:link.status || 'todo',priority:link.priority || 'Средний',issueTypeName:link.issueType || 'Задача',
      component:'Без компонента',sprint:link.sprint?.name || 'Бэклог FCRM',epicKey:'',epicName:'',
      assignee:{name:'Не назначен'},customer:{name:'Не указан'},projectTaskLinks:[],inProjectLinks:[],otherLinks:[]
    });
    developmentDashboard.dismissEditor();
    selectedTaskKey = link.key; isSidebarOpen = true; isEditingDescription = false; collapsedSidebarSections.pt = true;
    reloadSingleTaskFromJira(link.key,true,true);
  }
  const developmentDashboard = (function createDevelopmentDashboard(onRender, onOpenTask, onBeforeEditor, renderBadge = renderJiraBadge, inferCategory, widgetVersion = '', priorityService) {
    const teams = [{ id: 'cs', name: 'CS', boardId: 6197, pointsField: '' }, { id: 'crm_core', name: 'CRM_CORE', boardId: 7180, pointsField: '' }, { id: 'crm_bo', name: 'CRM_BO', boardId: 12696, pointsField: '' }];
    const state = {
        teamId: '', teamIds: [], sprints: [], selected: [], groups: [],
        loadingSprints: false, loadingTasks: false, closedLoaded: false,
        error: '', progress: '', sprintQuery: '', teamOpen: false, sprintsOpen: false,
        collapsed: new Set(), loadedSelection: [],
        grouping: ['sprint', 'project', 'epic'], depth: 0,
        expandedGroups: new Set(), expandedLinks: new Set(),
        menu: '', epicFilter: '', streamFilter: '', projectFilter: '', filterQuery: '',
        editor: null,
    };
    let settingsDraft = null;
    let settingsScroll = 0;
    let serial = 0;
    let controller = null;
    let pointsField = '';
    let sprintField = '';
    let epicField = '';
    let epicNameField = '';
    let editorRequest = 0;
    const componentOptionsCache = new Map();
    let issueLinkTypesPromise = null;
    let jiraFieldsPromise = null;
    let epicCatalogPromise = null;
    let epicCatalogItems = [];
    let epicCatalogUpdate = null;
    async function getJiraFields() {
        if (!jiraFieldsPromise)
            jiraFieldsPromise = json('/rest/api/2/field', new AbortController().signal)
                .catch((error) => { jiraFieldsPromise = null; throw error; });
        return jiraFieldsPromise;
    }
    async function getIssueLinkTypes() {
        if (!issueLinkTypesPromise)
            issueLinkTypesPromise = json('/rest/api/2/issueLinkType', new AbortController().signal)
                .then((data) => Array.isArray(data.issueLinkTypes) ? data.issueLinkTypes : [])
                .catch((error) => { issueLinkTypesPromise = null; throw error; });
        return issueLinkTypesPromise;
    }
    const baseColumns = { key: ['Ключ', 285], title: ['Название', 430], epic: ['Epic Link', 170], status: ['Статус', 175], sprint: ['Спринт', 235], component: ['Компонент', 180], points: ['Story Points', 120] };
    const defaultColumnOrder = ['key', 'title', 'epic', 'status', 'sprint', 'component', 'points'];
    const layout = { detailsOpen: true, epicDisplay: 'full', order: [...defaultColumnOrder], children: [0, 1, 2, 3, 4, 5], widths: {} };
    try {
        const saved = JSON.parse(localStorage.getItem('ozon-dev-columns') || 'null');
        if (saved) {
            if (typeof saved.detailsOpen === 'boolean')
                layout.detailsOpen = saved.detailsOpen;
            if (['key', 'status', 'full'].includes(saved.epicDisplay))
                layout.epicDisplay = saved.epicDisplay;
            if (Array.isArray(saved.order)) {
                const savedOrder = saved.order;
                layout.order = [...new Set(savedOrder.filter(id => id in baseColumns)), ...defaultColumnOrder.filter(id => !savedOrder.includes(id))];
            }
            if (Array.isArray(saved.children) && saved.children.length === 6 && new Set(saved.children).size === 6 && saved.children.every((id) => Number.isInteger(id) && id >= 0 && id < 6))
                layout.children = saved.children;
            Object.entries(saved.widths || {}).forEach(([id, width]) => { if (Number.isFinite(width))
                layout.widths[id] = Math.max(70, Math.min(1000, Number(width))); });
        }
    }
    catch (_) { /* Storage may be unavailable in a preview or restricted Jira page. */ }
    const saveLayout = () => { try {
        localStorage.setItem('ozon-dev-columns', JSON.stringify(layout));
    }
    catch (_) { /* Layout still works in memory. */ } };
    function moveColumn(id, direction, child = false) {
        const order = child ? layout.children.map(String) : [...layout.order];
        const from = order.indexOf(id);
        const to = from + direction;
        if (from < 0 || to < 0 || to >= order.length)
            return;
        [order[from], order[to]] = [order[to], order[from]];
        if (child)
            layout.children = order.map(Number);
        else
            layout.order = order;
        saveLayout();
        onRender();
    }
    const columns = [
        ['Продукты', 'Story Points задач, у эпика которых customfield_24000 = «Стрим 1».'],
        ['Внепроектное', 'Story Points задач со «Стрим 2» у эпика, кроме эпика OBPROJECT-5201.'],
        ['Внепроектные баги', 'Story Points задач с Epic Link = OBPROJECT-5201, независимо от типа задачи.'],
        ['Проектное', 'Story Points задач, у эпика которых customfield_24000 = «Стрим 3».'],
        ['Технострим', 'Story Points задач, у эпика которых customfield_24000 = «Стрим 4».'],
        ['Роузи', 'Story Points задач, у эпика которых customfield_24000 = «Стрим 5».'],
    ];
    const escape = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    const selectedTeams = () => teams.filter(item => state.teamIds.includes(item.id));
    const team = () => teams.find(item => item.id === state.teamId);
    function cancel() {
        ++serial;
        controller?.abort();
        controller = null;
        state.loadingTasks = false;
        state.loadingSprints = false;
        state.editor = null;
        ++editorRequest;
    }
    async function json(url, signal) {
        const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }, signal });
        if (!response.ok)
            throw new Error('Не удалось получить данные Jira (HTTP ' + response.status + ')');
        return response.json();
    }
    async function pages(url, property, signal) {
        const result = [];
        const seen = new Set();
        let startAt = 0;
        while (true) {
            const data = await json(url + (url.includes('?') ? '&' : '?') + 'startAt=' + startAt + '&maxResults=100', signal);
            const items = data[property];
            if (!Array.isArray(items))
                throw new Error('Jira вернула данные в неизвестном формате');
            if (!items.length) {
                if (Number(data.total) > startAt)
                    throw new Error('Jira вернула неполную страницу результатов. Повторите загрузку.');
                break;
            }
            const fingerprint = items.map((item) => item.id || item.key).join(',');
            if (seen.has(fingerprint))
                throw new Error('Jira повторяет страницу результатов. Повторите загрузку.');
            seen.add(fingerprint);
            result.push(...items);
            startAt += items.length;
            if (data.isLast === true || (typeof data.total === 'number' && startAt >= data.total))
                break;
            if (data.isLast !== false && typeof data.total !== 'number' && items.length < Number(data.maxResults || 100))
                break;
        }
        return result;
    }
    const sprintSort = (a, b) => {
        const order = { active: 0, future: 1, backlog: 2, closed: 3 };
        const rank = (order[a.state] ?? 3) - (order[b.state] ?? 3);
        if (rank)
            return rank;
        const dates = (Date.parse(a.startDate || '') || 0) - (Date.parse(b.startDate || '') || 0);
        return (a.state === 'closed' ? -dates : dates) || a.name.localeCompare(b.name, 'ru', { numeric: true });
    };
    async function selectTeam(id, keepOpen = false) {
        cancel();
        state.teamIds = (Array.isArray(id) ? id : [id]).filter(value => teams.some(item => item.id === value));
        state.teamId = state.teamIds[0] || '';
        state.selected = [];
        state.groups = [];
        state.loadedSelection = [];
        state.sprints = [];
        state.closedLoaded = false;
        state.epicFilter = '';
        state.streamFilter = '';
        state.menu = '';
        state.expandedLinks.clear();
        state.collapsed.clear();
        state.expandedGroups.clear();
        state.error = '';
        state.teamOpen = keepOpen;
        state.sprintsOpen = false;
        pointsField = '';
        if (!team()) {
            onRender();
            return;
        }
        state.loadingSprints = true;
        onRender();
        controller = new AbortController();
        const current = serial;
        try {
            const fields = await getJiraFields();
            if (current !== serial)
                return;
            const selected = selectedTeams();
            const result = (await Promise.all(selected.map(async (selectedTeam) => {
                if (!selectedTeam.boardId) {
                    const matches = await pages('/rest/agile/1.0/board?type=scrum&name=' + encodeURIComponent(selectedTeam.name), 'values', controller.signal);
                    if (current !== serial)
                        return;
                    const normalized = (name) => name.toUpperCase().replace(/[^A-Z0-9]/g, '');
                    const exact = matches.filter(board => normalized(board.name || '') === normalized(selectedTeam.name));
                    if (exact.length !== 1)
                        throw new Error('Не удалось однозначно определить доску команды ' + selectedTeam.name + '. В Jira должна быть одна Scrum-доска с этим названием.');
                    selectedTeam.boardId = Number(exact[0].id);
                }
                const boardId = selectedTeam.boardId;
                const [configuration, sprints] = await Promise.all([json('/rest/agile/1.0/board/' + boardId + '/configuration', controller.signal), pages('/rest/agile/1.0/board/' + boardId + '/sprint?state=active,future', 'values', controller.signal)]);
                if (current !== serial)
                    return;
                const field = configuration.estimation?.field?.fieldId;
                if (!field)
                    throw new Error('Для доски ' + selectedTeam.name + ' не настроена оценка Story Points.');
                selectedTeam.pointsField = field;
                return sprints.filter(item => Number(item.originBoardId) === boardId).map(item => ({ ...item, boardId, pointsField: field, teamName: selectedTeam.name }));
            }))).flat();
            if (current !== serial)
                return;
            // Keep the fallback deterministic; the per-team requests above finish in arbitrary order.
            pointsField = selected[0]?.pointsField || '';
            sprintField = fields.find((field) => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-sprint')?.id || '';
            epicField = fields.find((field) => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-epic-link')?.id || fields.find((field) => /^(epic link|ссылка на эпик)$/i.test(String(field.name || field.untranslatedName || '').trim()))?.id || '';
            epicNameField = fields.find((field) => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-epic-label')?.id || fields.find((field) => /^epic name$/i.test(String(field.name || field.untranslatedName || '').trim()))?.id || '';
            const backlogOptions = selected.map(item => ({ id: 'backlog-' + item.id, name: 'Бэклог · ' + item.name, state: 'backlog', boardId: item.boardId, pointsField: item.pointsField, teamName: item.name, isBacklog: true }));
            state.sprints = Array.from(new Map([...result, ...backlogOptions].map(item => [String(item.id), item])).values()).sort(sprintSort);
        }
        catch (error) {
            if (current === serial && error.name !== 'AbortError')
                state.error = error.message;
        }
        finally {
            if (current === serial) {
                state.loadingSprints = false;
                onRender();
            }
        }
    }
    async function loadClosedSprints() {
        if (!team() || state.loadingSprints || state.loadingTasks || state.closedLoaded)
            return;
        cancel();
        const current = serial;
        controller = new AbortController();
        state.loadingSprints = true;
        state.error = '';
        onRender();
        try {
            const unique = new Map(state.sprints.map(sprint => [String(sprint.id), sprint]));
            const closedByTeam = await Promise.all(selectedTeams().map(async (selectedTeam) => {
                const boardId = selectedTeam.boardId;
                const closed = await pages('/rest/agile/1.0/board/' + boardId + '/sprint?state=closed', 'values', controller.signal);
                return closed.filter(item => Number(item.originBoardId) === boardId).map(item => ({ ...item, boardId, pointsField: selectedTeam.pointsField, teamName: selectedTeam.name }));
            }));
            if (current !== serial)
                return;
            closedByTeam.flat().forEach(item => unique.set(String(item.id), item));
            state.sprints = Array.from(unique.values()).sort(sprintSort);
            state.closedLoaded = true;
        }
        catch (error) {
            if (current === serial && error.name !== 'AbortError')
                state.error = error.message;
        }
        finally {
            if (current === serial) {
                state.loadingSprints = false;
                onRender();
            }
        }
    }
    function setSelection(ids) {
        // Selection never loads issues. Discard results for the previous selection.
        const scrollTop = document.querySelector('.ozon-dev-sprints .ozon-dev-sprint-list')?.scrollTop || 0;
        cancel();
        const allowed = new Set(state.sprints.map(sprint => String(sprint.id)));
        state.selected = [...new Set(ids.filter(id => allowed.has(String(id))).map(String))];
        state.epicFilter = '';
        state.streamFilter = '';
        state.menu = '';
        state.groups = [];
        state.loadedSelection = [];
        state.error = '';
        onRender();
        const list = document.querySelector('.ozon-dev-sprints .ozon-dev-sprint-list');
        if (list)
            list.scrollTop = scrollTop;
    }
    function normalizeIssue(issue, estimateField = pointsField) {
        const fields = issue.fields || {};
        const epic = fields.epic && typeof fields.epic === 'object' ? fields.epic : null;
        const rawPoints = fields[estimateField];
        const numeric = typeof rawPoints === 'number' || (typeof rawPoints === 'string' && rawPoints.trim() !== '') ? Number(rawPoints) : NaN;
        return {
            key: String(issue.key), summary: String(fields.summary || issue.key),
            epicKey: epic?.key || fields.parent?.key || (typeof fields[epicField] === 'string' ? fields[epicField] : fields[epicField]?.key || fields[epicField]?.value) || '', epicTitle: epic?.summary || epic?.name || fields.parent?.fields?.summary || '',
            epicStatus: '', epicCategory: '',
            project: fields.project?.key || String(issue.key).split('-')[0],
            componentId: fields.components?.[0]?.id ? String(fields.components[0].id) : '',
            componentNames: Array.isArray(fields.components) ? fields.components.map((item) => item.name).filter(Boolean) : [],
            component: fields.components?.map((item) => item.name).filter(Boolean).join(', ') || 'Без компонента',
            labels: Array.isArray(fields.labels) ? fields.labels : [],
            priority: String(fields.priority?.name || 'Не указан'), issueType: String(fields.issuetype?.name || 'Задача'),
            links: (fields.issuelinks || []).flatMap((link) => {
                const target = link.outwardIssue || link.inwardIssue;
                if (!target?.key)
                    return [];
                const type = link.type || {};
                return [{ key: target.key, summary: target.fields?.summary || target.key, status: target.fields?.status?.name || 'Статус недоступен', category: target.fields?.status?.statusCategory?.key || '', projectTask: /задача проекта|project task/i.test([type.name, type.inward, type.outward].join(' ')) }];
            }),
            points: Number.isFinite(numeric) ? numeric : null,
            status: fields.status?.name || 'Статус недоступен', category: fields.status?.statusCategory?.key || '',
            history: [...(Array.isArray(fields[sprintField]) ? fields[sprintField] : []), ...(Array.isArray(fields.closedSprints) ? fields.closedSprints : []), ...(fields.sprint ? [fields.sprint] : [])],
            stream: '', allocations: [],
        };
    }
    function parseSprint(value) {
        if (value && typeof value === 'object')
            return value;
        if (typeof value !== 'string')
            return null;
        // Older Jira versions serialize the Sprint field as GreenHopper strings.
        const get = (name) => new RegExp('(?:\\[|,)' + name + '=([^,\\]]*)').exec(value)?.[1];
        const id = get('id');
        return id ? { id, startDate: get('startDate'), name: get('name'), state: String(get('state') || '').toLowerCase() } : null;
    }
    function lastSprint(history) {
        return history.map(parseSprint).filter(item => item?.id).sort((a, b) => {
            const aDate = Date.parse(a.startDate || '');
            const bDate = Date.parse(b.startDate || '');
            // Jira does not order closedSprints chronologically. Never take its last array item.
            return Number.isFinite(aDate) && Number.isFinite(bDate) && aDate !== bDate ? aDate - bDate : Number(a.id) - Number(b.id);
        }).at(-1);
    }
    function allocate(issue) {
        const matches = [issue.stream === 'Стрим 1', issue.stream === 'Стрим 2' && issue.epicKey !== 'OBPROJECT-5201', issue.epicKey === 'OBPROJECT-5201', issue.stream === 'Стрим 3', issue.stream === 'Стрим 4', issue.stream === 'Стрим 5'];
        issue.allocations = matches.map(match => match ? issue.points : null);
    }
    async function loadTasks() {
        if (!team() || !pointsField || !state.selected.length || state.loadingSprints || state.loadingTasks)
            return;
        cancel();
        const current = serial;
        controller = new AbortController();
        const signal = controller.signal;
        const selected = [...state.selected];
        const groups = [];
        state.groups = [];
        state.loadedSelection = [];
        state.error = '';
        state.loadingTasks = true;
        state.menu = '';
        state.sprintsOpen = false;
        onRender();
        try {
            for (let index = 0; index < selected.length; index++) {
                const sprint = state.sprints.find(item => String(item.id) === selected[index]);
                if (!sprint)
                    throw new Error('Выбранный спринт больше недоступен. Обновите список.');
                state.progress = 'Загружаем спринт ' + (index + 1) + ' из ' + selected.length + ': ' + sprint.name;
                onRender();
                const fields = encodeURIComponent(['summary', 'status', 'epic', 'parent', epicField, epicNameField, 'project', 'priority', 'issuelinks', 'sprint', 'closedSprints', 'components', 'labels', sprintField, sprint.pointsField || pointsField].filter(Boolean).join(','));
                const endpoint = sprint.isBacklog ? '/rest/agile/1.0/board/' + sprint.boardId + '/backlog' : '/rest/agile/1.0/board/' + (sprint.boardId || sprint.originBoardId) + '/sprint/' + encodeURIComponent(sprint.id) + '/issue';
                const raw = await pages(endpoint + '?fields=' + fields, 'issues', signal);
                if (current !== serial)
                    return;
                const issues = Array.from(new Map(raw.filter(item => item.key).map(item => [item.key, normalizeIssue(item, sprint.pointsField || pointsField)])).values());
                groups.push({ sprint, issues });
            }
            if (current !== serial)
                return;
            const unique = new Map();
            groups.forEach(group => group.issues.forEach((issue) => {
                const previous = unique.get(issue.key);
                if (previous) {
                    previous.history.push(...issue.history, ...(group.sprint.isBacklog ? [] : [group.sprint]));
                    if (group.sprint.isBacklog)
                        previous.backlogIds.push(String(group.sprint.id));
                }
                else
                    unique.set(issue.key, { ...issue, history: [...issue.history, ...(group.sprint.isBacklog ? [] : [group.sprint])], backlogIds: group.sprint.isBacklog ? [String(group.sprint.id)] : [] });
            }));
            const epicKeys = [...new Set([...unique.values()].flatMap(issue => [issue.epicKey, ...issue.links.map((link) => link.key)]).filter(Boolean))];
            const epics = new Map();
            for (let index = 0; index < epicKeys.length; index += 50) {
                state.progress = 'Получаем эпики и связи: ' + Math.min(index + 50, epicKeys.length) + ' из ' + epicKeys.length;
                onRender();
                const jql = 'key in (' + epicKeys.slice(index, index + 50).map(key => '"' + String(key).replace(/[^A-Za-z0-9-]/g, '') + '"').join(',') + ')';
                const result = await pages('/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&fields=' + encodeURIComponent(['summary', 'status', 'issuetype', 'priority', 'customfield_24000', 'sprint', 'closedSprints', 'components', 'labels', 'epic', 'parent', epicField, epicNameField, sprintField].filter(Boolean).join(',')), 'issues', signal);
                if (current !== serial)
                    return;
                result.forEach(epic => epics.set(epic.key, epic.fields || {}));
            }
            const relatedEpicKeys = [...new Set([...epics.values()].map(fields => normalizeIssue({ key: 'RELATED-0', fields }).epicKey).filter(key => key && !epics.has(key)))];
            for (let index = 0; index < relatedEpicKeys.length; index += 50) {
                const jql = 'key in (' + relatedEpicKeys.slice(index, index + 50).map(key => '"' + String(key).replace(/[^A-Za-z0-9-]/g, '') + '"').join(',') + ')';
                const found = await pages('/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&fields=summary,status', 'issues', signal);
                if (current !== serial)
                    return;
                found.forEach(item => epics.set(item.key, item.fields || {}));
            }
            unique.forEach(issue => {
                const epic = epics.get(issue.epicKey);
                const stream = epic?.customfield_24000;
                issue.stream = typeof stream === 'string' ? stream : stream?.value || '';
                if (epic?.summary)
                    issue.epicTitle = epic.summary;
                issue.epicType = epic?.issuetype?.name || '';
                issue.epicPriority = epic?.priority?.name || '';
                issue.epicStatus = epic?.status?.name || 'Статус недоступен';
                issue.epicCategory = epic?.status?.statusCategory?.key || '';
                issue.epicComponent = (epic?.components || []).map((component) => component.name).filter(Boolean).join(', ');
                issue.links.forEach((link) => {
                    const target = epics.get(link.key);
                    if (target?.summary)
                        link.summary = target.summary;
                    if (target?.status) {
                        link.status = target.status.name;
                        link.category = target.status.statusCategory?.key || '';
                    }
                    link.priority = target?.priority?.name || 'Не указан';
                    link.issueType = target?.issuetype?.name || 'Задача';
                    link.component = Array.isArray(target?.components) ? target.components.map((component) => component.name).filter(Boolean).join(', ') || 'Без компонента' : 'Без компонента';
                    const related = normalizeIssue({ key: link.key, fields: target || {} });
                    link.epicKey = related.epicKey;
                    const relatedEpic = epics.get(link.epicKey);
                    link.epicTitle = relatedEpic?.summary || related.epicTitle || '';
                    link.epicStatus = relatedEpic?.status?.name || '';
                    link.epicCategory = relatedEpic?.status?.statusCategory?.key || '';
                    link.sprint = lastSprint([...(target?.[sprintField] || []), ...(target?.closedSprints || []), ...(target?.sprint ? [target.sprint] : [])]);
                });
                allocate(issue);
                issue.lastSprintId = String(lastSprint(issue.history)?.id || '');
            });
            groups.forEach(group => {
                group.issues = [...unique.values()].filter(issue => {
                    const latest = lastSprint(issue.history);
                    if (group.sprint.isBacklog)
                        return issue.backlogIds.includes(String(group.sprint.id)) && !['active', 'future'].includes(String(latest?.state || '').toLowerCase()) && issue.backlogIds[0] === String(group.sprint.id);
                    if (issue.backlogIds.length && !['active', 'future'].includes(String(latest?.state || '').toLowerCase()))
                        return false;
                    return issue.lastSprintId === String(group.sprint.id);
                });
            });
            state.groups = groups;
            state.loadedSelection = selected;
        }
        catch (error) {
            if (current === serial && error.name !== 'AbortError')
                state.error = error.message;
        }
        finally {
            if (current === serial) {
                state.loadingTasks = false;
                state.progress = '';
                onRender();
            }
        }
    }
    function badge(name, category) {
        return renderBadge(escape(name), category || inferCategory?.(name) || 'todo');
    }
    const stateName = (value) => ({ active: 'Активный', future: 'Будущий', closed: 'Прошедший', backlog: 'Бэклог' }[value] || value);
    const issueLink = (key) => '<a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(key) + '" target="_blank" rel="noopener noreferrer">' + escape(key) + '</a>';
    const flatColumns = () => layout.order.flatMap(id => id === 'points' ? ['points', ...(layout.detailsOpen ? layout.children.map(index => 'metric-' + index) : [])] : [id]);
    const columnWidth = (id) => layout.widths[id] || baseColumns[id]?.[1] || 145;
    function rowCells(values) {
        return flatColumns().map(id => '<td data-column="' + id + '"' + (id === 'points' || id.startsWith('metric-') ? ' class="ozon-dev-points"' : '') + '>' + (values[id] || '') + '</td>').join('');
    }
    function groupCells(label, items, epicStatusHtml = '', componentHtml = '') {
        const ids = flatColumns();
        // Merge the longest run outside the SP family, whatever column order the user chose.
        let bestStart = 0, bestLength = 0, start = 0, length = 0;
        ids.forEach((id, index) => {
            if (id === 'points' || id.startsWith('metric-') || (epicStatusHtml && id === 'status') || (componentHtml && id === 'component')) {
                length = 0;
                return;
            }
            if (!length)
                start = index;
            length++;
            if (length > bestLength) {
                bestStart = start;
                bestLength = length;
            }
        });
        return ids.map((id, index) => {
            if (index === bestStart)
                return '<td colspan="' + bestLength + '">' + label + '</td>';
            if (index > bestStart && index < bestStart + bestLength)
                return '';
            return '<td data-column="' + id + '"' + (id === 'component' ? '' : ' class="ozon-dev-points"') + '>' + (id === 'status' ? epicStatusHtml : id === 'component' ? componentHtml : id === 'points' ? pointPair(items) : id.startsWith('metric-') ? pointPair(items, Number(id.slice(7))) : '') + '</td>';
        }).join('');
    }
    function sprintHtml(sprint, key = '') {
        const content = sprint?.name ? '<div class="ozon-dev-epic-inline ozon-dev-sprint-value" title="' + escape(sprint.name) + '"><span class="ozon-dev-ellipsis">' + escape(sprint.name) + '</span>' + (sprint.state ? badge(stateName(sprint.state), sprint.state) : '') + '</div>' : '<span class="ozon-ext-group-total">Не в спринте</span>';
        return key ? '<button class="ozon-dev-cell-edit" data-dev-action="edit-sprint" data-key="' + escape(key) + '" aria-label="Изменить спринт ' + escape(key) + '">' + content + '<span class="ozon-ext-toolbar-chevron"></span></button>' : content;
    }
    function pointPair(items, index = -1) {
        const value = (issue) => index < 0 ? issue.points : issue.allocations[index] ?? null;
        const assessed = items.filter(issue => value(issue) !== null);
        if (!assessed.length)
            return '<span title="Нет оценки">—</span>';
        const total = assessed.reduce((sum, issue) => sum + value(issue), 0);
        const burned = assessed.filter(issue => issue.category === 'done').reduce((sum, issue) => sum + value(issue), 0);
        const allPoints = index < 0 ? 0 : items.reduce((sum, issue) => sum + (Number.isFinite(issue.points) ? issue.points : 0), 0);
        const percent = index < 0 ? (total > 0 ? Math.round(burned / total * 1000) / 10 : null) : (allPoints > 0 ? Math.round(total / allPoints * 1000) / 10 : null);
        const percentLabel = percent === null ? '' : String(percent).replace('.', ',') + '%';
        const percentDescription = index < 0 ? 'доля сожжённых SP' : 'доля от всех SP в этой строке';
        return '<span class="ozon-dev-point-pair" aria-label="Всего ' + total + ', сожжено ' + burned + (percentLabel ? ', ' + percentDescription + ' ' + percentLabel : '') + '" title="Всего / Сожжено. Сожжено — SP задач в категории Jira «Готово».' + (percentLabel ? ' ' + percentDescription + ': ' + percentLabel + '.' : '') + '"><span>' + total + '</span><span class="ozon-dev-points-divider"> / </span><span class="ozon-dev-burned">' + burned + '</span>' + (percentLabel ? ' <span class="ozon-dev-point-percent">' + percentLabel + '</span>' : '') + '</span>';
    }
    const groupNames = { sprint: 'Спринт', project: 'Проект', epic: 'Epic', stream: 'Стрим', component: 'Компонент' };
    function visibleIssues() {
        return state.groups.flatMap(group => group.issues.map((issue) => ({ ...issue, sprint: group.sprint }))).filter(issue => (!state.projectFilter || issue.project === state.projectFilter) && (!state.epicFilter || (state.epicFilter === '__none' ? !issue.epicKey : issue.epicKey === state.epicFilter)) &&
            (!state.streamFilter || (state.streamFilter === '__none' ? !issue.stream : issue.stream === state.streamFilter)));
    }
    function setGrouping(order) {
        state.grouping = [...new Set(order.filter(value => ['sprint', 'project', 'epic', 'stream', 'component'].includes(value)))];
        state.depth = state.grouping.length;
        state.collapsed.clear();
        state.expandedGroups.clear();
        onRender();
    }
    function setDepth(depth) {
        state.depth = Math.max(0, Math.min(state.grouping.length, depth));
        state.collapsed.clear();
        state.expandedGroups.clear();
        state.expandedLinks.clear();
        onRender();
    }
    function statusSummary(items) {
        const statuses = new Map();
        items.forEach(issue => statuses.set(issue.status, (statuses.get(issue.status) || 0) + 1));
        return '<span class="ozon-ext-status-summary" aria-label="Сводка по статусам">' + [...statuses].map(([name, count]) => '<span class="ozon-ext-status-count">' + escape(name) + ' · ' + count + '</span>').join('') + '</span>';
    }
    function epicHtml(issue) {
        const content = issue.epicKey ? issueLink(issue.epicKey) + (layout.epicDisplay !== 'key' && issue.epicStatus ? badge(issue.epicStatus, issue.epicCategory) : '') + (layout.epicDisplay === 'full' ? '<span class="ozon-dev-ellipsis">' + escape(issue.epicTitle) + '</span>' : '') : '<span class="ozon-dev-ellipsis" style="color:#D92D20;">Без эпика</span>';
        return '<div class="ozon-dev-epic-inline ozon-dev-cell-edit" role="button" tabindex="0" data-dev-action="edit-epic" data-key="' + escape(issue.key) + '" aria-label="Изменить эпик ' + escape(issue.key) + '" title="' + escape([issue.epicKey, issue.epicStatus, issue.epicTitle].filter(Boolean).join(' · ')) + '">' + content + '<span class="ozon-ext-toolbar-chevron"></span></div>';
    }
    function indicators(issue) {
        const projectLinks = issue.links.filter((link) => link.projectTask);
        const missing = !projectLinks.length;
        const chain = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m10 13 4-4M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 8l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/></svg>';
        const linkTitle = missing ? 'Нет связи «Задача проекта»' : 'Задача проекта: ' + projectLinks.map((link) => link.key).join(', ');
        let html = '<span class="ozon-dev-indicator ' + (missing ? 'missing' : 'done') + '" role="img" aria-label="' + escape(linkTitle) + '" title="' + escape(linkTitle) + '">' + chain + '</span>';
        if (issue.project === 'OBFRONT') {
            const designs = issue.links.filter((link) => /^FTD-\d+$/i.test(link.key) && !/отмен|cancel/i.test(link.status));
            const color = !designs.length ? 'absent' : designs.every((link) => link.category === 'done' || /^(готово|закрыт[ао]?|done|closed)$/i.test(link.status)) ? 'done' : 'active';
            const title = 'Дизайн: ' + (!designs.length ? 'нет задач' : color === 'done' ? 'все задачи закрыты' : 'есть незакрытые задачи') + (designs.length ? ' · ' + designs.map((link) => link.key + ' — ' + link.status).join('; ') : '');
            html += '<span class="ozon-dev-indicator ' + color + '" role="img" aria-label="' + escape(title) + '" title="' + escape(title) + '"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20c2 0 2-2 1-3s-1-3 1-3h2a6 6 0 0 0 6-6c0-4-5-8-10-8Z"/><circle cx="7" cy="10" r="1"/><circle cx="10" cy="6" r="1"/><circle cx="16" cy="7" r="1"/></svg></span>';
        }
        return html;
    }
    function priorityHtml(name) {
        const high = /highest|blocker|critical|крит|блок|наивыс/i.test(name);
        const raised = high || /high|высок/i.test(name);
        const low = /low|низк/i.test(name);
        const path = raised ? '<path d="m6 14 6-6 6 6"/>' + (high ? '<path d="m6 19 6-6 6 6"/>' : '') : low ? '<path d="m6 8 6 6 6-6"/>' : '<path d="M5 10h14M5 15h14"/>';
        return '<span class="ozon-dev-priority" role="img" aria-label="Приоритет: ' + escape(name) + '" title="Приоритет: ' + escape(name) + '" style="color:' + (raised ? '#E5484D' : low ? '#005BFF' : '#D97706') + '"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' + path + '</svg></span>';
    }
    function priorityRank(name) {
        if (/highest|blocker|critical|крит|блок|наивыс/i.test(name))
            return 0;
        if (/high|высок/i.test(name))
            return 1;
        if (/medium|normal|standard|средн|стандарт|обычн/i.test(name))
            return 2;
        if (/low|низк/i.test(name))
            return 3;
        return 4;
    }
    function taskRows(items, level) {
        return [...items].sort((a, b) => priorityRank(a.priority || '') - priorityRank(b.priority || '') || a.key.localeCompare(b.key, 'ru', { numeric: true })).map(issue => {
            const expanded = state.expandedLinks.has(issue.key);
            const key = escape(issue.key);
            const values = {
                key: '<div class="ozon-dev-task-key" style="padding-left:' + level * 18 + 'px;"><button class="ozon-dev-link-toggle" data-dev-action="links" data-key="' + key + '" aria-label="Связи «Задача проекта» для ' + key + '" aria-expanded="' + expanded + '">' + (expanded ? '▾' : '▸') + '</button>' + issueLink(issue.key) + '<span class="ozon-ext-type-pill">' + escape(issue.issueType || 'Задача') + '</span><button type="button" class="ozon-dev-priority-edit" data-dev-action="edit-priority" data-key="' + key + '" aria-label="Изменить приоритет ' + key + '">' + priorityHtml(issue.priority) + '</button></div>',
                title: '<div class="ozon-dev-task-title"><span class="ozon-dev-ellipsis" title="' + escape(issue.summary) + '">' + escape(issue.summary) + '</span><span class="ozon-dev-indicators">' + indicators(issue) + '</span></div>',
                epic: epicHtml(issue), status: badge(issue.status, issue.category), sprint: sprintHtml(issue.sprint, issue.key), component: '<button class="ozon-dev-cell-edit" data-dev-action="edit-component" data-key="' + key + '" aria-label="Изменить компонент ' + key + '" title="' + escape(issue.component || 'Без компонента') + '"><span class="ozon-dev-ellipsis">' + escape(issue.component || 'Без компонента') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>', points: pointPair([issue]),
            };
            columns.forEach((_, index) => { values['metric-' + index] = pointPair([issue], index); });
            let html = '<tr data-dev-row="links" class="ozon-dev-task ozon-tree-depth-' + (level % 2) + ' ' + (!issue.epicKey ? 'ozon-dev-no-epic' : issue.category === 'done' ? 'ozon-dev-completed' : '') + '">' + rowCells(values) + '</tr>';
            if (expanded) {
                const links = issue.links.filter((link) => link.projectTask);
                html += links.length ? links.map((link) => '<tr class="ozon-dev-related ozon-tree-depth-' + ((level + 1) % 2) + ' ' + (link.category === 'done' ? 'ozon-dev-completed' : '') + '">' + rowCells({
                    key: '<div class="ozon-dev-task-key" style="padding-left:' + (level + 1) * 18 + 'px;"><span style="color:#94A3B8;">↳</span><span class="ozon-ext-link-type-tag" role="img" aria-label="Задача проекта" title="Тип связи: Задача проекта"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#64748B" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/></svg></span>' + issueLink(link.key) + '<span class="ozon-ext-type-pill"><span style="color:#005BFF;">●</span> ' + escape(link.issueType || 'Задача') + '</span><button type="button" class="ozon-dev-priority-edit" data-priority-key="' + escape(link.key) + '" title="Изменить приоритет: ' + escape(link.priority || 'Не указан') + '" aria-label="Изменить приоритет ' + escape(link.key) + '">' + priorityHtml(link.priority || 'Не указан') + '</button></div>',
                    title: '<div class="ozon-dev-task-title"><span class="ozon-dev-ellipsis" title="' + escape(link.summary) + '">' + escape(link.summary) + '</span>' + (/^FCRM-/i.test(link.key) ? '<button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="open-fcrm" data-key="' + escape(link.key) + '">Детали</button>' : '') + '</div>',
                    epic: link.epicKey ? '<div class="ozon-dev-epic-inline" title="' + escape([link.epicKey, link.epicStatus, link.epicTitle].filter(Boolean).join(' · ')) + '">' + issueLink(link.epicKey) + (layout.epicDisplay !== 'key' && link.epicStatus ? badge(link.epicStatus, link.epicCategory) : '') + (layout.epicDisplay === 'full' ? '<span class="ozon-dev-ellipsis">' + escape(link.epicTitle) + '</span>' : '') + '</div>' : '', status: badge(link.status, link.category), sprint: sprintHtml(link.sprint), component: '<span class="ozon-dev-ellipsis" title="' + escape(link.component || 'Без компонента') + '">' + escape(link.component || 'Без компонента') + '</span>',
                }) + '</tr>').join('') : '<tr class="ozon-dev-related"><td colspan="' + flatColumns().length + '" style="padding-left:' + ((level + 1) * 18 + 12) + 'px;color:#D92D20;">Нет связей «Задача проекта» <button class="ozon-ext-btn" data-dev-action="edit-link" data-key="' + key + '">Связать с FCRM</button></td></tr>';
            }
            return html;
        }).join('');
    }
    function renderGroups(items, level = 0, path = '') {
        if (level >= state.grouping.length)
            return taskRows(items, level);
        const dimension = state.grouping[level];
        const groups = new Map();
        items.forEach(issue => {
            const keys = dimension === 'component' ? (issue.componentNames?.length ? issue.componentNames : ['Без компонента']) : [String(dimension === 'sprint' ? issue.sprint.id : dimension === 'project' ? issue.project : dimension === 'stream' ? issue.stream : issue.epicKey || '')];
            keys.forEach((key) => { if (!groups.has(key))
                groups.set(key, []); groups.get(key).push(issue); });
        });
        return [...groups].sort(([a], [b]) => !a ? 1 : !b ? -1 : dimension === 'sprint' ? sprintSort(groups.get(a)[0].sprint, groups.get(b)[0].sprint) : a.localeCompare(b, 'ru', { numeric: true })).map(([key, children]) => {
            const groupId = path + '/' + dimension + ':' + key;
            const closed = state.collapsed.has(groupId) || (level >= state.depth && !state.expandedGroups.has(groupId));
            const first = children[0];
            const priorityControl = dimension === 'epic' && key ? '<button type="button" class="ozon-dev-priority-edit" data-priority-key="' + escape(key) + '" title="Изменить приоритет: ' + escape(first.epicPriority || 'Не указан') + '" aria-label="Изменить приоритет ' + escape(key) + '">' + (first.epicPriority ? priorityHtml(first.epicPriority) : '·') + '</button>' : '';
            const title = dimension === 'sprint' ? escape(first.sprint.name) + ' ' + badge(stateName(first.sprint.state), first.sprint.state) : dimension === 'project' || dimension === 'component' ? escape(key) : dimension === 'stream' ? escape(key || 'Без стрима') : key ? issueLink(key) + ' ' + (first.epicType ? '<span class="ozon-ext-type-pill">' + escape(first.epicType) + '</span> ' : '') + priorityControl + ' ' + escape(first.epicTitle) + ' <button class="ozon-dev-stream-edit' + (!first.stream ? ' is-empty' : '') + '" data-dev-action="edit-stream" data-key="' + escape(key) + '" aria-label="Изменить стрим ' + escape(key) + '">' + escape(first.stream || 'Без стрима') + '<span class="ozon-ext-toolbar-chevron"></span></button>' : 'Без эпика';
            const label = '<div class="ozon-dev-group-line" style="padding-left:' + level * 18 + 'px;"><button class="ozon-dev-link-toggle" data-dev-action="collapse" data-group="' + escape(groupId) + '" aria-expanded="' + !closed + '" aria-label="' + (closed ? 'Развернуть ' : 'Свернуть ') + escape(groupNames[dimension] + ' ' + (key || 'Без эпика')) + '">' + (closed ? '▸' : '▾') + '</button> ' + title + ' <span class="ozon-ext-group-total">' + children.length + ' задач</span> ' + statusSummary(children) + '</div>';
            const epicStatusHtml = dimension === 'epic' && key ? badge(first.epicStatus, first.epicCategory) : '';
            const componentHtml = dimension === 'epic' && key ? '<button class="ozon-dev-cell-edit" data-dev-action="edit-component" data-key="' + escape(key) + '" aria-label="Изменить компонент эпика ' + escape(key) + '" title="' + escape(first.epicComponent || 'Без компонента') + '"><span class="ozon-dev-ellipsis">' + escape(first.epicComponent || 'Без компонента') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' : '';
            return '<tr data-dev-row="collapse" class="ozon-dev-group ozon-tree-depth-' + (level % 2) + ' ozon-dev-' + dimension + '">' + groupCells(label, children, epicStatusHtml, componentHtml) + '</tr>' + (!closed ? renderGroups(children, level + 1, groupId) : '');
        }).join('');
    }
    function tableHtml() {
        if (state.loadingTasks)
            return '<div class="ozon-dev-empty"><p role="status">' + escape(state.progress || 'Загружаем задачи…') + '</p>' + Array.from({ length: 7 }, () => '<div class="ozon-ext-skeleton" style="height:27px;margin:9px 0;width:100%;"></div>').join('') + '</div>';
        if (!state.loadedSelection.length)
            return '<div class="ozon-dev-empty"><strong>' + (!team() ? 'Выберите команду' : !state.selected.length ? 'Выберите один или несколько спринтов' : 'Спринты выбраны') + '</strong><p>' + (!team() ? 'Начните с выбора команды разработки.' : 'Нажмите «Загрузить задачи», чтобы открыть таблицу.') + '</p></div>';
        const items = visibleIssues();
        const ids = flatColumns();
        const resizer = (id) => '<span role="separator" aria-orientation="vertical" aria-label="Изменить ширину: ' + escape(baseColumns[id]?.[0] || columns[Number(id.slice(7))]?.[0] || id) + '" tabindex="0" class="ozon-dev-col-resizer" data-resize-column="' + id + '"></span>';
        const top = layout.order.map(id => id === 'points' ? '<th colspan="' + (layout.detailsOpen ? 7 : 1) + '" scope="colgroup" class="ozon-dev-sp-parent"><button data-dev-action="toggle-sp" aria-expanded="' + layout.detailsOpen + '" aria-label="Детализация Story Points">' + (layout.detailsOpen ? '▾' : '▸') + ' Story Points</button> <span class="ozon-ext-group-total">Всего / Сожжено</span></th>' : '<th rowspan="2" scope="col">' + escape(baseColumns[id][0]) + (id === 'epic' ? ' <button type="button" class="ozon-dev-header-settings" data-dev-action="settings-open" aria-label="Настроить отображение Epic Link" title="Настроить отображение Epic Link"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 7h16M4 17h16M8 4v6m8 4v6"/></svg></button>' : '') + resizer(id) + '</th>').join('');
        const second = '<th scope="col">Всего SP' + resizer('points') + '</th>' + (layout.detailsOpen ? layout.children : []).map(index => '<th scope="col"><span tabindex="0" title="' + escape(columns[index][1]) + '">' + escape(columns[index][0]) + ' ⓘ</span>' + resizer('metric-' + index) + '</th>').join('');
        return '<div class="ozon-dev-table-scroll"><table class="ozon-dev-table" style="width:max(100%, ' + ids.reduce((sum, id) => sum + columnWidth(id), 0) + 'px);max-width:none!important;min-width:max(100%, ' + ids.reduce((sum, id) => sum + columnWidth(id), 0) + 'px);"><colgroup>' + ids.map(id => '<col data-dev-col="' + id + '" style="width:' + columnWidth(id) + 'px;">').join('') + '</colgroup><thead><tr>' + top + '</tr><tr>' + second + '</tr></thead><tbody>' + (items.length ? renderGroups(items) : '<tr><td colspan="' + ids.length + '" class="ozon-dev-empty">Нет задач для выбранных спринтов и фильтров.</td></tr>') + '<tr class="ozon-dev-filler" aria-hidden="true"><td colspan="' + ids.length + '"></td></tr></tbody><tfoot><tr class="ozon-dev-total">' + groupCells('Итого · ' + items.length + ' задач ' + statusSummary(items), items) + '</tr></tfoot></table></div>';
    }
    function filterControl(kind, title, values, selected) {
        const disabled = (kind === 'epic' || kind === 'stream' || kind === 'project') && (!state.loadedSelection.length || state.loadingTasks || state.loadingSprints);
        const opened = state.menu === kind && !disabled;
        const chosen = values.find(item => item.value === selected)?.label || 'Все';
        const query = state.filterQuery.toLowerCase().trim();
        const matches = values.filter(item => !query || (item.label + ' ' + (item.searchText || '')).toLowerCase().includes(query));
        const optionContent = (item) => kind === 'epic' && item.summary ? '<span class="ozon-mono">' + escape(item.value) + '</span>' + badge(item.status || '', item.category || '') + '<span class="ozon-dev-option-components">' + escape(item.component || 'Без компонента') + '</span><span class="ozon-dev-option-title">' + escape(item.summary) + '</span>' : escape(item.label);
        return '<div class="ozon-ext-toolbar-combo"><button class="ozon-ext-toolbar-trigger" data-dev-action="menu" data-menu="' + kind + '" ' + (disabled ? 'disabled ' : '') + 'aria-expanded="' + opened + '" title="' + escape(chosen) + '"><span class="ozon-ext-toolbar-label">' + title + ': ' + escape(chosen) + '</span><span class="ozon-ext-toolbar-chevron" aria-hidden="true"></span></button>' + (opened ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover ozon-dev-popover ' + (kind === 'epic' ? 'ozon-dev-epic-filter-sidebar' : '') + '">' + (kind === 'epic' ? '<div class="ozon-dev-editor-head"><strong>Фильтр по эпику</strong><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="menu" data-menu="epic" aria-label="Закрыть">✕</button></div>' : '') + '<input type="search" id="ozon-dev-filter-search" dir="ltr" aria-label="Поиск: ' + title + '" placeholder="Поиск…" value="' + escape(state.filterQuery) + '"><div class="ozon-dev-filter-list">' + (matches.length ? matches.map(item => '<button class="ozon-ext-combo-item ' + (selected === item.value ? 'active' : '') + '" data-dev-action="filter" data-filter="' + kind + '" data-value="' + escape(item.value) + '">' + optionContent(item) + '</button>').join('') : '<div class="ozon-ext-toolbar-empty">Ничего не найдено</div>') + '</div></div>' : '') + '</div>';
    }
    function viewControls(part) {
        const all = state.groups.flatMap(group => group.issues);
        const epics = new Map();
        epicCatalogItems.forEach(raw => { const fields = raw.fields || {}; epics.set(raw.key, { epicKey: raw.key, epicTitle: fields.summary || raw.key, epicStatus: fields.status?.name || 'Статус недоступен', epicCategory: fields.status?.statusCategory?.key || '', epicComponent: (fields.components || []).map((item) => item.name).filter(Boolean).join(', '), epicSearch: epicNameField ? fields[epicNameField] || '' : '' }); });
        const epicOptions = [{ value: '', label: 'Все' }, { value: '__none', label: 'Без эпика' }, ...[...epics.values()].sort((a, b) => a.epicKey.localeCompare(b.epicKey, 'ru', { numeric: true })).map(issue => ({ value: issue.epicKey, label: issue.epicKey + ' · ' + issue.epicStatus + ' · ' + issue.epicTitle, status: issue.epicStatus, category: issue.epicCategory, summary: issue.epicTitle, component: issue.epicComponent, searchText: issue.epicSearch }))];
        const streams = [...new Set(all.map(issue => issue.stream).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ru', { numeric: true }));
        const streamOptions = [{ value: '', label: 'Все' }, { value: '__none', label: 'Без стрима' }, ...streams.map(stream => ({ value: stream, label: stream }))];
        const order = [...state.grouping, ...['sprint', 'project', 'epic', 'stream', 'component'].filter(item => !state.grouping.includes(item))];
        const projectOptions = [{ value: '', label: 'Все' }, ...[...new Set(all.map(issue => issue.project).filter(Boolean))].sort().map(project => ({ value: project, label: project }))];
        if (part === 'filters')
            return filterControl('project', 'Проект', projectOptions, state.projectFilter) + filterControl('epic', 'Эпик', epicOptions, state.epicFilter) + filterControl('stream', 'Стрим', streamOptions, state.streamFilter);
        return '<div class="ozon-ext-toolbar-combo ozon-dev-grouping-control"><button class="ozon-ext-toolbar-trigger" data-dev-action="menu" data-menu="grouping" aria-expanded="' + (state.menu === 'grouping') + '" title="' + escape(state.grouping.map(key => groupNames[key]).concat('Задача').join(' → ')) + '"><span class="ozon-ext-toolbar-label">Группировка</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.menu === 'grouping' ? '<div class="ozon-ext-combo-popover ozon-dev-popover"><p class="ozon-dev-menu-hint">Выберите уровни и их порядок. Задача всегда последняя.</p>' + order.map((key, index) => '<div class="ozon-dev-group-option"><label><input type="checkbox" data-dev-group="' + key + '" ' + (state.grouping.includes(key) ? 'checked' : '') + '>' + groupNames[key] + '</label><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="group-up" data-dimension="' + key + '" aria-label="Поднять ' + groupNames[key] + '" ' + (!state.grouping.includes(key) || !index ? 'disabled' : '') + '>↑</button><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="group-down" data-dimension="' + key + '" aria-label="Опустить ' + groupNames[key] + '" ' + (!state.grouping.includes(key) || index >= state.grouping.length - 1 ? 'disabled' : '') + '>↓</button></div>').join('') + '<button class="ozon-ext-btn" data-dev-action="menu" data-menu="grouping">Готово</button></div>' : '') + '</div>' +
            (state.epicFilter || state.streamFilter || state.projectFilter ? '<button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="clear-filters">Сбросить фильтры</button>' : '');
    }
    function depthControls() {
        return filterControl('depth', 'Уровень', [...state.grouping.map((key, index) => ({ value: String(index), label: groupNames[key] })), { value: String(state.grouping.length), label: 'Задачи' }], String(state.depth));
    }
    const allIssues = () => state.groups.flatMap(group => group.issues);
    const normalizedIssueFields = () => ['summary', 'status', 'epic', 'priority', 'project', 'issuelinks', 'sprint', 'closedSprints', 'components', 'labels', sprintField, epicField, pointsField, 'customfield_24000'].filter(Boolean);
    async function readIssue(key, fields = normalizedIssueFields()) {
        return json('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=' + encodeURIComponent([...new Set(fields)].join(',')), new AbortController().signal);
    }
    async function write(url, method, body) {
        const response = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) });
        if (!response.ok) {
            let detail = '';
            try {
                const data = await response.json();
                detail = [...(data.errorMessages || []), ...Object.values(data.errors || {})].join('; ');
            }
            catch (_) { /* Use HTTP status. */ }
            throw new Error(detail || 'Jira не сохранила изменение (HTTP ' + response.status + ')');
        }
    }
    function editorHtml() {
        const editor = state.editor;
        if (!editor)
            return '';
        const name = editor.kind === 'link' ? 'Связать с FCRM' : editor.kind === 'stream' ? 'Стрим эпика' : editor.kind === 'epic' ? 'Эпик задачи' : editor.kind === 'component' ? 'Компонент задачи' : editor.kind === 'priority' ? 'Приоритет задачи' : 'Спринт задачи';
        const query = editor.query.toLowerCase().trim();
        const options = editor.kind === 'epic' || editor.kind === 'link' ? editor.options : editor.options.filter(item => item.label.toLowerCase().includes(query));
        const currentSprint = editor.kind === 'sprint' ? allIssues().find(issue => issue.key === editor.key)?.sprint : null;
        return '<aside id="ozon-dev-editor-panel" class="ozon-dev-editor ozon-ext-combo-popover" role="dialog" aria-modal="true" aria-label="' + name + '"><div class="ozon-dev-editor-head"><strong>' + name + ' · ' + escape(editor.key) + '</strong><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="close-editor" ' + (editor.busy ? 'disabled' : '') + ' aria-label="Закрыть редактирование">✕</button></div>' + (editor.kind === 'sprint' ? '<div class="ozon-sprint-current"><span>Текущий спринт</span><strong>' + escape(currentSprint?.name || 'Бэклог') + '</strong></div>' : '') + '<input id="ozon-dev-editor-search" type="search" dir="ltr" placeholder="Поиск…" aria-label="Поиск: ' + name + '" value="' + escape(editor.query) + '" ' + (editor.busy ? 'disabled' : '') + '>' + '<div id="ozon-dev-editor-message">' + (editor.error ? '<p role="alert" class="ozon-dev-error">' + escape(editor.error) + '</p>' : '') + '</div>' + (editor.kind === 'link' ? '<div class="ozon-dev-link-sprint-picker"><button class="ozon-ext-toolbar-trigger" data-dev-action="link-sprint-menu" aria-expanded="' + Boolean(editor.meta?.sprintOpen) + '"><span class="ozon-ext-toolbar-label">Спринт: ' + escape(!editor.meta ? 'Загрузка…' : editor.meta.sprintIds?.length ? 'Выбрано: ' + editor.meta.sprintIds.length : 'Все') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (editor.meta?.sprintOpen ? '<input id="ozon-dev-link-sprint-search" type="search" dir="ltr" placeholder="Поиск спринта FCRM…" value="' + escape(editor.meta.sprintQuery || '') + '"><div class="ozon-dev-editor-options"><button class="ozon-ext-combo-item" data-dev-action="link-sprint-pick" data-sprint="">Все спринты</button>' + (editor.meta.sprints || []).filter((sp) => sp.name.toLowerCase().includes((editor.meta.sprintQuery || '').toLowerCase())).map((sp) => '<button class="ozon-ext-combo-item ' + ((editor.meta.sprintIds || []).includes(String(sp.id)) ? 'active' : '') + '" data-dev-action="link-sprint-pick" data-sprint="' + sp.id + '">' + ((editor.meta.sprintIds || []).includes(String(sp.id)) ? '✓ ' : '') + escape(sp.name) + badge(stateName(sp.state), sp.state) + '</button>').join('') + '</div>' : '') + '</div><p class="ozon-dev-menu-hint">Поиск по ключу, названию и описанию. Выбор задачи создаст связь «Задача проекта».</p>' : '') + '<div id="ozon-dev-editor-results" class="ozon-dev-editor-options ' + (editor.kind === 'epic' ? 'ozon-dev-epic-options' : '') + '">' + (editor.loading ? '<div role="status" aria-label="Загрузка задач">' + [90, 75, 85, 70, 80].map(width => '<div class="ozon-ext-skeleton" style="display:block;height:22px;margin:12px 0;width:' + width + '%;"></div>').join('') + '</div>' : options.map((item, index) => '<button class="ozon-ext-combo-item" data-dev-action="save-editor" data-option="' + editor.options.indexOf(item) + '" ' + (editor.busy ? 'disabled' : '') + '>' + (item.raw ? '<span class="ozon-mono">' + escape(item.raw.key) + '</span>' + badge(item.raw.fields?.status?.name, item.raw.fields?.status?.statusCategory?.key || '') + '<span class="ozon-dev-option-title" title="' + escape(item.raw.fields?.summary || '') + '">' + escape(item.raw.fields?.summary) + '</span>' + (editor.kind === 'epic' ? '<span class="ozon-dev-option-components">' + escape((item.raw.fields?.components || []).map((component) => component.name).filter(Boolean).join(', ') || 'Без компонента') + '</span>' : '') : (editor.kind === 'priority' ? priorityHtml(item.label) : '') + escape(item.label) + (item.state ? badge(stateName(item.state), item.state) : '')) + '</button>').join('') || '<p class="ozon-dev-menu-hint">Ничего не найдено</p>') + '</div>' + '<div id="ozon-dev-editor-busy">' + (editor.busy ? '<p role="status">Сохраняем в Jira…</p>' : '') + '</div></aside>';
    }
    function renderEditorPreservingInput() {
        const panel = document.getElementById('ozon-dev-editor-panel');
        if (panel && state.editor) {
            // Keep the live input node and IME/caret intact; replace results only.
            const template = document.createElement('div');
            template.innerHTML = editorHtml();
            for (const id of ['ozon-dev-editor-results', 'ozon-dev-editor-message', 'ozon-dev-editor-busy']) {
                const current = panel.querySelector('#' + id), next = template.querySelector('#' + id);
                if (current && next) {
                    current.replaceWith(next);
                    bind(next);
                }
            }
            return;
        }
        const active = document.activeElement;
        const preserve = Boolean(active?.id && active.closest?.('.ozon-dev-editor'));
        const id = preserve ? active.id : '';
        const start = preserve ? active.selectionStart : null, end = preserve ? active.selectionEnd : null;
        onRender();
        if (id) {
            const next = document.getElementById(id);
            if (next) {
                next.focus({ preventScroll: true });
                if (start !== null && end !== null)
                    next.setSelectionRange(start, end);
            }
        }
    }
    function dismissEditor() { state.editor = null; ++editorRequest; }
    async function getEpicCatalog() {
        if (!epicCatalogPromise) {
            epicCatalogPromise = (async () => {
                const found = [];
                const fields = ['summary', 'status', 'issuetype', 'labels', 'components', epicNameField].filter(Boolean).join(',');
                const jql = 'project in (OBPROJECT, FCRM) AND issuetype = Epic ORDER BY updated DESC';
                const loadPage = async (startAt) => {
                    const data = await json('/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&startAt=' + startAt + '&maxResults=100&fields=' + encodeURIComponent(fields), new AbortController().signal);
                    found.push(...(Array.isArray(data.issues) ? data.issues.filter((issue) => /^(epic|эпик)$/i.test(String(issue.fields?.issuetype?.name || ''))) : []));
                    epicCatalogItems = found.slice();
                    epicCatalogUpdate?.(epicCatalogItems);
                    return data;
                };
                const first = await loadPage(0);
                const total = Number(first.total || 0);
                for (let startAt = 100; startAt < total; startAt += 500) {
                    const offsets = Array.from({ length: 5 }, (_, index) => startAt + index * 100).filter(offset => offset < total);
                    await Promise.all(offsets.map(loadPage));
                }
                return found;
            })().catch((error) => { epicCatalogPromise = null; throw error; });
        }
        return epicCatalogPromise;
    }
    async function searchEditor() {
        const editor = state.editor;
        if (!editor || !['epic', 'link'].includes(editor.kind))
            return;
        const request = ++editorRequest;
        editor.loading = true;
        editor.error = '';
        renderEditorPreservingInput();
        try {
            const input = editor.query.trim();
            const query = /\/browse\//i.test(input) ? (input.match(/(?:FCRM|OBPROJECT)-[0-9]+/i)?.[0] || input) : input;
            const safe = query.replace(/[\\"*?~]/g, ' ').trim();
            if (editor.kind === 'epic') {
                const normalized = query.toLocaleLowerCase();
                const updateOptions = (catalog) => {
                    const options = catalog.filter((issue) => {
                        if (!normalized)
                            return true;
                        const fields = issue.fields || {};
                        const epicName = epicNameField ? fields[epicNameField] : '';
                        const values = [issue.key, fields.summary, epicName, ...(Array.isArray(fields.labels) ? fields.labels : [])];
                        return values.some(value => String(value || '').toLocaleLowerCase().includes(normalized));
                    }).slice(0, 100).map((issue) => ({ value: issue.key, raw: issue, label: issue.key + ' · ' + (issue.fields?.status?.name || '') + ' · ' + (issue.fields?.summary || '') }));
                    if (request !== editorRequest || state.editor !== editor)
                        return;
                    editor.options = [{ value: null, label: 'Без эпика' }, ...options];
                    editor.loading = false;
                    renderEditorPreservingInput();
                };
                epicCatalogUpdate = updateOptions;
                if (epicCatalogItems.length)
                    updateOptions(epicCatalogItems);
                const catalog = await getEpicCatalog();
                updateOptions(catalog);
                if (epicCatalogUpdate === updateOptions)
                    epicCatalogUpdate = null;
                return;
            }
            const searchClauses = ['summary ~ "' + safe + '*"', 'description ~ "' + safe + '*"'];
            const condition = !query ? '' : /^[A-Z][A-Z0-9]*-\d+$/i.test(query)
                ? ' AND key = "' + query.toUpperCase() + '"'
                : ' AND (' + searchClauses.join(' OR ') + ')';
            const fields = ['summary', 'description', 'status', 'issuetype', 'priority', 'customfield_24000', 'labels', 'components', epicField, epicNameField, sprintField].filter(Boolean).join(',');
            const data = await json('/rest/api/2/search?jql=' + encodeURIComponent('project = FCRM' + condition + (editor.meta?.sprintIds?.length ? ' AND Sprint in (' + editor.meta.sprintIds.map((id) => Number(id)).filter(Number.isFinite).join(',') + ')' : '') + ' ORDER BY updated DESC') + '&maxResults=50&fields=' + encodeURIComponent(fields), new AbortController().signal);
            if (request !== editorRequest || state.editor !== editor)
                return;
            editor.options = [...(editor.kind === 'epic' ? [{ value: null, label: 'Без эпика' }] : []), ...(data.issues || []).map((issue) => ({ value: issue.key, raw: issue, label: issue.key + ' · ' + (issue.fields?.status?.name || '') + ' · ' + (issue.fields?.summary || '') + (editor.kind === 'link' ? ' · ' + (lastSprint(issue.fields?.[sprintField] || [])?.name || 'Не в спринте') : '') }))];
        }
        catch (error) {
            if (state.editor === editor && request === editorRequest)
                editor.error = error.message;
        }
        finally {
            if (state.editor === editor && request === editorRequest) {
                editor.loading = false;
                renderEditorPreservingInput();
            }
        }
    }
    async function openEditor(kind, key) {
        onBeforeEditor?.();
        state.menu = '';
        state.sprintsOpen = false;
        state.teamOpen = false;
        const editor = { kind, key, query: '', options: [], loading: true, busy: false, error: '', meta: null };
        state.editor = editor;
        ++editorRequest;
        onRender();
        document.getElementById('ozon-dev-editor-search')?.focus({ preventScroll: true });
        if (kind === 'link') {
            try {
                const sprints = await pages('/rest/agile/1.0/board/9349/sprint?state=active,future,closed', 'values', new AbortController().signal);
                const available = sprints.filter(sp => Number(sp.originBoardId) === 9349).sort((a, b) => { const rank = (sp) => String(sp.state).toLowerCase() === 'active' ? 0 : String(sp.state).toLowerCase() === 'future' ? 1 : 2; return rank(a) - rank(b) || sprintSort(a, b); });
                const active = available.filter(sp => String(sp.state).toLowerCase() === 'active');
                editor.meta = { sprints: available, sprintIds: active.map(sp => String(sp.id)), sprintQuery: '', sprintOpen: true };
            }
            catch (error) {
                editor.error = 'Не удалось загрузить спринты FCRM: ' + error.message;
                editor.meta = { sprints: [], sprintIds: [], sprintOpen: true };
            }
            if (state.editor === editor) {
                onRender();
                await searchEditor();
            }
            return;
        }
        if (kind === 'epic') {
            await searchEditor();
            return;
        }
        try {
            if (kind === 'priority') {
                editor.options = await priorityService.options(key);
            }
            else if (kind === 'component') {
                const issue = await readIssue(key, ['project', 'components']);
                const projectKey = issue.fields?.project?.key || key.split('-')[0];
                if (!componentOptionsCache.has(projectKey)) {
                    const components = await json('/rest/api/2/project/' + encodeURIComponent(projectKey) + '/components', new AbortController().signal);
                    componentOptionsCache.set(projectKey, [{ value: null, label: 'Без компонента' }, ...components.map((item) => ({ value: String(item.id), label: item.name }))]);
                }
                editor.meta = { projectKey };
                editor.options = componentOptionsCache.get(projectKey);
            }
            else if (kind === 'stream') {
                const meta = await json('/rest/api/2/issue/' + encodeURIComponent(key) + '/editmeta', new AbortController().signal);
                const field = meta.fields?.customfield_24000;
                if (!field || !Array.isArray(field.allowedValues))
                    throw new Error('Jira не вернула доступные значения поля «Стрим» для этого эпика.');
                editor.meta = field;
                editor.options = [...(!field.required ? [{ value: null, label: 'Без стрима' }] : []), ...field.allowedValues.map((item) => ({ value: item.id ? { id: String(item.id) } : item.value || item, label: item.value || item.name || String(item) }))];
            }
            else {
                editor.options = [{ value: null, label: 'Бэклог — убрать из текущего спринта' }, ...state.sprints.filter(sprint => ['active', 'future'].includes(sprint.state)).map(sprint => ({ value: sprint.id, label: sprint.name, state: sprint.state }))];
            }
        }
        catch (error) {
            editor.error = error.message;
        }
        finally {
            if (state.editor === editor) {
                editor.loading = false;
                onRender();
            }
        }
    }
    async function saveEditor(index) {
        const editor = state.editor;
        const option = editor?.options[index];
        if (!editor || !option || editor.busy)
            return;
        const current = serial;
        editor.busy = true;
        editor.error = '';
        onRender();
        try {
            if (editor.kind === 'link') {
                const source = allIssues().find(issue => issue.key === editor.key);
                if (!source)
                    throw new Error('Исходная задача больше не входит в выборку.');
                const before = normalizeIssue(await readIssue(editor.key));
                if (before.links.some((link) => link.key === option.value && link.projectTask))
                    throw new Error('Такая связь уже существует в Jira.');
                const types = await getIssueLinkTypes();
                const type = types.find((item) => /задача проекта|project task/i.test([item.name, item.inward, item.outward].join(' ')));
                if (!type)
                    throw new Error('В Jira не найден тип связи «Задача проекта».');
                const outward = /задача проекта|project task/i.test(type.outward || '');
                await write('/rest/api/2/issueLink', 'POST', { type: { id: type.id }, inwardIssue: { key: outward ? editor.key : option.value }, outwardIssue: { key: outward ? option.value : editor.key } });
                const fresh = normalizeIssue(await readIssue(editor.key));
                if (current !== serial)
                    return;
                if (!fresh.links.some((link) => link.key === option.value && link.projectTask))
                    throw new Error('Jira ещё не вернула созданную связь. Обновите задачу перед повторной попыткой.');
                source.links = fresh.links.map((link) => {
                    const known = source.links.find((old) => old.key === link.key);
                    if (link.key !== option.value)
                        return { ...link, ...known };
                    const fields = option.raw?.fields || {};
                    return { ...link, summary: fields.summary || link.summary, status: fields.status?.name || link.status, category: fields.status?.statusCategory?.key || link.category, priority: fields.priority?.name || 'Не указан', issueType: fields.issuetype?.name || 'Задача', sprint: lastSprint(fields[sprintField] || []) };
                });
            }
            else if (editor.kind === 'stream') {
                await write('/rest/api/2/issue/' + encodeURIComponent(editor.key), 'PUT', { fields: { customfield_24000: option.value } });
                const fresh = await readIssue(editor.key, ['customfield_24000']);
                if (current !== serial)
                    return;
                const raw = fresh.fields?.customfield_24000;
                const stream = typeof raw === 'string' ? raw : raw?.value || '';
                if ((option.value === null && stream) || (option.value !== null && stream !== option.label))
                    throw new Error('Jira вернула другое значение стрима. Обновите данные.');
                allIssues().filter(issue => issue.epicKey === editor.key).forEach(issue => { issue.stream = stream; allocate(issue); });
            }
            else if (editor.kind === 'priority') {
                const priority = await priorityService.save(editor.key, option.value);
                if (current !== serial)
                    return;
                state.groups.forEach(group => group.issues.forEach(issue => { if (issue.key === editor.key)
                    issue.priority = priority.name; issue.links.forEach((link) => { if (link.key === editor.key)
                    link.priority = priority.name; }); }));
            }
            else if (editor.kind === 'component') {
                await write('/rest/api/2/issue/' + encodeURIComponent(editor.key), 'PUT', { fields: { components: option.value ? [{ id: String(option.value) }] : [] } });
                const raw = await readIssue(editor.key, ['components']);
                if (current !== serial)
                    return;
                const previous = allIssues().find(issue => issue.key === editor.key);
                if (!previous)
                    throw new Error('Задача больше не входит в выборку. Обновите задачи.');
                const components = raw.fields?.components || [];
                const componentId = components[0]?.id ? String(components[0].id) : '';
                if (componentId !== (option.value ? String(option.value) : ''))
                    throw new Error('Компонент не изменился в Jira. Повторите попытку.');
                const updated = { ...previous, componentId, component: components.map((item) => item.name).filter(Boolean).join(', ') || 'Без компонента' };
                state.groups.forEach(group => { group.issues = group.issues.map(issue => issue.key === editor.key ? updated : issue); });
            }
            else {
                if (editor.kind === 'epic') {
                    if (!epicField)
                        throw new Error('Не найдено поле Epic Link в Jira. Обновите список команды.');
                    await write('/rest/api/2/issue/' + encodeURIComponent(editor.key), 'PUT', { fields: { [epicField]: option.value } });
                }
                else
                    await write(option.value === null ? '/rest/agile/1.0/backlog/issue' : '/rest/agile/1.0/sprint/' + option.value + '/issue', 'POST', { issues: [editor.key] });
                const raw = await readIssue(editor.key);
                if (current !== serial)
                    return;
                const previous = allIssues().find(issue => issue.key === editor.key);
                if (!previous)
                    throw new Error('Задача больше не входит в выборку. Обновите задачи.');
                const updated = { ...previous, ...normalizeIssue(raw), links: previous.links };
                if (editor.kind === 'epic' && updated.epicKey !== (option.value || ''))
                    throw new Error('Epic Link не изменился в Jira. Повторите попытку.');
                if (updated.epicKey) {
                    const epic = await readIssue(updated.epicKey, ['summary', 'status', 'components', 'customfield_24000']);
                    if (current !== serial)
                        return;
                    updated.epicTitle = epic.fields?.summary || updated.epicKey;
                    updated.epicStatus = epic.fields?.status?.name || 'Статус недоступен';
                    updated.epicCategory = epic.fields?.status?.statusCategory?.key || '';
                    updated.epicComponent = (epic.fields?.components || []).map((component) => component.name).filter(Boolean).join(', ');
                    const stream = epic.fields?.customfield_24000;
                    updated.stream = typeof stream === 'string' ? stream : stream?.value || '';
                }
                allocate(updated);
                updated.lastSprintId = String(lastSprint(updated.history)?.id || '');
                if (editor.kind === 'sprint' && option.value !== null && !updated.history.some(value => String(parseSprint(value)?.id) === String(option.value)))
                    throw new Error('Новый спринт пока не подтверждён Jira. Обновите задачи.');
                state.groups.forEach(group => { group.issues = group.issues.filter(issue => issue.key !== editor.key); if (String(group.sprint.id) === updated.lastSprintId)
                    group.issues.push(updated); });
            }
            if (state.editor === editor)
                state.editor = null;
        }
        catch (error) {
            if (state.editor === editor)
                editor.error = error.message;
        }
        finally {
            if (current === serial) {
                editor.busy = false;
                onRender();
            }
        }
    }
    function columnControls() {
        const option = (id, index, child = false) => {
            const order = child ? layout.children : layout.order;
            const title = child ? columns[Number(id)][0] : baseColumns[id][0];
            return '<div class="ozon-dev-group-option ' + (child ? 'ozon-dev-column-child' : '') + '"><span class="ozon-dev-column-label">' + escape(title) + '</span><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="column-move" data-column="' + id + '" data-child="' + child + '" data-direction="-1" aria-label="Поднять столбец ' + escape(title) + '" ' + (!index ? 'disabled' : '') + '>↑</button><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="column-move" data-column="' + id + '" data-child="' + child + '" data-direction="1" aria-label="Опустить столбец ' + escape(title) + '" ' + (index === order.length - 1 ? 'disabled' : '') + '>↓</button></div>';
        };
        return '<div class="ozon-ext-toolbar-combo"><button class="ozon-ext-toolbar-trigger" data-dev-action="menu" data-menu="columns" aria-expanded="' + (state.menu === 'columns') + '"><span class="ozon-ext-toolbar-label">Столбцы</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.menu === 'columns' ? '<div class="ozon-ext-combo-popover ozon-dev-popover ozon-dev-column-menu"><p class="ozon-dev-menu-hint">Порядок — стрелками. Ширина — за край заголовка. Story Points перемещается вместе с детализацией.</p>' + layout.order.map((id, index) => option(id, index) + (id === 'points' ? '<button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="toggle-sp" aria-expanded="' + layout.detailsOpen + '">' + (layout.detailsOpen ? 'Свернуть детализацию SP' : 'Развернуть детализацию SP') + '</button>' + (layout.detailsOpen ? layout.children : []).map((child, i) => option(String(child), i, true)).join('') : '')).join('') + '<button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="reset-columns">Сбросить столбцы</button></div>' : '') + '</div>';
    }
    function helpHtml() {
        return '<div class="ozon-dev-help"><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" aria-label="Как считаются спринты и столбцы" aria-describedby="ozon-dev-help-tooltip"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg></button><div id="ozon-dev-help-tooltip" role="tooltip"><strong>Как считаются спринты и столбцы</strong><p>Задача учитывается один раз — в последнем спринте её истории. Последний определяется по дате начала, без дат — по номеру Jira. Если он не выбран, задача не входит в таблицу.</p><p>В столбцах — Story Points. Стрим берётся у эпика. Пустая оценка или неподходящий стрим — «—». Формулы независимы: их сумма может отличаться от общего SP.</p>' + columns.map(([name, hint]) => '<p><b>' + escape(name) + ':</b> ' + escape(hint) + '</p>').join('') + '</div></div>';
    }
    function settingsHtml() {
        const draft = settingsDraft;
        if (!draft)
            return '';
        const stable = draft.presented;
        draft.presented = true;
        const row = (id, index, kind, title) => '<div class="ozon-dev-group-option' + (kind === 'child' ? ' ozon-dev-column-child' : '') + '"><span class="ozon-dev-column-label">' + (kind === 'group' ? '' : escape(title)) + '</span><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-move" data-kind="' + kind + '" data-id="' + id + '" data-direction="-1" aria-label="Поднять ' + escape(title) + '" ' + (!index ? 'disabled' : '') + '>↑</button><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-move" data-kind="' + kind + '" data-id="' + id + '" data-direction="1" aria-label="Опустить ' + escape(title) + '">↓</button></div>';
        return '<aside class="ozon-dev-settings' + (stable ? ' ozon-dev-settings-stable' : '') + '" role="dialog" aria-label="Настройки таблицы"><header class="ozon-dev-editor-head"><strong>Настройки таблицы</strong><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-cancel" aria-label="Закрыть настройки">✕</button></header><strong>Уровень раскрытия</strong><div class="ozon-ext-toolbar-combo"><button class="ozon-ext-toolbar-trigger" data-dev-action="menu" data-menu="settings-depth"><span class="ozon-ext-toolbar-label">' + escape(groupNames[draft.grouping[draft.depth]] || 'Задачи') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.menu === 'settings-depth' ? '<div class="ozon-ext-combo-popover">' + [...draft.grouping, 'task'].map((id, index) => '<button class="ozon-ext-combo-item ' + (index === draft.depth ? 'active' : '') + '" data-dev-action="settings-depth" data-depth="' + index + '">' + escape(groupNames[id] || 'Задачи') + '</button>').join('') + '</div>' : '') + '</div><strong>Отображение Epic Link</strong><div class="ozon-ext-toolbar-combo"><button class="ozon-ext-toolbar-trigger" data-dev-action="menu" data-menu="settings-epic" aria-expanded="' + (state.menu === 'settings-epic') + '"><span class="ozon-ext-toolbar-label">' + escape({ key: 'Только ключ', status: 'Ключ + статус', full: 'Ключ + статус + название' }[draft.layout.epicDisplay]) + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.menu === 'settings-epic' ? '<div class="ozon-ext-combo-popover">' + [['key', 'Только ключ'], ['status', 'Ключ + статус'], ['full', 'Ключ + статус + название']].map(([value, label]) => '<button class="ozon-ext-combo-item ' + (draft.layout.epicDisplay === value ? 'active' : '') + '" data-dev-action="settings-epic-display" data-value="' + value + '">' + label + '</button>').join('') + '</div>' : '') + '</div><strong>Группировка</strong><div>' + [...draft.grouping, ...['sprint', 'project', 'epic', 'stream', 'component'].filter(id => !draft.grouping.includes(id))].map((id, index) => '<div class="ozon-dev-group-option"><label><input type="checkbox" data-settings-group="' + id + '" ' + (draft.grouping.includes(id) ? 'checked' : '') + '> ' + groupNames[id] + '</label>' + (draft.grouping.includes(id) ? row(id, index, 'group', groupNames[id]).replace('<div class="ozon-dev-group-option">', '<span style="display:flex;gap:6px;">').replace('</div>', '</span>') : '') + '</div>').join('') + '</div><strong>Столбцы</strong><p class="ozon-dev-menu-hint">Ширину можно менять за границу заголовка таблицы.</p><div>' + draft.layout.order.map((id, index) => row(id, index, 'column', baseColumns[id][0]) + (id === 'points' ? '<label class="ozon-dev-column-child"><input type="checkbox" data-settings-sp ' + (draft.layout.detailsOpen ? 'checked' : '') + '> Детализация Story Points</label>' + (draft.layout.detailsOpen ? draft.layout.children.map((child, i) => row(String(child), i, 'child', columns[child][0])).join('') : '') : '')).join('') + '</div><footer><button class="ozon-ext-btn" data-dev-action="settings-apply">Применить</button><button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-cancel">Отмена</button></footer></aside>';
    }
    function html() {
        const busy = state.loadingSprints || state.loadingTasks;
        const matches = state.sprints.filter(sprint => sprint.name.toLowerCase().includes(state.sprintQuery.trim().toLowerCase()));
        const active = team();
        return '<section class="ozon-dev-dashboard"><header class="ozon-ext-header-bar"><strong>Команды разработки</strong><div class="ozon-dev-header-actions">' + teams.map(item => '<a href="https://jit.o3.ru/secure/RapidBoard.jspa?rapidView=' + item.boardId + '&view=planning" target="_blank" rel="noopener noreferrer">Доска ' + escape(item.name) + ' ↗</a>').join('') + (widgetVersion ? '<span class="ozon-dev-version" title="Версия виджета">v' + escape(widgetVersion) + '</span>' : '') + helpHtml() + '</div></header><div class="ozon-dev-controls ozon-ext-filter-bar">' + '<button class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="settings-open"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 7h16M4 17h16M8 4v6M16 14v6"/></svg> Настройки</button>' +
            '<div class="ozon-ext-toolbar-combo"><button type="button" class="ozon-ext-toolbar-trigger" data-dev-action="team-menu" aria-expanded="' + state.teamOpen + '"><span class="ozon-ext-toolbar-label">Команда: ' + escape(selectedTeams().map(item => item.name).join(', ') || 'Выберите команду') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' + (state.teamOpen ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover ozon-dev-popover ozon-dev-team-popover">' + teams.map(item => '<label class="ozon-dev-team-option"><input type="checkbox" data-dev-team="' + item.id + '" ' + (state.teamIds.includes(item.id) ? 'checked' : '') + '><span class="ozon-dev-team-name">' + escape(item.name) + '</span></label>').join('') + '<button class="ozon-ext-btn" data-dev-action="team-menu">Готово</button>' + '</div>' : '') + '</div>' +
            '<div class="ozon-ext-toolbar-combo"><button type="button" class="ozon-ext-toolbar-trigger" data-dev-action="sprints-menu" aria-expanded="' + state.sprintsOpen + '" ' + (!active || state.loadingSprints ? 'disabled' : '') + ' title="' + escape(state.selected.map(id => state.sprints.find(sprint => String(sprint.id) === id)?.name || '').join('; ')) + '"><span class="ozon-ext-toolbar-label">' + (state.loadingSprints ? 'Загружаем спринты…' : state.selected.length ? 'Спринтов выбрано: ' + state.selected.length : 'Выберите спринты') + '</span><span class="ozon-ext-toolbar-chevron"></span></button>' +
            (state.sprintsOpen ? '<div class="ozon-ext-combo-popover ozon-dev-popover ozon-dev-sprints" role="dialog" aria-label="Выбор спринтов"><div class="ozon-dev-editor-head"><strong>Выбор спринтов</strong><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="sprints-menu" aria-label="Закрыть">✕</button></div><input type="search" id="ozon-dev-sprint-search" aria-label="Поиск спринта" placeholder="Поиск спринта…" value="' + escape(state.sprintQuery) + '"><div class="ozon-dev-sprint-list">' + (matches.length ? matches.map(sprint => '<label class="ozon-dev-sprint-option"><input type="checkbox" data-dev-sprint="' + sprint.id + '" ' + (state.selected.includes(String(sprint.id)) ? 'checked' : '') + '><span>' + escape(sprint.name) + '</span>' + badge(stateName(sprint.state), sprint.state) + '</label>').join('') : (!state.loadingSprints ? '<p style="color:#64748B;">Спринты не найдены</p>' : '')) + (state.loadingSprints ? '<div role="status" aria-label="Загрузка прошедших спринтов" style="padding:8px 4px;">' + [85, 70, 90, 75].map(width => '<div class="ozon-ext-skeleton" style="height:22px;margin:8px 0;width:' + width + '%;"></div>').join('') + '</div>' : '') + '</div><div class="ozon-dev-popover-footer">' + (!state.closedLoaded ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="closed" ' + (busy ? 'disabled' : '') + '>Показать прошедшие</button>' : '') + '<button type="button" class="ozon-ext-btn" data-dev-action="sprints-done" ' + (!state.selected.length || busy ? 'disabled' : '') + '>Готово</button></div></div>' : '') + '</div>' +
            '<button type="button" class="ozon-ext-btn" data-dev-action="load" ' + (!pointsField || !state.selected.length || busy ? 'disabled' : '') + '>' + (state.loadingTasks ? 'Загружаем задачи…' : 'Загрузить задачи') + '</button>' +
            (active ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-dev-action="refresh-sprints" ' + (busy ? 'disabled' : '') + '>Обновить спринты</button>' : '') + viewControls('filters') + '</div>' +
            (state.error ? '<div class="ozon-dev-error" role="alert">' + escape(state.error) + '</div>' : '') +
            (state.loadingSprints ? '<div style="padding:12px 16px;"><div class="ozon-ext-skeleton" style="height:25px;width:40%;"></div></div>' : '') +
            '<div class="ozon-dev-content">' + tableHtml() + '</div>' + editorHtml() + settingsHtml() + '</section>';
    }
    function bind(root) {
        const scroll = root.querySelector('.ozon-dev-table-scroll');
        const table = scroll?.querySelector('.ozon-dev-table');
        const filler = table?.querySelector('.ozon-dev-filler td');
        if (scroll && table && filler) {
            filler.style.height = Math.max(0, scroll.clientHeight - table.offsetHeight) + 'px';
        }
        const settings = root.querySelector('.ozon-dev-settings');
        if (settings) {
            settings.scrollTop = settingsScroll;
            settings.addEventListener('scroll', () => { settingsScroll = settings.scrollTop; });
        }
        root.querySelectorAll('.ozon-dev-controls .ozon-dev-popover').forEach(popover => {
            const rect = popover.getBoundingClientRect();
            const overshoot = Math.max(0, rect.right - window.innerWidth + 12);
            if (overshoot)
                popover.style.transform = 'translateX(-' + overshoot + 'px)';
        });
        root.querySelectorAll('[data-resize-column]').forEach(handle => {
            const resize = (width) => {
                const id = handle.dataset.resizeColumn;
                layout.widths[id] = Math.max(70, Math.min(1000, width));
                const col = root.querySelector('col[data-dev-col="' + id + '"]');
                if (col)
                    col.style.width = layout.widths[id] + 'px';
                const table = root.querySelector('.ozon-dev-table');
                if (table) {
                    const totalWidth = flatColumns().reduce((sum, key) => sum + columnWidth(key), 0) + 'px';
                    table.style.setProperty('width', 'max(100%, ' + totalWidth + ')', 'important');
                    table.style.setProperty('min-width', 'max(100%, ' + totalWidth + ')', 'important');
                }
            };
            handle.addEventListener('pointerdown', event => {
                event.preventDefault();
                event.stopPropagation();
                const startX = event.clientX, startWidth = columnWidth(handle.dataset.resizeColumn);
                const move = (next) => resize(startWidth + next.clientX - startX);
                const stop = () => { document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', stop); document.removeEventListener('pointercancel', stop); saveLayout(); };
                document.addEventListener('pointermove', move);
                document.addEventListener('pointerup', stop);
                document.addEventListener('pointercancel', stop);
            });
            handle.addEventListener('keydown', event => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                resize(columnWidth(handle.dataset.resizeColumn) + (event.key === 'ArrowLeft' ? -10 : 10));
                saveLayout();
            } });
        });
        root.querySelectorAll('[data-dev-action]').forEach(button => button.addEventListener('click', event => {
            if (button.dataset.devAction === 'edit-epic' && event.target.closest('a'))
                return;
            event.stopPropagation();
            const action = button.dataset.devAction;
            if (action === 'settings-open') {
                settingsScroll = 0;
                settingsDraft = { grouping: [...state.grouping], depth: state.depth, layout: JSON.parse(JSON.stringify(layout)) };
                state.menu = '';
                onRender();
                return;
            }
            if (action === 'settings-cancel') {
                settingsDraft = null;
                state.menu = '';
                onRender();
                return;
            }
            if (action === 'settings-apply' && settingsDraft) {
                const draft = settingsDraft;
                settingsDraft = null;
                Object.assign(layout, draft.layout);
                saveLayout();
                state.grouping = [...draft.grouping];
                state.depth = Math.min(draft.depth, state.grouping.length);
                state.collapsed.clear();
                state.expandedGroups.clear();
                state.menu = '';
                onRender();
                return;
            }
            if (action === 'settings-epic-display' && settingsDraft) {
                settingsDraft.layout.epicDisplay = button.dataset.value || 'full';
                state.menu = '';
                onRender();
                return;
            }
            if (action === 'settings-depth' && settingsDraft) {
                settingsDraft.depth = Number(button.dataset.depth);
                state.menu = '';
                onRender();
                return;
            }
            if (action === 'settings-move' && settingsDraft) {
                const kind = button.dataset.kind;
                const list = kind === 'group' ? settingsDraft.grouping : kind === 'child' ? settingsDraft.layout.children : settingsDraft.layout.order;
                const from = list.map(String).indexOf(button.dataset.id);
                const to = from + Number(button.dataset.direction);
                if (from >= 0 && to >= 0 && to < list.length)
                    [list[from], list[to]] = [list[to], list[from]];
                onRender();
                return;
            }
            if (action?.startsWith('edit-')) {
                openEditor(action.slice(5), button.dataset.key);
                return;
            }
            if (action === 'close-editor') {
                if (!state.editor?.busy) {
                    state.editor = null;
                    ++editorRequest;
                }
                onRender();
                return;
            }
            if (action === 'save-editor') {
                saveEditor(Number(button.dataset.option));
                return;
            }
            if (action === 'link-sprint-menu' && state.editor?.kind === 'link') {
                state.editor.meta.sprintOpen = !state.editor.meta.sprintOpen;
                onRender();
                return;
            }
            if (action === 'link-sprint-pick' && state.editor?.kind === 'link') {
                const meta = state.editor.meta;
                const id = button.dataset.sprint || '';
                meta.sprintIds = !id ? [] : meta.sprintIds.includes(id) ? meta.sprintIds.filter((value) => value !== id) : [...meta.sprintIds, id];
                onRender();
                searchEditor();
                return;
            }
            if (action === 'toggle-sp') {
                layout.detailsOpen = button.getAttribute('aria-expanded') !== 'true';
                saveLayout();
                onRender();
                return;
            }
            if (action === 'column-move') {
                moveColumn(button.dataset.column, Number(button.dataset.direction), button.dataset.child === 'true');
                return;
            }
            if (action === 'reset-columns') {
                layout.order = ['key', 'title', 'epic', 'status', 'sprint', 'points'];
                layout.children = [0, 1, 2, 3, 4, 5];
                layout.widths = {};
                layout.detailsOpen = true;
                saveLayout();
                onRender();
                return;
            }
            if (action === 'open-fcrm') {
                const link = state.groups.flatMap(group => group.issues).flatMap(issue => issue.links).find(link => link.key === button.dataset.key);
                if (link)
                    onOpenTask?.(link);
                return;
            }
            if (action === 'team') {
                selectTeam(button.dataset.team || '');
                return;
            }
            if (action === 'load') {
                loadTasks();
                return;
            }
            if (action === 'closed') {
                loadClosedSprints();
                return;
            }
            if (action === 'refresh-sprints') {
                selectTeam(state.teamIds);
                return;
            }
            if (action === 'menu') {
                state.menu = state.menu === button.dataset.menu ? '' : button.dataset.menu;
                state.filterQuery = '';
                state.teamOpen = false;
                state.sprintsOpen = false;
                if (state.menu === 'epic')
                    getEpicCatalog().then(() => { if (state.menu === 'epic') {
                        const input = document.getElementById('ozon-dev-filter-search');
                        const start = input?.selectionStart, end = input?.selectionEnd;
                        const focused = document.activeElement === input;
                        onRender();
                        const next = document.getElementById('ozon-dev-filter-search');
                        if (focused && next) {
                            next.focus({ preventScroll: true });
                            if (start != null && end != null)
                                next.setSelectionRange(start, end);
                        }
                    } }).catch((error) => { state.error = 'Не удалось загрузить эпики: ' + error.message; onRender(); });
            }
            if (action === 'filter') {
                if (button.dataset.filter === 'depth') {
                    state.menu = '';
                    setDepth(Number(button.dataset.value));
                    return;
                }
                if (button.dataset.filter === 'epic')
                    state.epicFilter = button.dataset.value;
                else if (button.dataset.filter === 'project')
                    state.projectFilter = button.dataset.value;
                else
                    state.streamFilter = button.dataset.value;
                state.menu = '';
            }
            if (action === 'clear-filters') {
                state.epicFilter = '';
                state.streamFilter = '';
                state.projectFilter = '';
            }
            if (action === 'depth') {
                setDepth(Number(button.dataset.depth));
                return;
            }
            if (action === 'group-up' || action === 'group-down') {
                const order = [...state.grouping];
                const from = order.indexOf(button.dataset.dimension);
                const to = from + (action === 'group-up' ? -1 : 1);
                if (from >= 0 && to >= 0 && to < order.length) {
                    [order[from], order[to]] = [order[to], order[from]];
                    setGrouping(order);
                }
                return;
            }
            if (action === 'links') {
                const key = button.dataset.key;
                state.expandedLinks.has(key) ? state.expandedLinks.delete(key) : state.expandedLinks.add(key);
            }
            if (action === 'team-menu') {
                state.teamOpen = !state.teamOpen;
                state.sprintsOpen = false;
                state.menu = '';
            }
            if (action === 'sprints-done') {
                if (!state.selected.length || state.loadingTasks || state.loadingSprints)
                    return;
                state.sprintsOpen = false;
                loadTasks();
                return;
            }
            if (action === 'sprints-menu') {
                state.sprintsOpen = !state.sprintsOpen;
                state.teamOpen = false;
                state.menu = '';
            }
            if (action === 'collapse') {
                const id = button.dataset.group;
                if (button.getAttribute('aria-expanded') === 'true') {
                    state.collapsed.add(id);
                    state.expandedGroups.delete(id);
                }
                else {
                    state.collapsed.delete(id);
                    state.expandedGroups.add(id);
                }
            }
            onRender();
        }));
        root.querySelectorAll('[role="button"][data-dev-action]').forEach(control => control.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            control.click();
        } }));
        root.querySelectorAll('[data-settings-group]').forEach(input => input.addEventListener('change', () => { if (!settingsDraft)
            return; const id = input.dataset.settingsGroup; settingsDraft.grouping = input.checked ? [...settingsDraft.grouping, id] : settingsDraft.grouping.filter(item => item !== id); settingsDraft.depth = Math.min(settingsDraft.depth, settingsDraft.grouping.length); onRender(); }));
        root.querySelector('[data-settings-sp]')?.addEventListener('change', event => { if (settingsDraft)
            settingsDraft.layout.detailsOpen = event.target.checked; onRender(); });
        const editorSearch = root.querySelector('#ozon-dev-editor-search');
        const linkSprintSearch = root.querySelector('#ozon-dev-link-sprint-search');
        linkSprintSearch?.addEventListener('input', () => { if (state.editor?.kind === 'link') {
            state.editor.meta.sprintQuery = linkSprintSearch.value;
            onRender();
            document.getElementById('ozon-dev-link-sprint-search')?.focus({ preventScroll: true });
        } });
        editorSearch?.addEventListener('input', () => {
            if (!state.editor)
                return;
            state.editor.query = editorSearch.value;
            if (state.editor.kind === 'epic' || state.editor.kind === 'link')
                searchEditor();
            else
                renderEditorPreservingInput();
        });
        root.querySelectorAll('[data-dev-row]').forEach(row => row.addEventListener('click', event => {
            const target = event.target;
            // Match the product backlog: the row toggles; links and controls keep their own action.
            if (target.closest('a,button,input,label,[role="button"]'))
                return;
            row.querySelector('[data-dev-action]')?.click();
        }));
        const section = root.querySelector('.ozon-dev-dashboard');
        section?.addEventListener('click', event => {
            if (event.target.closest('.ozon-ext-toolbar-combo,.ozon-dev-editor,.ozon-dev-settings'))
                return;
            if (state.editor && !state.editor.busy) {
                state.editor = null;
                ++editorRequest;
                onRender();
                return;
            }
            if (state.menu || state.teamOpen || state.sprintsOpen) {
                state.menu = '';
                state.teamOpen = false;
                state.sprintsOpen = false;
                onRender();
            }
        });
        section?.addEventListener('keydown', event => {
            if (event.key === 'Escape' && state.editor && !state.editor.busy) {
                state.editor = null;
                ++editorRequest;
                onRender();
                return;
            }
            if (event.key === 'Escape' && (state.menu || state.teamOpen || state.sprintsOpen)) {
                state.menu = '';
                state.teamOpen = false;
                state.sprintsOpen = false;
                onRender();
            }
        });
        root.querySelectorAll('[data-dev-team]').forEach(input => input.addEventListener('change', () => { const id = input.dataset.devTeam; selectTeam(input.checked ? [...state.teamIds, id] : state.teamIds.filter(value => value !== id), true); }));
        root.querySelectorAll('[data-dev-sprint]').forEach(input => input.addEventListener('change', () => {
            const id = input.dataset.devSprint;
            setSelection(input.checked ? [...state.selected, id] : state.selected.filter(item => item !== id));
        }));
        root.querySelectorAll('[data-dev-group]').forEach(input => input.addEventListener('change', () => {
            const dimension = input.dataset.devGroup;
            setGrouping(input.checked ? [...state.grouping, dimension] : state.grouping.filter(item => item !== dimension));
        }));
        const filterSearch = root.querySelector('#ozon-dev-filter-search');
        filterSearch?.addEventListener('input', () => {
            const start = filterSearch.selectionStart;
            const end = filterSearch.selectionEnd;
            state.filterQuery = filterSearch.value;
            onRender();
            const replacement = document.getElementById('ozon-dev-filter-search');
            replacement?.focus({ preventScroll: true });
            try {
                if (start !== null && end !== null)
                    replacement?.setSelectionRange(start, end);
            }
            catch (_) { /* Selection is not supported by every browser. */ }
        });
        const search = root.querySelector('#ozon-dev-sprint-search');
        search?.addEventListener('input', () => {
            state.sprintQuery = search.value;
            const caret = search.selectionStart;
            onRender();
            const replacement = document.getElementById('ozon-dev-sprint-search');
            replacement?.focus({ preventScroll: true });
            try {
                if (caret !== null)
                    replacement?.setSelectionRange(caret, caret);
            }
            catch (_) { /* Search inputs do not expose selection everywhere. */ }
        });
    }
    const copyReferences = () => {
        const references = new Map();
        allIssues().forEach(issue => { references.set(issue.key, issue.summary); if (issue.epicKey)
            references.set(issue.epicKey, issue.epicTitle); issue.links.forEach((link) => references.set(link.key, link.summary)); });
        return references;
    };
    return { html, bind, selectTeam, setSelection, loadTasks, loadClosedSprints, setGrouping, setDepth, moveColumn, getLayout: () => layout, openEditor, saveEditor, copyReferences, cancel, dismissEditor, getState: () => state };
})(() => renderStructure(), openSharedFcrmDetails,()=>{sbEpicComboOpen=false;sbCompComboOpen=false;sbIpCompOpenIdx=null;sbIpSprintOpenIdx=null;activeSearchSelectId='';}, renderBadge, getStatusCategoryClass, "3.5.156", jiraPriorityService);
  const generatingLinkKeys = new Set();
  const ticketSearchStates = new Map();
  let draggedThreadChannel = null;

  function getTicketSearchState(key, kind) {
    const id = key + ':' + kind;
    if (!ticketSearchStates.has(id)) ticketSearchStates.set(id, {
      open: false, loading: false, channels: '', items: null, errors: [], error: '', raw: '', message: '', reply: '',
      choices: ['bank-crm-dev', 'cs_incident_techsup', 'crmcs', 'quality_cs', 'bank_cs_team', 'bank_cs_team_public', 'crm_bo_team_public', 'crm_bo_team_dev', 'crm_dev_team', 'bank_crm_core_team', 'trs', 'ob_trs_public', 'cs_fcrm_changes', 'crm-vs-srm', 'tmp_db2c', 'case-study', 'case-study-b2b', 'suppproduct_b2c', 'bi-weekly--support'].map(name => ({ url: 'https://chatzone.o3t.ru/ozon/channels/' + name, checked: false })),
      queue: [], index: -1, history: []
    });
    return ticketSearchStates.get(id);
  }

  function parseTicketSearchResponse(text, kind, issueKey) {
    const block = /<search_results>([\s\S]*?)<\/search_results>/i.exec(String(text));
    const raw = block ? block[1] : String(text).trim().replace(/^\x60\x60\x60(?:json)?\s*/i, '').replace(/\x60\x60\x60\s*$/, '');
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.items) || (data.errors != null && !Array.isArray(data.errors))) throw new Error('DeepSeek вернул ответ без списка результатов. Повторите поиск.');
    const errors = [];
    const noMatchNotes = [];
    (data.errors || []).map(String).forEach(note => {
      // Some responses put a successful empty search in errors. Only reclassify
      // explicit no-match messages; access and partial-search failures stay errors.
      if (kind === 'threads' && !data.items.length && /не найден[оы]?\s+(?:обсуждений|совпадений|сообщений|результатов)/i.test(note) && !/(?:недоступ|не удалось|ошибк|не выполнен|не проверен|нет доступа)/i.test(note)) noMatchNotes.push(note);
      else errors.push(note);
    });
    const items = [];
    const seen = new Set();
    for (const item of data.items) {
      if (!item || typeof item !== 'object') { errors.push('Пропущен некорректный результат поиска.'); continue; }
      if (kind === 'fcrm') {
        const key = String(item.key || '').trim().toUpperCase();
        if (key === issueKey || seen.has(key)) continue;
        if (!/^FCRM-[0-9]+$/.test(key) || typeof item.title !== 'string' || !item.title.trim() || typeof item.status !== 'string' || !item.status.trim()) {
          errors.push('Пропущена задача без корректного ключа, названия или статуса.');
          continue;
        }
        seen.add(key);
        items.push({ key, title: item.title.trim(), status: item.status.trim() });
      } else {
        try {
          const url = new URL(String(item.url || ''));
          if (url.protocol !== 'https:' || url.username || url.password || !['chatzone.o3t.ru', 'chatzone.o3.ru'].includes(url.hostname) || !/\/pl\/[^/]+\/?$/.test(url.pathname) || typeof item.text !== 'string' || !item.text.trim()) throw new Error('invalid');
          if (seen.has(url.href)) continue;
          seen.add(url.href);
          items.push({ url: url.href, text: item.text.trim().slice(0, 300) });
        } catch (_) { errors.push('Пропущено сообщение без корректной ссылки chatZone или текста.'); }
      }
    }
    return { items: items.slice(0, 10), errors: Array.from(new Set(errors)), message: [typeof data.message === 'string' ? data.message : '', ...noMatchNotes].filter(Boolean).join(' ') };
  }

  function addThreadChannels(state) {
    const urls = state.channels.trim().split(/[\s,;]+/).filter(Boolean).map(value => {
      let url;
      try { url = new URL(value); } catch (_) { throw new Error('Некорректная ссылка на канал: ' + value); }
      if (url.protocol !== 'https:' || url.username || url.password || !['chatzone.o3t.ru', 'chatzone.o3.ru'].includes(url.hostname) || !/^\/[^/]+\/channels\/[^/]+\/?$/.test(url.pathname)) throw new Error('Некорректная ссылка на канал: ' + value);
      return url.origin + url.pathname.replace(/\/$/, '');
    });
    urls.forEach(url => { if (!state.choices.some(choice => choice.url === url)) state.choices.push({ url, checked: true }); });
    state.channels = '';
  }

  async function runThreadChannelStep(key, reply = '', retryIndex = -1) {
    const state = getTicketSearchState(key, 'threads');
    const previous = retryIndex >= 0 ? state.history[retryIndex] : null;
    if (state.loading || (retryIndex >= 0 && (!previous || (!previous.error && !previous.errors.length))) || (retryIndex < 0 && !state.queue[state.index])) return;
    const channel = previous ? previous.channel : state.queue[state.index];
    if (previous) reply = previous.reply || '';
    const conversation = state.history.filter((step, index) => step.channel === channel && (retryIndex < 0 || index < retryIndex) && !step.error && !step.errors.length).map(step => ({ reply: step.reply, response: step.response }));
    state.loading = true;
    state.retryIndex = retryIndex;
    state.error = '';
    renderStructure();
    let step = { channel, reply, response: '', items: null, errors: [], error: '', raw: '', message: '' };
    try {
      const text = await new Promise((resolve, reject) => {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) { reject(new Error('Поиск доступен в установленном расширении Chrome')); return; }
        chrome.runtime.sendMessage({type:'o3ds:chat',mode:'search_threads',issueKey:key,approvedDescription:JSON.stringify({channels:[channel],reply,conversation})}, response => {
          const error = chrome.runtime.lastError;
          if (error || !response?.ok) reject(new Error(error?.message || response?.error || 'Нет ответа DeepSeek'));
          else resolve(response.text || '');
        });
      });
      step.response = String(text);
      try { Object.assign(step, parseTicketSearchResponse(step.response, 'threads', key)); }
      catch (error) { step.error = String(error.message || error); step.raw = step.response; }
    } catch (error) {
      step.error = String(error.message || error);
      step.response = step.error;
    } finally {
      if (retryIndex >= 0) state.history[retryIndex] = step;
      else { state.history.push(step); state.reply = ''; }
      state.loading = false;
      state.retryIndex = -1;
      if (selectedTaskKey === key) renderStructure();
    }
  }

  function renderThreadChannelControls(key, state) {
    const locked = state.queue.length > 0 || state.loading;
    const disabled = locked ? ' disabled' : '';
    let html = '<div style="font-size:11px;color:#64748b;margin-bottom:8px;">Последние 30 дней. Выберите каналы и перетащите их в нужном порядке. Проверяется один канал за шаг.</div>';
    html += '<div style="max-height:260px;overflow:auto;margin-bottom:10px;">' + state.choices.map((choice, index) =>
      '<div data-thread-channel-row="' + index + '" data-issue-key="' + escapeHtml(key) + '" draggable="' + !locked + '" style="display:flex;align-items:center;gap:6px;padding:6px;border-bottom:1px solid #e2e8f0;">' +
      '<span aria-hidden="true" style="color:#94a3b8;cursor:grab;">⠿</span><label style="display:flex;gap:6px;align-items:center;min-width:0;flex:1;"><input type="checkbox" data-thread-channel-check="' + index + '" data-issue-key="' + escapeHtml(key) + '"' + (choice.checked ? ' checked' : '') + disabled + '><span style="overflow-wrap:anywhere;">' + escapeHtml(new URL(choice.url).pathname.split('/').pop()) + '</span></label>' +
      '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-thread-channel-move="' + index + '" data-direction="-1" data-issue-key="' + escapeHtml(key) + '" aria-label="Канал выше"' + (locked || index === 0 ? ' disabled' : '') + '>↑</button>' +
      '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-thread-channel-move="' + index + '" data-direction="1" data-issue-key="' + escapeHtml(key) + '" aria-label="Канал ниже"' + (locked || index === state.choices.length - 1 ? ' disabled' : '') + '>↓</button></div>').join('') + '</div>';
    if (!locked) html += '<label>Дополнительные каналы<textarea data-ticket-search-channels="' + escapeHtml(key) + '" rows="2" placeholder="Ссылки на каналы, каждая с новой строки" style="width:100%;box-sizing:border-box;resize:vertical;">' + escapeHtml(state.channels) + '</textarea></label><button type="button" class="ozon-ext-btn" data-thread-channels-add data-issue-key="' + escapeHtml(key) + '" style="margin:6px 0;">Добавить каналы</button>';
    if (state.queue.length) html += '<div style="font-weight:600;margin:8px 0;">Канал ' + (state.index + 1) + ' из ' + state.queue.length + ': ' + escapeHtml(new URL(state.queue[state.index]).pathname.split('/').pop()) + '</div>';
    return html;
  }

  function renderThreadSearchResult(key, item) {
    return '<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid #e2e8f0;"><div style="white-space:pre-wrap;overflow-wrap:anywhere;min-width:0;flex:1;">' + escapeHtml(item.text) + '</div><div style="display:flex;gap:6px;flex-shrink:0;"><a class="ozon-ext-btn ozon-ext-btn-surface" href="' + escapeHtml(item.url) + '" target="_blank" rel="noopener noreferrer">Открыть сообщение</a><button type="button" class="ozon-ext-btn" data-thread-link-url="' + escapeHtml(item.url) + '" data-issue-key="' + escapeHtml(key) + '">Связать</button></div></div>';
  }

  function renderThreadSearchHistory(key, state) {
    let html = state.history.map((step, index) => '<details' + (index === state.history.length - 1 || step.error || step.errors.length || state.retryIndex === index ? ' open' : '') + ' style="margin:10px 0;"><summary style="font-weight:600;">' + escapeHtml(new URL(step.channel).pathname.split('/').pop()) + (step.reply ? ' · уточнение' : '') + '</summary><div style="padding-top:8px;">' +
      (step.error ? '<div role="alert" style="color:#b42318;">' + escapeHtml(step.error) + '</div>' : '') +
      (step.message ? '<p>' + escapeHtml(step.message) + '</p>' : '') +
      (step.items && !step.items.length ? '<p>' + (step.errors.length ? 'Нет подтверждённых результатов. Есть ошибки поиска.' : 'Совпадений не найдено.') + '</p>' : '') +
      (step.items || []).map(item => renderThreadSearchResult(key, item)).join('') +
      step.errors.map(error => '<div style="color:#b42318;">' + escapeHtml(error) + '</div>').join('') +
      ((step.error || step.errors.length) ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-thread-search-retry="' + index + '" data-issue-key="' + escapeHtml(key) + '"' + (state.loading ? ' disabled' : '') + '>' + (state.loading && state.retryIndex === index ? 'Повторный поиск…' : 'Повторить поиск') + '</button>' : '') +
      (step.raw ? '<details><summary>Ответ DeepSeek</summary>' + renderAnswerMarkup(step.raw) + '</details>' : '') + '</div></details>').join('');
    if (state.queue.length && !state.loading && state.history.length) {
      html += '<div style="display:flex;gap:8px;margin-top:12px;"><button type="button" class="ozon-ext-btn" data-thread-search-next data-issue-key="' + escapeHtml(key) + '"' + (state.index + 1 >= state.queue.length ? ' disabled' : '') + '>Продолжить</button><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-thread-search-reset data-issue-key="' + escapeHtml(key) + '">Изменить каналы</button></div>';
      if (state.index + 1 >= state.queue.length) html += '<p>' + (state.history.some(step => step.error || step.errors.length) ? 'Поиск завершён с ошибками. Можно повторить поиск в нужном канале.' : 'Все выбранные каналы проверены. Можно уточнить последний результат.') + '</p>';
      html += '<textarea data-thread-search-reply="' + escapeHtml(key) + '" rows="3" placeholder="Уточнение по текущему каналу" style="width:100%;box-sizing:border-box;margin-top:10px;resize:vertical;">' + escapeHtml(state.reply) + '</textarea><button type="button" class="ozon-ext-btn" data-thread-search-answer data-issue-key="' + escapeHtml(key) + '"' + (!state.reply.trim() ? ' disabled' : '') + '>Ответить</button>';
    }
    return html;
  }

  function renderTicketSearchSection(key, kind) {
    const state = getTicketSearchState(key, kind);
    const title = kind === 'fcrm' ? 'Похожие задачи FCRM' : 'Обсуждения chatZone';
    const button = kind === 'fcrm' ? 'Искать похожие в FCRM' : 'Искать по тредам';
    let body = '';
    if (state.open) {
      if (kind === 'threads') body += renderThreadChannelControls(key, state);
      if (kind === 'fcrm' || !state.queue.length) body += '<button type="button" class="ozon-ext-btn" data-ticket-search-run="' + kind + '" data-issue-key="' + escapeHtml(key) + '"' + (state.loading ? ' disabled' : '') + '>' + button + '</button>';
      if (kind === 'threads') body += renderThreadSearchHistory(key, state);
      if (state.loading) {
        body += '<div role="status" aria-label="Поиск выполняется" style="padding-top:10px;">' + [90, 65, 80].map(width => '<div class="ozon-ext-skeleton" style="display:block;height:18px;margin:10px 0;width:' + width + '%;"></div>').join('') + '</div>';
      } else {
        if (state.error) body += '<div role="alert" style="margin-top:10px;color:#b42318;">' + escapeHtml(state.error) + '</div>';
        if (state.items) {
          if (!state.items.length) body += '<p>' + (state.errors.length ? 'Подтверждённых результатов нет. Поиск выполнен с ошибками.' : 'Совпадений не найдено.') + '</p>';
          body += state.items.map(item => kind === 'fcrm'
            ? '<div style="display:flex;align-items:flex-start;gap:8px;padding:10px 0;border-bottom:1px solid #e2e8f0;"><div style="min-width:0;flex:1;"><a href="/browse/' + encodeURIComponent(item.key) + '" target="_blank" rel="noopener noreferrer" style="color:#005bff;font-weight:700;">' + escapeHtml(item.key) + '</a><div style="overflow-wrap:anywhere;">' + escapeHtml(item.title) + '</div></div>' + getStatusBadgeHtml(item.status) + '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-similar-link="' + escapeHtml(item.key) + '" data-issue-key="' + escapeHtml(key) + '">Связать</button></div>'
            : renderThreadSearchResult(key, item)).join('');
        }
        if (state.errors.length) body += '<div role="alert" style="margin-top:10px;color:#b42318;">' + state.errors.map(error => '<div>' + escapeHtml(error) + '</div>').join('') + '</div>';
        if (state.raw) body += '<details style="margin-top:10px;"><summary>Ответ DeepSeek</summary><div>' + renderAnswerMarkup(state.raw) + '</div></details>';
      }
    }
    return '<div class="ozon-ext-section-card"><button type="button" class="ozon-ext-section-head ' + (state.open ? '' : 'collapsed') + '" data-ticket-search-toggle="' + kind + '" data-issue-key="' + escapeHtml(key) + '" aria-expanded="' + state.open + '" style="width:100%;border:0;text-align:left;"><span style="display:flex;align-items:center;gap:6px;"><span style="color:#005BFF;font-size:10px;">▾</span><span>' + title + '</span></span></button>' + (state.open ? '<div aria-live="polite" aria-busy="' + state.loading + '" style="padding:12px;">' + body + '</div>' : '') + '</div>';
  }

  function showLinksSnackbar(message) {
    let stack = document.getElementById('ozon-links-snackbars');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'ozon-links-snackbars';
      stack.style.cssText = 'position:fixed;bottom:24px;left:24px;z-index:100100;width:min(560px,calc(100vw - 48px));max-height:calc(100vh - 48px);overflow-y:auto;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
      document.body.appendChild(stack);
    }
    const bar = document.createElement('div');
    {
      bar.className = 'ozon-links-snackbar';
      bar.setAttribute('role', 'status');
      bar.setAttribute('aria-live', 'polite');
      bar.style.cssText = 'position:relative;overflow:hidden;padding:14px 16px 18px;border-radius:12px;background:#071026;color:white;box-shadow:0 8px 28px #07102633;font:13px/1.5 sans-serif;display:flex;align-items:flex-start;gap:12px;flex-shrink:0;pointer-events:auto;';
      const text = document.createElement('div');
      text.style.cssText = 'white-space:normal;overflow:auto;max-height:140px;min-width:0;flex:1;';
      const close = document.createElement('button');
      close.type = 'button';
      close.textContent = 'Закрыть';
      close.style.cssText = 'border:0;background:transparent;color:#a9d2ff;cursor:pointer;padding:0;font:inherit;';
      close.onclick = () => bar.remove();
      const progress = document.createElement('div');
      progress.style.cssText = 'position:absolute;bottom:0;left:0;height:3px;width:100%;background:#459bff;transform-origin:left;display:none;';
      bar.append(text, close, progress);
      stack.appendChild(bar);
    }
    bar.firstChild.textContent = message;
    let timer = null, startedAt = 0, remaining = 5000;
    const progress = bar.lastChild;
    const resume = () => {
      if (!bar.isConnected || remaining <= 0) return;
      startedAt = Date.now();
      progress.style.display = 'block';
      progress.style.transition = 'none';
      progress.style.transform = 'scaleX(' + (remaining / 5000) + ')';
      requestAnimationFrame(() => { progress.style.transition = 'transform ' + remaining + 'ms linear'; progress.style.transform = 'scaleX(0)'; });
      timer = setTimeout(() => bar.remove(), remaining);
    };
    bar.addEventListener('mouseenter', () => { if (!timer) return; clearTimeout(timer); timer = null; remaining = Math.max(0, remaining - (Date.now() - startedAt)); progress.style.transition = 'none'; progress.style.transform = 'scaleX(' + (remaining / 5000) + ')'; });
    bar.addEventListener('mouseleave', () => { if (progress.style.display !== 'none' && !timer) resume(); });
    return (nextMessage, html = false) => {
      if (!bar.isConnected) return;
      if (html) {
        const tmp = document.createElement('div'); tmp.innerHTML = nextMessage;
        bar.firstChild.textContent = (tmp.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 240);
      } else bar.firstChild.textContent = nextMessage;
      clearTimeout(timer); timer = null; remaining = 5000;
      if (!bar.matches(':hover')) resume(); else progress.style.display = 'block';
    };
  }

  let threadCreationBusy = false;
  async function openThreadCreationSidebar() {
    const existing = document.getElementById('ozon-thread-sidebar');
    if (existing) { existing.hidden = false; return; }
    const panel = document.createElement('aside');
    panel.id = 'ozon-thread-sidebar';
    panel.setAttribute('aria-label', 'Создать FCRM из треда');
    panel.style.cssText = 'position:fixed;right:0;top:40px;bottom:0;width:min(480px,100vw);z-index:100050;background:white;box-shadow:-8px 0 28px #07102622;padding:20px;overflow:auto;font:13px/1.5 sans-serif;color:#071026;';
    panel.innerHTML = '<div style="display:flex;justify-content:space-between;gap:12px"><strong>Создать FCRM из треда</strong><button type="button" data-thread-close>Закрыть</button></div><form style="display:flex;flex-direction:column;gap:14px;margin-top:20px;"><label>Ссылки на треды chatZone<textarea name="urls" rows="5" required placeholder="https://chatzone.o3t.ru/pl/…"></textarea></label><label>Тип задачи<input name="issueType" list="ozon-thread-types" placeholder="Поиск типа задачи" required autocomplete="off"><datalist id="ozon-thread-types"></datalist></label><label>Компонент FCRM<input name="component" list="ozon-thread-components" placeholder="Поиск компонента" required autocomplete="off"><datalist id="ozon-thread-components"></datalist></label><button type="submit" disabled>Создать задачу</button><div role="status" aria-live="polite">Загружаю типы задач и компоненты…</div><a data-thread-result target="_blank" rel="noopener noreferrer" hidden></a></form>';
    panel.querySelectorAll('input,textarea,button').forEach(el => {
      el.style.cssText = 'box-sizing:border-box;max-width:100%;padding:8px 10px;border:1px solid #dce3eb;border-radius:9px;background:white;color:#071026;font:inherit;';
      if (el.matches('input,textarea')) el.style.width = '100%';
    });
    const form = panel.querySelector('form');
    const resultView = document.createElement('div');
    resultView.setAttribute('aria-live', 'polite');
    form.before(resultView);
    const skeleton = document.createElement('div');
    skeleton.hidden = true;
    skeleton.setAttribute('role', 'status');
    skeleton.setAttribute('aria-label', 'DeepSeek создаёт задачу');
    skeleton.innerHTML = '<p>Изучаю обсуждения и создаю задачу…</p>' + [95, 70, 90, 80, 60].map(width => '<div aria-hidden="true" style="display:block!important;height:20px!important;min-height:20px!important;margin:16px 0!important;width:' + width + '%!important;border-radius:7px!important;background:linear-gradient(90deg,#eef2f6 25%,#dce4ee 50%,#eef2f6 75%)!important;background-size:200% 100%!important;animation:ozon-skeleton-shimmer 1.2s linear infinite!important;"></div>').join('');
    form.before(skeleton);
    const submit = panel.querySelector('[type="submit"]');
    submit.style.background = '#005bff';
    submit.style.color = 'white';
    const urlsInput = form.querySelector('[name="urls"]');
    urlsInput.rows = 3;
    urlsInput.placeholder = 'https://chatzone.o3t.ru/o3/pl/…';
    urlsInput.style.cssText += 'resize:vertical;min-height:88px;border:0;background:transparent;outline:none;';
    const urlField = document.createElement('div');
    urlField.style.cssText = 'display:flex;align-items:flex-start;gap:4px;margin-top:6px;border:1px solid #dce3eb;border-radius:10px;background:#f8fbff;';
    const urlIcon = document.createElement('span');
    urlIcon.style.cssText = 'display:flex;padding:12px 0 0 12px;color:#005bff;flex-shrink:0;';
    urlIcon.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="m10 13 4-4M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 8l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/></svg>';
    urlsInput.replaceWith(urlField);
    urlField.append(urlIcon, urlsInput);
    urlsInput.addEventListener('focus', () => { urlField.style.borderColor = '#005bff'; });
    urlsInput.addEventListener('blur', () => { urlField.style.borderColor = '#dce3eb'; });
    const urlHint = document.createElement('div');
    urlHint.id = 'ozon-thread-url-hint';
    urlHint.textContent = 'Вставьте ссылку на тред. Несколько ссылок — каждая с новой строки.';
    urlHint.style.cssText = 'margin-top:4px;font-size:11px;color:#64748b;';
    urlsInput.setAttribute('aria-describedby', urlHint.id);
    urlField.after(urlHint);
    const contextLabel = document.createElement('label');
    contextLabel.textContent = 'Дополнительная информация';
    const contextInput = document.createElement('textarea');
    contextInput.name = 'additionalInfo';
    contextInput.rows = 4;
    contextInput.placeholder = 'Контекст, требования или уточнения, которых нет в обсуждении';
    contextInput.style.cssText = 'display:block;box-sizing:border-box;width:100%;margin-top:6px;padding:8px 10px;min-height:100px;resize:vertical;border:1px solid #dce3eb;border-radius:9px;background:white;color:#071026;font:inherit;';
    contextLabel.appendChild(contextInput);
    submit.before(contextLabel);
    const status = form.querySelector('[role="status"]');
    const conversation = [];
    let requestSnapshot = null;
    let createdIssueKey = '';
    let uncertainResult = false;
    const followup = document.createElement('form');
    followup.style.cssText = 'display:none;flex-direction:column;gap:10px;margin-top:18px;';
    const reply = document.createElement('textarea');
    reply.rows = 3;
    reply.placeholder = 'Уточните детали или объясните отличия от найденных дублей';
    reply.setAttribute('aria-label', reply.placeholder);
    reply.style.cssText = 'box-sizing:border-box;width:100%;min-height:88px;padding:10px;border:1px solid #dce3eb;border-radius:9px;resize:vertical;font:inherit;';
    const continueButton = document.createElement('button');
    continueButton.type = 'submit';
    continueButton.textContent = 'Продолжить';
    continueButton.disabled = true;
    continueButton.style.cssText = 'padding:9px 12px;background:#005bff;color:white;border:0;border-radius:9px;font:inherit;cursor:pointer;';
    reply.oninput = () => {
      continueButton.disabled = threadCreationBusy || !reply.value.trim();
      reply.style.height = '88px';
      reply.style.height = Math.min(220, Math.max(88, reply.scrollHeight)) + 'px';
    };
    followup.append(reply, continueButton);
    panel.appendChild(followup);
    panel.querySelector('[data-thread-close]').onclick = () => {
      if (threadCreationBusy) panel.hidden = true;
      else panel.remove();
    };
    document.body.appendChild(panel);
    try {
      const [types, components] = await Promise.all([loadIssueCreateMeta('FCRM'), loadIssueCreateComponents('FCRM')]);
      const availableTypes = types.filter(type => !type.subtask && !/sub.?task|подзадач/i.test(type.name));
      const makeSelect = (name, options, placeholder) => {
        const original = form.querySelector('[name="' + name + '"]');
        const wrapper = document.createElement('div');
        wrapper.className = 'ozon-ext-search-select';
        wrapper.style.position = 'relative';
        wrapper.innerHTML = '<button type="button" class="ozon-ext-search-select-trigger" aria-expanded="false"><span class="ozon-ext-search-select-value"></span><span class="ozon-ext-search-select-caret" aria-hidden="true"></span></button><div class="ozon-ext-combo-popover ozon-ext-search-select-popover" hidden><input type="search" autocomplete="off"><div class="ozon-ext-combo-list"></div></div>';
        original.replaceWith(wrapper);
        const trigger = wrapper.querySelector('button');
        const label = trigger.querySelector('span');
        label.textContent = placeholder;
        const menu = wrapper.querySelector('.ozon-ext-combo-popover');
        const search = menu.querySelector('input');
        const list = menu.querySelector('.ozon-ext-combo-list');
        menu.style.setProperty('display', 'none', 'important');
        search.placeholder = placeholder;
        search.setAttribute('aria-label', placeholder);
        let selected = null;
        const close = () => {
          menu.hidden = true;
          menu.style.setProperty('display', 'none', 'important');
          trigger.setAttribute('aria-expanded', 'false');
        };
        const draw = () => {
          list.replaceChildren();
          const query = search.value.trim().toLocaleLowerCase('ru');
          options.filter(item => item.name.toLocaleLowerCase('ru').includes(query)).forEach(item => {
            const option = document.createElement('button');
            option.type = 'button';
            option.className = 'ozon-ext-combo-item ozon-ext-search-select-option' + (selected?.id === item.id ? ' active' : '');
            option.textContent = item.name;
            option.style.cssText = 'background:transparent;border:0;text-align:left;width:100%;';
            option.onclick = () => { selected = item; label.textContent = item.name; close(); trigger.focus(); };
            list.appendChild(option);
          });
          if (!list.children.length) list.textContent = 'Ничего не найдено';
        };
        trigger.onclick = () => {
          if (!menu.hidden) { close(); return; }
          panel.querySelectorAll('.ozon-ext-search-select-trigger[aria-expanded="true"]').forEach(other => other.click());
          menu.hidden = false;
          menu.style.setProperty('display', 'flex', 'important');
          trigger.setAttribute('aria-expanded', 'true');
          search.value = '';
          draw();
          search.focus();
        };
        search.oninput = draw;
        wrapper.addEventListener('keydown', event => {
          if (event.key === 'Escape') { close(); trigger.focus(); event.preventDefault(); }
          if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            const items = Array.from(list.querySelectorAll('button'));
            const index = items.indexOf(document.activeElement);
            const next = event.key === 'ArrowDown' ? index + 1 : index <= 0 ? items.length - 1 : index - 1;
            items[(next + items.length) % items.length]?.focus();
            event.preventDefault();
          }
          if (event.key === 'Enter' && document.activeElement === search) {
            event.preventDefault();
            list.querySelector('button')?.click();
          }
        });
        wrapper.addEventListener('focusout', event => { if (!wrapper.contains(event.relatedTarget)) close(); });
        return () => selected;
      };
      const getType = makeSelect('issueType', availableTypes, 'Поиск типа задачи');
      const getComponent = makeSelect('component', components, 'Поиск компонента');
      panel.querySelectorAll('datalist').forEach(el => el.remove());
      status.textContent = 'Укажите одну или несколько ссылок. Задача будет создана сразу после обработки обсуждений.';
      submit.disabled = false;
      form.onsubmit = async event => {
        event.preventDefault();
        if (threadCreationBusy) return;
        const values = new FormData(form);
        const urls = Array.from(new Set(String(values.get('urls') || '').trim().split(/[\s,;]+/).filter(Boolean)));
        const type = getType();
        const component = getComponent();
        if (!urls.length) { status.textContent = 'Добавьте хотя бы одну ссылку на тред chatZone.'; return; }
        const invalidUrl = urls.find(url => {
          try { const parsed = new URL(url); return parsed.protocol !== 'https:' || !['chatzone.o3t.ru', 'chatzone.o3.ru'].includes(parsed.hostname) || !/\/pl\/[^/]+\/?$/.test(parsed.pathname); } catch (_) { return true; }
        });
        if (invalidUrl) { status.textContent = 'Не удалось распознать ссылку на тред: ' + invalidUrl; return; }
        if (!type) { status.textContent = 'Выберите тип задачи из выпадающего списка.'; return; }
        if (!component) { status.textContent = 'Выберите компонент FCRM из выпадающего списка.'; return; }
        threadCreationBusy = true;
        submit.disabled = true;
        status.textContent = 'Подбираю примеры задач…';
        let exampleIssueKeys = [];
        try {
          const quoteJql = value => '"' + String(value).split(String.fromCharCode(92)).join(String.fromCharCode(92,92)).split('"').join(String.fromCharCode(92) + '"') + '"';
          const exampleJql = 'project = FCRM AND issuetype = ' + quoteJql(type.name) + ' AND component = ' + quoteJql(component.name) + ' ORDER BY created DESC';
          const exampleResponse = await fetch('/rest/api/2/search?jql=' + encodeURIComponent(exampleJql) + '&fields=issuetype,components&maxResults=2', {credentials:'same-origin', headers:{Accept:'application/json'}});
          if (exampleResponse.ok) {
            const exampleData = await exampleResponse.json();
            exampleIssueKeys = (exampleData.issues || []).filter(issue => /^FCRM-[0-9]+$/i.test(issue.key || '') && String(issue.fields?.issuetype?.name || '').toLowerCase() === String(type.name).toLowerCase() && (issue.fields?.components || []).some(item => String(item.name || '').toLowerCase() === String(component.name).toLowerCase())).map(issue => issue.key).slice(0, 2);
          }
        } catch (_) { /* Примеры необязательны для создания задачи. */ }
        requestSnapshot = { urls: Array.from(urls), issueTypeName: String(type.name || '').trim(), componentName: String(component.name || '').trim(), issueTypeId: String(type.id || ''), componentId: String(component.id || ''), exampleIssueKeys, additionalInfo: String(values.get('additionalInfo') || '') };
        await runRequest(requestSnapshot);
      };
      followup.onsubmit = async event => {
        event.preventDefault();
        if (threadCreationBusy || !reply.value.trim() || !requestSnapshot) return;
        await runRequest(Object.assign({}, requestSnapshot, {
          continuation: true,
          existingIssueKey: createdIssueKey,
          uncertainResult,
          conversation: conversation.slice(),
          clarification: reply.value.trim()
        }));
      };
      const runRequest = async input => {
        threadCreationBusy = true;
        followup.style.display = 'none';
        continueButton.disabled = true;
        form.hidden = true;
        form.style.setProperty('display', 'none', 'important');
        panel.setAttribute('aria-busy', 'true');
        resultView.replaceChildren();
        skeleton.hidden = false;
        skeleton.style.setProperty('display', 'block', 'important');
        submit.disabled = true;
        const resultLink = panel.querySelector('[data-thread-result]');
        resultLink.hidden = true;
        const update = showLinksSnackbar('Собираю обсуждения chatZone и создаю FCRM. Можно продолжать работу.');
        status.textContent = 'DeepSeek читает обсуждения и создаёт задачу…';
        let rejectedBeforeCreation = false;
        try {
          const text = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) { rejectedBeforeCreation = true; reject(new Error('Доступно в установленном расширении Chrome')); return; }
            chrome.runtime.sendMessage({type:'o3ds:chat',mode:'thread',issueKey:'FCRM',approvedDescription:JSON.stringify(input)}, response => {
              const error = chrome.runtime.lastError;
              if (error || !response?.ok) { if (response?.errorCode === 'THREAD_INPUT_INVALID') rejectedBeforeCreation = true; reject(new Error(error?.message || response?.error || 'Нет ответа DeepSeek')); }
              else resolve(response.text || 'DeepSeek не вернул результат');
            });
          });
          const key = /<created_issue>\s*(FCRM-[0-9]+)\s*<\/created_issue>/i.exec(String(text))?.[1];
          if (key && !createdIssueKey) createdIssueKey = key;
          conversation.push({ clarification: input.clarification || '', response: String(text) });
          reply.value = '';
          const message = String(text).replace(/<\/?created_issue>/gi, '');
          status.textContent = 'Обработка завершена';
          resultView.innerHTML = renderStructuredAnswer(String(text), 'thread', renderAnswerMarkup);
          if (createdIssueKey && !key) {
            resultView.innerHTML = renderStructuredAnswer('<created_issue>' + createdIssueKey + '</created_issue>' + String(text), 'thread', renderAnswerMarkup);
          }
          update(renderStructuredAnswer(String(text), 'thread', renderAnswerMarkup), true);
          if (key) {
            submit.textContent = 'Создано ' + key;
          } else {
            status.textContent += ' Проверьте результат в Jira перед повторным созданием.';
          }
        } catch (error) {
          uncertainResult = !rejectedBeforeCreation;
          const message = 'Ошибка: ' + String(error.message || error) + (rejectedBeforeCreation ? '' : '. Проверьте Jira перед повторной попыткой: задача могла уже создаться.');
          status.textContent = message;
          resultView.textContent = message;
          update(message);
        } finally {
          threadCreationBusy = false;
          skeleton.hidden = true;
          skeleton.style.setProperty('display', 'none', 'important');
          form.hidden = !rejectedBeforeCreation;
          form.style.setProperty('display', rejectedBeforeCreation ? 'flex' : 'none', 'important');
          submit.disabled = false;
          followup.style.display = rejectedBeforeCreation ? 'none' : 'flex';
          continueButton.disabled = !reply.value.trim();
          panel.setAttribute('aria-busy', 'false');
        }
      };
    } catch (error) {
      status.textContent = 'Не удалось загрузить поля FCRM: ' + String(error.message || error);
    }
  }

  function generationIconHtml() {
    return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m10 13 4-4M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 8l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0" transform="translate(1 1) scale(.85)"/><path d="m19 2 1 2 2 1-2 1-1 2-1-2-2-1 2-1Z"/></svg>';
  }

  function renderTaskProjectGeneration(task) {
    const linked = (task.projectTaskLinks || []).some(link => !isCanceledStatus(link.status));
    const busy = generatingLinkKeys.has(task.key);
    const title = (linked ? 'Задача проекта есть' : 'Нет Задачи проекта') + ' · Сгенерировать связи';
    return '<button type="button" class="ozon-ext-btn ozon-ext-inner-ctrl ozon-ext-project-generation ' + (linked ? 'linked' : 'missing') + '" data-action="generate-links" data-task-keys="' + escapeHtml(task.key) + '" ' + (busy ? 'disabled aria-busy="true"' : '') + ' title="' + title + '" aria-label="' + title + '">' + (busy ? '<span class="ozon-ext-spinner"></span>' : generationIconHtml()) + '</button>';
  }

  function renderMissingCustomerIndicator(task) {
    if (/^(ошибка|bug)$/i.test(String(task.issueTypeName || '').trim())) return '';
    const customer = task.customer || {};
    const name = String(customer.name || '').trim().toLowerCase();
    if (customer.login || (name && !['не указан', 'не назначен', '—', '-', 'unknown', 'unassigned'].includes(name))) return '';
    return '<span class="ozon-ext-delivery-indicator" role="img" aria-label="Нет заказчика" title="Не указан Заказчик/Owner" style="color:#D92D20;background:#FFF0EE;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 10-4M18 12v5M18 21h.01"/></svg></span>';
  }

  function renderDeliveryIndicators(task) {
    const links = (task.inProjectLinks || []).filter(link => !isCanceledStatus(link.status));
    return '<span class="ozon-ext-delivery-indicators">' + [
      { project: 'FTD', label: 'Дизайн' },
      { project: 'OB', label: 'Бэкенд' },
      { project: 'OBFRONT', label: 'Фронтенд' }
    ].map(group => {
      const items = links.filter(link => String(link.key || '').split('-')[0].toUpperCase() === group.project);
      const state = !items.length ? 'absent' : items.every(isDoneTask) ? 'done' : 'active';
      const title = group.label + ': ' + (!items.length ? 'нет задач' : state === 'done' ? 'все задачи закрыты' : 'есть незакрытые задачи');
      const detail = title + (items.length ? ' · ' + items.map(item => item.key + ' — ' + item.status).join('; ') : '');
      return '<span class="ozon-ext-delivery-indicator ' + state + '" role="img" aria-label="' + escapeHtml(title) + '" title="' + escapeHtml(detail) + '">' + getLinkedProjectGroupMeta(group.project + '-1', false).iconSvg + '</span>';
    }).join('') + '</span>';
  }

  async function refreshGeneratedTaskLinks(key) {
    const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=issuelinks', {
      credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }
    });
    if (!response.ok) throw new Error('Не удалось обновить связи ' + key);
    const raw = await response.json();
    await syncStrategyLinks(raw);
    const updated = (await normalizeAndEnrichJiraIssues([raw]))[0];
    if (!updated) throw new Error('Нет данных связей ' + key);
    tasks = tasks.map(task => task.key === key ? Object.assign({}, task, {
      projectTaskLinks: updated.projectTaskLinks,
      inProjectLinks: updated.inProjectLinks,
      otherLinks: updated.otherLinks
    }) : task);
  }
  let isInitialBoardLoading = false;
  let initialLoadProgress = 4;
  let initialLoadStage = 'Подключаемся к Jira';
  let groupByComponentInsideSprint = true;
  const productGroupingStorage = 'ozon-product-grouping-v1';
  let productGroupingOrder = (() => { try { const saved = JSON.parse(localStorage.getItem(productGroupingStorage) || 'null'); if (Array.isArray(saved) && saved.every((x) => ['sprint', 'component'].includes(x)) && new Set(saved).size === saved.length) return saved; } catch (_) {} return ['sprint', 'component']; })();
  groupByComponentInsideSprint = productGroupingOrder.length > 1;
  let productExpandedGroups = {};
  let selectedTaskKey = null;
  let isSidebarOpen = false;
  function syncStrategyIssue(raw) {
    const issue = raw?.key && strategicDashboard.getState().issues.find((item) => item.key === raw.key);
    if (!issue?.fields || !raw.fields) return;
    Object.assign(issue.fields, raw.fields);
    strategicDashboard.invalidateGraph();
  }
  async function refreshStrategyIssue(key, fields, deferRender) {
    if (!strategicDashboard.getState().issues.some((item) => item.key === key)) return;
    try {
      const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=' + encodeURIComponent(fields), {credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});
      if (!response.ok) return;
      syncStrategyIssue(await response.json());
      if (!deferRender && activeDashboardView === 'strategy') renderStructure();
    } catch (_) { /* Следующее обновление списка повторит чтение из Jira. */ }
  }
  async function syncStrategyLinks(raw) {
    const issue = raw?.key && strategicDashboard.getState().issues.find((item) => item.key === raw.key);
    if (!issue?.fields || !Array.isArray(raw.fields?.issuelinks)) return;
    const oldLinks = issue.fields.issuelinks || [];
    const newLinks = raw.fields.issuelinks;
    const signature = (links) => links.map((link) => String(link.id || '') + ':' + ((link.inwardIssue || link.outwardIssue || {}).key || '') + ':' + (link.type?.name || '')).sort().join('|');
    const changed = signature(oldLinks) !== signature(newLinks);
    syncStrategyIssue(raw);
    if (!changed) return;
    const keys = [...new Set([...oldLinks, ...newLinks].map((link) => (link.inwardIssue || link.outwardIssue || {}).key).filter((key) => key && key !== raw.key))];
    await Promise.all(keys.map((key) => refreshStrategyIssue(key, 'issuelinks', true)));
  }
  let isEditingDescription = false;
  const sidebarDrafts = new Map();
  function sidebarDraft(key) {
    if (!sidebarDrafts.has(key)) sidebarDrafts.set(key, {});
    return sidebarDrafts.get(key);
  }
  async function saveSidebarFields(key, fields) {
    const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), {
      method:'PUT', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify({fields})
    });
    if (!response.ok) throw new Error('Jira ответила с ошибкой ' + response.status);
    tasks = tasks.map((task) => task.key === key ? Object.assign({}, task, fields) : task);
    saveTaskOverride(key, fields);
    const draft = sidebarDraft(key);
    Object.keys(fields).forEach((field) => { if (draft[field] === fields[field] || (field === 'summary' && String(draft[field] || '').trim() === fields[field])) delete draft[field]; });
    const strategyIssue = strategicDashboard.getState().issues.find((issue) => issue.key === key);
    if (strategyIssue?.fields) { Object.assign(strategyIssue.fields, fields); strategicDashboard.invalidateGraph(); }
  }
  async function confirmSidebarExit() {
    const key = selectedTaskKey;
    const draft = sidebarDrafts.get(key);
    if (!draft || (!Object.prototype.hasOwnProperty.call(draft, 'summary') && !Object.prototype.hasOwnProperty.call(draft, 'description'))) return true;
    const choice = await new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'ozon-sidebar-draft-overlay';
      overlay.innerHTML = '<div class="ozon-sidebar-draft-dialog" role="dialog" aria-modal="true" aria-labelledby="ozon-draft-title"><strong id="ozon-draft-title">Есть несохранённые изменения</strong><p>Сохранить изменения задачи ' + escapeHtml(key) + ' перед закрытием?</p><div><button type="button" data-choice="stay">Продолжить редактирование</button><button type="button" data-choice="discard">Не сохранять</button><button type="button" class="primary" data-choice="save">Сохранить</button></div></div>';
      document.body.appendChild(overlay);
      overlay.querySelectorAll('[data-choice]').forEach((button) => button.addEventListener('click', () => { const value = button.getAttribute('data-choice'); overlay.remove(); resolve(value); }));
      overlay.querySelector('[data-choice="stay"]').focus();
    });
    if (choice === 'stay') return false;
    if (choice === 'discard') { sidebarDrafts.delete(key); return true; }
    const fields = Object.assign({}, draft);
    if (Object.prototype.hasOwnProperty.call(fields, 'summary')) { fields.summary = fields.summary.trim(); if (!fields.summary) { showSaveToast('Название задачи не может быть пустым'); return false; } }
    try { await saveSidebarFields(key, fields); sidebarDrafts.delete(key); showSaveToast('Изменения ' + key + ' сохранены'); return true; }
    catch (error) { showSaveToast('Не удалось сохранить изменения: ' + (error.message || 'ошибка запроса')); return false; }
  }
  let loadingSidebarTaskKey = null;
  let sidebarBlockLoading = { taskKey: null, desc: false, params: false, links: false, ipMeta: false };
  let loadingSprintsMap = {};
  let loadingComponentsMap = {};
  let frontDesignLinksByKey = {};
  let sidebarWidth = Number(localStorage.getItem(STORAGE_KEY_SIDEBAR_W)) || 540;

  // ПО УМОЛЧАНИЮ ВСЕ СПРИНТЫ И ВСЕ КОМПОНЕНТЫ СВЕРНУТЫ!
  // Храним явно развернутые пользователем спринты и компоненты:
  let expandedSprints = {}; // { [sprintName]: true }
  let expandedComponents = {}; // { [sprintName + '::' + compName]: true }
  let expandedSubRows = {};

  // Сворачиваемые аккордеоны в сайдбаре и группы связей OB / OBFRONT / FTD
  let collapsedSidebarSections = {
    desc: false,
    params: false,
    pt: true,
    pt_quick: true, // Быстрый фильтр в аккордеоне «Задачи проекта» по умолчанию закрыт
    ip: false,
    other: false
  };
  let collapsedIpGroups = {}; // { [groupKey]: true }
  let createInProjectMenuOpen = false;
  let otherLinkMenuOpen = false;
  const expandedSidebarDescriptions = new Set();
  let linkCreateDraft = null;
  let issueCreateDraft = null;
  let issueCreateBusy = false;
  let issueCreateLoading = false;
  const projectComponentRequests = new Map();
  const projectComponentRecords = new Map();
  const issueCreateMetaByProject = {};

  // Состояние открытых Input-Select комбобоксов в таблице и сайдбаре
  let activeTableCombo = null; // { type: 'status' | 'epic' | 'component' | 'assignee' | 'customer' | 'sprint', taskKey, query }
  let tableUserSearchResults = [];
  let tableUserSearchTimer = null;
  let sbEpicComboOpen = false;
  let sbEpicSearchQuery = '';
  let sbCompComboOpen = false;
  let sbCompSearchQuery = '';
  let sbIpCompOpenIdx = null; // индекс связи «В проекте», у которой открыт Input-Select компонента
  let sbIpCompSearchQuery = '';
  let sbIpSprintOpenIdx = null;
  let sbIpSprintSearchQuery = '';
  let ipSprintLoadProgress = {};
  let filterEpicComboOpen = false;
  let filterEpicSearchQuery = '';
  let filterCompComboOpen = false;
  let filterCompSearchQuery = '';
  let activeToolbarFilter = '';
  let toolbarFilterSearch = '';
  let activeSearchSelectId = '';
  let searchSelectQuery = '';
  let isColOrderPanelOpen = false;
  let draggedColKey = null;

  // Фильтры и сортировка верхней панели
  let searchQuery = '';
  let filterComponent = 'all';
  let filterEpic = 'all';
  let filterStatus = 'all';
  let allSprintIssuesLoaded = false;
  let loadedSprintMode = null;
  let filterSprintState = 'open_future_backlog'; // активные, будущие и бэклог
  let hideDone = false;
  let filterIssueType = 'all';
  let tableTreeLevel = 'sprints';
  let treeLevelApplied = false;
  let sortByField = 'default'; // 'default' | 'priority_desc' | 'priority_asc' | 'created_desc' | 'created_asc'

  let umbSearchQuery = '';
  let umbSearchTimer = null;
  let epicRemoteSearchTimer = null;
  let assigneeSearchQuery = '';
  let customerSearchQuery = '';
  let searchedUsersResults = [];
  let searchedCustomerResults = [];
  let userSearchTimer = null;
  let custSearchTimer = null;
  let statusMessage = 'Выберите фильтры и загрузите задачи';
  let saveToastText = '';
  let saveToastTimer = null;

  // Динамически обнаруженные метаданные Jira
  let discoveredFields = {
    sprint: null,
    epicLink: null,
    epicName: null,
    storyPoints: null,
    customer: null
  };
  let discoveredCustomerFieldIds = [];
  let discoveredIssueLinkTypes = [];
  let discoveredIssueLinkTypesPromise = null;
  async function loadIssueLinkTypes() {
    if (Array.isArray(discoveredIssueLinkTypes) && discoveredIssueLinkTypes.length) return discoveredIssueLinkTypes;
    if (!discoveredIssueLinkTypesPromise) {
      discoveredIssueLinkTypesPromise = fetch('/rest/api/2/issueLinkType', {
        credentials: 'same-origin', headers: { Accept: 'application/json' }
      }).then(async (response) => {
        if (!response.ok) throw new Error('Не удалось получить типы связей Jira');
        const data = await response.json();
        discoveredIssueLinkTypes = Array.isArray(data.issueLinkTypes) ? data.issueLinkTypes : [];
        return discoveredIssueLinkTypes;
      }).catch((error) => { discoveredIssueLinkTypesPromise = null; throw error; });
    }
    return discoveredIssueLinkTypesPromise;
  }
  let sprintNameById = {};
  let sprintIdByName = {};
  let sprintStateByName = {};
  let sprintOrderWeight = {};
  let boardOwnedSprintIds = new Set();
  let boardOwnedSprintNames = new Set();
  let closedSprintIds = new Set();
  let closedSprintNames = new Set();
  let issueSprintOverrideMap = {};
  let epicNameByKey = {}; // Все эпики (для отображения названий)
  let epicStatusByKey = {};
  let epicLabelsByKey = {};
  let epicObprojectByFcrmEpicKey = {};
  let fcrmEpicNameByKey = {}; // СТРОГО эпики проекта FCRM для Input-Select выбора эпика
  let projectComponentsList = [];
  let externalProjectComponentsMap = {}; // { [projectKey]: string[] }
  let externalProjectSprintsMap = {}; // { [projectKey + '::' + compName]: string[] }
  let discoveredEpicIssueTypeName = null;
  let projectIssueTypesList = []; // [{ id, name, subtask }] — типы задач, доступные в проекте
  let issueTypeIdByName = {}; // { [typeName]: typeId }
  let projectStatusesList = [];
  let statusesByIssueTypeMap = {}; // { [issueTypeName]: string[] } — статусы строго из схемы типа задачи
  let projectPrioritiesList = [];
  let priorityIconUrlMap = {}; // { [priorityName]: iconUrl }
  let assignableUsersList = [];
  let issueTransitionsByKey = {};

  function isCanceledStatus(statusName) {
    if (!statusName) return false;
    const low = String(statusName).trim().toLowerCase();
    return (
      low === 'canceled' ||
      low === 'cancelled' ||
      low.includes('cancel') ||
      low.includes('отмен') ||
      low.includes('отклон') ||
      low === 'rejected'
    );
  }

  function isEpicIssueType(typeName) {
    if (!typeName) return false;
    const low = String(typeName).trim().toLowerCase();
    return low === 'epic' || low === 'эпик' || low.includes('epic') || low.includes('эпик');
  }

  function getPrioritySortWeight(priorityName) {
    const low = String(priorityName || 'Medium').trim().toLowerCase();
    if (low.includes('block') || low.includes('блок')) return 100;
    if (low.includes('crit') || low.includes('highest') || low.includes('крит') || low.includes('наивысш')) return 80;
    if (low.includes('high') || low.includes('major') || low.includes('высок') || low.includes('важн')) return 60;
    if (low.includes('lowest') || low.includes('triv') || low.includes('миним') || low.includes('трив')) return 10;
    if (low.includes('low') || low.includes('minor') || low.includes('низк') || low.includes('незнач')) return 20;
    return 40; // Medium / Стандартный / Средний
  }

  function parseTaskCreatedTimestamp(task) {
    if (!task) return 0;
    if (typeof task.createdTimestamp === 'number' && !isNaN(task.createdTimestamp) && task.createdTimestamp > 0) {
      return task.createdTimestamp;
    }
    const str = String(task.createdAt || '').trim();
    const m = str.match(/^(\d{2})\.(\d{2})\.(\d{4})(?:\s+(\d{2}):(\d{2}))?/);
    if (m) {
      const day = Number(m[1]);
      const month = Number(m[2]) - 1;
      const year = Number(m[3]);
      const hour = m[4] ? Number(m[4]) : 0;
      const min = m[5] ? Number(m[5]) : 0;
      return new Date(year, month, day, hour, min).getTime();
    }
    const parsed = Date.parse(str);
    return isNaN(parsed) ? 0 : parsed;
  }

  function sortTasksList(list) {
    if (!Array.isArray(list) || list.length <= 1 || sortByField === 'default') {
      return list;
    }
    const copy = list.slice();
    if (sortByField === 'priority_desc' || sortByField === 'priority_asc') {
      const dir = sortByField === 'priority_desc' ? -1 : 1;
      copy.sort((a, b) => {
        const wa = getPrioritySortWeight(a.priority);
        const wb = getPrioritySortWeight(b.priority);
        if (wa !== wb) return (wa - wb) * dir;
        return parseTaskCreatedTimestamp(b) - parseTaskCreatedTimestamp(a);
      });
    } else if (sortByField === 'created_desc' || sortByField === 'created_asc') {
      const dir = sortByField === 'created_desc' ? -1 : 1;
      copy.sort((a, b) => {
        const ta = parseTaskCreatedTimestamp(a);
        const tb = parseTaskCreatedTimestamp(b);
        if (ta !== tb) return (ta - tb) * dir;
        return String(a.key || '').localeCompare(String(b.key || ''), 'ru', { numeric: true });
      });
    }
    return copy;
  }

  function isRealHumanJiraUser(u) {
    if (!u) return false;
    const dn = String(u.displayName || '').trim();
    const nm = String(u.name || u.key || '').trim();
    if (!dn && !nm) return false;
    if (dn.startsWith('$') || nm.startsWith('$')) return false;
    if (/^$[A-Z0-9_-]+$/i.test(dn) || /^$[A-Z0-9_-]+$/i.test(nm)) return false;
    // Отсекаем технических роботов, тестовые и почтовые/номерные учетки (08 Robot test, srv_..., 1, 10supervisor@okcall.ru, mailer и т.д.)
    if (/^d+$/.test(dn) || /^d+$/.test(nm)) return false;
    if (dn.includes('@') || nm.includes('@')) return false;
    const lowDn = dn.toLowerCase();
    const lowNm = nm.toLowerCase();
    if (
      lowNm.startsWith('srv_') ||
      lowNm.startsWith('bot_') ||
      lowNm.startsWith('svc_') ||
      lowNm.startsWith('tech_') ||
      lowDn.includes('robot') ||
      lowNm.includes('robot') ||
      lowDn.includes('supervisor') ||
      lowNm.includes('supervisor') ||
      lowDn.includes('mailer') ||
      lowNm.includes('mailer') ||
      lowDn.includes('autotest') ||
      /test/i.test(lowDn)
    ) {
      return false;
    }
    return true;
  }

  function getSprintStateCode(sprintName) {
    if (!sprintName) return 'BACKLOG';
    const clean = String(sprintName).trim();
    const low = clean.toLowerCase();
    if (!clean || clean === 'Не в спринте' || low.includes('бэклог') || low.includes('backlog')) {
      return 'BACKLOG';
    }
    if (sprintStateByName[clean]) {
      const st = String(sprintStateByName[clean]).toUpperCase();
      if (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED') return st;
    }
    if (closedSprintNames.has(clean)) {
      return 'CLOSED';
    }
    if (low.includes('прошедш') || low.includes('closed')) return 'CLOSED';
    if (low.includes('будущ') || low.includes('future')) return 'FUTURE';
    return 'ACTIVE';
  }

  function getSprintStateLabelRu(sprintName) {
    const code = getSprintStateCode(sprintName);
    if (code === 'CLOSED') return 'Прошедший';
    if (code === 'ACTIVE') return 'Активный';
    if (code === 'FUTURE') return 'Будущий';
    return '';
  }

  function formatSprintWithStateText(sprintName) {
    if (!sprintName) return 'Не в спринте';
    const clean = String(sprintName).trim();
    const label = getSprintStateLabelRu(clean);
    if (!label) return clean;
    if (clean.includes('(' + label + ')')) return clean;
    return clean + ' (' + label + ')';
  }

  function getSprintStateBadgeHtml(sprintName) {
    const label = getSprintStateLabelRu(sprintName);
    return label ? renderBadge(escapeHtml(label), getSprintStateCode(sprintName).toLowerCase()) : '';
  }

  const DEFAULT_COLUMNS_META = [
    { key: 'task', label: 'Задача (Спринт → Компонент → Задача)', width: 370 },
    { key: 'status', label: 'Статус ▾', width: 130 },
    { key: 'epic', label: 'Epic Link ▾', width: 240 },
    { key: 'epicObproject', label: 'Эпик OBPROJECT', width: 220 },
    { key: 'component', label: 'Компонент ▾', width: 180 },
    { key: 'assignee', label: 'Исполнитель ▾', width: 165 },
    { key: 'created', label: 'Создана', width: 115 },
    { key: 'sprint', label: 'Спринт ▾', width: 175 }
  ];

  const DEFAULT_COLUMN_ORDER = DEFAULT_COLUMNS_META.map((c) => c.key);
  let epicSearchTimer = null;
  let componentsByProjectMap = externalProjectComponentsMap;

  function getIssueProjectKey(issueKey) {
    if (!issueKey || typeof issueKey !== 'string') return CONFIG.projectKey;
    const parts = issueKey.trim().split('-');
    return (parts[0] || CONFIG.projectKey).toUpperCase();
  }

  async function loadRemoteIssueLinks(issueKey) {
    try {
      const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/remotelink', {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
        cache: 'no-store'
      });
      if (!response.ok) return [];
      const links = await response.json();
      if (!Array.isArray(links)) return [];
      return links.map((link) => {
        const object = link && link.object || {};
        const url = String(object.url || '');
        return {
          id: 'remote-' + String(link.id || url),
          key: String(object.title || url || 'Веб-ссылка'),
          summary: String(object.title || url || 'Веб-ссылка'),
          status: 'Открыто',
          url: url,
          linkType: String(link.relationship || 'Веб-ссылка')
        };
      }).filter((link) => link.url);
    } catch (e) { return []; }
  }

  async function loadEpicObprojectDetails(fcrmEpicKey, suppliedCustomFieldValue) {
    const key = String(fcrmEpicKey || '').trim().toUpperCase();
    if (!key) return;
    const existing = epicObprojectByFcrmEpicKey[key];
    if (existing && existing.loading && arguments.length < 2) return;
    if (existing && existing.key && arguments.length < 2) return;
    const initialSelectedIssue = tasks.find((task) => task.key === selectedTaskKey) || {};
    const initialSourceKey = isEpicIssueType(initialSelectedIssue.issueTypeName) ? initialSelectedIssue.key : initialSelectedIssue.epicKey;
    let obprojectKey = '';
    try {
      let rawValue = suppliedCustomFieldValue;
      if (arguments.length < 2) {
        const fcrmResponse = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=customfield_20100', {
          credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
        });
        if (!fcrmResponse.ok) throw new Error('Не удалось прочитать customfield_20100');
        const fcrmIssue = await fcrmResponse.json();
        rawValue = fcrmIssue && fcrmIssue.fields ? fcrmIssue.fields.customfield_20100 : null;
      }
      const value = Array.isArray(rawValue) ? rawValue[0] : rawValue;
      obprojectKey = String(value && typeof value === 'object' ? value.key || value.value || value.name || value.url || '' : value || '').trim().toUpperCase();
      const matchedKey = /[A-Z][A-Z0-9]+-[0-9]+/.exec(obprojectKey);
      if (!matchedKey) {
        epicObprojectByFcrmEpicKey[key] = { loading: false, key: '', summary: '', status: '' };
      } else {
        obprojectKey = matchedKey[0];
        // Show the key as soon as customfield_20100 is received. Loading the
        // linked issue's summary/status is supplementary and must not hide it.
        epicObprojectByFcrmEpicKey[key] = { loading: true, key: obprojectKey, summary: '', status: '' };
        if (selectedTaskKey && initialSourceKey === key) renderStructure();
        const obKey = obprojectKey;
        const issueResponse = await fetch('/rest/api/2/issue/' + encodeURIComponent(obKey) + '?fields=summary,status', {
          credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
        });
        if (issueResponse.ok) {
          const obIssue = await issueResponse.json();
          epicObprojectByFcrmEpicKey[key] = {
            loading: false,
            key: obKey,
            summary: String(obIssue.fields && obIssue.fields.summary || ''),
            status: readStatusName(obIssue.fields && obIssue.fields.status, '')
          };
        } else {
          epicObprojectByFcrmEpicKey[key] = { loading: false, key: obKey, summary: '', status: '', error: true };
        }
      }
    } catch (_) {
      epicObprojectByFcrmEpicKey[key] = obprojectKey
        ? { loading: false, key: obprojectKey, summary: '', status: '', error: true }
        : { loading: false, error: true };
    }
    const selectedIssue = tasks.find((task) => task.key === selectedTaskKey) || {};
    const selectedObprojectSource = isEpicIssueType(selectedIssue.issueTypeName) ? selectedIssue.key : selectedIssue.epicKey;
    if (selectedTaskKey && selectedObprojectSource === key) renderStructure();
  }

  function cacheEpicMetadata(issues) {
    issues.forEach(issue => {
      const fields = issue.fields || {};
      if (fields.summary) epicNameByKey[issue.key] = String(fields.summary);
      if (fields.status) epicStatusByKey[issue.key] = readStatusName(fields.status, '');
      if (Array.isArray(fields.labels)) epicLabelsByKey[issue.key] = fields.labels;
      if (!Object.prototype.hasOwnProperty.call(fields, 'customfield_20100')) return;
      let value = fields.customfield_20100;
      if (Array.isArray(value)) value = value[0];
      const raw = value && typeof value === 'object' ? value.key || value.value || value.name || value.url || '' : value || '';
      const match = /[A-Z][A-Z0-9]+-[0-9]+/.exec(String(raw).toUpperCase());
      const key = match ? match[0] : '';
      const previous = epicObprojectByFcrmEpicKey[issue.key];
      if (!previous || previous.key !== key) epicObprojectByFcrmEpicKey[issue.key] = { loading:false, key, summary:'', status:'' };
    });
  }

  async function loadTableObprojectMetadata() {
    const pending = Object.entries(epicObprojectByFcrmEpicKey).filter(([source, value]) => value.key);
    const keys = Array.from(new Set(pending.map(([source, value]) => value.key)));
    for (let offset = 0; offset < keys.length; offset += 50) {
      const chunk = keys.slice(offset, offset + 50);
      try {
        const response = await fetch('/rest/api/2/search?jql=' + encodeURIComponent('key in (' + chunk.join(',') + ')') + '&fields=summary,status&maxResults=100', { credentials:'same-origin', cache:'no-store', headers:{ Accept:'application/json' } });
        if (!response.ok) continue;
        const data = await response.json();
        (data.issues || []).forEach(issue => {
          pending.filter(([source, value]) => value.key === issue.key).forEach(([source]) => {
            epicObprojectByFcrmEpicKey[source] = { loading:false, key:issue.key, summary:String(issue.fields.summary || ''), status:readStatusName(issue.fields.status, '') };
          });
        });
      } catch (_) {}
    }
  }

  async function refreshTaskEpicDetails(taskKey, rawIssue) {
    const task = tasks.find((item) => item.key === taskKey);
    if (!task) return;
    if (isEpicIssueType(task.issueTypeName)) {
      await loadEpicObprojectDetails(task.key, rawIssue.fields.customfield_20100);
      return;
    }
    if (!task.epicKey) return;
    const epicKey = task.epicKey;
    const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(epicKey) + '?fields=summary,status,customfield_20100,labels', {
      credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
    });
    if (!response.ok) throw new Error('Не удалось обновить эпик ' + epicKey);
    const epic = await response.json();
    cacheEpicMetadata([epic]);
    epicNameByKey[epicKey] = String(epic.fields.summary || '');
    epicStatusByKey[epicKey] = readStatusName(epic.fields.status, '');
    tasks = tasks.map((item) => item.epicKey === epicKey ? Object.assign({}, item, { epicName: epicNameByKey[epicKey] }) : item);
    await loadEpicObprojectDetails(epicKey, epic.fields.customfield_20100);
  }

  const refreshingSidebarSections = new Set();
  async function refreshSidebarSection(taskKey, section) {
    const requestRevision = taskEditRevision;
    const requestKey = taskKey + ':' + section;
    if (refreshingSidebarSections.has(requestKey)) return;
    refreshingSidebarSections.add(requestKey);
    renderStructure();
    try {
      const fields = section === 'params' ? getBoardFieldsParam() : 'issuelinks';
      const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(taskKey) + '?fields=' + fields, {
        credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }
      });
      if (!response.ok) throw new Error('Jira: HTTP ' + response.status);
      const raw = await response.json();
      await syncStrategyLinks(raw);
      syncStrategyIssue(raw);
      const updated = (await normalizeAndEnrichJiraIssues([raw]))[0];
      if (!updated) throw new Error('Jira не вернула данные задачи');
      if (section === 'params') {
        const keys = ['issueTypeName', 'issueTypeId', 'priority', 'sprint', 'component', 'epicKey', 'epicName', 'assignee', 'customer', 'labels', 'status'];
        const patch = {};
        keys.forEach((key) => { patch[key] = updated[key]; });
        clearTaskOverride(taskKey, requestRevision);
        delete issueSprintOverrideMap[taskKey];
        tasks = applyLocalOverridesToTasks(tasks.map((item) => item.key === taskKey ? Object.assign({}, item, patch) : item), requestRevision, taskKey);
        const transitions = await fetch('/rest/api/2/issue/' + encodeURIComponent(taskKey) + '/transitions', { credentials: 'same-origin', cache: 'no-store' });
        if (transitions.ok) issueTransitionsByKey[taskKey] = (await transitions.json()).transitions || [];
        await refreshTaskEpicDetails(taskKey, raw);
      } else {
        const field = section === 'pt' ? 'projectTaskLinks' : 'inProjectLinks';
        tasks = tasks.map((item) => item.key === taskKey ? Object.assign({}, item, { [field]: updated[field] }) : item);
        if (section === 'ip') {
          await Promise.all(updated.inProjectLinks.map(async (link) => {
            delete frontDesignLinksByKey[link.key];
            await Promise.all([loadFrontDesignRelation(link.key)]);
          }));
        }
      }
      showSaveToast('✓ Блок обновлён из Jira');
    } catch (error) {
      showSaveToast('Не удалось обновить блок: ' + error.message);
    } finally {
      refreshingSidebarSections.delete(requestKey);
      renderStructure();
    }
  }

  function sidebarRefreshButton(taskKey, section) {
    const busy = refreshingSidebarSections.has(taskKey + ':' + section) || (sidebarBlockLoading.taskKey === taskKey && sidebarBlockLoading[section === 'params' ? 'params' : 'links']);
    return '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="refresh-sidebar-section" data-section="' + section + '" title="Перезагрузить" aria-label="Перезагрузить" ' + (busy ? 'disabled aria-busy="true"' : '') + ' style="width:26px;height:26px;padding:4px;flex-shrink:0;">' + (busy ? '<span class="ozon-ext-spinner"></span>' : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 11a8 8 0 0 0-14.9-3L4 10M4 4v6h6M4 13a8 8 0 0 0 14.9 3L20 14M20 20v-6h-6"/></svg>') + '</button>';
  }

  async function loadFrontDesignRelation(issueKey) {
    if (!issueKey || frontDesignLinksByKey[issueKey]) return;
    frontDesignLinksByKey[issueKey] = { loading: true, keys: [] };
    try {
      const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '?fields=issuelinks', {
        credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
      });
      if (!response.ok) throw new Error('Не удалось проверить связи');
      const data = await response.json();
      const links = data && data.fields && Array.isArray(data.fields.issuelinks) ? data.fields.issuelinks : [];
      const keys = links.map((link) => (link.inwardIssue || link.outwardIssue || {}).key).filter((key) => /^FTD-/i.test(String(key || '')));
      frontDesignLinksByKey[issueKey] = { loading: false, keys };
    } catch (_) {
      frontDesignLinksByKey[issueKey] = { loading: false, keys: [], error: true };
    }
    if (selectedTaskKey) renderStructure();
  }

  async function loadExternalProjectComponents(projKey) {
    return ensureProjectComponentsLoaded(projKey);
  }

  let defaultColWidths = {};
  DEFAULT_COLUMNS_META.forEach((c) => {
    defaultColWidths[c.key] = c.width;
  });
  defaultColWidths.createdAt = 115;

  let columnOrder = [...DEFAULT_COLUMN_ORDER];
  try {
    const savedOrder = JSON.parse(localStorage.getItem(STORAGE_KEY_COL_ORDER) || 'null');
    if (Array.isArray(savedOrder) && savedOrder.length > 0) {
      const normalized = savedOrder.map((k) => (k === 'createdAt' ? 'created' : k));
      const validKeys = normalized.filter((k) => defaultColWidths[k]);
      DEFAULT_COLUMNS_META.forEach((c) => {
        if (!validKeys.includes(c.key)) {
          if (c.key === 'epicObproject' && validKeys.includes('epic')) validKeys.splice(validKeys.indexOf('epic') + 1, 0, c.key);
          else validKeys.push(c.key);
        }
      });
      columnOrder = validKeys;
    }
  } catch (e) {}

  let colWidths = Object.assign({}, defaultColWidths);
  try {
    const savedCols = JSON.parse(localStorage.getItem(STORAGE_KEY_COL_WIDTHS) || 'null');
    if (savedCols && typeof savedCols === 'object') {
      colWidths = Object.assign({}, defaultColWidths, savedCols);
    }
  } catch (e) {}

  function getColumnLabel(colKey) {
    const found = DEFAULT_COLUMNS_META.find((c) => c.key === colKey);
    return found ? found.label : colKey;
  }

  function getTotalTableWidth() {
    return columnOrder.reduce((sum, k) => sum + (Number(colWidths[k]) || defaultColWidths[k] || 150), 0);
  }

  function showSaveToast(msg) {
    const update = showLinksSnackbar(msg);
    update(msg);
  }

  // Only edits made during an in-flight request may override Jira's response.
  let taskEditRevision = 0;
  const taskEdits = {};
  function saveTaskOverride(taskKey, patch) {
    if (!taskKey) return;
    const edits = taskEdits[taskKey] || (taskEdits[taskKey] = {});
    Object.keys(patch).forEach((field) => {
      if (['inProjectLinks', 'projectTaskLinks', 'otherLinks'].includes(field)) return;
      edits[field] = { value: patch[field], revision: ++taskEditRevision };
    });
  }

  function applyLocalOverridesToTasks(list, requestRevision, onlyTaskKey) {
    return list.map((task) => {
      if (onlyTaskKey && task.key !== onlyTaskKey) return task;
      const edits = taskEdits[task.key];
      if (!edits) return task;
      const patch = {};
      Object.keys(edits).forEach((field) => {
        if (edits[field].revision > requestRevision) patch[field] = edits[field].value;
      });
      return Object.assign({}, task, patch);
    });
  }

  function clearTaskOverride(taskKey, throughRevision) {
    const edits = taskEdits[taskKey];
    if (!edits) return;
    Object.keys(edits).forEach((field) => {
      if (edits[field].revision <= throughRevision) delete edits[field];
    });
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatDate(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return String(iso);
      const pad = (n) => String(n).padStart(2, '0');
      return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    } catch (e) {
      return String(iso);
    }
  }

  const doneByStatus = new Map();
  const categoryByStatus = new Map();
  function readStatusName(status, fallback) {
    if (status && status.name && status.statusCategory) {
      doneByStatus.set(status.name, status.statusCategory.key === 'done');
      categoryByStatus.set(status.name, status.statusCategory.key);
    }
    return status && status.name || fallback;
  }

  function getStatusCategoryClass(statusName) {
    const jiraCategory = categoryByStatus.get(statusName);
    if (jiraCategory === 'done') return 'done';
    if (jiraCategory === 'indeterminate') return 'progress';
    if (jiraCategory === 'new') return 'todo';
    const low = String(statusName || '').toLowerCase();
    if (low.includes('к выполнению') || low.includes('to do') || low.includes('backlog')) return 'todo';
    if (
      low.includes('ondev') ||
      low.includes('onanalysis') ||
      low.includes('analysis') ||
      low.includes('работ') ||
      low.includes('progress') ||
      low.includes('аналитик') ||
      low.includes('разработ') ||
      low.includes('исполн')
    ) {
      return 'progress';
    }
    if (
      low.includes('готов') ||
      low.includes('закр') ||
      low.includes('done') ||
      low.includes('closed') ||
      low.includes('resolved') ||
      low.includes('выполн') ||
      low.includes('заверш')
    ) {
      return 'done';
    }
    if (
      low.includes('planning') ||
      low.includes('ontest') ||
      low.includes('waiting') ||
      low.includes('ревью') ||
      low.includes('тест') ||
      low.includes('review') ||
      low.includes('qa') ||
      low.includes('ожид') ||
      low.includes('соглас')
    ) {
      return 'review';
    }
    return 'todo';
  }

  function getStatusBadgeHtml(statusName) {
    const s = String(statusName || 'Открыто');
    const cat = getStatusCategoryClass(s);
    return renderBadge(escapeHtml(s), cat);
  }

  /**
   * Нейтральный тег типа связи («Задача проекта» / «В проекте») с иконкой связи,
   * чтобы визуально НЕ путать с цветными бейджами статусов («Закрыт», «В работе»).
   */
  function getLinkTypeTagHtml(isProjectTask) {
    if (isProjectTask) {
      return '<span class="ozon-ext-link-type-tag" role="img" aria-label="Задача проекта" title="Тип связи: Задача проекта (fcrm_umb_epic)"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#64748B" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/></svg></span>';
    }
    return '<span class="ozon-ext-link-type-tag" role="img" aria-label="В проекте" title="Тип связи: В проекте (смежная задача реализации)"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#64748B" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></span>';
  }

  /**
   * Форматирование описания задачи Jira (поддержка Jira Wiki Markup и Markdown):
   * - *Жирные заголовки* и *жирный текст*, _курсив_, +подчеркнутый+, {{моноширинный}}
   * - Заголовки h1. - h6. и разделители h2. / ----
   * - Списки (маркированные * / - и нумерованные 1. / 1 клиент... / #)
   * - Кликабельные ссылки https://... и пиллы задач Jira (OB-277222, FCRM-1365 и др.)
   * - Блоки {code}, {noformat}, {quote}
   */
  function formatInlineJiraMarkup(escapedLine) {
    let s = String(escapedLine || '');

    // Инлайн-код {{...}}
    s = s.replace(/\{\{([^}]+)\}\}/g, '<code class="ozon-desc-inline-code">$1</code>');
    s = s.replace(/\x60([^\x60]+)\x60/g, '<code class="ozon-desc-inline-code">$1</code>');

    // Ссылки формата Jira [Текст|https://...]
    s = s.replace(/\[([^\]|]+)\|(https?:\/\/[^\]]+)\]/g, function (_, label, url) {
      return '<a href="' + url + '" target="_blank" rel="noopener noreferrer" class="ozon-desc-link">' + label + ' ↗</a>';
    });

    // Ссылки на задачи Jira вида https://jit.o3.ru/browse/OB-277222 и обычные URL
    s = s.replace(/(https?:\/\/[^\s<)"']+)/g, function (rawUrl) {
      const cleanUrl = rawUrl.replace(/[.,;:!?]+$/, '');
      const trailing = rawUrl.slice(cleanUrl.length);
      const browseMatch = cleanUrl.match(/\/browse\/([A-Z][A-Z0-9_]+-\d+)$/i);
      if (browseMatch && browseMatch[1]) {
        const key = browseMatch[1].toUpperCase();
        return '<a href="' + cleanUrl + '" target="_blank" rel="noopener noreferrer" class="ozon-desc-issue-pill">' + key + ' ↗</a>' + trailing;
      }
      return '<a href="' + cleanUrl + '" target="_blank" rel="noopener noreferrer" class="ozon-desc-link">' + cleanUrl + ' ↗</a>' + trailing;
    });

    // Цвета {color:#hex}...{color}
    s = s.replace(/\{color:([^}]+)\}([\s\S]*?)\{color\}/gi, '<span style="color:$1;font-weight:600;">$2</span>');

    // Жирный текст *текст*
    s = s.replace(/(^|[\s(В«"'])\*([^\s*][^*]*?[^\s*]|[^\s*])\*(?=[\s)В»"',.:;!?]|$)/g, '$1<strong style="color:#071026;font-weight:700;">$2</strong>');
    // Курсив _текст_
    s = s.replace(/(^|[\s(В«"'])_([^\s_][^_]*?[^\s_]|[^\s_])_(?=[\s)В»"',.:;!?]|$)/g, '$1<em>$2</em>');

    return s;
  }

  function formatJiraDescriptionHtml(rawText) {
    const raw = String(rawText || '').trim();
    if (!raw) {
      return '<div style="color:#94A3B8;font-style:italic;font-size:11.5px;">Описание задачи отсутствует. Нажмите «✎ Редактировать», чтобы добавить описание.</div>';
    }

    let text = escapeHtml(raw).replace(/\r\n/g, '\n');

    // Выделяем многострочные блоки {code}...{code} и {noformat}...{noformat}
    const codeBlocks = [];
    text = text.replace(/\{(?:code|noformat)(?::[^}]*)?\}([\s\S]*?)\{(?:code|noformat)\}/gi, function (_, codeContent) {
      const idx = codeBlocks.length;
      codeBlocks.push('<pre class="ozon-desc-code"><code>' + codeContent.trim() + '</code></pre>');
      return '___OZON_CODE_BLOCK_' + idx + '___';
    });

    // Блоки {quote}...{quote}
    text = text.replace(/\{quote\}([\s\S]*?)\{quote\}/gi, function (_, qContent) {
      return '<blockquote class="ozon-desc-quote">' + formatInlineJiraMarkup(qContent.trim()).replace(/\n/g, '<br/>') + '</blockquote>';
    });

    const lines = text.split('\n');
    const out = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      if (!trimmed) {
        continue;
      }

      const codeMatch = trimmed.match(/^___OZON_CODE_BLOCK_(\d+)___$/);
      if (codeMatch) {
        out.push(codeBlocks[Number(codeMatch[1])] || '');
        continue;
      }

      // Пустой заголовок вида "h2." или разделитель "----"
      if (/^h[1-6]\.\s*$/i.test(trimmed) || /^-{3,}$/.test(trimmed)) {
        out.push('<hr class="ozon-desc-hr" />');
        continue;
      }

      // Заголовки Jira h1. - h6.
      const hMatch = trimmed.match(/^h([1-6])\.\s+(.+)$/i);
      if (hMatch) {
        out.push('<div class="ozon-desc-heading">' + formatInlineJiraMarkup(hMatch[2]) + '</div>');
        continue;
      }

      // Строка целиком в звездочках *Цель / Зачем*, *Контекст*, *Суть / Что делаем* или **Заголовок**
      const boldHeadingMatch = trimmed.match(/^\*{1,2}([^*]+)\*{1,2}:?$/);
      if (boldHeadingMatch && trimmed.length < 95) {
        out.push('<div class="ozon-desc-heading">' + formatInlineJiraMarkup(boldHeadingMatch[1].trim()) + '</div>');
        continue;
      }

      // Цитата bq.
      if (/^bq\.\s+/i.test(trimmed)) {
        out.push('<blockquote class="ozon-desc-quote">' + formatInlineJiraMarkup(trimmed.replace(/^bq\.\s+/i, '')) + '</blockquote>');
        continue;
      }

      // Маркированный список (* пункт, - пункт, • пункт)
      const bulletMatch = trimmed.match(/^(?:\*{1,3}|-|•)\s+(.+)$/);
      if (bulletMatch) {
        out.push(
          '<div class="ozon-desc-li"><span class="ozon-desc-bullet">•</span><span style="flex:1;">' +
            formatInlineJiraMarkup(bulletMatch[1]) +
            '</span></div>'
        );
        continue;
      }

      // Нумерованный список (# пункт, 1. пункт, 1) пункт, либо "1 клиент переводит..." как в задачах FCRM)
      const numMatch = trimmed.match(/^(?:(#+)|(\d+)[.)]|(\d+)\s+(?=[^\x00-\x7F]))\s*(.+)$/);
      if (numMatch) {
        const numLabel = numMatch[2] ? numMatch[2] + '.' : numMatch[3] ? numMatch[3] + '.' : '•';
        out.push(
          '<div class="ozon-desc-li"><span class="ozon-desc-num">' +
            numLabel +
            '</span><span style="flex:1;">' +
            formatInlineJiraMarkup(numMatch[4]) +
            '</span></div>'
        );
        continue;
      }

      out.push('<div class="ozon-desc-p">' + formatInlineJiraMarkup(trimmed) + '</div>');
    }

    return '<div class="ozon-ext-desc-rendered">' + out.join('') + '</div>';
  }

  /**
   * Стандартные SVG-иконки приоритетов Jira (Blocker, Highest/Critical, High/Major, Medium/Стандартный, Low/Minor, Lowest/Trivial)
   * Никаких эмодзи!
   */
  function getJiraPriorityIconSvg(priorityName) {
    const p = String(priorityName || 'Medium').trim();
    const low = p.toLowerCase();
    if (low.includes('block') || low.includes('блок')) {
      return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><circle cx="8" cy="8" r="6.5" fill="#DC2626"/><rect x="4.2" y="7" width="7.6" height="2" rx="1" fill="#FFFFFF"/></svg>';
    }
    if (low.includes('crit') || low.includes('highest') || low.includes('крит') || low.includes('наивысш')) {
      return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><path d="M3 7.5L8 2.5L13 7.5" stroke="#DC2626" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12.5L8 7.5L13 12.5" stroke="#DC2626" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    if (low.includes('high') || low.includes('major') || low.includes('высок') || low.includes('важн')) {
      return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><path d="M3 10.5L8 5.5L13 10.5" stroke="#EA580C" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    if (low.includes('lowest') || low.includes('triv') || low.includes('миним') || low.includes('трив')) {
      return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><path d="M3 3.5L8 8.5L13 3.5" stroke="#64748B" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 8.5L8 13.5L13 8.5" stroke="#64748B" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    if (low.includes('low') || low.includes('minor') || low.includes('низк') || low.includes('незнач')) {
      return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><path d="M3 5.5L8 10.5L13 5.5" stroke="#2563EB" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    // Medium / Стандартный / Средний (две горизонтальные полосы Jira Medium)
    return '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;vertical-align:middle;" title="Приоритет: ' + escapeHtml(p) + '"><path d="M3 6H13" stroke="#D97706" stroke-width="2.2" stroke-linecap="round"/><path d="M3 10H13" stroke="#D97706" stroke-width="2.2" stroke-linecap="round"/></svg>';
  }

  /**
   * Иконка и компактный бейдж типа задачи Jira (Эпик, История/Story, Ошибка/Bug, Задача/Task, Аналитика, Дизайн и др.)
   */
  function getJiraIssueTypeIconSvg(issueTypeName) {
    const t = String(issueTypeName || 'Задача').trim();
    const low = t.toLowerCase();
    if (low === 'epic' || low === 'эпик' || low.includes('epic') || low.includes('эпик')) {
      return '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;" title="Тип задачи: ' + escapeHtml(t) + '"><rect x="1.5" y="1.5" width="13" height="13" rx="3" fill="#9333EA"/><path d="M8.8 3.5L4.8 8.7H7.7L7.2 12.5L11.2 7.3H8.3L8.8 3.5Z" fill="#FFFFFF"/></svg>';
    }
    if (low.includes('bug') || low.includes('ошибк') || low.includes('дефект') || low.includes('инцидент')) {
      return '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;" title="Тип задачи: ' + escapeHtml(t) + '"><rect x="1.5" y="1.5" width="13" height="13" rx="3" fill="#DC2626"/><circle cx="8" cy="8" r="2.8" fill="#FFFFFF"/></svg>';
    }
    if (low.includes('story') || low.includes('истори') || low.includes('feature') || low.includes('фича')) {
      return '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;" title="Тип задачи: ' + escapeHtml(t) + '"><rect x="1.5" y="1.5" width="13" height="13" rx="3" fill="#16A34A"/><path d="M5 4.2H11V12L8 9.8L5 12V4.2Z" fill="#FFFFFF"/></svg>';
    }
    if (low.includes('аналит') || low.includes('analysis') || low.includes('research') || low.includes('исслед')) {
      return '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;" title="Тип задачи: ' + escapeHtml(t) + '"><rect x="1.5" y="1.5" width="13" height="13" rx="3" fill="#0284C7"/><circle cx="7.5" cy="7.5" r="2.5" stroke="#FFFFFF" stroke-width="1.6"/><path d="M9.5 9.5L11.8 11.8" stroke="#FFFFFF" stroke-width="1.6" stroke-linecap="round"/></svg>';
    }
    // Задача / Task / Разработка (стандартный синий чекбокс Jira Task)
    return '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;" title="Тип задачи: ' + escapeHtml(t) + '"><rect x="1.5" y="1.5" width="13" height="13" rx="3" fill="#2563EB"/><path d="M4.8 8.2L7 10.4L11.3 5.8" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }

  function getIssueTypeBadgeHtml(issueTypeName, showLabel) {
    const t = String(issueTypeName || 'Задача').trim() || 'Задача';
    const color = isEpicIssueType(t) ? "#9333ea" : /истори|story/i.test(t) ? "#16a34a" : /ошиб|bug/i.test(t) ? "#dc2626" : /аналит|analy/i.test(t) ? "#d97706" : "#2563eb";
    return '<span class="ozon-ext-type-pill" title="' + escapeHtml(t) + '"><i style="background:' + color + '"></i>' + (showLabel ? escapeHtml(t) : "") + "</span>";
  }

  /**
   * Иконка красной скрепки для задач, у которых НЕТ привязанной «Задачи проекта»
   */
  function getMissingProjectTaskWarnSvg() {
    return '<span class="ozon-ext-inner-ctrl" title="Внимание: у задачи нет связи «Задача проекта» (fcrm_umb_epic)" style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:4px;background:#FEE2E2;color:#DC2626;flex-shrink:0;cursor:help;"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg></span>';
  }

  /**
   * Иконка красного человечка для задач, у которых НЕ назначен Исполнитель
   */
  function getMissingAssigneeWarnSvg() {
    return '<span class="ozon-ext-inner-ctrl" title="Внимание: у задачи не назначен Исполнитель" style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:4px;background:#FEE2E2;color:#DC2626;flex-shrink:0;cursor:help;"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span>';
  }

  function isTaskMissingAssignee(task) {
    if (!task || !task.assignee) return true;
    const nm = String(task.assignee.name || '').trim();
    const lg = String(task.assignee.login || '').trim();
    if (!nm && !lg) return true;
    const lower = nm.toLowerCase();
    return (
      lower === 'не назначен' ||
      lower === 'не указан' ||
      lower === 'unassigned' ||
      lower === '—' ||
      lower === '-'
    );
  }

  /**
   * Иконки и метаданные групп связанных задач (OB — Бэкенд, OBFRONT — Фронтенд, FTD — Дизайн, FCRM — Задача проекта / CRM)
   */
  function getLinkedProjectGroupMeta(issueKey, isProjectTaskBlock) {
    const prefix = String(issueKey || '').split('-')[0].toUpperCase();
    if (isProjectTaskBlock) {
      const icon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/><circle cx="12" cy="13" r="2"/></svg>';
      return {
        id: 'UMB',
        groupKey: 'UMB',
        label: 'Задачи проекта (fcrm_umb_epic)',
        title: 'Задачи проекта (fcrm_umb_epic)',
        shortTag: 'Проект',
        order: 0,
        bg: '#E5F0FF',
        color: '#005BFF',
        iconSvg: icon,
        svg: icon
      };
    }
    if (prefix === 'OB') {
      const icon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg>';
      return {
        id: 'OB',
        groupKey: 'OB',
        label: 'OB · Бэкенд',
        title: 'OB · Бэкенд',
        shortTag: 'Бэкенд',
        order: 1,
        bg: '#EDE9FE',
        color: '#6D28D9',
        iconSvg: icon,
        svg: icon
      };
    }
    if (prefix === 'OBFRONT') {
      const icon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>';
      return {
        id: 'OBFRONT',
        groupKey: 'OBFRONT',
        label: 'OBFRONT · Фронтенд',
        title: 'OBFRONT · Фронтенд',
        shortTag: 'Фронтенд',
        order: 2,
        bg: '#E0F2FE',
        color: '#0284C7',
        iconSvg: icon,
        svg: icon
      };
    }
    if (prefix === 'FTD') {
      const icon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>';
      return {
        id: 'FTD',
        groupKey: 'FTD',
        label: 'FTD · Дизайн',
        title: 'FTD · Дизайн',
        shortTag: 'Дизайн',
        order: 3,
        bg: '#FCE7F3',
        color: '#DB2777',
        iconSvg: icon,
        svg: icon
      };
    }
    const icon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';
    return {
      id: prefix || 'OTHER',
      groupKey: prefix || 'OTHER',
      label: (prefix || 'CRM') + ' · Смежные задачи',
      title: (prefix || 'CRM') + ' · Смежные задачи',
      shortTag: prefix || 'CRM',
      order: 4,
      bg: '#E5F0FF',
      color: '#005BFF',
      iconSvg: icon,
      svg: icon
    };
  }

  function getPriorityBadgeClass(priorityName) {
    const low = String(priorityName || '').toLowerCase();
    if (low.includes('block') || low.includes('crit') || low.includes('крит') || low.includes('блок') || low.includes('highest')) {
      return 'ozon-ext-badge-critical';
    }
    if (low.includes('high') || low.includes('major') || low.includes('высок')) {
      return 'ozon-ext-badge-review';
    }
    if (low.includes('low') || low.includes('minor') || low.includes('triv') || low.includes('низк')) {
      return 'ozon-ext-badge-todo';
    }
    return 'ozon-ext-badge-progress';
  }

  function isBogusEpicTitle(text, epicKey) {
    if (!text) return true;
    const clean = String(text).trim();
    if (!clean) return true;
    const low = clean.toLowerCase();
    if (
      low === 'epic link' ||
      low === 'ссылка на эпик' ||
      low === 'epic name' ||
      low === 'имя эпика' ||
      low === 'название эпика' ||
      low === 'без эпика' ||
      low === 'no epic'
    ) {
      return true;
    }
    if (epicKey && clean.toUpperCase() === String(epicKey).trim().toUpperCase()) {
      return true;
    }
    return false;
  }

  /**
   * Проверяет, является ли имя спринта родным спринтом доски FCRM (#9349),
   * отсекая чужие спринты других команд (TXCTRL_VED_REQ, PFM B2C, HOGWARTS_CD, CRM_CORE, CRM_BO, CS, Collection и т.д.).
   */
  function isNativeFcrmBoardSprintName(sprintName, originBoardId) {
    if (!sprintName) return false;
    const clean = String(sprintName).trim();
    if (!clean || clean === '9223372036854775807' || /^\d+$/.test(clean)) return false;
    if (clean === 'Бэклог FCRM') return true;
    if (closedSprintNames.has(clean)) return false;

    // Если Jira явно указала originBoardId:
    if (originBoardId != null) {
      return String(originBoardId) === String(CONFIG.rapidViewId);
    }

    // Если спринт уже подтверждён как принадлежащий доске 9349:
    if (boardOwnedSprintNames.has(clean)) return true;

    const low = clean.toLowerCase();
    if (
      low.startsWith('#разработка') ||
      low.startsWith('разработка') ||
      low.includes('product dicsvery') ||
      low.includes('product discovery') ||
      low.includes('fcrm')
    ) {
      return true;
    }
    return false;
  }

  function isFcrmSprintCandidate(sprintId, sprintName, originBoardId, stateStr, rawStr, allowClosed) {
    if (!sprintName || sprintName === '9223372036854775807' || /^\d+$/.test(String(sprintName).trim())) {
      return false;
    }
    const nameClean = String(sprintName).trim();
    if (nameClean === 'Бэклог FCRM') return true;

    const isClosed =
      (sprintId && closedSprintIds.has(String(sprintId))) ||
      closedSprintNames.has(nameClean) ||
      (stateStr && String(stateStr).toUpperCase() === 'CLOSED') ||
      (rawStr && typeof rawStr === 'string' && /state=CLOSED/i.test(rawStr));

    if (isClosed) {
      if (sprintId) closedSprintIds.add(String(sprintId));
      closedSprintNames.add(nameClean);
      sprintStateByName[nameClean] = 'CLOSED';
      if (!allowClosed) return false;
    }

    if (originBoardId != null && String(originBoardId) !== String(CONFIG.rapidViewId)) {
      if (!isNativeFcrmBoardSprintName(nameClean, originBoardId)) {
        return false;
      }
    }

    return true;
  }

  function extractCleanSprintName(rawVal, issueId, issueKey, allowClosed) {
    if (!rawVal) return null;

    if (Array.isArray(rawVal)) {
      for (let i = rawVal.length - 1; i >= 0; i--) {
        const parsed = extractCleanSprintName(rawVal[i], null, null, allowClosed);
        if (parsed) return parsed;
      }
      return null;
    }

    if (typeof rawVal === 'object') {
      const sId = rawVal.id ? String(rawVal.id) : null;
      const sName = rawVal.name ? String(rawVal.name).trim() : null;
      const originId = rawVal.originBoardId || rawVal.rapidViewId || null;
      const st = rawVal.state ? String(rawVal.state).toUpperCase() : null;

      if (sName && st && (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED')) {
        sprintStateByName[sName] = st;
      }
      if (sId && sName) {
        sprintNameById[sId] = sName;
        sprintIdByName[sName] = sId;
      }

      if (st === 'CLOSED') {
        if (sId) closedSprintIds.add(sId);
        if (sName) closedSprintNames.add(sName);
        if (!allowClosed) return null;
      }

      if (sName && isFcrmSprintCandidate(sId, sName, originId, st, null, allowClosed)) {
        return sName;
      }
      if (sId && sprintNameById[sId] && (allowClosed || !closedSprintIds.has(sId))) {
        return sprintNameById[sId];
      }
      return null;
    }

    const str = String(rawVal).trim();
    if (!str || str === '9223372036854775807' || str === 'null' || str === 'undefined') {
      return null;
    }

    const idMatch = str.match(/id=(\d+)/);
    const sId = idMatch && idMatch[1] ? idMatch[1] : null;
    const stateMatch = str.match(/state=([^,\]]+)/);
    const st = stateMatch && stateMatch[1] ? stateMatch[1].trim().toUpperCase() : null;
    const nameMatch = str.match(/name=([^,\]]+)/);
    const viewMatch = str.match(/rapidViewId=(\d+)/);
    const originId = viewMatch && viewMatch[1] ? viewMatch[1] : null;

    if (nameMatch && nameMatch[1]) {
      const candidate = nameMatch[1].trim();
      if (st && (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED')) {
        sprintStateByName[candidate] = st;
      }
      if (sId) {
        sprintNameById[sId] = candidate;
        sprintIdByName[candidate] = sId;
      }
      if (st === 'CLOSED') {
        if (sId) closedSprintIds.add(sId);
        closedSprintNames.add(candidate);
        if (!allowClosed) return null;
      }
      if (isFcrmSprintCandidate(sId, candidate, originId, st, str, allowClosed)) {
        return candidate;
      }
      return null;
    }

    if (st === 'CLOSED') {
      if (sId) closedSprintIds.add(sId);
      if (!allowClosed) return null;
    }

    if (sId && sprintNameById[sId] && (allowClosed || !closedSprintIds.has(sId))) {
      return sprintNameById[sId];
    }

    if (/^\d+$/.test(str)) {
      return sprintNameById[str] && (allowClosed || !closedSprintIds.has(str)) ? sprintNameById[str] : null;
    }

    return isFcrmSprintCandidate(null, str, originId, st, str, allowClosed) ? str : null;
  }

  function resolveIssueSprint(iss) {
    if (!iss) return 'Бэклог FCRM';
    const f = iss.fields || {};

    if (Array.isArray(f.closedSprints)) {
      f.closedSprints.forEach((cs) => {
        if (cs && cs.id) closedSprintIds.add(String(cs.id));
        if (cs && cs.name) {
          const csN = String(cs.name).trim();
          closedSprintNames.add(csN);
          sprintStateByName[csN] = 'CLOSED';
          if (cs.id) {
            sprintNameById[String(cs.id)] = csN;
            sprintIdByName[csN] = String(cs.id);
          }
        }
      });
    }

    // Jira sprint fields take precedence over historical board membership.
    const fromAgileActive = extractCleanSprintName(f.sprint, iss.id, iss.key, false);
    if (fromAgileActive) return fromAgileActive;

    if (discoveredFields.sprint && f[discoveredFields.sprint]) {
      const fromCustomActive = extractCleanSprintName(f[discoveredFields.sprint], iss.id, iss.key, false);
      if (fromCustomActive) return fromCustomActive;
    }

    for (const k of Object.keys(f)) {
      const val = f[k];
      if (Array.isArray(val) && val.length > 0 && typeof val[0] === 'string' && val[0].includes('greenhopper.service.sprint.Sprint')) {
        const parsedActive = extractCleanSprintName(val, iss.id, iss.key, false);
        if (parsedActive) return parsedActive;
      }
    }

    // Use closed sprints only when there is no active or future sprint.
    const fromAgileClosed = extractCleanSprintName(f.sprint, iss.id, iss.key, true);
    if (fromAgileClosed) return fromAgileClosed;

    if (discoveredFields.sprint && f[discoveredFields.sprint]) {
      const fromCustomClosed = extractCleanSprintName(f[discoveredFields.sprint], iss.id, iss.key, true);
      if (fromCustomClosed) return fromCustomClosed;
    }

    if (Array.isArray(f.closedSprints) && f.closedSprints.length > 0) {
      const fromClosedArr = extractCleanSprintName(f.closedSprints, iss.id, iss.key, true);
      if (fromClosedArr) return fromClosedArr;
    }

    for (const k of Object.keys(f)) {
      const val = f[k];
      if (Array.isArray(val) && val.length > 0 && typeof val[0] === 'string' && val[0].includes('greenhopper.service.sprint.Sprint')) {
        const parsedClosed = extractCleanSprintName(val, iss.id, iss.key, true);
        if (parsedClosed) return parsedClosed;
      }
    }

    return 'Бэклог FCRM';
  }

  function extractAnyRealSprintName(rawVal) {
    if (!rawVal) return null;
    if (Array.isArray(rawVal)) {
      for (let i = rawVal.length - 1; i >= 0; i--) {
        const name = extractAnyRealSprintName(rawVal[i]);
        if (name) return name;
      }
      return null;
    }
    if (typeof rawVal === 'object') {
      if (rawVal.name && String(rawVal.name).trim() && String(rawVal.name).trim() !== '9223372036854775807') {
        const cleanN = String(rawVal.name).trim();
        const st = rawVal.state ? String(rawVal.state).trim().toUpperCase() : '';
        if (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED') {
          sprintStateByName[cleanN] = st;
        }
        if (rawVal.id) {
          sprintNameById[String(rawVal.id)] = cleanN;
          sprintIdByName[cleanN] = String(rawVal.id);
        }
        return cleanN;
      }
      if (rawVal.id && sprintNameById[String(rawVal.id)]) {
        return sprintNameById[String(rawVal.id)];
      }
      return null;
    }
    const str = String(rawVal).trim();
    if (!str || str === '9223372036854775807' || str === 'null' || str === 'undefined') return null;
    const idMatch = str.match(/id=(\d+)/);
    const sId = idMatch && idMatch[1] ? idMatch[1] : null;
    const stateMatch = str.match(/state=([^,\]]+)/);
    const st = stateMatch && stateMatch[1] ? stateMatch[1].trim().toUpperCase() : '';
    const nameMatch = str.match(/name=([^,\]]+)/);
    if (nameMatch && nameMatch[1]) {
      const cleanN = nameMatch[1].trim();
      if (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED') {
        sprintStateByName[cleanN] = st;
      }
      if (sId) {
        sprintNameById[sId] = cleanN;
        sprintIdByName[cleanN] = sId;
      }
      return cleanN;
    }
    if (sId && sprintNameById[sId]) {
      return sprintNameById[sId];
    }
    if (!str.includes('com.atlassian.greenhopper') && !/^\d+$/.test(str)) {
      return str;
    }
    return null;
  }

  function resolveRealLinkedIssueSprint(lIss) {
    if (!lIss) return 'Не в спринте';
    const fields = lIss.fields || {};
    const candidates = [fields.sprint];
    if (discoveredFields.sprint) candidates.push(fields[discoveredFields.sprint]);
    Object.keys(fields).forEach((key) => {
      const value = fields[key];
      if (Array.isArray(value) && value.length && typeof value[0] === 'string' && value[0].includes('greenhopper.service.sprint.Sprint')) candidates.push(value);
    });
    candidates.push(fields.closedSprints);
    let closed = null;
    for (const candidate of candidates) {
      const values = Array.isArray(candidate) ? candidate.slice().reverse() : [candidate];
      for (const value of values) {
        const name = extractAnyRealSprintName(value);
        if (!name) continue;
        const state = sprintStateByName[name];
        if (state !== 'CLOSED') return name;
        if (!closed) closed = name;
      }
    }
    return closed || 'Не в спринте';
  }

  function resolveRealLinkedIssueComponent(lIss) {
    if (!lIss || !lIss.fields) return 'Без компонента';
    const comps = lIss.fields.components;
    if (Array.isArray(comps) && comps.length > 0) {
      const names = comps.map((c) => c && c.name).filter(Boolean);
      if (names.length > 0) return names.join(', ');
    }
    return 'Без компонента';
  }

  function fetchProjectComponents(key, refresh = false) {
    if (projectComponentRequests.has(key)) return projectComponentRequests.get(key);
    if (!refresh && projectComponentRecords.has(key)) return Promise.resolve(projectComponentRecords.get(key));
    const request = fetch('/rest/api/2/project/' + encodeURIComponent(key) + '/components', {
      credentials: 'same-origin', headers: { Accept: 'application/json' }
    }).then(async response => {
      if (!response.ok) throw new Error('Не удалось загрузить компоненты проекта ' + key);
      const items = await response.json();
      if (!Array.isArray(items)) throw new Error('Неизвестный формат списка компонентов ' + key);
      const records = items.filter(item => item && item.name);
      projectComponentRecords.set(key, records);
      return records;
    }).finally(() => projectComponentRequests.delete(key));
    projectComponentRequests.set(key, request);
    return request;
  }

  async function ensureProjectComponentsLoaded(projKey) {
    if (!projKey) return [];
    const key = String(projKey).trim().toUpperCase();
    if (key === String(CONFIG.projectKey).toUpperCase()) return getAllComponentOptions();
    if (externalProjectComponentsMap[key]) return externalProjectComponentsMap[key];
    try {
      const components = await fetchProjectComponents(key);
      const names = ['Без компонента', ...components.map(item => item.name)];
      externalProjectComponentsMap[key] = prioritizeFavoriteComponents(Array.from(new Set(names)));
      return externalProjectComponentsMap[key];
    } catch {
      return ['Без компонента'];
    }
  }

  async function loadIssueCreateComponents(projectKey) {
    const components = await fetchProjectComponents(String(projectKey).trim().toUpperCase());
    const favorites = ['CS', 'CRM_BO', 'CRM_CORE'];
    const rank = name => {
      const index = favorites.indexOf(name.toUpperCase());
      return index < 0 ? favorites.length : index;
    };
    return components.filter(item => item.id).sort((a, b) =>
      rank(a.name) - rank(b.name) || a.name.localeCompare(b.name, 'ru'));
  }

  async function loadIssueCreateMeta(projectKey) {
    const key = String(projectKey || '').toUpperCase();
    if (issueCreateMetaByProject[key]) return issueCreateMetaByProject[key];
    const base = '/rest/api/2/issue/createmeta/' + encodeURIComponent(key) + '/issuetypes';
    const response = await fetch(base + '?startAt=0&maxResults=1000', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    if (!response.ok) {
      const fallback = await fetch('/rest/api/2/project/' + encodeURIComponent(key) + '/statuses', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      if (fallback.ok) {
        const statusTypes = await fallback.json();
        const fallbackTypes = Array.isArray(statusTypes) ? statusTypes.filter((item) => item && item.id && item.name).map((item) => ({ id: String(item.id), name: String(item.name), subtask: Boolean(item.subtask), fields: {} })) : [];
        if (fallbackTypes.length) {
          issueCreateMetaByProject[key] = fallbackTypes;
          return fallbackTypes;
        }
      }
      throw new Error('Jira did not return create issue types for ' + key + ' (HTTP ' + response.status + ')');
    }
    const payload = await response.json();
    const issueTypes = Array.isArray(payload) ? payload : payload.values || payload.issueTypes || [];
    if (!issueTypes.length) throw new Error('No issue types are available in ' + key);
    issueCreateMetaByProject[key] = await Promise.all(issueTypes.map(async (type) => {
      try {
        const fieldsResponse = await fetch(base + '/' + encodeURIComponent(type.id) + '?startAt=0&maxResults=1000', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
        if (!fieldsResponse.ok) return type;
        const detail = await fieldsResponse.json();
        const rawFields = Array.isArray(detail.values) ? detail.values : detail.fields || {};
        const fields = Array.isArray(rawFields)
          ? Object.fromEntries(rawFields.map((field) => [field.fieldId || field.key, field]).filter(([id]) => id))
          : rawFields;
        return Object.assign({}, type, { fields });
      } catch (e) { return type; }
    }));
    return issueCreateMetaByProject[key];
  }

  function getIssueCreateType(projectKey, kind, issueTypes) {
    const epic = kind === 'epic';
    const candidates = (issueTypes || []).filter((type) => epic
      ? /epic|эпик/i.test(String(type.name || ''))
      : !/epic|эпик|sub.?task|подзадач/i.test(String(type.name || '')) && /task|задач/i.test(String(type.name || '')));
    if (candidates.length) return candidates[0];
    if (!epic) return (issueTypes || []).find((type) => !/sub.?task|подзадач/i.test(String(type.name || '')));
    return null;
  }

  function isEpicNameCreateField(meta) {
    return Boolean(meta && (
      /gh-epic-label$/i.test(String(meta.schema && meta.schema.custom || '')) ||
      /epic[ _-]*(name|label|метка)|название эпика|эпик.*(метка|название)/i.test(String(meta.name || ''))
    ));
  }

  async function createIssueFromSidebar(draft) {
    const projectKey = String(draft.projectKey).toUpperCase();
    const [issueTypes, components] = await Promise.all([
      loadIssueCreateMeta(projectKey),
      loadIssueCreateComponents(projectKey)
    ]);
    const issueType = getIssueCreateType(projectKey, draft.kind, issueTypes);
    if (!issueType) throw new Error(draft.kind === 'epic' ? 'В FCRM не найден тип задачи Epic' : 'В проекте не найден обычный тип задачи');
    const component = components.find((item) => String(item.id) === String(draft.componentId));
    if (!component) throw new Error('Выберите компонент проекта ' + projectKey);

    const fieldsMeta = issueType.fields || {};
    const fields = {
      project: { key: projectKey },
      issuetype: { id: String(issueType.id) },
      summary: String(draft.summary || '').trim(),
      components: [{ id: String(component.id) }]
    };
    if (draft.kind !== 'epic' && String(draft.description || '').trim()) fields.description = String(draft.description).trim();
    if (draft.kind === 'epic') {
      fields.labels = ['fcrm_umb_epic'];
      fields.description = String(draft.summary || '').trim();
      const epicNameField = Object.entries(fieldsMeta).find(([, meta]) => isEpicNameCreateField(meta));
      if (epicNameField) fields[epicNameField[0]] = String(draft.summary).trim();
      else {
        const allFieldsResponse = await fetch('/rest/api/2/field', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
        if (allFieldsResponse.ok) {
          const allFields = await allFieldsResponse.json();
          const epicName = Array.isArray(allFields) && allFields.find(isEpicNameCreateField);
          if (epicName && epicName.id) fields[epicName.id] = String(draft.summary).trim();
        }
        if (!Object.keys(fields).some(id => id.startsWith('customfield_'))) {
          throw new Error('Не удалось найти поле «Epic Метка» для создания тематики. Обновите данные Jira и повторите попытку.');
        }
      }
    }

    if (fieldsMeta.reporter && fieldsMeta.reporter.required) {
      const myselfResponse = await fetch('/rest/api/2/myself', {
        credentials: 'same-origin', headers: { Accept: 'application/json' }
      });
      if (!myselfResponse.ok) throw new Error('Не удалось определить автора задачи Jira');
      const myself = await myselfResponse.json();
      if (!myself.name) throw new Error('Jira не вернула имя текущего пользователя для поля «Автор»');
      fields.reporter = { name: String(myself.name) };
    }

    Object.entries(fieldsMeta).forEach(([fieldId, meta]) => {
      if (!meta || !meta.required || Object.prototype.hasOwnProperty.call(fields, fieldId)) return;
      const fieldName = String(meta.name || '').toLowerCase();
      const schema = meta.schema || {};
      if (fieldId === 'labels' || /метки|labels/i.test(fieldName)) {
        fields[fieldId] = draft.kind === 'epic' ? ['fcrm_umb_epic'] : [String(draft.summary || '').trim()];
      } else if (schema.type === 'string' || fieldId === 'description' || isEpicNameCreateField(meta)) {
        fields[fieldId] = String(draft.summary || '').trim();
      } else if (schema.type === 'array' && schema.items === 'string') {
        fields[fieldId] = [String(draft.summary || '').trim()];
      } else if (meta.defaultValue != null) {
        fields[fieldId] = meta.defaultValue;
      }
    });

    const missing = Object.entries(fieldsMeta)
      .filter(([fieldId, meta]) => meta && meta.required && !meta.hasDefaultValue && !Object.prototype.hasOwnProperty.call(fields, fieldId))
      .map(([, meta]) => meta.name || 'обязательное поле');
    if (missing.length) throw new Error('Для создания Jira требует заполнить ещё: ' + missing.join(', '));

    const response = await fetch('/rest/api/2/issue', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ fields })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const details = result.errors ? Object.values(result.errors).join('; ') : result.errorMessages && result.errorMessages.join('; ');
      throw new Error(details || 'Jira не создала задачу (HTTP ' + response.status + ')');
    }
    return { key: result.key, summary: fields.summary, component: component.name, issueType: issueType.name, kind: draft.kind };
  }

  async function createDesignIssueFromSidebar(sourceTaskKey, summary, description) {
    const projectKey = 'FTD';
    const [issueTypes, components] = await Promise.all([loadIssueCreateMeta(projectKey), loadIssueCreateComponents(projectKey)]);
    const issueType = issueTypes.find((type) => /^(задача|task)$/i.test(String(type.name || '').trim()));
    if (!issueType) throw new Error('В проекте FTD не найден тип задачи «Задача»');
    const component = components.find((item) => String(item.name || '').trim().toLowerCase() === 'bank crm');
    if (!component) throw new Error('В проекте FTD не найден компонент «bank crm»');
    const fields = {
      project: { key: projectKey },
      issuetype: { id: String(issueType.id) },
      summary: String(summary || '').trim(),
      description: String(description || '').trim(),
      components: [{ id: String(component.id) }]
    };
    const requiredMissing = Object.entries(issueType.fields || {})
      .filter(([fieldId, meta]) => meta && meta.required && !Object.prototype.hasOwnProperty.call(fields, fieldId))
      .map(([, meta]) => meta.name || 'обязательное поле');
    if (requiredMissing.length) throw new Error('Для создания задачи FTD требуется заполнить: ' + requiredMissing.join(', '));
    const response = await fetch('/rest/api/2/issue', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ fields })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const details = result.errors ? Object.values(result.errors).join('; ') : result.errorMessages && result.errorMessages.join('; ');
      throw new Error(details || 'Jira не создала задачу FTD (HTTP ' + response.status + ')');
    }
    if (!result.key) throw new Error('Jira создала задачу FTD, но не вернула её ключ');
    const linked = await createIssueLinkInJira(sourceTaskKey, result.key, 'inProject');
    await reloadSingleTaskFromJira(sourceTaskKey, true);
    return { key: result.key, linked };
  }

  async function beginSidebarIssueCreate(kind) {
    const projectKey = kind === 'epic' ? CONFIG.projectKey : kind === 'front' ? 'OBFRONT' : 'OB';
    createInProjectMenuOpen = false;
    issueCreateBusy = false;
    issueCreateLoading = true;
    issueCreateDraft = { kind, projectKey, summary: '', description: '', componentId: '', componentQuery: '', components: [], error: '' };
    const draft = issueCreateDraft;
    renderStructure();
    try {
      const [metaResult, componentResult] = await Promise.allSettled([
        loadIssueCreateMeta(projectKey),
        loadIssueCreateComponents(projectKey)
      ]);
      if (issueCreateDraft !== draft) return;
      if (componentResult.status === 'fulfilled') issueCreateDraft.components = componentResult.value;
      if (metaResult.status === 'rejected') throw metaResult.reason;
      const issueTypes = metaResult.value;
      if (!getIssueCreateType(projectKey, kind, issueTypes)) {
        throw new Error(kind === 'epic' ? 'В FCRM не найден тип задачи Epic' : 'В проекте не найден тип задачи');
      }
    } catch (error) {
      if (issueCreateDraft !== draft) return;
      issueCreateDraft.error = error && error.message ? error.message : 'Не удалось загрузить данные Jira';
    }
    issueCreateLoading = false;
    renderStructure();
    setTimeout(() => document.getElementById('ozon-create-issue-summary')?.focus(), 0);
  }

  async function submitSidebarIssueCreate() {
    if (!issueCreateDraft || issueCreateBusy) return;
    issueCreateDraft.summary = String(document.getElementById('ozon-create-issue-summary')?.value || issueCreateDraft.summary).trim();
    issueCreateDraft.description = String(document.getElementById('ozon-create-issue-description')?.value || issueCreateDraft.description).trim();
    if (!issueCreateDraft.summary) {
      issueCreateDraft.error = 'Введите название';
      renderStructure();
      document.getElementById('ozon-create-issue-summary')?.focus();
      return;
    }
    if (issueCreateDraft.kind !== 'epic' && !String(issueCreateDraft.description || '').trim()) {
      issueCreateDraft.error = 'Введите описание задачи';
      renderStructure();
      document.getElementById('ozon-create-issue-description')?.focus();
      return;
    }
    if (!issueCreateDraft.componentId) {
      issueCreateDraft.error = 'Выберите компонент';
      renderStructure();
      return;
    }

    const sourceTaskKey = selectedTaskKey;
    issueCreateBusy = true;
    issueCreateDraft.error = '';
    renderStructure();
    try {
      const created = await createIssueFromSidebar(issueCreateDraft);
      if (!created.key) throw new Error('Jira создала задачу, но не вернула её ключ');
      if (created.kind === 'epic') {
        umbCatalog = [{
          key: created.key,
          summary: created.summary,
          status: 'Открыто',
          component: created.component,
          issueType: 'Epic',
          issueTypeName: 'Epic'
        }, ...umbCatalog.filter((item) => item.key !== created.key)];
      }
      issueCreateDraft = null;
      issueCreateBusy = false;
      renderStructure();
      const linkCategory = created.kind === 'epic' ? 'projectTask' : 'inProject';
      const linked = await createIssueLinkInJira(sourceTaskKey, created.key, linkCategory);
      if (!linked) {
        showSaveToast('Создана ' + created.key + ', но автоматическую связь сохранить не удалось');
        await reloadSingleTaskFromJira(sourceTaskKey, true);
      } else {
        await reloadSingleTaskFromJira(sourceTaskKey, true);
        showSaveToast('Создана и связана задача ' + created.key);
      }
    } catch (error) {
      issueCreateBusy = false;
      if (issueCreateDraft) issueCreateDraft.error = error && error.message ? error.message : 'Не удалось создать задачу';
      renderStructure();
    }
  }

  /**
   * Извлекает командный префикс серии спринта (например из "CS #73 (20.10 - 02.11)" -> "CS")
   */
  function extractSprintSeriesPrefix(sprintName) {
    if (!sprintName || sprintName === 'Не в спринте' || sprintName.includes('Бэклог')) return '';
    const m = String(sprintName).trim().match(/^([A-Za-z\p{L}0-9_&\-\s]+?)(?:\s*#\d+|\s+\d+|\s*\()/u);
    return m && m[1] ? m[1].trim() : '';
  }

  /**
   * Загружает реальные активные и будущие спринты для связанной задачи (например OBFRONT + компонент CS),
   * НЕ подмешивая спринты из FCRM.
   */
  async function loadSprintsForLinkedIssue(lnk) {
    if (!lnk || !lnk.key) return [];
    const projKey = getIssueProjectKey(lnk.key);
    if (projKey === CONFIG.projectKey) {
      return getEditableSprintOptions();
    }
    const compName = lnk.component && lnk.component !== 'Без компонента' ? String(lnk.component).split(',')[0].trim() : '';
    const curSprint = lnk.sprint && lnk.sprint !== 'Не в спринте' ? String(lnk.sprint).trim() : '';
    const cacheKey = projKey + '::' + (compName || '*');
    if (!externalProjectSprintsMap[cacheKey]) {
      ipSprintLoadProgress[lnk.key] = 12;
      renderStructure();
    }
    const foundSprints = new Set((externalProjectSprintsMap[cacheKey] || []).filter((sp) => isEditableSprintOption(sp)));
    if (curSprint && isEditableSprintOption(curSprint)) {
      foundSprints.add(curSprint);
    }

    const seriesPrefix = extractSprintSeriesPrefix(curSprint) || compName;

    // 1. Запрос к GreenHopper Sprint Picker API по префиксу спринта или компоненту (например "CS") — берём ТОЛЬКО Активные и Будущие
    const pickerQueries = Array.from(new Set([seriesPrefix, compName].filter(Boolean)));
    for (const qTerm of pickerQueries) {
      try {
        const ghRes = await fetch('/rest/greenhopper/1.0/sprint/picker?query=' + encodeURIComponent(qTerm), {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        if (ghRes.ok) {
          ipSprintLoadProgress[lnk.key] = 48;
          renderStructure();
          const ghData = await ghRes.json();
          const allMatches = [
            ...(Array.isArray(ghData && ghData.suggestions) ? ghData.suggestions : []),
            ...(Array.isArray(ghData && ghData.allMatches) ? ghData.allMatches : [])
          ];
          const qLow = qTerm.toLowerCase();
          allMatches.forEach((sp) => {
            if (!sp || !sp.name) return;
            const stKey = String(sp.stateKey || sp.state || '').toUpperCase();
            const spName = String(sp.name).trim();
            if (stKey === 'ACTIVE' || stKey === 'FUTURE' || stKey === 'CLOSED') {
              sprintStateByName[spName] = stKey;
            }
            if (stKey === 'CLOSED') {
              closedSprintNames.add(spName);
              if (sp.id) closedSprintIds.add(String(sp.id));
              return;
            }
            if (sp.id) {
              sprintIdByName[spName] = String(sp.id);
              sprintNameById[String(sp.id)] = spName;
            }
            if ((spName.toLowerCase().startsWith(qLow) || spName.toLowerCase().includes(qLow)) && isEditableSprintOption(spName)) {
              foundSprints.add(spName);
            }
          });
        }
      } catch (e) {}
    }

    // 2. Поиск открытых и будущих спринтов конкретно для проекта (OBFRONT/OB/FTD) и компонента (CS и др.) через JQL
    try {
      const sprintField = discoveredFields.sprint || CONFIG.sprintFieldId;
      const fieldsList = ['sprint', 'closedSprints', sprintField].filter(Boolean).join(',');
      const jqlWithComp =
        compName
          ? 'project = "' + projKey + '" AND component = "' + compName.replace(/"/g, '') + '" AND Sprint is not EMPTY ORDER BY updated DESC'
          : 'project = "' + projKey + '" AND Sprint is not EMPTY ORDER BY updated DESC';

      const sRes = await fetch(
        '/rest/api/2/search?jql=' + encodeURIComponent(jqlWithComp) + '&fields=' + encodeURIComponent(fieldsList) + '&maxResults=50',
        { credentials: 'same-origin', headers: { Accept: 'application/json' } }
      );
      if (sRes.ok) {
        ipSprintLoadProgress[lnk.key] = 82;
        renderStructure();
        const sData = await sRes.json();
        if (Array.isArray(sData.issues)) {
          sData.issues.forEach((iss) => {
            const lf = (iss && iss.fields) || {};
            const registerRawSprint = (raw, isFromClosedField) => {
              if (!raw) return;
              if (Array.isArray(raw)) {
                raw.forEach((item) => registerRawSprint(item, isFromClosedField));
                return;
              }
              if (typeof raw === 'object' && raw.name) {
                const st = isFromClosedField ? 'CLOSED' : String(raw.state || '').toUpperCase();
                const nm = String(raw.name).trim();
                if (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED') {
                  sprintStateByName[nm] = st;
                }
                if (st === 'CLOSED') {
                  closedSprintNames.add(nm);
                  if (raw.id) closedSprintIds.add(String(raw.id));
                  return;
                }
                if (raw.id) {
                  sprintIdByName[nm] = String(raw.id);
                  sprintNameById[String(raw.id)] = nm;
                }
                if (isEditableSprintOption(nm)) {
                  foundSprints.add(nm);
                }
                return;
              }
              const sStr = String(raw);
              const stMatch = sStr.match(/state=([^,\]]+)/);
              const parsedSt = isFromClosedField ? 'CLOSED' : stMatch && stMatch[1] ? stMatch[1].trim().toUpperCase() : '';
              const nm = extractAnyRealSprintName(raw);
              if (nm && (parsedSt === 'ACTIVE' || parsedSt === 'FUTURE' || parsedSt === 'CLOSED')) {
                sprintStateByName[nm] = parsedSt;
              }
              if (nm && parsedSt === 'CLOSED') {
                closedSprintNames.add(nm);
                return;
              }
              if (nm && isEditableSprintOption(nm)) {
                foundSprints.add(nm);
              }
            };
            registerRawSprint(lf.closedSprints, true);
            registerRawSprint(lf.sprint, false);
            if (sprintField && lf[sprintField]) registerRawSprint(lf[sprintField], false);
          });
        }
      }
    } catch (e) {}

    const teamPrefix = compName.toLowerCase();
    externalProjectSprintsMap[cacheKey] = Array.from(foundSprints).filter((sp) =>
      isEditableSprintOption(sp) && getSprintStateCode(sp) !== 'CLOSED' && (!teamPrefix || sp.toLowerCase().startsWith(teamPrefix))
    );
    delete ipSprintLoadProgress[lnk.key];
    return externalProjectSprintsMap[cacheKey];
  }

  function getSprintsForLinkedIssue(lnk) {
    if (!lnk || !lnk.key) return ['Не в спринте'];
    const projKey = getIssueProjectKey(lnk.key);
    const realSprintVal = (lnk.sprint && String(lnk.sprint).trim()) || 'Не в спринте';

    // Если связанная задача из самого FCRM — возвращаем ТОЛЬКО активные и будущие спринты FCRM (+ Бэклог / Не в спринте)
    if (projKey === CONFIG.projectKey) {
      return Array.from(new Set([...getEditableSprintOptions(), 'Не в спринте'])).filter((sp) => isEditableSprintOption(sp));
    }

    // Для внешних проектов (OBFRONT, OB, FTD и др.) НИКОГДА не подмешиваем спринты из FCRM и исключаем Прошедшие (CLOSED) спринты!
    const compName = lnk.component && lnk.component !== 'Без компонента' ? String(lnk.component).split(',')[0].trim() : '';
    const cacheKey = projKey + '::' + (compName || '*');
    const cached = (externalProjectSprintsMap[cacheKey] || []).filter((sp) =>
      isEditableSprintOption(sp)
    );

    // Также собираем активные и будущие спринты других связанных задач того же проекта и компонента
    const fromSameProjectCompLinks = [];
    const seriesPrefix = compName || extractSprintSeriesPrefix(realSprintVal);
    const prefixLow = seriesPrefix ? seriesPrefix.toLowerCase() : '';

    tasks.forEach((t) => {
      (t.inProjectLinks || []).forEach((otherLnk) => {
        if (!otherLnk || !otherLnk.key) return;
        const otherProj = getIssueProjectKey(otherLnk.key);
        if (otherProj !== projKey) return;
        const otherComp = otherLnk.component && otherLnk.component !== 'Без компонента' ? String(otherLnk.component).split(',')[0].trim() : '';
        const otherSp = otherLnk.sprint && otherLnk.sprint !== 'Не в спринте' ? String(otherLnk.sprint).trim() : '';
        if (!otherSp || !isEditableSprintOption(otherSp)) return;
        if (compName && otherComp.toLowerCase() === compName.toLowerCase()) {
          fromSameProjectCompLinks.push(otherSp);
        }
      });
    });

    // И проверяем известные активные и будущие спринты в sprintIdByName с тем же командным префиксом (например "CS #74", "CS #75")
    const fromKnownPrefix = [];
    if (prefixLow && prefixLow.length >= 2) {
      Object.keys(sprintIdByName).forEach((spName) => {
        if (boardOwnedSprintNames.has(spName)) return; // исключаем спринты FCRM
        if (!isEditableSprintOption(spName)) return; // исключаем прошедшие спринты
        if (spName.toLowerCase().startsWith(prefixLow)) {
          fromKnownPrefix.push(spName);
        }
      });
    }

    const teamSprints = compName ? [...cached, ...fromKnownPrefix, ...fromSameProjectCompLinks] : [realSprintVal];
    const combined = Array.from(
      new Set([
        ...(isEditableSprintOption(realSprintVal) ? [realSprintVal] : []),
        ...teamSprints,
        'Не в спринте'
      ])
    ).filter((sp) => isEditableSprintOption(sp) && getSprintStateCode(sp) !== 'CLOSED');

    const dummyGroups = {};
    combined.forEach((s) => {
      dummyGroups[s] = true;
    });
    return getSortedSprintNames(dummyGroups);
  }

  // ============================================================================
  // РЕАЛЬНОЕ СОЗДАНИЕ И УДАЛЕНИЕ СВЯЗЕЙ (ISSUE LINKS) В JIRA REST API
  // ============================================================================
  function renderLinkActions(link, current) {
    if (!link || !link.key) return '';
    const attrs = ' data-link-key="' + escapeHtml(link.key) + '" data-jira-link-id="' + escapeHtml(link.jiraLinkId || link.id || '') + '" data-current="' + current + '"';
    const types = [['projectTask','Задача проекта'],['inProject','В проекте'],['linkedTask','Связанная задача'],['duplicates','Дублирует']];
    return '<details class="ozon-link-actions"><summary aria-label="Действия со связью" title="Действия со связью">⋯</summary><div class="ozon-link-actions-menu">' + types.filter(([id]) => id !== current).map(([id,label]) => '<button type="button" data-action="change-link-type" data-link-type="' + id + '"' + attrs + '>' + label + '</button>').join('') + '<button type="button" data-action="delete-link"' + attrs + '>Удалить связь</button><div class="ozon-link-action-message" role="status" style="color:#D92D20;font-size:11px;white-space:normal;"></div></div></details>';
  }
  async function createIssueLinkInJira(sourceTaskKey, targetTaskKey, category /* 'projectTask' | 'inProject' */, strictType, deferReload) {
    if (!sourceTaskKey || !targetTaskKey) return false;
    try {
      // Подгружаем типы связей, если они ещё не загружены
      await loadIssueLinkTypes();

      // Ищем тип связи "Задача проекта" / "В проекте" в вашей Jira
      const categoryPattern = category === 'projectTask' ? /задача проекта|project task/i : category === 'linkedTask' ? /связанная задача|relates to|relates/i : category === 'duplicates' ? /дублирует|дубликат|duplicates?/i : /в проекте|in project/i;
      let chosenType = discoveredIssueLinkTypes.find((lt) => {
        const n = String(lt.name || '').toLowerCase();
        const inw = String(lt.inward || '').toLowerCase();
        const outw = String(lt.outward || '').toLowerCase();
        return categoryPattern.test(n) || categoryPattern.test(inw) || categoryPattern.test(outw);
      });

      if (!chosenType) {
        if (strictType) throw new Error('В Jira не найден тип связи «' + (category === 'duplicates' ? 'Дублирует' : category === 'linkedTask' ? 'Связанная задача' : category === 'projectTask' ? 'Задача проекта' : 'В проекте') + '».');
        chosenType =
          discoveredIssueLinkTypes.find((lt) => /relates|связ|project/i.test(String(lt.name || ''))) ||
          discoveredIssueLinkTypes[0] || {
            name: CONFIG.linkTypeProjectTask || 'Задача проекта',
            inward: 'задача проекта',
            outward: 'в проекте'
          };
      }

      const inwDesc = String(chosenType.inward || '').toLowerCase();
      const outwDesc = String(chosenType.outward || '').toLowerCase();

      // В Jira REST API POST /rest/api/2/issueLink:
      // На карточке задачи A связанная задача B отображается в направлении inward, если в POST передано:
      // inwardIssue: { key: B }, outwardIssue: { key: A }
      // И отображается в направлении outward, если передано:
      // inwardIssue: { key: A }, outwardIssue: { key: B }
      let inwardKey = targetTaskKey;
      let outwardKey = sourceTaskKey;

      if (category === 'projectTask') {
        if (outwDesc.includes('задача проекта') && !inwDesc.includes('задача проекта')) {
          inwardKey = sourceTaskKey;
          outwardKey = targetTaskKey;
        } else {
          inwardKey = targetTaskKey;
          outwardKey = sourceTaskKey;
        }
      } else if (category === 'duplicates') {
        if (/дублирует|дубликат|duplicates?/i.test(outwDesc)) { inwardKey = sourceTaskKey; outwardKey = targetTaskKey; }
        else if (/дублирует|дубликат|duplicates?/i.test(inwDesc)) { inwardKey = targetTaskKey; outwardKey = sourceTaskKey; }
        else throw new Error('Направление связи «Дублирует» недоступно');
      } else {
        // Связанная задача — симметричный тип; Jira всё равно покажет его с обеих сторон.
        if (inwDesc.includes('в проекте') && !outwDesc.includes('в проекте')) {
          inwardKey = targetTaskKey;
          outwardKey = sourceTaskKey;
        } else {
          inwardKey = sourceTaskKey;
          outwardKey = targetTaskKey;
        }
      }

      const postRes = await fetch('/rest/api/2/issueLink', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          type: { name: chosenType.name },
          inwardIssue: { key: inwardKey },
          outwardIssue: { key: outwardKey }
        })
      });

      if (postRes.ok) {
        showSaveToast('✓ Связь ' + sourceTaskKey + ' ↔ ' + targetTaskKey + ' сохранена в Jira');
        // Перезагружаем задачу из Jira, чтобы подтянуть реальный ID связи и все поля связанной задачи
        if (!deferReload) await reloadSingleTaskFromJira(sourceTaskKey);
        return true;
      } else {
        // Резервная попытка с Relates, если кастомное имя типа связи отличается
        const fallbackType = discoveredIssueLinkTypes.find((lt) => /relates|связ/i.test(String(lt.name || ''))) || discoveredIssueLinkTypes[0];
        if (!strictType && fallbackType && fallbackType.name !== chosenType.name) {
          const retryRes = await fetch('/rest/api/2/issueLink', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({
              type: { name: fallbackType.name },
              inwardIssue: { key: inwardKey },
              outwardIssue: { key: outwardKey }
            })
          });
          if (retryRes.ok) {
            showSaveToast('✓ Связь ' + sourceTaskKey + ' ↔ ' + targetTaskKey + ' сохранена в Jira');
            if (!deferReload) await reloadSingleTaskFromJira(sourceTaskKey);
            return true;
          }
        }
        showSaveToast('⚠ Не удалось создать связь с ' + targetTaskKey + ' (проверьте ключ задачи)');
        return false;
      }
    } catch (e) {
      if (strictType) throw e;
      return false;
    }
  }

  async function deleteIssueLinkInJira(sourceTaskKey, targetTaskKey, explicitJiraLinkId) {
    if (!sourceTaskKey || !targetTaskKey) return false;
    try {
      let linkIdToDelete = explicitJiraLinkId && /^\d+$/.test(String(explicitJiraLinkId)) ? String(explicitJiraLinkId) : null;

      if (!linkIdToDelete) {
        const r = await fetch('/rest/api/2/issue/' + encodeURIComponent(sourceTaskKey) + '?fields=issuelinks', {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        if (r.ok) {
          const d = await r.json();
          const links = (d && d.fields && Array.isArray(d.fields.issuelinks)) ? d.fields.issuelinks : [];
          const found = links.find((lnk) => {
            const k1 = lnk.inwardIssue && lnk.inwardIssue.key;
            const k2 = lnk.outwardIssue && lnk.outwardIssue.key;
            return k1 === targetTaskKey || k2 === targetTaskKey;
          });
          if (found && found.id) {
            linkIdToDelete = String(found.id);
          }
        }
      }

      if (!linkIdToDelete) {
        showSaveToast('Связь ' + targetTaskKey + ' убрана');
        return false;
      }

      const delRes = await fetch('/rest/api/2/issueLink/' + encodeURIComponent(linkIdToDelete), {
        method: 'DELETE',
        credentials: 'same-origin'
      });

      if (delRes.ok || delRes.status === 204) {
        showSaveToast('✓ Связь с ' + targetTaskKey + ' удалена из Jira');
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Живой поиск пользователей в Jira по ФИО или логину (отфильтровывая технические аккаунты с $)
  async function searchJiraUsers(query, issueKey) {
    const q = String(query || '').trim();
    const qLow = q.toLowerCase();

    const localMatches = assignableUsersList.filter(
      (u) =>
        isRealHumanJiraUser(u) &&
        (!qLow ||
          (u.displayName && u.displayName.toLowerCase().includes(qLow)) ||
          (u.name && u.name.toLowerCase().includes(qLow)))
    );

    if (!q) {
      return localMatches.slice(0, 25);
    }

    const mergedMap = new Map();
    localMatches.forEach((u) => mergedMap.set(u.name, u));

    try {
      const issueParam = issueKey ? 'issueKey=' + encodeURIComponent(issueKey) + '&' : 'project=' + encodeURIComponent(CONFIG.projectKey) + '&';
      const res1 = await fetch(
        '/rest/api/2/user/assignable/search?' + issueParam + 'username=' + encodeURIComponent(q) + '&query=' + encodeURIComponent(q) + '&maxResults=25',
        { credentials: 'same-origin', headers: { Accept: 'application/json' } }
      );
      if (res1.ok) {
        const arr1 = await res1.json();
        if (Array.isArray(arr1)) {
          arr1.forEach((u) => {
            if (!isRealHumanJiraUser(u)) return;
            const login = u.name || u.key || u.displayName;
            if (login && u.displayName) {
              const item = { name: login, displayName: u.displayName, email: u.emailAddress || '' };
              mergedMap.set(login, item);
              if (!assignableUsersList.some((ex) => ex.name === login)) {
                assignableUsersList.push(item);
              }
            }
          });
        }
      }
    } catch (e) {}

    if (mergedMap.size < 5) {
      try {
        const res2 = await fetch(
          '/rest/api/2/user/search?username=' + encodeURIComponent(q) + '&query=' + encodeURIComponent(q) + '&maxResults=25',
          { credentials: 'same-origin', headers: { Accept: 'application/json' } }
        );
        if (res2.ok) {
          const arr2 = await res2.json();
          if (Array.isArray(arr2)) {
            arr2.forEach((u) => {
              if (!isRealHumanJiraUser(u)) return;
              const login = u.name || u.key || u.displayName;
              if (login && u.displayName) {
                const item = { name: login, displayName: u.displayName, email: u.emailAddress || '' };
                mergedMap.set(login, item);
                if (!assignableUsersList.some((ex) => ex.name === login)) {
                  assignableUsersList.push(item);
                }
              }
            });
          }
        }
      } catch (e) {}
    }

    return Array.from(mergedMap.values()).slice(0, 30);
  }

  async function transitionIssueStatusInJira(issueKey, targetStatusName, explicitTransitionId) {
    try {
      let trId = explicitTransitionId;
      let transitions = issueTransitionsByKey[issueKey];

      if (!trId) {
        const trRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/transitions', {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        if (trRes.ok) {
          const trData = await trRes.json();
          transitions = Array.isArray(trData.transitions) ? trData.transitions : [];
          issueTransitionsByKey[issueKey] = transitions;
        }
      }

      if (!trId && Array.isArray(transitions)) {
        const targetLow = String(targetStatusName || '').trim().toLowerCase();
        const matched = transitions.find((tr) => {
          const toName = (tr.to && tr.to.name ? String(tr.to.name) : '').trim().toLowerCase();
          const trName = (tr.name ? String(tr.name) : '').trim().toLowerCase();
          return toName === targetLow || trName === targetLow || toName.includes(targetLow) || trName.includes(targetLow);
        });
        if (matched && matched.id) {
          trId = String(matched.id);
        }
      }

      if (!trId) {
        showSaveToast('Статус ' + issueKey + ' → ' + targetStatusName + ' (локально)');
        return false;
      }

      const postRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/transitions', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ transition: { id: String(trId) } })
      });
      if (postRes.ok) {
        showSaveToast('✓ Статус ' + issueKey + ' переведён в «' + targetStatusName + '»');
        void refreshStrategyIssue(issueKey, 'status');
        fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/transitions', {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d && Array.isArray(d.transitions)) {
              issueTransitionsByKey[issueKey] = d.transitions;
              renderStructure();
            }
          })
          .catch(() => {});
      }
      return postRes.ok;
    } catch (e) {
      return false;
    }
  }

  async function updateIssueTypeInJira(issueKey, newTypeName) {
    if (!issueKey || !newTypeName) return false;
    try {
      const cleanName = String(newTypeName).trim();
      const typeId = issueTypeIdByName[cleanName] || null;
      const issuetypePayload = typeId ? { id: String(typeId) } : { name: cleanName };

      const putRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
        method: 'PUT',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ fields: { issuetype: issuetypePayload } })
      });

      if (putRes.ok || putRes.status === 204) {
        showSaveToast('✓ Тип задачи ' + issueKey + ' → ' + cleanName);
        void refreshStrategyIssue(issueKey, 'issuetype');
        return true;
      }

      // Фоллбэк по имени типа задачи, если по ID вернулась ошибка схемы
      if (typeId) {
        const retryRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ fields: { issuetype: { name: cleanName } } })
        });
        if (retryRes.ok || retryRes.status === 204) {
          showSaveToast('✓ Тип задачи ' + issueKey + ' → ' + cleanName);
          void refreshStrategyIssue(issueKey, 'issuetype');
          return true;
        }
      }

      showSaveToast('✓ Тип задачи ' + issueKey + ' → ' + cleanName);
      return false;
    } catch (e) {
      return false;
    }
  }

  async function updateIssueEpicInJira(issueKey, newEpicKey) {
    try {
      const cleanEpKey = newEpicKey ? String(newEpicKey).trim().toUpperCase() : '';

      // 1. Если для нового эпика ещё не загружено название — подтягиваем из Jira
      if (cleanEpKey && !epicNameByKey[cleanEpKey]) {
        try {
          const epInfoRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(cleanEpKey) + '?fields=summary', {
            credentials: 'same-origin',
            headers: { Accept: 'application/json' }
          });
          if (epInfoRes.ok) {
            const epInfo = await epInfoRes.json();
            const epSum = epInfo && epInfo.fields && epInfo.fields.summary ? String(epInfo.fields.summary).trim() : '';
            if (epSum) {
              epicNameByKey[cleanEpKey] = epSum;
              if (cleanEpKey.startsWith(CONFIG.projectKey + '-')) {
                fcrmEpicNameByKey[cleanEpKey] = epSum;
              }
              tasks = tasks.map((t) =>
                t.key === issueKey ? Object.assign({}, t, { epicKey: cleanEpKey, epicName: epSum }) : t
              );
              saveTaskOverride(issueKey, { epicKey: cleanEpKey, epicName: epSum });
              renderStructure();
            }
          }
        } catch (e) {}
      }

      // 2. Если ID кастомного поля Epic Link ещё не обнаружен — определяем через editmeta задачи
      if (!discoveredFields.epicLink) {
        try {
          const metaRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/editmeta', {
            credentials: 'same-origin',
            headers: { Accept: 'application/json' }
          });
          if (metaRes.ok) {
            const metaData = await metaRes.json();
            const metaFields = (metaData && metaData.fields) || {};
            Object.keys(metaFields).forEach((fKey) => {
              const mf = metaFields[fKey];
              const cType = (mf && mf.schema && mf.schema.custom) || '';
              const fName = String((mf && mf.name) || '').toLowerCase();
              if (cType.includes('gh-epic-link') || fName === 'epic link' || fName === 'ссылка на эпик' || fName.includes('эпик')) {
                discoveredFields.epicLink = fKey;
              }
            });
          }
        } catch (e) {}
      }

      let savedOk = false;

      // 3. Обновляем поле Epic Link через стандартный PUT /rest/api/2/issue/{issueKey}
      if (discoveredFields.epicLink) {
        const payload = { fields: {} };
        payload.fields[discoveredFields.epicLink] = cleanEpKey || null;
        const putRes = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(payload)
        });
        if (putRes.ok || putRes.status === 204) {
          savedOk = true;
        }
      }

      // 4. Дублируем через Agile API /rest/agile/1.0/epic/{epicKey|none}/issue
      const agileTarget = cleanEpKey ? encodeURIComponent(cleanEpKey) : 'none';
      const agRes = await fetch('/rest/agile/1.0/epic/' + agileTarget + '/issue', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ issues: [issueKey] })
      });
      if (agRes.ok || agRes.status === 204) {
        savedOk = true;
      }

      if (savedOk) {
        showSaveToast('✓ Эпик ' + issueKey + ' → ' + (cleanEpKey || 'Без эпика') + ' сохранён в Jira');
        void refreshStrategyIssue(issueKey, [discoveredFields.epicLink, 'epic'].filter(Boolean).join(','));
      } else {
        showSaveToast('⚠ Проверьте код эпика ' + (cleanEpKey || ''));
      }
    } catch (e) {}
  }

  async function updateIssueAssigneeInJira(issueKey, displayNameOrLogin, explicitLogin) {
    try {
      const foundUser = assignableUsersList.find(
        (u) => u.displayName === displayNameOrLogin || u.name === displayNameOrLogin
      );
      const loginName =
        displayNameOrLogin === 'Не назначен' || !displayNameOrLogin
          ? null
          : explicitLogin || (foundUser && foundUser.name) || displayNameOrLogin;

      const res = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey) + '/assignee', {
        method: 'PUT',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: loginName })
      });

      if (!res.ok && loginName) {
        await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fields: { assignee: { name: loginName } } })
        }).catch(() => {});
      }
      showSaveToast('✓ Исполнитель ' + issueKey + ' → ' + (displayNameOrLogin || 'Не назначен'));
    } catch (e) {}
  }

  async function updateIssueCustomerInJira(issueKey, customerValue, explicitLogin) {
    try {
      const foundUser = assignableUsersList.find(
        (u) => u.displayName === customerValue || u.name === customerValue
      );
      const resolvedLogin = explicitLogin || (foundUser && foundUser.name) || null;
      const candidateFields = Array.from(new Set([discoveredFields.customer, ...discoveredCustomerFieldIds].filter(Boolean)));

      for (const fId of candidateFields) {
        if (customerValue === 'Не указан' || !customerValue) {
          const payload = { fields: { [fId]: null } };
          const r = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          if (r.ok || r.status === 204) {
            discoveredFields.customer = fId;
            break;
          }
          continue;
        }

        // Вариант 1: User Picker ({ name: login }) — основной формат для поля "Заказчик/Owner" в Jira
        if (resolvedLogin) {
          const pUser = { fields: { [fId]: { name: resolvedLogin } } };
          const r1 = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(pUser)
          });
          if (r1.ok || r1.status === 204) {
            discoveredFields.customer = fId;
            break;
          }
          // Вариант 2: Multi-User Picker ([{ name: login }])
          const pMulti = { fields: { [fId]: [{ name: resolvedLogin }] } };
          const r2 = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(pMulti)
          });
          if (r2.ok || r2.status === 204) {
            discoveredFields.customer = fId;
            break;
          }
        }

        // Вариант 3: Текстовое поле
        const pStr = { fields: { [fId]: customerValue } };
        const r3 = await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(pStr)
        });
        if (r3.ok || r3.status === 204) {
          discoveredFields.customer = fId;
          break;
        }
      }
      showSaveToast('✓ Заказчик/Owner ' + issueKey + ' → ' + customerValue);
    } catch (e) {}
  }

  async function updateIssueSprintInJira(issueKey, newSprintName) {
    try {
      const isRemoveFromSprint =
        !newSprintName ||
        newSprintName.includes('Бэклог') ||
        newSprintName === 'Не в спринте';

      const targetSpId = !isRemoveFromSprint ? sprintIdByName[newSprintName] : null;

      if (targetSpId) {
        await fetch('/rest/agile/1.0/sprint/' + encodeURIComponent(targetSpId) + '/issue', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ issues: [issueKey] })
        }).catch(() => {});
        if (discoveredFields.sprint) {
          const p = { fields: {} };
          p.fields[discoveredFields.sprint] = Number(targetSpId) || targetSpId;
          await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(p)
          }).catch(() => {});
        }
        showSaveToast('✓ Спринт ' + issueKey + ' → ' + newSprintName);
      } else {
        await fetch('/rest/agile/1.0/backlog/issue', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ issues: [issueKey] })
        }).catch(() => {});
        if (discoveredFields.sprint) {
          const p = { fields: {} };
          p.fields[discoveredFields.sprint] = null;
          await fetch('/rest/api/2/issue/' + encodeURIComponent(issueKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(p)
          }).catch(() => {});
        }
        showSaveToast('✓ Задача ' + issueKey + ' удалена из спринта (в Бэклог)');
      }
    } catch (e) {}
  }

  /**
   * Живой поиск эпиков СТРОГО внутри проекта FCRM без ошибки 400 Bad Request на issuetype in (Epic, "Эпик")
   */
  async function searchFcrmEpicsInJira(query) {
    const qClean = String(query || '').trim().replace(/"/g, '');

    // 1. Нативный GreenHopper Epic Picker API для проекта FCRM
    try {
      const ghEpRes = await fetch(
        '/rest/greenhopper/1.0/epics?searchQuery=' + encodeURIComponent(qClean) + '&projectKey=' + encodeURIComponent(CONFIG.projectKey) + '&maxResults=100',
        { credentials: 'same-origin', headers: { Accept: 'application/json' } }
      );
      if (ghEpRes.ok) {
        const ghEpData = await ghEpRes.json();
        const lists = (ghEpData && Array.isArray(ghEpData.epicLists) ? ghEpData.epicLists : []);
        lists.forEach((lst) => {
          if (lst && Array.isArray(lst.epicNames)) {
            lst.epicNames.forEach((ep) => {
              if (ep && ep.key && String(ep.key).startsWith(CONFIG.projectKey + '-') && ep.name) {
                const title = String(ep.name).trim();
                if (!isBogusEpicTitle(title, ep.key)) {
                  fcrmEpicNameByKey[ep.key] = title;
                  epicNameByKey[ep.key] = title;
                }
              }
            });
          }
        });
      }
    } catch (e) {}

    // 2. Поиск через JQL /rest/api/2/search с безопасным определением типа задачи Epic и поддержкой префиксного поиска (почт*)
    const epFields = ['summary', 'status', 'labels', 'customfield_20100'];
    if (discoveredFields.epicName) epFields.push(discoveredFields.epicName);

    const buildEpicJql = (epicTypeClause) => {
      let base = 'project = ' + CONFIG.projectKey + (epicTypeClause ? ' AND ' + epicTypeClause : '');
      if (qClean) {
        if (/^[A-Za-z]+-\d+$/i.test(qClean)) {
          base += ' AND (key = "' + qClean.toUpperCase() + '" OR summary ~ "' + qClean + '*")';
        } else {
          base += ' AND (summary ~ "' + qClean + '*" OR summary ~ "' + qClean + '")';
        }
      }
      return base + ' ORDER BY updated DESC';
    };

    const candidateClauses = [];
    if (discoveredEpicIssueTypeName) {
      candidateClauses.push('issuetype = "' + discoveredEpicIssueTypeName.replace(/"/g, '') + '"');
    } else {
      candidateClauses.push('issuetype = Epic');
      candidateClauses.push('issuetype = "Эпик"');
    }
    if (discoveredFields.epicName) {
      const cfNum = String(discoveredFields.epicName).replace('customfield_', '');
      if (/^\d+$/.test(cfNum)) {
        candidateClauses.push('cf[' + cfNum + '] is not EMPTY');
      }
    }

    for (const clause of candidateClauses) {
      try {
        const jql = buildEpicJql(clause);
        const res = await fetch(
          '/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&fields=' + epFields.join(',') + '&maxResults=100',
          { credentials: 'same-origin', headers: { Accept: 'application/json' } }
        );
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.issues)) {
            cacheEpicMetadata(data.issues);
            data.issues.forEach((epIss) => {
              if (!epIss || !epIss.key || !String(epIss.key).startsWith(CONFIG.projectKey + '-')) return;
              const ef = epIss.fields || {};
              const sum = ef.summary ? String(ef.summary).trim() : '';
              const cName = discoveredFields.epicName && ef[discoveredFields.epicName] ? String(ef[discoveredFields.epicName]).trim() : '';
              const title = !isBogusEpicTitle(sum, epIss.key) ? sum : !isBogusEpicTitle(cName, epIss.key) ? cName : epIss.key;
              fcrmEpicNameByKey[epIss.key] = title;
              epicNameByKey[epIss.key] = title;
            });
          }
          break; // Успешный запрос — не нужно перебирать запасные варианты
        }
      } catch (e) {}
    }
  }

  // Шаг 1. Авто-обнаружение ID кастомных полей, типов связей, компонентов, статусов из схемы, приоритетов и исполнителей FCRM
  async function discoverJiraFieldsAndComponents() {
    try {
      const res = await fetch('/rest/api/2/field', {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      if (res.ok) {
        const fields = await res.json();
        if (Array.isArray(fields)) {
          const exactOwnerIds = [];
          const secondaryOwnerIds = [];
          fields.forEach((fld) => {
            const customType = (fld.schema && fld.schema.custom) || '';
            const nameLow = String(fld.name || '').toLowerCase().trim();
            const nameCompact = nameLow.replace(/\s+/g, '');
            if (nameLow === 'story points' || nameLow === 'story point' || nameLow === 'стори поинты') discoveredFields.storyPoints = fld.id;

            if (customType.includes('gh-sprint') || nameLow === 'sprint' || nameLow === 'спринт') {
              discoveredFields.sprint = fld.id;
            }
            if (customType.includes('gh-epic-link') || nameLow === 'epic link' || nameLow === 'ссылка на эпик') {
              discoveredFields.epicLink = fld.id;
            }
            if (customType.includes('gh-epic-label') || nameLow === 'epic name' || nameLow === 'название эпика' || nameLow === 'имя эпика') {
              discoveredFields.epicName = fld.id;
            }
            // Везде где отображаем заказчика, ищем поле "Заказчик/Owner" с наивысшим приоритетом
            if (nameCompact === 'заказчик/owner' || nameLow.includes('заказчик/owner') || (nameLow.includes('заказчик') && nameLow.includes('owner'))) {
              exactOwnerIds.push(fld.id);
            } else if (nameLow === 'заказчик' || nameLow === 'owner' || nameLow === 'бизнес-заказчик' || nameLow === 'customer' || nameLow.includes('заказчик')) {
              secondaryOwnerIds.push(fld.id);
            }
          });
          discoveredCustomerFieldIds = Array.from(new Set([...exactOwnerIds, ...secondaryOwnerIds]));
          if (discoveredCustomerFieldIds.length > 0) {
            discoveredFields.customer = discoveredCustomerFieldIds[0];
          }
        }
      }
    } catch (e) {}

    try { await loadIssueLinkTypes(); } catch (e) {}

    // Компоненты СТРОГО проекта FCRM
    try {
      const key = String(CONFIG.projectKey).toUpperCase();
      const components = await fetchProjectComponents(key, true);
      projectComponentsList = components
        .filter(item => !item.project || String(item.project).toUpperCase() === key)
        .map(item => item.name);
    } catch (e) {}

    // Статусы и типы задач проекта FCRM строго в разрезе каждого типа задачи (Workflow Scheme!) + точное имя типа задачи Epic
    try {
      const stRes = await fetch('/rest/api/2/project/' + encodeURIComponent(CONFIG.projectKey) + '/statuses', {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      if (stRes.ok) {
        const stData = await stRes.json();
        const stSet = new Set();
        const typesList = [];
        if (Array.isArray(stData)) {
          stData.forEach((issueTypeObj) => {
            const typeName = issueTypeObj && issueTypeObj.name ? String(issueTypeObj.name).trim() : '';
            const typeId = issueTypeObj && issueTypeObj.id ? String(issueTypeObj.id) : '';
            if (typeName) {
              if (typeId) {
                issueTypeIdByName[typeName] = typeId;
              }
              if (!typesList.some((it) => it.name === typeName)) {
                typesList.push({ id: typeId, name: typeName, subtask: Boolean(issueTypeObj.subtask) });
              }
            }
            if (typeName.toLowerCase() === 'epic' || typeName.toLowerCase() === 'эпик') {
              discoveredEpicIssueTypeName = typeName;
            }
            const typeStatuses = [];
            if (Array.isArray(issueTypeObj.statuses)) {
              issueTypeObj.statuses.forEach((s) => {
                if (s && s.name && !isCanceledStatus(s.name)) {
                  stSet.add(s.name);
                  typeStatuses.push(s.name);
                } else if (s && s.name) {
                  typeStatuses.push(s.name);
                }
              });
            }
            if (typeName && typeStatuses.length > 0) {
              statusesByIssueTypeMap[typeName] = typeStatuses;
            }
            if (typeId && typeStatuses.length > 0) {
              statusesByIssueTypeMap[typeId] = typeStatuses;
            }
          });
        }
        if (typesList.length > 0) {
          projectIssueTypesList = typesList;
        }
        if (stSet.size > 0) {
          projectStatusesList = Array.from(stSet);
        }
      }
    } catch (e) {}

    // Дополнительно проверяем типы задач проекта через /rest/api/2/project/{projectKey}, если список пуст
    if (projectIssueTypesList.length === 0) {
      try {
        const prjRes = await fetch('/rest/api/2/project/' + encodeURIComponent(CONFIG.projectKey), {
          credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        if (prjRes.ok) {
          const prjData = await prjRes.json();
          if (prjData && Array.isArray(prjData.issueTypes)) {
            prjData.issueTypes.forEach((it) => {
              if (it && it.name) {
                const tName = String(it.name).trim();
                const tId = it.id ? String(it.id) : '';
                if (tId) issueTypeIdByName[tName] = tId;
                if (!projectIssueTypesList.some((x) => x.name === tName)) {
                  projectIssueTypesList.push({ id: tId, name: tName, subtask: Boolean(it.subtask) });
                }
              }
            });
          }
        }
      } catch (e) {}
    }

    // Все приоритеты Jira
    try {
      const prRes = await fetch('/rest/api/2/priority', {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      if (prRes.ok) {
        const prData = await prRes.json();
        if (Array.isArray(prData)) {
          projectPrioritiesList = prData.map((p) => p && p.name).filter(Boolean);
          prData.forEach((p) => {
            if (p && p.name && p.iconUrl) {
              priorityIconUrlMap[p.name] = p.iconUrl;
            }
          });
        }
      }
    } catch (e) {}

    // Исполнители проекта FCRM (без технических ботов $)
    try {
      const usrRes = await fetch('/rest/api/2/user/assignable/search?project=' + encodeURIComponent(CONFIG.projectKey) + '&maxResults=100', {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      if (usrRes.ok) {
        const usrs = await usrRes.json();
        if (Array.isArray(usrs)) {
          assignableUsersList = usrs
            .filter((u) => u && (u.name || u.key) && u.displayName && isRealHumanJiraUser(u))
            .map((u) => ({ name: u.name || u.key, displayName: u.displayName, email: u.emailAddress || '' }));
        }
      }
    } catch (e) {}
  }

  /**
   * Шаг 2. Подгрузка родных Активных, Будущих И Закрытых (Прошедших) спринтов доски FCRM (#9349) с пагинацией (дозапросами) и эпиков FCRM.
   */
  async function loadBoardSprintsAndEpics() {
    try {
      let spStartAt = 0;
      let spIsLast = false;
      let spPageGuard = 0;
      let globalSpIdx = 0;

      while (!spIsLast && spPageGuard < 15) {
        spPageGuard++;
        const spRes = await fetch(
          '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/sprint?state=active,future,closed&startAt=' + spStartAt + '&maxResults=50',
          {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { Accept: 'application/json' }
          }
        );
        if (!spRes.ok) break;
        const spData = await spRes.json();
        const vals = Array.isArray(spData.values) ? spData.values : [];
        if (vals.length === 0) break;

        vals.forEach((sp) => {
          globalSpIdx++;
          if (!sp || !sp.id || !sp.name) return;
          const spIdStr = String(sp.id);
          const spNameClean = String(sp.name).trim();
          const stateLow = String(sp.state || '').toLowerCase();
          const stateUp = stateLow.toUpperCase();

          if (stateLow === 'closed') {
            closedSprintIds.add(spIdStr);
            closedSprintNames.add(spNameClean);
          } else if (stateLow === 'active' || stateLow === 'future') {
            closedSprintIds.delete(spIdStr);
            closedSprintNames.delete(spNameClean);
          }

          sprintNameById[spIdStr] = sp.name;
          sprintIdByName[sp.name] = spIdStr;
          sprintIdByName[spNameClean] = spIdStr;
          if (stateUp === 'ACTIVE' || stateUp === 'FUTURE' || stateUp === 'CLOSED') {
            sprintStateByName[sp.name] = stateUp;
            sprintStateByName[spNameClean] = stateUp;
          }

          const isOwnedByBoard =
            (sp.originBoardId && String(sp.originBoardId) === String(CONFIG.rapidViewId)) ||
            isNativeFcrmBoardSprintName(sp.name, sp.originBoardId);

          if (!isOwnedByBoard) {
            return;
          }

          boardOwnedSprintIds.add(spIdStr);
          boardOwnedSprintNames.add(spNameClean);
          if (stateLow === 'active') sprintOrderWeight[sp.name] = 1 + globalSpIdx;
          else if (stateLow === 'future') sprintOrderWeight[sp.name] = 50 + globalSpIdx;
          else sprintOrderWeight[sp.name] = Math.max(200, 450 - Number(sp.id || globalSpIdx));
        });

        spStartAt += vals.length;
        if (isInitialBoardLoading && Number(spData.total) > 0) {
          initialLoadProgress = Math.max(initialLoadProgress, Math.min(31, 15 + Math.round((spStartAt / Number(spData.total)) * 16)));
          initialLoadStage = 'Загружаю спринты: ' + Math.min(spStartAt, Number(spData.total)) + ' из ' + Number(spData.total);
          renderStructure();
        }
        if (spData.isLast === true || vals.length < (spData.maxResults || 50)) {
          spIsLast = true;
        }
      }
    } catch (e) {}

    try {
      const ghRes = await fetch('/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId=' + CONFIG.rapidViewId, {
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { Accept: 'application/json' }
      });
      if (ghRes.ok) {
        const ghData = await ghRes.json();
        const fcrmIssueIdsOnBoard = new Set();
        if (Array.isArray(ghData.issues)) {
          ghData.issues.forEach((iss) => {
            if (iss && iss.id && iss.key && String(iss.key).startsWith(CONFIG.projectKey + '-')) {
              fcrmIssueIdsOnBoard.add(String(iss.id));
            }
          });
        }

        if (Array.isArray(ghData.sprints)) {
          ghData.sprints.forEach((sp, idx) => {
            if (!sp || !sp.id || !sp.name) return;
            const st = String(sp.state || '').toUpperCase();
            const spIdStr = String(sp.id);
            const spNameClean = String(sp.name).trim();

            if (st === 'CLOSED') {
              closedSprintIds.add(spIdStr);
              closedSprintNames.add(spNameClean);
            }
            if (st === 'ACTIVE' || st === 'FUTURE' || st === 'CLOSED') {
              sprintStateByName[sp.name] = st;
              sprintStateByName[spNameClean] = st;
            }
            sprintNameById[spIdStr] = sp.name;
            sprintIdByName[sp.name] = spIdStr;

            const spIssuesIds = Array.isArray(sp.issuesIds) ? sp.issuesIds.map(String) : [];
            const hasFcrmIssuesInSprint = spIssuesIds.some((id) => fcrmIssueIdsOnBoard.has(id));
            const isNative =
              boardOwnedSprintIds.has(spIdStr) ||
              hasFcrmIssuesInSprint ||
              isNativeFcrmBoardSprintName(sp.name, null);

            if (!isNative) {
              return;
            }

            boardOwnedSprintIds.add(spIdStr);
            boardOwnedSprintNames.add(spNameClean);
            if (!sprintOrderWeight[sp.name]) {
              sprintOrderWeight[sp.name] = st === 'ACTIVE' ? 10 + idx : st === 'FUTURE' ? 60 + idx : 300 + idx;
            }
            spIssuesIds.forEach((issId) => {
              if (st !== 'CLOSED' || !issueSprintOverrideMap[issId]) {
                issueSprintOverrideMap[issId] = sp.name;
              }
            });
          });
        }

        if (ghData.epicData && Array.isArray(ghData.epicData.epics)) {
          ghData.epicData.epics.forEach((ep) => {
            const epKey = ep.key;
            if (!epKey) return;
            const candidateSummary = ep.summary;
            const candidateText = ep.epicField && ep.epicField.text;
            let resolved = '';
            if (!isBogusEpicTitle(candidateSummary, epKey)) {
              resolved = candidateSummary.trim();
            } else if (!isBogusEpicTitle(candidateText, epKey)) {
              resolved = candidateText.trim();
            }
            if (resolved) {
              epicNameByKey[epKey] = resolved;
              if (String(epKey).startsWith(CONFIG.projectKey + '-')) {
                fcrmEpicNameByKey[epKey] = resolved;
              }
            }
          });
        }
      }
    } catch (e) {}

    // 3. Загружаем эпики СТРОГО проекта FCRM через JQL поиск
    await searchFcrmEpicsInJira('');
  }

  async function loadUmbEpicTasksFromJira(customQuery) {
    try {
      let jql = 'labels = fcrm_umb_epic';
      if (customQuery && String(customQuery).trim()) {
        const qClean = String(customQuery).trim().replace(/"/g, '');
        if (/^[A-Za-z]+-\d+$/i.test(qClean)) {
          jql = 'labels = fcrm_umb_epic AND (key = "' + qClean.toUpperCase() + '" OR summary ~ "' + qClean + '")';
        } else {
          jql = 'labels = fcrm_umb_epic AND summary ~ "' + qClean + '"';
        }
      }
      const issues = [];
      let startAt = 0;
      do {
      const res = await fetch('/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&fields=key,summary,status,issuetype,components,issuelinks&maxResults=200&startAt=' + startAt, {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return;
      const data = await res.json();
      const page = Array.isArray(data.issues) ? data.issues : [];
      issues.push(...page);
      startAt += page.length;
      if (!page.length || startAt >= Number(data.total || issues.length)) break;
      } while (true);
      if (issues.length > 0) {
        const loaded = issues
          .map((iss, idx) => ({
            id: 'umb-' + idx + '-' + iss.key,
            key: iss.key,
            summary: (iss.fields && iss.fields.summary) || iss.key,
            status: (iss.fields && iss.fields.status && iss.fields.status.name) || 'Открыто',
            issueTypeName: (iss.fields && iss.fields.issuetype && iss.fields.issuetype.name) || 'Задача',
            component: resolveRealLinkedIssueComponent(iss),
            components: ((iss.fields && iss.fields.components) || []).map((c) => c && c.name).filter(Boolean),
            parents: ((iss.fields && iss.fields.issuelinks) || []).map((link) => {
              const inward = Boolean(link.inwardIssue);
              const direction = inward ? link.type && link.type.inward : link.type && link.type.outward;
              const target = inward ? link.inwardIssue : link.outwardIssue;
              return /задача проекта|project task/i.test(String(direction || '')) && target ? target.key : '';
            }).filter(Boolean)
          }))
          .filter((item) => !isCanceledStatus(item.status));
        if (!customQuery) {
          umbCatalog = loaded;
        } else {
          const map = new Map();
          loaded.forEach((item) => map.set(item.key, item));
          umbCatalog.forEach((item) => {
            if (!map.has(item.key) && !isCanceledStatus(item.status)) map.set(item.key, item);
          });
          umbCatalog = Array.from(map.values());
        }
      }
      if (!customQuery) umbCatalogReady = true;
    } catch (e) {}
  }

  function getBoardFieldsParam() {
    const fieldList = [
      'summary',
      'description',
      'labels',
      'customfield_20100',
      'issuetype',
      'status',
      'priority',
      'components',
      'assignee',
      'reporter',
      'creator',
      'created',
      'issuelinks',
      'parent',
      'sprint',
      'closedSprints',
      'epic'
    ];
    if (discoveredFields.sprint) fieldList.push(discoveredFields.sprint);
    if (discoveredFields.epicLink) fieldList.push(discoveredFields.epicLink);
    if (discoveredFields.epicName) fieldList.push(discoveredFields.epicName);
    if (discoveredFields.customer) fieldList.push(discoveredFields.customer);
    if (Array.isArray(discoveredCustomerFieldIds)) {
      discoveredCustomerFieldIds.forEach((cfId) => {
        if (cfId) fieldList.push(cfId);
      });
    }
    return encodeURIComponent(Array.from(new Set(fieldList)).join(','));
  }

  function extractCustomerOwnerFromIssueFields(f) {
    const candidates = Array.from(new Set([discoveredFields.customer, ...(discoveredCustomerFieldIds || [])].filter(Boolean)));
    for (const fId of candidates) {
      const rawCust = f && f[fId];
      if (!rawCust) continue;
      if (Array.isArray(rawCust) && rawCust.length > 0 && rawCust[0]) {
        const first = rawCust[0];
        const nm = first.displayName || first.value || first.name || first.fullName || (typeof first === 'string' ? first : '');
        const lg = first.name || first.key || '';
        if (nm && String(nm).trim()) {
          discoveredFields.customer = fId;
          return { name: String(nm).trim(), login: String(lg || '').trim() };
        }
      } else if (typeof rawCust === 'object') {
        const nm = rawCust.displayName || rawCust.value || rawCust.name || rawCust.fullName || '';
        const lg = rawCust.name || rawCust.key || '';
        if (nm && String(nm).trim()) {
          discoveredFields.customer = fId;
          return { name: String(nm).trim(), login: String(lg || '').trim() };
        }
      } else if (typeof rawCust === 'string' && rawCust.trim()) {
        discoveredFields.customer = fId;
        return { name: rawCust.trim(), login: '' };
      }
    }
    return { name: 'Не указан', login: '' };
  }

  async function normalizeAndEnrichJiraIssues(rawIssues) {
    const allEpicKeysToResolve = new Set();
    const linkedIssueKeys = new Set();
    const umbKeysSet = new Set(umbCatalog.map((u) => u.key));

    rawIssues.forEach((iss) => {
      const f = iss.fields || {};
      if (f.assignee && (f.assignee.name || f.assignee.key) && f.assignee.displayName && isRealHumanJiraUser(f.assignee)) {
        const uLogin = f.assignee.name || f.assignee.key;
        if (!assignableUsersList.some((u) => u.name === uLogin)) {
          assignableUsersList.push({ name: uLogin, displayName: f.assignee.displayName, email: f.assignee.emailAddress || '' });
        }
      }
      if (f.reporter && (f.reporter.name || f.reporter.key) && f.reporter.displayName && isRealHumanJiraUser(f.reporter)) {
        const rLogin = f.reporter.name || f.reporter.key;
        if (!assignableUsersList.some((u) => u.name === rLogin)) {
          assignableUsersList.push({ name: rLogin, displayName: f.reporter.displayName, email: f.reporter.emailAddress || '' });
        }
      }
      const parsedOwner = extractCustomerOwnerFromIssueFields(f);
      if (parsedOwner.name && parsedOwner.name !== 'Не указан' && parsedOwner.login && !parsedOwner.name.startsWith('$')) {
        if (!assignableUsersList.some((u) => u.name === parsedOwner.login)) {
          assignableUsersList.push({ name: parsedOwner.login, displayName: parsedOwner.name, email: '' });
        }
      }
      const epObj = f.epic;
      if (epObj && epObj.key) {
        if (!isBogusEpicTitle(epObj.summary, epObj.key)) {
          epicNameByKey[epObj.key] = String(epObj.summary).trim();
        } else if (!isBogusEpicTitle(epObj.name, epObj.key) && !epicNameByKey[epObj.key]) {
          epicNameByKey[epObj.key] = String(epObj.name).trim();
        }
        if (String(epObj.key).startsWith(CONFIG.projectKey + '-') && epicNameByKey[epObj.key]) {
          fcrmEpicNameByKey[epObj.key] = epicNameByKey[epObj.key];
        }
      }
      const rawEpicKey =
        (epObj && epObj.key) ||
        (discoveredFields.epicLink && typeof f[discoveredFields.epicLink] === 'string' ? f[discoveredFields.epicLink] : null) ||
        (f.parent && f.parent.key) ||
        null;
      if (rawEpicKey && typeof rawEpicKey === 'string') {
        allEpicKeysToResolve.add(rawEpicKey.trim());
      }
      if (isEpicIssueType(f.issuetype && f.issuetype.name)) {
        allEpicKeysToResolve.add(iss.key);
        cacheEpicMetadata([iss]);
      }
      if (Array.isArray(f.issuelinks)) {
        f.issuelinks.forEach((lnk) => {
          const target = lnk.outwardIssue || lnk.inwardIssue;
          if (target && target.key) {
            linkedIssueKeys.add(target.key);
          }
        });
      }
    });

    // Обогащение всех связанных задач их реальными Эпиками, Компонентами, Спринтами, Исполнителями, Авторами и Приоритетами из Jira
    const linkedDetailsByKey = {};
    if (linkedIssueKeys.size > 0) {
      const lnkKeysAll = Array.from(linkedIssueKeys);
      const lnkFields = [
        'summary',
        'status',
        'issuetype',
        'priority',
        'components',
        'labels',
        'sprint',
        'closedSprints',
        'epic',
        'parent',
        'assignee',
        'reporter',
        'creator',
        'created'
      ];
      if (discoveredFields.sprint) lnkFields.push(discoveredFields.sprint);
      if (discoveredFields.epicLink) lnkFields.push(discoveredFields.epicLink);
      if (discoveredFields.epicName) lnkFields.push(discoveredFields.epicName);
      if (discoveredFields.storyPoints) lnkFields.push(discoveredFields.storyPoints);

      function parseLinkedIssueFields(lIss) {
        const lf = (lIss && lIss.fields) || {};
        const realComp = resolveRealLinkedIssueComponent(lIss);
        const realSprint = resolveRealLinkedIssueSprint(lIss);
        const labelsArr = Array.isArray(lf.labels) ? lf.labels : [];
        const lEpObj = lf.epic;
        if (lEpObj && lEpObj.key) {
          if (!isBogusEpicTitle(lEpObj.summary, lEpObj.key)) {
            epicNameByKey[lEpObj.key] = String(lEpObj.summary).trim();
          } else if (!isBogusEpicTitle(lEpObj.name, lEpObj.key) && !epicNameByKey[lEpObj.key]) {
            epicNameByKey[lEpObj.key] = String(lEpObj.name).trim();
          }
        }
        const lEpicKey =
          (lEpObj && lEpObj.key) ||
          (discoveredFields.epicLink && typeof lf[discoveredFields.epicLink] === 'string' ? lf[discoveredFields.epicLink].trim() : '') ||
          (lf.parent && lf.parent.key) ||
          '';
        if (lEpicKey) {
          allEpicKeysToResolve.add(lEpicKey);
        }
        return {
          summary: lf.summary || lIss.key,
          status: readStatusName(lf.status, 'Открыто'),
          issueTypeName: (lf.issuetype && lf.issuetype.name) || 'Задача',
          priority: (lf.priority && lf.priority.name) || 'Medium',
          storyPoints: discoveredFields.storyPoints && lf[discoveredFields.storyPoints] != null ? lf[discoveredFields.storyPoints] : null,
          component: realComp,
          sprint: realSprint,
          epicKey: lEpicKey,
          epicName: (lEpicKey && epicNameByKey[lEpicKey]) || '',
          assigneeName: (lf.assignee && lf.assignee.displayName) || '—',
          authorName: (lf.reporter && lf.reporter.displayName) || (lf.creator && lf.creator.displayName) || '—',
          createdAt: lf.created ? formatDate(lf.created) : '—',
          createdTimestamp: lf.created ? new Date(lf.created).getTime() : 0,
          isUmbEpic: labelsArr.includes('fcrm_umb_epic') || umbKeysSet.has(lIss.key)
        };
      }

      const lnkChunks = [];
      for (let i = 0; i < lnkKeysAll.length; i += 50) {
        lnkChunks.push(lnkKeysAll.slice(i, i + 50));
      }
      for (let b = 0; b < lnkChunks.length; b += 4) {
        const batch = lnkChunks.slice(b, b + 4);
        await Promise.all(
          batch.map(async (chunk) => {
            try {
              const lnkRes = await fetch(
                '/rest/api/2/search?jql=' + encodeURIComponent('key in (' + chunk.join(',') + ')') + '&fields=' + lnkFields.join(',') + '&maxResults=100',
                { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } }
              );
              if (lnkRes.ok) {
                const lnkData = await lnkRes.json();
                if (Array.isArray(lnkData.issues)) {
                  lnkData.issues.forEach((lIss) => {
                    linkedDetailsByKey[lIss.key] = parseLinkedIssueFields(lIss);
                  });
                }
              }
            } catch (e) {}
          })
        );
      }

      if (rawIssues.length === 1) {
        const missingKeys = lnkKeysAll.filter((k) => !linkedDetailsByKey[k]);
        await Promise.all(
          missingKeys.slice(0, 15).map(async (mKey) => {
            try {
              const r = await fetch(
                '/rest/api/2/issue/' + encodeURIComponent(mKey) + '?fields=' + lnkFields.join(','),
                { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } }
              );
              if (r.ok) {
                const lIss = await r.json();
                linkedDetailsByKey[mKey] = parseLinkedIssueFields(lIss);
              }
            } catch (e) {}
          })
        );

        const adjProjects = new Set();
        lnkKeysAll.forEach((k) => {
          const p = String(k).split('-')[0];
          if (p && p.toUpperCase() !== String(CONFIG.projectKey).toUpperCase()) {
            adjProjects.add(p.toUpperCase());
          }
        });
        await Promise.all(Array.from(adjProjects).slice(0, 8).map((pk) => ensureProjectComponentsLoaded(pk)));
      }
    }

    // Подтягиваем названия всех эпиков (как основных задач FCRM, так и эпиков связанных задач!)
    if (allEpicKeysToResolve.size > 0) {
      const epKeysAll = Array.from(allEpicKeysToResolve);
      const epChunks = [];
      for (let i = 0; i < epKeysAll.length; i += 50) {
        epChunks.push(epKeysAll.slice(i, i + 50));
      }
      for (let b = 0; b < epChunks.length; b += 4) {
        const batch = epChunks.slice(b, b + 4);
        await Promise.all(
          batch.map(async (chunk) => {
            try {
              const epFields = ['summary', 'status', 'customfield_20100', 'labels'];
              if (discoveredFields.epicName) epFields.push(discoveredFields.epicName);
              const epRes = await fetch(
                '/rest/api/2/search?jql=' + encodeURIComponent('key in (' + chunk.join(',') + ')') + '&fields=' + epFields.join(',') + '&maxResults=100',
                { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } }
              );
              if (epRes.ok) {
                const epData = await epRes.json();
                if (Array.isArray(epData.issues)) {
                  cacheEpicMetadata(epData.issues);
                  epData.issues.forEach((epIss) => {
                    const ef = epIss.fields || {};
                    const summaryTitle = ef.summary ? String(ef.summary).trim() : '';
                    const customEpicName = discoveredFields.epicName && ef[discoveredFields.epicName] ? String(ef[discoveredFields.epicName]).trim() : '';
                    const finalTitle = !isBogusEpicTitle(summaryTitle, epIss.key)
                      ? summaryTitle
                      : !isBogusEpicTitle(customEpicName, epIss.key)
                      ? customEpicName
                      : '';
                    if (finalTitle) {
                      epicNameByKey[epIss.key] = finalTitle;
                      if (String(epIss.key).startsWith(CONFIG.projectKey + '-')) {
                        fcrmEpicNameByKey[epIss.key] = finalTitle;
                      }
                    }
                  });
                }
              }
            } catch (e) {}
          })
        );
      }
    }

    await loadTableObprojectMetadata();
    return rawIssues.map((iss) => {
      const f = iss.fields || {};
      const taskSprint = resolveIssueSprint(iss);
      if (taskSprint && taskSprint !== 'Бэклог FCRM') {
        boardOwnedSprintNames.add(taskSprint);
      }

      const epObj = f.epic;
      let epicKey =
        (epObj && epObj.key) ||
        (discoveredFields.epicLink && typeof f[discoveredFields.epicLink] === 'string' ? f[discoveredFields.epicLink].trim() : '') ||
        '';

      let resolvedEpicTitle = epicKey && epicNameByKey[epicKey] ? epicNameByKey[epicKey] : '';
      if (!resolvedEpicTitle && epObj) {
        if (!isBogusEpicTitle(epObj.summary, epicKey)) resolvedEpicTitle = String(epObj.summary).trim();
        else if (!isBogusEpicTitle(epObj.name, epicKey)) resolvedEpicTitle = String(epObj.name).trim();
      }
      if (epicKey && resolvedEpicTitle && String(epicKey).startsWith(CONFIG.projectKey + '-')) {
        fcrmEpicNameByKey[epicKey] = resolvedEpicTitle;
      }
      let epicName = resolvedEpicTitle || 'Без эпика';

      const compName =
        Array.isArray(f.components) && f.components.length
          ? f.components.map((c) => c && c.name).filter(Boolean).join(', ')
          : 'Без компонента';

      const parsedOwner = extractCustomerOwnerFromIssueFields(f);
      const custName = parsedOwner.name || 'Не указан';

      const rawLinks = Array.isArray(f.issuelinks) ? f.issuelinks : [];
      const ptLinks = [];
      const ipLinks = [];
      const otherLinks = [];

      rawLinks.forEach((lnk, idx) => {
        const isInward = Boolean(lnk.inwardIssue);
        const target = lnk.inwardIssue || lnk.outwardIssue;
        if (!target || !target.key) return;

        const enriched = linkedDetailsByKey[target.key];
        const activeDirDesc = String(
          (isInward ? (lnk.type && lnk.type.inward) : (lnk.type && lnk.type.outward)) || ''
        )
          .trim()
          .toLowerCase();

        const realLinkComp = enriched ? enriched.component : resolveRealLinkedIssueComponent(target);
        const realLinkSprint = enriched ? enriched.sprint : resolveRealLinkedIssueSprint(target);
        const lEpKey = (enriched && enriched.epicKey) || '';
        const lEpName = (lEpKey && epicNameByKey[lEpKey]) || (enriched && enriched.epicName) || '';

        const itemStatus = (enriched && enriched.status) || readStatusName(target.fields && target.fields.status, 'Открыто');
        const item = {
          id: lnk.id ? String(lnk.id) : 'lnk-' + iss.key + '-' + idx,
          jiraLinkId: lnk.id ? String(lnk.id) : null,
          key: target.key,
          summary: (enriched && enriched.summary) || (target.fields && target.fields.summary) || target.key,
          status: itemStatus,
          issueTypeName: (enriched && enriched.issueTypeName) || (target.fields && target.fields.issuetype && target.fields.issuetype.name) || 'Задача',
          priority: (enriched && enriched.priority) || 'Medium',
          storyPoints: enriched?.storyPoints ?? null,
          component: realLinkComp,
          sprint: realLinkSprint,
          epicKey: lEpKey,
          epicName: lEpName,
          assigneeName: (enriched && enriched.assigneeName) || '—',
          authorName: (enriched && enriched.authorName) || '—',
          createdAt: (enriched && enriched.createdAt) || '—',
          linkType: String((lnk.type && lnk.type.name) || ''),
          linkDirection: activeDirDesc
        };

        if (/задача проекта|project task/i.test(activeDirDesc)) {
          if (!isCanceledStatus(itemStatus)) ptLinks.push(item);
        } else if (/в проекте|in project/i.test(activeDirDesc)) {
          if (!isCanceledStatus(itemStatus)) ipLinks.push(item);
        } else {
          otherLinks.push(item);
        }
      });

      const rawDesc = typeof f.description === 'string' ? f.description : '';
      const issueTypeName = (f.issuetype && f.issuetype.name) || 'Задача';
      const issueTypeId = (f.issuetype && f.issuetype.id) || '';
      if (issueTypeName && issueTypeId) {
        issueTypeIdByName[issueTypeName] = String(issueTypeId);
      }

      return {
        key: iss.key,
        summary: f.summary || iss.key,
        description: rawDesc,
        labels: Array.isArray(f.labels) ? f.labels : [],
        issueTypeName: issueTypeName,
        issueTypeId: issueTypeId,
        epicKey: epicKey,
        epicName: epicName,
        component: compName,
        components: Array.isArray(f.components) ? f.components.map((c) => c && c.name).filter(Boolean) : [],
        assignee: {
          name: (f.assignee && f.assignee.displayName) || 'Не назначен',
          login: (f.assignee && (f.assignee.name || f.assignee.key)) || '',
          role: (f.assignee && f.assignee.emailAddress) || 'Ozon Банк'
        },
        author: {
          name: (f.reporter && f.reporter.displayName) || (f.creator && f.creator.displayName) || 'Неизвестен',
          login: (f.reporter && (f.reporter.name || f.reporter.key)) || ''
        },
        customer: {
          name: custName,
          login: parsedOwner.login || '',
          department: 'FCRM'
        },
        createdAt: formatDate(f.created),
        createdTimestamp: f.created ? new Date(f.created).getTime() : 0,
        sprint: taskSprint,
        status: readStatusName(f.status, 'Открыто'),
        priority: (f.priority && f.priority.name) || 'Medium',
        projectTaskLinks: ptLinks,
        inProjectLinks: ipLinks,
        otherLinks: otherLinks
      };
    }).filter((t) => !isCanceledStatus(t.status));
  }

  /**
   * Универсальная пагинация (дозапросы по startAt) для Agile endpoints (/sprint/{id}/issue, /backlog, /board/{id}/issue)
   */
  async function fetchPaginatedIssues(url, limit, onProgress) {
    const issues = [];
    const separator = url.includes('?') ? '&' : '?';
    async function page(offset, size) {
      const response = await fetch(url + separator + 'startAt=' + offset + '&maxResults=' + size, {
        credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }
      });
      if (!response.ok) throw new Error('Jira HTTP ' + response.status);
      const data = await response.json();
      if (!Array.isArray(data.issues)) throw new Error('Некорректная страница задач');
      return data;
    }
    try {
      const first = await page(0, Math.min(100, limit));
      const total = Math.min(first.total ?? first.issues.length, limit);
      const step = first.issues.length;
      issues.push(...first.issues.slice(0, total));
      onProgress?.(issues.length, total);
      if (!step && total) return { ok: false, issues, total };
      for (let start = step; start < total; start += 3 * step) {
        const pages = [];
        for (let offset = start; offset < total && pages.length < 3; offset += step) {
          pages.push(page(offset, Math.min(step, total - offset)));
        }
        for (const data of await Promise.all(pages)) issues.push(...data.issues.slice(0, total - issues.length));
        onProgress?.(issues.length, total);
      }
      return { ok: issues.length === total, issues, total };
    } catch {
      return { ok: false, issues, total: issues.length };
    }
  }

  function fetchPaginatedAgileIssues(url, maxTotal, onProgress) {
    return fetchPaginatedIssues(url, maxTotal || 2500, onProgress);
  }

  function fetchPaginatedJqlIssues(jql, fields, maxTotal, onProgress) {
    const url = '/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&fields=' + fields;
    return fetchPaginatedIssues(url, maxTotal || 3000, onProgress);
  }

  async function reloadSingleSprintFromJira(sprintName) {
    const requestRevision = taskEditRevision;
    loadingSprintsMap[sprintName] = 5;
    renderStructure();

    try {
      const fieldsParam = getBoardFieldsParam();
      const spId = sprintIdByName[sprintName];
      let sprintRawIssues = [];

      if (spId) {
        const agRes = await fetchPaginatedAgileIssues(
          '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/sprint/' + encodeURIComponent(spId) + '/issue?jql=' + encodeURIComponent('project = ' + CONFIG.projectKey) + '&fields=' + fieldsParam,
          1000,
          (loaded, total) => {
            loadingSprintsMap[sprintName] = total ? Math.min(90, Math.max(8, Math.round((loaded / total) * 90))) : 20;
            renderStructure();
          }
        );
        if (agRes.ok && agRes.issues.length > 0) {
          sprintRawIssues = agRes.issues.filter((iss) => iss && iss.key && iss.key.startsWith(CONFIG.projectKey + '-'));
        } else {
          // Фоллбэк через JQL по ID спринта (особенно полезно для закрытых спринтов)
          const jqlRes = await fetchPaginatedJqlIssues(
            'project = ' + CONFIG.projectKey + ' AND Sprint = ' + spId + ' ORDER BY updated DESC',
            fieldsParam,
            1000,
            (loaded, total) => { loadingSprintsMap[sprintName] = total ? Math.min(90, Math.max(8, Math.round((loaded / total) * 90))) : 20; renderStructure(); }
          );
          if (jqlRes.ok && jqlRes.issues.length > 0) {
            sprintRawIssues = jqlRes.issues.filter((iss) => iss && iss.key && iss.key.startsWith(CONFIG.projectKey + '-'));
          }
        }
        sprintRawIssues.forEach((iss) => {
          issueSprintOverrideMap[iss.key] = sprintName;
        });
      } else if (sprintName.includes('Бэклог')) {
        let agBacklog = await fetchPaginatedAgileIssues(
          '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/backlog?jql=' + encodeURIComponent('project = ' + CONFIG.projectKey + ' ORDER BY updated DESC') + '&fields=' + fieldsParam,
          1500,
          (loaded, total) => { loadingSprintsMap[sprintName] = total ? Math.min(90, Math.max(8, Math.round((loaded / total) * 90))) : 20; renderStructure(); }
        );
        if (!agBacklog.ok || agBacklog.issues.length === 0) {
          agBacklog = await fetchPaginatedJqlIssues(
            'project = ' + CONFIG.projectKey + ' AND (Sprint is EMPTY OR Sprint not in (openSprints(), futureSprints(), closedSprints())) ORDER BY updated DESC',
            fieldsParam,
            1500,
            (loaded, total) => { loadingSprintsMap[sprintName] = total ? Math.min(90, Math.max(8, Math.round((loaded / total) * 90))) : 20; renderStructure(); }
          );
        }
        if (agBacklog.ok) {
          sprintRawIssues = agBacklog.issues.filter((iss) => iss && iss.key && iss.key.startsWith(CONFIG.projectKey + '-'));
        }
      }

      if (sprintRawIssues.length > 0) {
        const refreshedTasks = applyLocalOverridesToTasks(await normalizeAndEnrichJiraIssues(sprintRawIssues), requestRevision);
        const refreshedMap = {};
        refreshedTasks.forEach((t) => {
          refreshedMap[t.key] = t;
        });
        tasks = tasks.map((t) => refreshedMap[t.key] || t);
        refreshedTasks.forEach((rt) => {
          if (!tasks.some((t) => t.key === rt.key)) {
            tasks.push(rt);
          }
        });
      }
    } catch (e) {}

    loadingSprintsMap[sprintName] = false;
    renderStructure();
  }

  /**
   * Перезапрос задач конкретного компонента внутри спринта при его раскрытии в списке
   */
  async function reloadSingleComponentFromJira(sprintName, compName) {
    const requestRevision = taskEditRevision;
    if (!sprintName || !compName) return;
    const compKey = sprintName + '::' + compName;
    loadingComponentsMap[compKey] = true;
    renderStructure();

    try {
      const fieldsParam = getBoardFieldsParam();
      const spId = sprintIdByName[sprintName];
      const safeComp = String(compName).replace(/"/g, '\"');
      const compClause =
        compName === 'Без компонента'
          ? 'component is EMPTY'
          : 'component = "' + safeComp + '"';

      let sprintClause = '';
      if (spId) {
        sprintClause = 'Sprint = ' + spId;
      } else if (sprintName.toLowerCase().includes('бэклог') || sprintName.toLowerCase().includes('backlog')) {
        sprintClause = '(Sprint is EMPTY OR Sprint not in (openSprints(), futureSprints(), closedSprints()))';
      } else {
        sprintClause = 'Sprint = "' + String(sprintName).replace(/"/g, '\"') + '"';
      }

      const jql = 'project = ' + CONFIG.projectKey + ' AND ' + sprintClause + ' AND ' + compClause + ' ORDER BY updated DESC';
      const jqlRes = await fetchPaginatedJqlIssues(jql, fieldsParam, 600);

      if (jqlRes.ok && jqlRes.issues.length > 0) {
        const compRawIssues = jqlRes.issues.filter((iss) => iss && iss.key && iss.key.startsWith(CONFIG.projectKey + '-'));
        if (spId) {
          compRawIssues.forEach((iss) => {
            issueSprintOverrideMap[iss.key] = sprintName;
          });
        }
        if (compRawIssues.length > 0) {
          const refreshedTasks = applyLocalOverridesToTasks(await normalizeAndEnrichJiraIssues(compRawIssues), requestRevision);
          const refreshedMap = {};
          refreshedTasks.forEach((t) => {
            refreshedMap[t.key] = t;
          });
          tasks = tasks.map((t) => refreshedMap[t.key] || t);
          refreshedTasks.forEach((rt) => {
            if (!tasks.some((t) => t.key === rt.key)) {
              tasks.push(rt);
            }
          });
        }
      }
    } catch (e) {}

    loadingComponentsMap[compKey] = false;
    renderStructure();
  }

  /**
   * Последовательная (поблочная) загрузка деталей задачи в правом сайдбаре:
   * 1. Базовые поля и описание задачи (мгновенное обновление блока «Описание задачи» и шапки)
   * 2. Доступные переходы статуса и справочники проекта (обновление блока «Параметры задачи»)
   * 3. Обогащение связанных задач «Задача проекта» и «В проекте» (обновление аккордеонов связей)
   * 4. Компоненты и спринты смежных проектов (OB / OBFRONT / FTD) для выпадающих списков связей
   */
  let sidebarLoadGeneration = 0;
  async function reloadSingleTaskFromJira(taskKey, forceFromJira, showFullSkeleton) {
    const requestRevision = taskEditRevision;
    if (!taskKey) return;
    const generation = ++sidebarLoadGeneration;
    const isCurrentLoad = () => generation === sidebarLoadGeneration && sidebarBlockLoading.taskKey === taskKey;
    const hasExistingTask = tasks.some((t) => t.key === taskKey);
    loadingSidebarTaskKey = showFullSkeleton || !hasExistingTask ? taskKey : null;
    sidebarBlockLoading = {
      taskKey: taskKey,
      desc: true,
      params: true,
      links: true,
      ipMeta: true
    };
    assigneeSearchQuery = '';
    customerSearchQuery = '';
    const taskRequest = fetch('/rest/api/2/issue/' + encodeURIComponent(taskKey) + '?fields=' + getBoardFieldsParam(), {
      credentials:'same-origin', cache:'no-store',
      headers:{Accept:'application/json', ...(forceFromJira ? {'Cache-Control':'no-cache'} : {})}
    });
    const transitionsRequest = fetch('/rest/api/2/issue/' + encodeURIComponent(taskKey) + '/transitions', {credentials:'same-origin',headers:{Accept:'application/json'}}).catch(() => null);
    const remoteLinksRequest = loadRemoteIssueLinks(taskKey).catch(() => []);
    const componentsRequest = ensureProjectComponentsLoaded(getIssueProjectKey(taskKey)).catch(() => {});
    renderStructure();
    let refreshErrorText = '';

    try {
      // The detail refresh explicitly requests OBPROJECT from Jira.
      // ЭТАП 1: Загружаем саму задачу (описание + основные поля) и сразу рендерим блок «Описание задачи»
      let rawIssue = null;
      try {
        const issRes = await taskRequest;
        if (issRes.ok) {
          rawIssue = await issRes.json();
          if (rawIssue && rawIssue.key) {
            if (!isCurrentLoad()) return;
            void syncStrategyLinks(rawIssue);
            syncStrategyIssue(rawIssue);
            if (forceFromJira) {
              clearTaskOverride(taskKey, requestRevision);
              delete issueSprintOverrideMap[taskKey];
            }
            const f = rawIssue.fields || {};
            const parsedOwner = extractCustomerOwnerFromIssueFields(f);
            const compName =
              Array.isArray(f.components) && f.components.length
                ? f.components.map((c) => c && c.name).filter(Boolean).join(', ')
                : 'Без компонента';
            const quickSprint = resolveIssueSprint(rawIssue);

            const refreshedTaskList = tasks.map((t) => {
                if (t.key !== taskKey) return t;
                return Object.assign({}, t, {
                  summary: Object.prototype.hasOwnProperty.call(f, 'summary') ? String(f.summary || '') : t.summary,
                  description: Object.prototype.hasOwnProperty.call(f, 'description') ? (typeof f.description === 'string' ? f.description : '') : t.description || '',
                  status: readStatusName(f.status, t.status),
                  issueTypeName: (f.issuetype && f.issuetype.name) || t.issueTypeName || 'Задача',
                  issueTypeId: (f.issuetype && f.issuetype.id) || t.issueTypeId || '',
                  priority: (f.priority && f.priority.name) || t.priority,
                  labels: Array.isArray(f.labels) ? f.labels : [],
                  component: compName,
                  components: Array.isArray(f.components) ? f.components.map((c) => c && c.name).filter(Boolean) : [],
                  sprint: quickSprint || (forceFromJira ? 'Бэклог FCRM' : t.sprint),
                  assignee: f.assignee
                    ? {
                        name: f.assignee.displayName || f.assignee.name || 'Не назначен',
                        login: f.assignee.name || f.assignee.key || ''
                      }
                    : { name: 'Не назначен', login: '' },
                  customer:
                    parsedOwner && parsedOwner.name && parsedOwner.name !== 'Не указан'
                      ? parsedOwner
                      : { name: 'Не указан', login: '', department: 'FCRM' }
                });
              });
            tasks = applyLocalOverridesToTasks(refreshedTaskList, requestRevision, taskKey).filter((t) => !isCanceledStatus(t.status));
          }
        } else {
          refreshErrorText = 'Не удалось обновить ' + taskKey + ' из Jira (HTTP ' + issRes.status + ')';
        }
      } catch (e) {
        refreshErrorText = 'Не удалось обновить ' + taskKey + ' из Jira';
      }

      if (!isCurrentLoad()) return;
      loadingSidebarTaskKey = null;
      sidebarBlockLoading.desc = false;
      renderStructure();

      // Связи и сведения об эпике не зависят от загрузки переходов статуса.
      const enrichedRequest = rawIssue?.key ? normalizeAndEnrichJiraIssues([rawIssue]).catch(() => []) : Promise.resolve([]);
      const epicDetailsRequest = rawIssue?.key ? refreshTaskEpicDetails(taskKey, rawIssue).catch(() => {}) : Promise.resolve();

      // ЭТАП 2: Загружаем переходы воркфлоу (transitions) и компоненты проекта для блока «Параметры задачи»
      const paramsRequest = (async () => { try {
        const [trRes] = await Promise.all([
          transitionsRequest,
          componentsRequest
        ]);
        if (trRes && trRes.ok) {
          const trData = await trRes.json();
          if (Array.isArray(trData.transitions)) {
            issueTransitionsByKey[taskKey] = trData.transitions;
          }
        }
      } catch (e) {}
      if (isCurrentLoad()) { sidebarBlockLoading.params = false; renderStructure(); }
      })();

      // ЭТАП 3: Полное обогащение связей «Задача проекта» и «В проекте» (статусы, приоритеты, эпики, спринты связей)
      let enrichedTask = null;
      if (rawIssue && rawIssue.key) {
        try {
          const enrichedArr = applyLocalOverridesToTasks(await enrichedRequest, requestRevision, taskKey);
          if (!isCurrentLoad()) return;
          if (enrichedArr[0]) {
            enrichedTask = enrichedArr[0];
            const hasTask = tasks.some((t) => t.key === taskKey);
            tasks = hasTask ? tasks.map((t) => (t.key === taskKey ? Object.assign({}, t, {projectTaskLinks:enrichedTask.projectTaskLinks,inProjectLinks:enrichedTask.inProjectLinks,otherLinks:enrichedTask.otherLinks}) : t)) : [...tasks, enrichedTask];
          }
        } catch (e) {}
      }

      if (enrichedTask) {
        const [, remoteLinks] = await Promise.all([epicDetailsRequest, remoteLinksRequest]);
        if (!isCurrentLoad()) return;
        tasks = tasks.map((t) => t.key === taskKey ? Object.assign({}, t, {otherLinks:[...(enrichedTask.otherLinks || []), ...remoteLinks]}) : t);
      }

      if (!isCurrentLoad()) return;
      sidebarBlockLoading.links = false;
      renderStructure();

      // ЭТАП 4: Последовательная догрузка справочников компонентов и спринтов для связанных задач «В проекте»
      const ipLinks = (enrichedTask && enrichedTask.inProjectLinks) || [];
      await Promise.all(ipLinks.filter((link) => /^OBFRONT-/i.test(String(link.key || ''))).map((link) => loadFrontDesignRelation(link.key)));
      await paramsRequest;
    } catch (e) {
      if (forceFromJira && !refreshErrorText) refreshErrorText = 'Не удалось полностью обновить ' + taskKey + ' из Jira';
    }

    if (!isCurrentLoad()) return;
    if (sidebarBlockLoading.taskKey === taskKey) {
      sidebarBlockLoading = { taskKey: null, desc: false, params: false, links: false, ipMeta: false };
    }
    if (loadingSidebarTaskKey === taskKey) {
      loadingSidebarTaskKey = null;
    }
    if (forceFromJira) showSaveToast(refreshErrorText || ('✓ Данные ' + taskKey + ' обновлены из Jira'));
    renderStructure();
  }

  let productFiltersPromise = null;
  let productFiltersReady = false;
  async function prepareProductFilters() {
    if (productFiltersReady || productFiltersPromise) return;
    productFiltersPromise = Promise.allSettled([
      fetchProjectComponents(String(CONFIG.projectKey).toUpperCase()),
      fetch('/rest/api/2/project/' + encodeURIComponent(CONFIG.projectKey) + '/statuses', {credentials:'same-origin',headers:{Accept:'application/json'}}).then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
    ]).then(results => {
      if (results[0].status === 'fulfilled') projectComponentsList = results[0].value.map(item => item.name).filter(Boolean);
      if (results[1].status === 'fulfilled' && Array.isArray(results[1].value)) {
        const types = results[1].value;
        projectIssueTypesList = types.filter(item => item?.name).map(item => ({id:String(item.id || ''),name:item.name,subtask:Boolean(item.subtask)}));
        projectStatusesList = Array.from(new Set(types.flatMap(item => (item.statuses || []).map(status => status.name).filter(Boolean))));
      }
      productFiltersReady = results.every(result => result.status === 'fulfilled');
      if (!productFiltersReady && !productDashboardLoaded) statusMessage = 'Не удалось загрузить часть фильтров. Повторите открытие страницы.';
      if (activeDashboardView === 'product') renderStructure();
    }).finally(() => { productFiltersPromise = null; });
    return productFiltersPromise;
  }

  async function loadBoardIssuesFromJira() {
    const requestRevision = taskEditRevision;
    if (isInitialBoardLoading) return;
    isInitialBoardLoading = true;
    const requestedSprintMode = filterSprintState;
    const sprintJqlClauses = { ACTIVE:'sprint in openSprints()', FUTURE:'sprint in futureSprints()', BACKLOG:'sprint is EMPTY', CLOSED:'sprint in closedSprints()', open_future:'(sprint in openSprints() OR sprint in futureSprints())', open_future_backlog:'(sprint in openSprints() OR sprint in futureSprints() OR sprint is EMPTY)', all:'' };
    const sprintJql = sprintJqlClauses[requestedSprintMode] ?? sprintJqlClauses.open_future_backlog;
    const issueJql = 'project = ' + CONFIG.projectKey + (sprintJql ? ' AND ' + sprintJql : '') + ' ORDER BY updated DESC';
    initialLoadProgress = 4;
    initialLoadStage = 'Подключаемся к Jira…';
    renderStructure();

    try {
      await discoverJiraFieldsAndComponents();
      initialLoadProgress = 15;
      initialLoadStage = 'Загружаю список спринтов…';
      renderStructure();
      await Promise.all([loadBoardSprintsAndEpics(), loadUmbEpicTasksFromJira()]);
      initialLoadProgress = 32;
      initialLoadStage = 'Получаю задачи выбранных спринтов…';
      renderStructure();

      const fieldsParam = getBoardFieldsParam();
      let rawIssues = [];
      const issuePositions = new Map();

      const addUniqueIssues = (arr, preferNew) => {
        if (!Array.isArray(arr)) return;
        arr.forEach((iss) => {
          if (!iss || !iss.key || !String(iss.key).startsWith(CONFIG.projectKey + '-')) return;
          if (!issuePositions.has(iss.key)) {
            issuePositions.set(iss.key, rawIssues.length);
            rawIssues.push(iss);
          } else if (preferNew) {
            rawIssues[issuePositions.get(iss.key)] = iss;
          }
        });
      };

      // 1. Запрашиваем задачи для родных активных и будущих спринтов доски 9349 с дозапросами (пагинацией)
      const allowedSprintStates = {ACTIVE:['ACTIVE'],FUTURE:['FUTURE'],BACKLOG:[],CLOSED:['CLOSED'],open_future:['ACTIVE','FUTURE'],open_future_backlog:['ACTIVE','FUTURE'],all:['ACTIVE','FUTURE','CLOSED']};
      const allowedStates = allowedSprintStates[requestedSprintMode] || allowedSprintStates.open_future_backlog;
      const activeAndFutureSprintIds = Array.from(boardOwnedSprintIds).filter((id) => allowedStates.includes(sprintStateByName[sprintNameById[id]]));
      await Promise.all(
        activeAndFutureSprintIds.slice(0, 20).map(async (spId) => {
          const spRes = await fetchPaginatedAgileIssues(
            '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/sprint/' + spId + '/issue?jql=' + encodeURIComponent('project = ' + CONFIG.projectKey) + '&fields=' + fieldsParam,
            1000,
            (loaded, total) => {
              if (total > 0) {
                initialLoadProgress = Math.max(initialLoadProgress, 32 + Math.round((loaded / total) * 20));
                initialLoadStage = 'Получаю задачи спринтов: ' + loaded + ' из ' + total;
                renderStructure();
              }
            }
          );
          if (spRes.ok) {
            addUniqueIssues(spRes.issues, false);
          }
        })
      );

      initialLoadProgress = Math.max(initialLoadProgress, 54);
      initialLoadStage = 'Загружаю задачи FCRM…';
      renderStructure();

      // При первом открытии запрашиваем только актуальные спринты и бэклог;
      // прошедшие спринты загружаются при выборе соответствующего фильтра.
      const jqlAllRes = await fetchPaginatedJqlIssues(
        issueJql,
        fieldsParam,
        3000,
        (loaded, totalCount) => {
          initialLoadProgress = totalCount ? Math.min(90, Math.max(initialLoadProgress, 54 + Math.round((loaded / totalCount) * 36))) : Math.max(initialLoadProgress, 60);
          initialLoadStage = 'Загружаю задачи FCRM: ' + loaded + ' из ' + (totalCount || loaded);
          statusMessage = initialLoadStage;
          renderStructure();
        }
      );

      if (jqlAllRes.ok) {
        addUniqueIssues(jqlAllRes.issues, true);
      } else {
        // Резервный вариант через Agile Board API с пагинацией
        let boardPaginated = await fetchPaginatedAgileIssues(
          '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/issue?jql=' + encodeURIComponent(issueJql) + '&fields=' + fieldsParam,
          2500,
          (loaded, total) => {
            initialLoadProgress = total ? Math.min(90, Math.max(initialLoadProgress, 54 + Math.round((loaded / total) * 36))) : initialLoadProgress;
            initialLoadStage = 'Загружаю задачи FCRM: ' + loaded + ' из ' + (total || loaded);
            renderStructure();
          }
        );
        if ((!boardPaginated.ok || boardPaginated.issues.length === 0) && (requestedSprintMode === 'BACKLOG' || requestedSprintMode === 'open_future_backlog' || requestedSprintMode === 'all')) {
          boardPaginated = await fetchPaginatedAgileIssues(
            '/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/backlog?jql=' + encodeURIComponent('project = ' + CONFIG.projectKey + ' ORDER BY updated DESC') + '&fields=' + fieldsParam,
            2500,
            (loaded, total) => {
              initialLoadProgress = total ? Math.min(90, Math.max(initialLoadProgress, 54 + Math.round((loaded / total) * 36))) : initialLoadProgress;
              initialLoadStage = 'Загружаю задачи FCRM: ' + loaded + ' из ' + (total || loaded);
              renderStructure();
            }
          );
        }
        if (boardPaginated.ok) {
          addUniqueIssues(boardPaginated.issues, true);
        }
      }

      if (requestedSprintMode === 'BACKLOG' || requestedSprintMode === 'open_future_backlog') {
        const backlogRes = await fetchPaginatedAgileIssues('/rest/agile/1.0/board/' + CONFIG.rapidViewId + '/backlog?jql=' + encodeURIComponent('project = ' + CONFIG.projectKey) + '&fields=' + fieldsParam, 2500);
        if (backlogRes.ok) addUniqueIssues(backlogRes.issues, false);
      }
      allSprintIssuesLoaded = requestedSprintMode === 'all';
      loadedSprintMode = requestedSprintMode;
      if (rawIssues.length === 0) {
        initialLoadProgress = 100;
        initialLoadStage = 'Загрузка завершена';
        isInitialBoardLoading = false;
        tasks = []; productDashboardLoaded = true;
        statusMessage = 'По выбранным условиям задачи не найдены';
        renderStructure();
        return;
      }

      initialLoadProgress = 94;
      initialLoadStage = 'Обрабатываю данные задач…';
      renderStructure();
      tasks = applyLocalOverridesToTasks(await normalizeAndEnrichJiraIssues(rawIssues), requestRevision);
      productDashboardLoaded = true;
      initialLoadProgress = 100;
      initialLoadStage = 'Загрузка завершена';
      isInitialBoardLoading = false;
      statusMessage = 'Спринт → Компонент (' + tasks.length + ' задач FCRM)';
      renderStructure();
    } catch (e) {
      initialLoadProgress = 100;
      initialLoadStage = 'Не удалось загрузить задачи FCRM';
      isInitialBoardLoading = false;
      statusMessage = 'Не удалось загрузить задачи FCRM. Повторите попытку.';
      renderStructure();
    }
  }

  function getSortedSprintNames(groupsObj) {
    const getTier = (spName) => {
      if (!spName) return 5;
      if (spName.includes('Бэклог') || spName.toLowerCase().includes('backlog')) return 4;
      const st = getSprintStateCode(spName);
      if (st === 'ACTIVE') return 1;
      if (st === 'FUTURE') return 2;
      if (st === 'CLOSED') return 3;
      return 2;
    };

    return Object.keys(groupsObj).sort((a, b) => {
      const ta = getTier(a);
      const tb = getTier(b);
      if (ta !== tb) return ta - tb;

      // Для прошедших (закрытых) спринтов сортируем от самых свежих к более старым по ID спринта или дате/номеру
      if (ta === 3) {
        const idA = Number(sprintIdByName[a]) || 0;
        const idB = Number(sprintIdByName[b]) || 0;
        if (idA !== idB && idA > 0 && idB > 0) return idB - idA;
        return b.localeCompare(a, 'ru', { numeric: true });
      }

      const wa = sprintOrderWeight[a] || 500;
      const wb = sprintOrderWeight[b] || 500;
      if (wa !== wb) return wa - wb;
      return a.localeCompare(b, 'ru', { numeric: true });
    });
  }

  function getAllComponentOptions() {
    if (projectComponentsList.length > 0) {
      return Array.from(new Set([...projectComponentsList, 'Без компонента']));
    }
    if (!productDashboardLoaded) return ['Без компонента'];
    const fcrmOnly = (productDashboardLoaded ? tasks : [])
      .filter((t) => t.key && t.key.startsWith(CONFIG.projectKey + '-'))
      .flatMap((t) => Array.isArray(t.components) && t.components.length ? t.components : [t.component])
      .filter(Boolean);
    return Array.from(
      new Set([
        ...fcrmOnly,
        'CRM: СЭД (Развитие)',
        'CRM: Поддержка (Развитие)',
        'CRM: Поддержка (Продукт)',
        'Роли и доступы',
        'Без компонента'
      ])
    );
  }

  /**
   * Возвращает список спринтов нашей доски FCRM (#9349), ВКЛЮЧАЯ Активные, Будущие И Прошедшие (Закрытые) спринты (для отображения групп на доске).
   */
  function getAllSprintOptions() {
    const ownedSprints = Array.from(boardOwnedSprintNames).filter(Boolean);
    const closedOwned = Array.from(closedSprintNames).filter((name) => name && isNativeFcrmBoardSprintName(name, null));
    const fcrmTaskSprints = tasks
      .filter((t) => t.key && t.key.startsWith(CONFIG.projectKey + '-'))
      .map((t) => t.sprint)
      .filter(Boolean);

    const set = new Set([...ownedSprints, ...closedOwned, ...fcrmTaskSprints, 'Бэклог FCRM']);
    const rawList = Array.from(set).filter((s) => s && s !== '9223372036854775807' && !/^\d+$/.test(s));
    const dummyGroups = {};
    rawList.forEach((s) => {
      dummyGroups[s] = true;
    });
    return getSortedSprintNames(dummyGroups);
  }

  /**
   * Проверяет, доступен ли спринт для выбора при изменении спринта задачи (ТОЛЬКО Активные, Будущие и Бэклог / Не в спринте).
   */
  function isEditableSprintOption(sprintName) {
    if (!sprintName) return false;
    const clean = String(sprintName).trim();
    if (!clean) return false;
    const code = getSprintStateCode(clean);
    return code === 'ACTIVE' || code === 'FUTURE' || code === 'BACKLOG';
  }

  /**
   * Возвращает ТОЛЬКО Активные и Будущие спринты (+ Бэклог FCRM) для всех селекторов смены спринта.
   */
  function getEditableSprintOptions() {
    return getAllSprintOptions().filter((sp) => isEditableSprintOption(sp));
  }

  function buildSprintSelectOptionsHtml(editableList, currentSprintVal, optionPrefix) {
    const pref = optionPrefix || '';
    const cur = (currentSprintVal && String(currentSprintVal).trim()) || '';
    const filtered = (Array.isArray(editableList) ? editableList : []).filter((sp) => isEditableSprintOption(sp));
    let html = '';
    if (cur && !filtered.includes(cur)) {
      html += `<option value="${escapeHtml(cur)}" selected disabled hidden>${escapeHtml(pref + formatSprintWithStateText(cur))}</option>`;
    }
    html += filtered
      .map((sp) => `<option value="${escapeHtml(sp)}" ${sp === cur ? 'selected' : ''}>${escapeHtml(pref + formatSprintWithStateText(sp))}</option>`)
      .join('');
    return html;
  }

  function getStatusOptionsForTask(task) {
    // 1. Если для конкретной задачи уже загружены доступные переходы (transitions) её схемы воркфлоу — показываем ТОЛЬКО текущий статус + переходы из схемы
    const transitions = issueTransitionsByKey[task.key] || [];
    if (transitions.length > 0) {
      const fromTaskTransitions = transitions
        .map((tr) => (tr.to && tr.to.name) || tr.name)
        .filter(Boolean);
      return Array.from(new Set([task.status, ...fromTaskTransitions])).filter(Boolean);
    }

    // 2. Иначе проверяем схему статусов конкретного типа задачи (issuetype) из /rest/api/2/project/FCRM/statuses
    const schemeForType =
      (task.issueTypeName && statusesByIssueTypeMap[task.issueTypeName]) ||
      (task.issueTypeId && statusesByIssueTypeMap[task.issueTypeId]) ||
      null;
    if (Array.isArray(schemeForType) && schemeForType.length > 0) {
      return Array.from(new Set([task.status, ...schemeForType])).filter(Boolean);
    }

    // 3. Базовый фоллбэк схемы FCRM (без отменённых Canceled и без чужих технических статусов)
    const fallbackScheme = ['Backlog', 'Ready for Planning', 'OnAnalysis', 'Waiting', 'OnDev', 'product/design review', 'User Testing', 'Готово'];
    return Array.from(new Set([task.status, ...fallbackScheme])).filter((st) => st && !isCanceledStatus(st));
  }

  function getProjectIssueTypeOptions(task) {
    const fromProjectApi = projectIssueTypesList.map((it) => it && it.name).filter(Boolean);
    const fromBoardTasks = tasks
      .filter((t) => t.key && t.key.startsWith(CONFIG.projectKey + '-'))
      .map((t) => t.issueTypeName)
      .filter(Boolean);
    const set = new Set([
      (task && task.issueTypeName) || 'Задача',
      ...fromProjectApi,
      ...fromBoardTasks,
      'Задача',
      'История',
      'Эпик',
      'Ошибка',
      'Аналитика'
    ]);
    return Array.from(set).filter(Boolean);
  }

  function getPriorityOptionsForTask(task) {
    const fromBoard = tasks.map((t) => t.priority).filter(Boolean);
    const set = new Set([
      task.priority,
      ...projectPrioritiesList,
      ...fromBoard,
      'Blocker',
      'Critical',
      'Major',
      'High',
      'Medium',
      'Minor',
      'Low',
      'Стандартный',
      'Критический',
      'Высокий',
      'Средний',
      'Низкий'
    ]);
    return Array.from(set).filter(Boolean);
  }

  function getAllAssigneeOptions() {
    const fromApi = assignableUsersList.map((u) => u.displayName);
    const fromTasks = tasks.map((t) => t.assignee && t.assignee.name).filter(Boolean);
    const fromAuthors = tasks.map((t) => t.author && t.author.name).filter(Boolean);
    return Array.from(new Set(['Не назначен', ...fromTasks, ...fromAuthors, ...fromApi]));
  }

  /**
   * Возвращает справочник эпиков СТРОГО проекта FCRM для выпадающих списков (Input-Select).
   */
  function getAllEpicOptions() {
    const map = {};
    Object.keys(epicNameByKey).forEach((k) => {
      if (k && k.startsWith(CONFIG.projectKey + '-') && !isBogusEpicTitle(epicNameByKey[k], k)) {
        map[k] = epicNameByKey[k];
      }
    });
    (productDashboardLoaded ? tasks : []).forEach((t) => {
      if (t.epicKey && t.epicKey.startsWith(CONFIG.projectKey + '-') && !isBogusEpicTitle(t.epicName, t.epicKey)) {
        map[t.epicKey] = t.epicName;
      }
    });
    return map;
  }

  function getComponentsForProject(projectKey) {
    const pk = (projectKey || CONFIG.projectKey).toUpperCase();
    const cached = componentsByProjectMap[pk];
    if (Array.isArray(cached) && cached.length > 0) {
      return Array.from(new Set([...cached, 'Без компонента']));
    }
    if (pk === CONFIG.projectKey) {
      return getAllComponentOptions();
    }
    // Собираем известные компоненты из связанных задач данного проекта, пока грузится API
    const fromLinks = [];
    tasks.forEach((t) => {
      [...(t.projectTaskLinks || []), ...(t.inProjectLinks || [])].forEach((l) => {
        if (l.key && l.key.startsWith(pk + '-') && l.component && l.component !== 'Без компонента') {
          fromLinks.push(l.component);
        }
      });
    });
    return Array.from(new Set([...fromLinks, 'Без компонента']));
  }

  const favoriteComponentNames = ['CS', 'CRM_BO', 'CRM_CORE', 'crm support'];
  function prioritizeFavoriteComponents(names) {
    return names.slice().sort((a, b) => {
      const ai = favoriteComponentNames.findIndex(name => name.toLowerCase() === a.toLowerCase());
      const bi = favoriteComponentNames.findIndex(name => name.toLowerCase() === b.toLowerCase());
      return (ai < 0 ? 99 : ai) - (bi < 0 ? 99 : bi) || a.localeCompare(b);
    });
  }

  function buildSkeletonTableRowsHtml(count) {
    let html = '';
    for (let i = 0; i < count; i++) {
      html += `
        <tr class="ozon-ext-task-row" style="pointer-events:none;">
          ${columnOrder
            .map(
              (colId) =>
                `<td><div class="ozon-ext-cell-singleline"><span class="ozon-ext-skeleton" style="width:${colId === 'task' ? '210px' : '110px'};height:13px;"></span></div></td>`
            )
            .join('')}
        </tr>
      `;
    }
    return html;
  }

  function renderSingleTaskRowAndSubrows(task, allComponents, allSprints, allAssignees, epicMap, epicKeys, treeDepth = 0) {
    const isSelected = isSidebarOpen && task.key === selectedTaskKey;
    const ptList = (task.projectTaskLinks || []).filter((l) => !isCanceledStatus(l.status));
    const ipList = (task.inProjectLinks || []).filter((l) => !isCanceledStatus(l.status));
    const totalLinks = ptList.length + ipList.length;
    const isSubExpanded = Boolean(expandedSubRows[task.key]);
    const hasNoAssignee = isTaskMissingAssignee(task);

    const taskTransitions = issueTransitionsByKey[task.key] || [];
    const statusList = getStatusOptionsForTask(task);
    const statusCat = getStatusCategoryClass(task.status);

    const sprintOptions = buildSprintSelectOptionsHtml(allSprints, task.sprint, '');

    const cleanEpicTitle =
      (task.epicKey && epicNameByKey[task.epicKey]) ||
      (!isBogusEpicTitle(task.epicName, task.epicKey) ? task.epicName : '');

    const isStatusComboOpen = activeTableCombo && activeTableCombo.type === 'status' && activeTableCombo.taskKey === task.key;
    const isEpicComboOpen = activeTableCombo && activeTableCombo.type === 'epic' && activeTableCombo.taskKey === task.key;
    const isCompComboOpen = activeTableCombo && activeTableCombo.type === 'component' && activeTableCombo.taskKey === task.key;
    const isAssigneeComboOpen = activeTableCombo && activeTableCombo.type === 'assignee' && activeTableCombo.taskKey === task.key;
    const isCustomerComboOpen = activeTableCombo && activeTableCombo.type === 'customer' && activeTableCombo.taskKey === task.key;

    const comboItemStyle = 'padding:5px 8px;margin-bottom:2px;border-radius:6px;line-height:1.35;min-height:24px;display:flex;align-items:center;gap:6px;cursor:pointer;';

    let statusPopoverHtml = '';
    if (isStatusComboOpen) {
      statusPopoverHtml = `
        <div class="ozon-ext-inner-ctrl ozon-ext-combo-popover" style="min-width:210px;padding:6px;display:flex;flex-direction:column;gap:4px;" onclick="event.stopPropagation();">
          <div class="ozon-ext-combo-list" id="ozon-table-combo-list" style="display:flex;flex-direction:column;gap:2px;">
            ${statusList
              .map((st) => {
                const matchedTr = taskTransitions.find(
                  (tr) => ((tr.to && tr.to.name) || tr.name || '').toLowerCase() === st.toLowerCase()
                );
                const trId = matchedTr && matchedTr.id ? matchedTr.id : '';
                return `
                  <div class="ozon-ext-combo-item ${st === task.status ? 'active' : ''}" style="${comboItemStyle}justify-content:space-between;" data-action="pick-table-status" data-key="${escapeHtml(task.key)}" data-status="${escapeHtml(st)}" data-tr-id="${escapeHtml(trId)}">
                    ${getStatusBadgeHtml(st)}
                    ${st === task.status ? '<span style="color:#005BFF;font-weight:700;font-size:11px;">✓</span>' : ''}
                  </div>
                `;
              })
              .join('')}
          </div>
        </div>
      `;
    }

    const statusCellHtml = `
      <div class="ozon-ext-inner-ctrl ozon-ext-status-trigger status-${statusCat}" data-action="open-table-status-combo" data-key="${escapeHtml(task.key)}" title="Статус: ${escapeHtml(task.status)} (Нажмите для выбора статуса)">
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(task.status)}</span>
        <span style="font-size:9px;opacity:0.75;flex-shrink:0;">▾</span>
        ${statusPopoverHtml}
      </div>
    `;

    let epicPopoverHtml = '';
    if (isEpicComboOpen) {
      const q = (activeTableCombo.query || '').trim().toLowerCase();
      const filteredEpics = epicKeys.filter((k) => {
        if (!q) return true;
        const name = (epicMap[k] || '').toLowerCase();
        return k.toLowerCase().includes(q) || name.includes(q);
      });
      epicPopoverHtml = `
        <aside role="dialog" aria-label="Эпик задачи" class="ozon-ext-inner-ctrl ozon-ext-combo-popover ozon-ext-epic-picker-popover" style="min-width:290px;padding:6px;display:flex;flex-direction:column;gap:5px;" onclick="event.stopPropagation();">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;"><strong>Эпик задачи · ${escapeHtml(task.key)}</strong><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="close-table-epic" aria-label="Закрыть">✕</button></div>
          <input type="search" class="ozon-ext-input" id="ozon-table-combo-input" data-action="table-combo-search" placeholder="Поиск эпика FCRM (код или название)..." value="${escapeHtml(activeTableCombo.query || '')}" autocomplete="off" />
          <div class="ozon-ext-combo-list" id="ozon-table-combo-list" style="display:flex;flex-direction:column;gap:2px;">
            <div class="ozon-ext-combo-item ${!task.epicKey ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-epic" data-key="${escapeHtml(task.key)}" data-epic-key="" data-epic-name="">
              <span style="color:#94A3B8;">✕ Без эпика</span>
            </div>
            ${
              filteredEpics.length > 0
                ? filteredEpics
                    .slice(0, 40)
                    .map(
                      (k) => `
                        <div class="ozon-ext-combo-item ozon-ext-epic-option ${k === task.epicKey ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-epic" data-key="${escapeHtml(task.key)}" data-epic-key="${escapeHtml(k)}" data-epic-name="${escapeHtml(epicMap[k] || '')}">
                          ${renderEpicOption(k, epicMap[k] || '')}
                        </div>
                      `
                    )
                    .join('')
                : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Эпики FCRM не найдены (введите запрос для поиска в Jira)</div>'
            }
          </div>
        </aside>
      `;
    }

    const tableFcrmEpicKey = task.epicKey || (isEpicIssueType(task.issueTypeName) ? task.key : '');
    const tableEpicStatus = epicStatusByKey[tableFcrmEpicKey] || '';
    const tableEpicProjectTag = renderEpicProjectTag(tableFcrmEpicKey);
    const tableObprojectSource = isEpicIssueType(task.issueTypeName) ? task.key : task.epicKey;
    const tableObproject = epicObprojectByFcrmEpicKey[tableObprojectSource];
    const epicCellHtml = `
        <div class="ozon-ext-inner-ctrl ozon-ext-cell-combo-trigger" data-action="open-table-epic-combo" data-key="${escapeHtml(task.key)}" title="Нажмите для выбора эпика FCRM">
          <div class="ozon-ext-table-epic-line" style="flex:1;overflow:hidden;">
            ${tableFcrmEpicKey ? '<a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(tableFcrmEpicKey) + '" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation();">' + escapeHtml(tableFcrmEpicKey) + '</a>' + (tableEpicStatus ? getStatusBadgeHtml(tableEpicStatus) : '') + tableEpicProjectTag + '<span class="epic-title" title="' + escapeHtml(cleanEpicTitle || task.summary) + '">' + escapeHtml(cleanEpicTitle || task.summary) + '</span>' : '<span style="color:#94A3B8;">Без эпика FCRM</span>'}
          </div>
          <span class="ozon-ext-toolbar-chevron" aria-hidden="true"></span>
          ${epicPopoverHtml}
        </div>
    `;
    const obprojectCellHtml = `
        <div class="ozon-ext-table-epic-line ozon-ext-inner-ctrl" style="min-height:22px;">
          ${tableObproject && tableObproject.key ? '<a class="ozon-mono" href="https://jit.o3.ru/browse/' + encodeURIComponent(tableObproject.key) + '" target="_blank" rel="noopener noreferrer" title="' + escapeHtml(tableObproject.summary || tableObproject.key) + '" onclick="event.stopPropagation();">' + escapeHtml(tableObproject.key) + '</a>' + (tableObproject.status ? getStatusBadgeHtml(tableObproject.status) : '<span style="color:#94A3B8;">Статус недоступен</span>') + '<span class="epic-title" title="' + escapeHtml(tableObproject.summary || '') + '">' + escapeHtml(tableObproject.summary || '') + '</span>' : '<span style="color:#94A3B8;">OBPROJECT: не указан</span>'}
        </div>
    `;

    const taskProjKey = getIssueProjectKey(task.key);
    const taskProjComponents = getComponentsForProject(taskProjKey);
    let compPopoverHtml = '';
    if (isCompComboOpen) {
      const cq = (activeTableCombo.query || '').trim().toLowerCase();
      const filteredComps = taskProjComponents.filter((c) => !cq || c.toLowerCase().includes(cq));
      compPopoverHtml = `
        <div class="ozon-ext-inner-ctrl ozon-ext-combo-popover" style="min-width:260px;padding:6px;display:flex;flex-direction:column;gap:5px;" onclick="event.stopPropagation();">
          <input type="search" class="ozon-ext-input" id="ozon-table-combo-input" data-action="table-combo-search" placeholder="Поиск компонента (${escapeHtml(taskProjKey)})..." value="${escapeHtml(activeTableCombo.query || '')}" autocomplete="off" />
          <div class="ozon-ext-combo-list" id="ozon-table-combo-list" style="display:flex;flex-direction:column;gap:2px;">
            ${
              filteredComps.length > 0
                ? filteredComps
                    .map(
                      (c) => `
                        <div class="ozon-ext-combo-item ${c === task.component ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-comp" data-key="${escapeHtml(task.key)}" data-comp="${escapeHtml(c)}">
                          <span style="overflow:hidden;text-overflow:ellipsis;color:#071026;font-weight:${c === task.component ? '700' : '500'};">${escapeHtml(c)}</span>
                        </div>
                      `
                    )
                    .join('')
                : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Компоненты не найдены</div>'
            }
          </div>
        </div>
      `;
    }

    const compCellHtml = `
      <div class="ozon-ext-inner-ctrl ozon-ext-cell-combo-trigger" data-action="open-table-comp-combo" data-key="${escapeHtml(task.key)}" title="${escapeHtml(task.component)} (Нажмите для поиска компонента ${escapeHtml(taskProjKey)})">
        <span style="color:#071026;font-weight:600;font-size:11px;overflow:hidden;text-overflow:ellipsis;flex:1;">${escapeHtml(task.component || 'Без компонента')}</span>
        <span style="color:#94A3B8;font-size:9px;flex-shrink:0;">▾</span>
        ${compPopoverHtml}
      </div>
    `;

    // Поиск и выбор Исполнителя в таблице
    let assigneePopoverHtml = '';
    if (isAssigneeComboOpen) {
      const aq = (activeTableCombo.query || '').trim().toLowerCase();
      const candidateUsers =
        tableUserSearchResults.length > 0
          ? tableUserSearchResults
          : assignableUsersList.filter((u) => isRealHumanJiraUser(u));
      const filteredUsers = candidateUsers.filter((u) => {
        if (!isRealHumanJiraUser(u)) return false;
        if (!aq) return true;
        return (
          String(u.displayName || '').toLowerCase().includes(aq) ||
          String(u.name || '').toLowerCase().includes(aq)
        );
      });

      assigneePopoverHtml = `
        <div class="ozon-ext-inner-ctrl ozon-ext-combo-popover" style="min-width:270px;padding:6px;display:flex;flex-direction:column;gap:5px;" onclick="event.stopPropagation();">
          <input type="search" class="ozon-ext-input" id="ozon-table-combo-input" data-action="table-combo-search" placeholder="Поиск человека (ФИО или логин)..." value="${escapeHtml(activeTableCombo.query || '')}" autocomplete="off" />
          <div class="ozon-ext-combo-list" id="ozon-table-combo-list" style="display:flex;flex-direction:column;gap:2px;">
            <div class="ozon-ext-combo-item ${task.assignee.name === 'Не назначен' ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-assignee" data-key="${escapeHtml(task.key)}" data-user-login="" data-user-display="Не назначен">
              <span style="color:#94A3B8;">✕ Не назначен</span>
            </div>
            ${
              filteredUsers.length > 0
                ? filteredUsers
                    .slice(0, 35)
                    .map(
                      (u) => `
                        <div class="ozon-ext-combo-item ${u.displayName === task.assignee.name ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-assignee" data-key="${escapeHtml(task.key)}" data-user-login="${escapeHtml(u.name || '')}" data-user-display="${escapeHtml(u.displayName)}">
                          <span style="color:#071026;font-weight:600;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(u.displayName)}</span>
                          ${u.name ? `<span style="color:#64748B;font-size:10px;flex-shrink:0;">(${escapeHtml(u.name)})</span>` : ''}
                        </div>
                      `
                    )
                    .join('')
                : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Сотрудники не найдены — введите ФИО или логин</div>'
            }
          </div>
        </div>
      `;
    }

    const assigneeCellHtml = `
      <div class="ozon-ext-inner-ctrl ozon-ext-cell-combo-trigger" data-action="open-table-assignee-combo" data-key="${escapeHtml(task.key)}" title="Исполнитель: ${escapeHtml(task.assignee.name)} (Нажмите для поиска сотрудника)">
        <span style="color:${task.assignee.name === 'Не назначен' ? '#94A3B8' : '#071026'};font-weight:500;font-size:11px;overflow:hidden;text-overflow:ellipsis;flex:1;">${escapeHtml(task.assignee.name || 'Не назначен')}</span>
        <span style="color:#94A3B8;font-size:9px;flex-shrink:0;">▾</span>
        ${assigneePopoverHtml}
      </div>
    `;

    // Поиск и выбор Заказчик/Owner в таблице
    const isCustEmpty = !task.customer.name || task.customer.name === 'Не указан';
    let customerPopoverHtml = '';
    if (isCustomerComboOpen) {
      const custQ = (activeTableCombo.query || '').trim().toLowerCase();
      const candidateCusts =
        tableUserSearchResults.length > 0
          ? tableUserSearchResults
          : assignableUsersList.filter((u) => isRealHumanJiraUser(u));
      const filteredCusts = candidateCusts.filter((u) => {
        if (!isRealHumanJiraUser(u)) return false;
        if (!custQ) return true;
        return (
          String(u.displayName || '').toLowerCase().includes(custQ) ||
          String(u.name || '').toLowerCase().includes(custQ)
        );
      });

      customerPopoverHtml = `
        <div class="ozon-ext-inner-ctrl ozon-ext-combo-popover" style="min-width:270px;padding:6px;display:flex;flex-direction:column;gap:5px;" onclick="event.stopPropagation();">
          <input type="search" class="ozon-ext-input" id="ozon-table-combo-input" data-action="table-combo-search" placeholder="Поиск Заказчик/Owner (ФИО или логин)..." value="${escapeHtml(activeTableCombo.query || '')}" autocomplete="off" />
          <div class="ozon-ext-combo-list" id="ozon-table-combo-list" style="display:flex;flex-direction:column;gap:2px;">
            <div class="ozon-ext-combo-item ${isCustEmpty ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-customer" data-key="${escapeHtml(task.key)}" data-user-login="" data-user-display="Не указан">
              <span style="color:#94A3B8;">✕ Не указан</span>
            </div>
            ${
              filteredCusts.length > 0
                ? filteredCusts
                    .slice(0, 35)
                    .map(
                      (u) => `
                        <div class="ozon-ext-combo-item ${u.displayName === task.customer.name ? 'active' : ''}" style="${comboItemStyle}" data-action="pick-table-customer" data-key="${escapeHtml(task.key)}" data-user-login="${escapeHtml(u.name || '')}" data-user-display="${escapeHtml(u.displayName)}">
                          <span style="color:#071026;font-weight:600;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(u.displayName)}</span>
                          ${u.name ? `<span style="color:#64748B;font-size:10px;flex-shrink:0;">(${escapeHtml(u.name)})</span>` : ''}
                        </div>
                      `
                    )
                    .join('')
                : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Сотрудники не найдены — нажмите Enter для сохранения текста</div>'
            }
          </div>
        </div>
      `;
    }

    const customerCellHtml = `
      <div class="ozon-ext-inner-ctrl ozon-ext-cell-combo-trigger" data-action="open-table-customer-combo" data-key="${escapeHtml(task.key)}" title="Заказчик/Owner: ${escapeHtml(task.customer.name || 'Не указан')} (Нажмите для поиска сотрудника)">
        <span style="color:${isCustEmpty ? '#94A3B8' : '#071026'};font-weight:500;font-size:11px;overflow:hidden;text-overflow:ellipsis;flex:1;">${escapeHtml(task.customer.name || 'Не указан')}</span>
        <span style="color:#94A3B8;font-size:9px;flex-shrink:0;">▾</span>
        ${customerPopoverHtml}
      </div>
    `;

    // СТРОГО 1 ЛИНИЯ для ячейки «Задача проекта»
    let ptSingleLineHtml = '<span style="color:#CBD5E1;">—</span>';
    if (ptList.length > 0) {
      const firstPt = ptList[0];
      const morePtCount = ptList.length - 1;
      const allPtTooltip = ptList.map((l) => l.key + ': ' + l.summary + ' [' + l.status + ']').join('\n');
      ptSingleLineHtml = `
        <div class="ozon-ext-cell-singleline" title="${escapeHtml(allPtTooltip)}">
          <span class="ozon-mono" style="color:#005BFF;font-weight:600;font-size:10.5px;flex-shrink:0;">${escapeHtml(firstPt.key)}</span>
          <span style="color:#334155;font-size:11px;overflow:hidden;text-overflow:ellipsis;flex:1;">${escapeHtml(firstPt.summary)}</span>
          ${
            morePtCount > 0
              ? `<button type="button" class="ozon-ext-inner-ctrl ozon-ext-more-links-pill" data-action="toggle-subrow" data-key="${escapeHtml(task.key)}" title="Показать все задачи проекта (${ptList.length})">+${morePtCount} ещё ${isSubExpanded ? '▴' : '▾'}</button>`
              : ''
          }
        </div>
      `;
    }

    // СТРОГО 1 ЛИНИЯ для ячейки «В проекте»
    let ipSingleLineHtml = '<span style="color:#CBD5E1;">—</span>';
    if (ipList.length > 0) {
      const firstIp = ipList[0];
      const moreIpCount = ipList.length - 1;
      const allIpTooltip = ipList
        .map((l) => l.key + ' — ' + l.summary + ' | Статус: ' + l.status + ' | Комп.: ' + (l.component || '—') + ' | Спринт: ' + (l.sprint || '—'))
        .join('\n');
      ipSingleLineHtml = `
        <div class="ozon-ext-cell-singleline" title="${escapeHtml(allIpTooltip)}">
          <span class="ozon-mono" style="color:#005BFF;font-weight:600;font-size:10.5px;flex-shrink:0;">${escapeHtml(firstIp.key)}</span>
          <span style="color:#071026;font-weight:500;font-size:11px;overflow:hidden;text-overflow:ellipsis;flex:1;">${escapeHtml(firstIp.summary)}</span>
          <span style="color:#64748B;font-size:10px;flex-shrink:0;">${escapeHtml(firstIp.component && firstIp.component !== 'Без компонента' ? firstIp.component : firstIp.status)}</span>
          ${
            moreIpCount > 0
              ? `<button type="button" class="ozon-ext-inner-ctrl ozon-ext-more-links-pill" data-action="toggle-subrow" data-key="${escapeHtml(task.key)}" title="Развернуть все задачи «В проекте» (${ipList.length})">+${moreIpCount} ещё ${isSubExpanded ? '▴' : '▾'}</button>`
              : ''
          }
        </div>
      `;
    }

    const taskIndentPx = 8 + treeDepth * 20;
    const subRowIndentPx = taskIndentPx + 20;

    const cellMap = {
      task: `
        <td style="padding-left:${taskIndentPx}px !important;border-left:3px solid #E2E8F0 !important;">
          <div class="ozon-ext-cell-singleline">
            ${
              totalLinks > 0
                ? `<button type="button" class="ozon-ext-inner-ctrl" data-action="toggle-subrow" data-key="${escapeHtml(task.key)}" title="Развернуть/свернуть связанные задачи (${totalLinks})" style="border:none;background:transparent;color:#005BFF;font-weight:700;cursor:pointer;padding:0;width:16px;min-width:16px;display:inline-flex;align-items:center;justify-content:center;font-size:10px;line-height:1;flex-shrink:0;">${isSubExpanded ? '▼' : '▶'}</button>`
                : '<span style="display:inline-block;width:16px;min-width:16px;flex-shrink:0;"></span>'
            }
            <a href="/browse/${escapeHtml(task.key)}" target="_blank" class="ozon-ext-inner-ctrl ozon-mono" onclick="event.stopPropagation();" style="color:#005BFF;font-weight:700;font-size:11px;text-decoration:none;flex-shrink:0;">${escapeHtml(task.key)}</a>
            ${getIssueTypeBadgeHtml(task.issueTypeName || 'Задача', true)}
            <button type="button" class="ozon-dev-priority-edit ozon-ext-inner-ctrl" data-priority-key="${escapeHtml(task.key)}" title="Изменить приоритет: ${escapeHtml(task.priority || 'Не указан')}" aria-label="Изменить приоритет ${escapeHtml(task.key)}">${getJiraPriorityIconSvg(task.priority)}</button>
            ${hasNoAssignee ? getMissingAssigneeWarnSvg() : ''}
            <span style="overflow:hidden;text-overflow:ellipsis;color:#071026;font-weight:500;font-size:11.5px;flex:1;min-width:0;">${escapeHtml(task.summary)}</span>
            ${renderTaskProjectGeneration(task)}
            ${renderDeliveryIndicators(task)}
            ${renderMissingCustomerIndicator(task)}
            <button type="button" class="ozon-ext-inner-ctrl ozon-ext-open-sb-btn ${isSelected ? 'active' : ''}" data-action="open-sidebar" data-key="${escapeHtml(task.key)}" title="Открыть детали задачи ${escapeHtml(task.key)} в боковой панели справа">
              Детали
            </button>
          </div>
        </td>
      `,
      status: `<td style="overflow:visible;">${statusCellHtml}</td>`,
      epic: `<td style="overflow:visible;">${epicCellHtml}</td>`,
      epicObproject: `<td>${obprojectCellHtml}</td>`,
      component: `<td style="overflow:visible;">${compCellHtml}</td>`,
      assignee: `<td style="overflow:visible;">${assigneeCellHtml}</td>`,
      author: `
        <td title="${escapeHtml(task.author.name)}" style="color:#475569;font-size:11px;">
          <div class="ozon-ext-cell-singleline">${escapeHtml(task.author.name)}</div>
        </td>
      `,
      customer: `<td style="overflow:visible;">${customerCellHtml}</td>`,
      created: `
        <td class="ozon-mono" style="color:#475569;font-size:10.5px;">
          <div class="ozon-ext-cell-singleline">${escapeHtml(task.createdAt)}</div>
        </td>
      `,
      createdAt: `
        <td class="ozon-mono" style="color:#475569;font-size:10.5px;">
          <div class="ozon-ext-cell-singleline">${escapeHtml(task.createdAt)}</div>
        </td>
      `,
      sprint: `
        <td style="overflow:visible;">
          <div class="ozon-ext-cell-singleline">
            ${renderSearchSelect('table-sprint-' + task.key, task.sprint, Array.from(new Set([...allSprints, task.sprint].filter(Boolean))).map(sp => ({ value: sp, label: formatSprintWithStateText(sp) })), 'Поиск спринта...', 'compact')}
          </div>
        </td>
      `,
      projectTask: `<td>${ptSingleLineHtml}</td>`,
      inProject: `<td>${ipSingleLineHtml}</td>`
    };

    let html = `
      <tr class="ozon-ext-task-row ozon-tree-depth-${treeDepth % 2} ${isDoneTask(task) ? 'completed' : ''} ${isSelected ? 'selected' : ''}" data-key="${escapeHtml(task.key)}" title="Нажмите на строку, чтобы развернуть/свернуть связанные задачи (или нажмите «◨ Детали» для открытия боковой панели)">
        ${columnOrder.map((colId) => cellMap[colId] || '<td></td>').join('')}
      </tr>
    `;

    if (isSubExpanded && totalLinks > 0) {
      const renderLinkedSubrow = (l, isPt) => {
        const lEpicClean =
          (l.epicKey && epicNameByKey[l.epicKey]) ||
          (!isBogusEpicTitle(l.epicName, l.epicKey) ? l.epicName : '');
        const lEpicHtml = l.epicKey
          ? `<div class="ozon-ext-cell-singleline" title="${escapeHtml(l.epicKey + (lEpicClean ? ' — ' + lEpicClean : ''))}">
               <span class="ozon-mono" style="color:#005BFF;font-weight:600;font-size:10.5px;flex-shrink:0;">${escapeHtml(l.epicKey)}</span>
               <span style="color:#334155;font-size:11px;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(lEpicClean || l.epicKey)}</span>
             </div>`
          : '<span style="color:#94A3B8;">—</span>';

        const subCellMap = {
          task: `
            <td style="padding-left:${subRowIndentPx}px !important;border-left:3px solid #CBD5E1 !important;">
              <div class="ozon-ext-cell-singleline">
                <span class="ozon-mono" style="color:#94A3B8;font-weight:700;">↳</span>
                ${getLinkTypeTagHtml(isPt)}
                <a href="/browse/${escapeHtml(l.key)}" target="_blank" class="ozon-mono" style="color:#005BFF;font-weight:700;font-size:11px;text-decoration:none;flex-shrink:0;">${escapeHtml(l.key)}</a>
                ${getIssueTypeBadgeHtml(l.issueTypeName || 'Задача', true)}
                <button type="button" class="ozon-dev-priority-edit ozon-ext-inner-ctrl" data-priority-key="${escapeHtml(l.key)}" title="Изменить приоритет: ${escapeHtml(l.priority || 'Не указан')}" aria-label="Изменить приоритет ${escapeHtml(l.key)}">${getJiraPriorityIconSvg(l.priority || 'Medium')}</button>
                <span style="color:#071026;font-weight:500;overflow:hidden;text-overflow:ellipsis;" title="${escapeHtml(l.summary)}">${escapeHtml(l.summary)}</span>
              </div>
            </td>
          `,
          status: `<td><div class="ozon-ext-cell-singleline">${getStatusBadgeHtml(l.status)}</div></td>`,
          epic: `<td>${lEpicHtml}</td>`,
          component: `<td style="color:#071026;font-weight:600;"><div class="ozon-ext-cell-singleline" title="${escapeHtml(l.component || 'Без компонента')}">${escapeHtml(l.component || 'Без компонента')}</div></td>`,
          assignee: `<td style="color:#475569;font-size:11px;"><div class="ozon-ext-cell-singleline" title="${escapeHtml(l.assigneeName || '—')}">${escapeHtml(l.assigneeName || '—')}</div></td>`,
          author: `<td style="color:#64748B;font-size:11px;"><div class="ozon-ext-cell-singleline" title="${escapeHtml(l.authorName || '—')}">${escapeHtml(l.authorName || '—')}</div></td>`,
          customer: `<td style="color:#94A3B8;">—</td>`,
          created: `<td class="ozon-mono" style="color:#64748B;font-size:10.5px;"><div class="ozon-ext-cell-singleline">${escapeHtml(l.createdAt || '—')}</div></td>`,
          createdAt: `<td class="ozon-mono" style="color:#64748B;font-size:10.5px;"><div class="ozon-ext-cell-singleline">${escapeHtml(l.createdAt || '—')}</div></td>`,
          sprint: `<td style="color:#334155;font-weight:500;"><div class="ozon-ext-cell-singleline ozon-ext-sprint-value" title="${escapeHtml(formatSprintWithStateText(l.sprint || 'Не в спринте'))}"><span style="overflow:hidden;text-overflow:ellipsis;">${escapeHtml(l.sprint || 'Не в спринте')}</span>${getSprintStateBadgeHtml(l.sprint)}</div></td>`,
          projectTask: isPt
            ? `<td><div class="ozon-ext-cell-singleline">${getLinkTypeTagHtml(true)}</div></td>`
            : `<td style="color:#94A3B8;">—</td>`,
          inProject: !isPt
            ? `<td><div class="ozon-ext-cell-singleline">${getLinkTypeTagHtml(false)}</div></td>`
            : `<td style="color:#94A3B8;">—</td>`
        };

        return `
          <tr class="ozon-ext-subrow ozon-tree-depth-${(treeDepth + 1) % 2} ${isDoneTask(l) ? 'completed' : ''}">
            ${columnOrder.map((colId) => subCellMap[colId] || '<td></td>').join('')}
          </tr>
        `;
      };

      ptList.forEach((l) => {
        html += renderLinkedSubrow(l, true);
      });
      ipList.forEach((l) => {
        html += renderLinkedSubrow(l, false);
      });
    }

    return html;
  }

  function buildTableRowsHtml(filteredTasks) {
    if (isInitialBoardLoading) {
      return `
        <tr class="ozon-ext-sprint-row">
          <td colspan="${columnOrder.length}">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
              <span class="ozon-ext-spinner"></span>
              <div class="ozon-ext-load-progress">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;color:#334155;font-size:11px;"><span>${escapeHtml(initialLoadStage || statusMessage || 'Загрузка спринтов и задач FCRM из Jira...')}</span><strong style="color:#005BFF;">${initialLoadProgress}%</strong></div>
                <div class="ozon-ext-load-progress-track"><div class="ozon-ext-load-progress-fill" style="--load-progress:${initialLoadProgress}%"></div></div>
              </div>
            </div>
          </td>
        </tr>
        ${buildSkeletonTableRowsHtml(8)}
      `;
    }

    if (!productDashboardLoaded) return '<tr><td colspan="' + columnOrder.length + '" style="padding:20px;color:#64748B">Выберите спринты и нажмите «Загрузить задачи». После загрузки можно применить дополнительные фильтры.</td></tr>';
    const groups = {};
    const hasActiveTaskFilters = Boolean(searchQuery.trim()) || filterComponent !== 'all' || filterEpic !== 'all' || filterStatus !== 'all' || hideDone || filterIssueType !== 'all';

    // Инициализируем все родные спринты доски (включая Прошедшие/Закрытые), чтобы они всегда отображались в списке
    if (!hasActiveTaskFilters) {
      boardOwnedSprintNames.forEach((spName) => {
        if (spName && !groups[spName]) {
          groups[spName] = [];
        }
      });
    }

    // Группируем задачи FCRM по спринтам (включая Прошедшие спринты!)
    filteredTasks.forEach((t) => {
      const sp = t.sprint || 'Бэклог FCRM';
      if (!groups[sp]) groups[sp] = [];
      groups[sp].push(t);
    });

    const sortedSprints = getSortedSprintNames(groups).filter((spName) => {
      const items = groups[spName] || [];
      const spState = getSprintStateCode(spName);
      if (!matchesSprintState(spState)) return false;
      if (hasActiveTaskFilters) return items.length > 0;
      return items.length > 0 || boardOwnedSprintNames.has(spName);
    });

    const allComponents = getAllComponentOptions();
    const allSprints = getEditableSprintOptions();
    const allAssignees = getAllAssigneeOptions();
    const epicMap = getAllEpicOptions();
    const epicKeys = Object.keys(epicMap);

    let rowsHtml = '';

    if (productGroupingOrder.join(',') !== 'sprint,component') {
      const renderGroups = (items, depth, path) => {
        if (depth >= productGroupingOrder.length) return sortTasksList(items).map((task) => renderSingleTaskRowAndSubrows(task, allComponents, allSprints, allAssignees, epicMap, epicKeys, depth)).join('');
        const field = productGroupingOrder[depth]; const buckets = {};
        items.forEach((task) => {
          const values = field === 'sprint' ? [task.sprint || 'Бэклог FCRM'] : (task.components?.length ? task.components : [task.component || 'Без компонента']);
          values.forEach((value) => { if (field === 'component' && filterComponent !== 'all' && value !== filterComponent) return; (buckets[value] ||= []).push(task); });
        });
        if (field === 'sprint' && depth === 0 && !hasActiveTaskFilters) sortedSprints.forEach((name) => { buckets[name] ||= []; });
        const names = field === 'sprint' ? getSortedSprintNames(buckets) : Object.keys(buckets).sort((a,b) => a === 'Без компонента' ? 1 : b === 'Без компонента' ? -1 : a.localeCompare(b,'ru'));
        return names.map((name) => {
          const key = JSON.stringify([...path, [field, name]]); const groupItems = buckets[name];
          const defaultExpanded = treeLevelApplied && (tableTreeLevel === 'tasks' || tableTreeLevel === 'links' || (tableTreeLevel === 'components' && depth === 0));
          const expanded = Object.prototype.hasOwnProperty.call(productExpandedGroups, key) ? productExpandedGroups[key] : (defaultExpanded || (!treeLevelApplied && Boolean(searchQuery.trim())));
          const heading = field === 'sprint' ? escapeHtml(name) + ' ' + (getSprintStateBadgeHtml(name) || renderBadge('Бэклог','todo')) : '<span style="color:#64748B;font-weight:500">Компонент:</span> ' + escapeHtml(name);
          const row = '<tr class="ozon-ext-product-group ozon-tree-depth-' + (depth % 2) + ' ' + (field === 'sprint' ? 'ozon-ext-sprint-row' : 'ozon-ext-comp-group-row') + '" data-group-key="' + escapeHtml(key) + '"><td colspan="' + columnOrder.length + '"><div style="display:flex;align-items:center;gap:8px;padding-left:' + (depth * 20) + 'px"><span style="color:#005BFF">' + (expanded ? '▾' : '▸') + '</span><strong>' + heading + '</strong><span class="ozon-ext-group-total">' + groupItems.length + ' задач</span>' + renderStatusSummary(groupItems) + '</div></td></tr>';
          return row + (expanded ? renderGroups(groupItems, depth + 1, [...path, [field,name]]) : '');
        }).join('');
      };
      return renderGroups(filteredTasks, 0, []);
    }

    sortedSprints.forEach((sprintName) => {
      const groupItems = sortTasksList(groups[sprintName] || []);
      // По умолчанию спринты СВЁРНУТЫ (разворачиваются по клику или при активном поиске)
      const isExpanded = Boolean(expandedSprints[sprintName]) || (!treeLevelApplied && Boolean(searchQuery.trim()));
      const collapsed = !isExpanded;
      const isSprintLoading = Boolean(loadingSprintsMap[sprintName]);
      rowsHtml += `
        <tr class="ozon-ext-sprint-row" data-sprint="${escapeHtml(sprintName)}">
          <td colspan="${columnOrder.length}">
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <div style="display:flex;align-items:center;gap:8px;">
                ${isSprintLoading ? '<span class="ozon-ext-spinner"></span>' : `<span style="color:#005BFF;font-size:10px;">${collapsed ? '▾' : '▾'}</span>`}
                <span style="color:#071026;font-weight:700;font-size:12px;">${escapeHtml(sprintName)}</span>
                ${getSprintStateBadgeHtml(sprintName) || renderBadge("Бэклог", "todo")}
                <span class="ozon-ext-group-total">${groupItems.length} задач</span>
                ${renderStatusSummary(groupItems)}
              </div>
              <span class="ozon-ext-sprint-chevron" style="color:#64748B;font-size:11px;">
                ${isSprintLoading ? 'Обновление из Jira...' : collapsed ? 'Развернуть спринт' : 'Свернуть спринт'}
              </span>
            </div>
          </td>
        </tr>
      `;

      if (isSprintLoading) {
        const progress = Number(loadingSprintsMap[sprintName]) || 5;
        rowsHtml += `<tr><td colspan="${columnOrder.length}" class="ozon-ext-sprint-progress-cell"><div class="ozon-ext-load-progress"><div style="display:flex;justify-content:space-between;gap:10px;color:#64748B;font-size:10px;"><span>Загружаю задачи спринта из Jira…</span><strong style="color:#005BFF;">${progress}%</strong></div><div class="ozon-ext-load-progress-track"><div class="ozon-ext-load-progress-fill" style="--load-progress:${progress}%"></div></div></div></td></tr>`;
      }

      if (!collapsed) {
        if (isSprintLoading) {
          rowsHtml += buildSkeletonTableRowsHtml(Math.max(3, Math.min(6, groupItems.length || 4)));
          return;
        }

        if (groupByComponentInsideSprint) {
          const compGroups = {};
          groupItems.forEach((t) => {
            const names = Array.isArray(t.components) && t.components.length ? t.components : [t.component || 'Без компонента'];
            names.forEach((cName) => { if (filterComponent !== 'all' && cName !== filterComponent) return; if (!compGroups[cName]) compGroups[cName] = []; compGroups[cName].push(t); });
          });

          const sortedCompNames = Object.keys(compGroups).sort((a, b) => {
            if (a === 'Без компонента' && b !== 'Без компонента') return 1;
            if (a !== 'Без компонента' && b === 'Без компонента') return -1;
            return a.localeCompare(b, 'ru');
          });

          sortedCompNames.forEach((compName) => {
            const compItems = sortByField !== 'default' ? sortTasksList(compGroups[compName] || []) : (compGroups[compName] || []).slice().sort((a, b) => {
              const priorityDifference = getPrioritySortWeight(b.priority) - getPrioritySortWeight(a.priority);
              if (priorityDifference !== 0) return priorityDifference;
              return parseTaskCreatedTimestamp(b) - parseTaskCreatedTimestamp(a);
            });
            const compKey = sprintName + '::' + compName;
            // По умолчанию компоненты внутри спринта тоже СВЁРНУТЫ (или развёрнуты при активном поиске)
            const isCompExpanded = Boolean(expandedComponents[compKey]) || (!treeLevelApplied && Boolean(searchQuery.trim()));
            const isCompCollapsed = !isCompExpanded;
            const isCompLoading = Boolean(loadingComponentsMap[compKey]);

            rowsHtml += `
              <tr class="ozon-ext-comp-group-row ozon-tree-depth-1" data-comp-group="${escapeHtml(compKey)}">
                <td colspan="${columnOrder.length}">
                  <div style="display:flex;align-items:center;justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:7px;">
                      ${isCompLoading ? '<span class="ozon-ext-spinner" style="width:11px;height:11px;border-width:1.8px;"></span>' : `<span style="color:#005BFF;font-size:9.5px;">${isCompCollapsed ? '▾' : '▾'}</span>`}
                      <span style="color:#64748B;font-size:11px;font-weight:500;">Компонент:</span>
                      <strong style="color:#071026;font-size:11px;font-weight:700;">${escapeHtml(compName)}</strong>
                      <span class="ozon-ext-group-total">${compItems.length} задач</span>
                      ${renderStatusSummary(compItems)}
                    </div>
                    <span style="color:#94A3B8;font-size:10.5px;">${isCompLoading ? 'Обновление задач компонента из Jira...' : isCompCollapsed ? 'Показать (' + compItems.length + ')' : 'Свернуть'}</span>
                  </div>
                </td>
              </tr>
            `;

            if (!isCompCollapsed) {
              compItems.forEach((task) => {
                rowsHtml += renderSingleTaskRowAndSubrows(task, allComponents, allSprints, allAssignees, epicMap, epicKeys, groupByComponentInsideSprint ? 2 : 1);
              });
            }
          });
        } else {
          groupItems.forEach((task) => {
            rowsHtml += renderSingleTaskRowAndSubrows(task, allComponents, allSprints, allAssignees, epicMap, epicKeys, groupByComponentInsideSprint ? 2 : 1);
          });
        }
      }
    });

    return rowsHtml;
  }

  function renderUserSearchResultsHtml(users) {
    const cleanUsers = (Array.isArray(users) ? users : []).filter((u) => isRealHumanJiraUser(u));
    if (cleanUsers.length === 0) {
      return '';
    }
    return (
      '<div class="ozon-ext-user-dropdown">' +
      cleanUsers
        .map(
          (u) => `
            <div class="ozon-ext-user-option" data-action="pick-jira-user" data-user-login="${escapeHtml(u.name)}" data-user-display="${escapeHtml(u.displayName)}">
              <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                <strong style="color:#071026;">${escapeHtml(u.displayName)}</strong>
                <span style="color:#64748B;font-size:10.5px;margin-left:5px;">(${escapeHtml(u.name)})</span>
              </div>
              <span style="color:#005BFF;font-weight:700;font-size:10.5px;flex-shrink:0;">Выбрать</span>
            </div>
          `
        )
        .join('') +
      '</div>'
    );
  }

  function renderCustomerSearchResultsHtml(users) {
    const cleanUsers = (Array.isArray(users) ? users : []).filter((u) => isRealHumanJiraUser(u));
    if (cleanUsers.length === 0) {
      return '';
    }
    return (
      '<div class="ozon-ext-user-dropdown">' +
      cleanUsers
        .map(
          (u) => `
            <div class="ozon-ext-user-option" data-action="pick-jira-customer" data-user-login="${escapeHtml(u.name)}" data-user-display="${escapeHtml(u.displayName)}">
              <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                <strong style="color:#071026;">${escapeHtml(u.displayName)}</strong>
                <span style="color:#64748B;font-size:10.5px;margin-left:5px;">(${escapeHtml(u.name)})</span>
              </div>
              <span style="color:#005BFF;font-weight:700;font-size:10.5px;flex-shrink:0;">Выбрать</span>
            </div>
          `
        )
        .join('') +
      '</div>'
    );
  }

  const COLUMN_META = {
    task: { label: 'Задача (Спринт → Компонент → Задача)', accent: false },
    status: { label: 'Статус ▾', accent: false },
    epic: { label: 'Epic Link ▾', accent: false },
    epicObproject: { label: 'Эпик OBPROJECT', accent: false },
    component: { label: 'Компонент ▾', accent: true },
    assignee: { label: 'Исполнитель ▾', accent: false },
    author: { label: 'Автор', accent: false },
    customer: { label: 'Заказчик/Owner ▾', accent: false },
    created: { label: 'Создана', accent: false },
    createdAt: { label: 'Создана', accent: false },
    sprint: { label: 'Спринт ▾', accent: false },
    projectTask: { label: 'Задача проекта (fcrm_umb_epic)', accent: false },
    inProject: { label: 'В проекте (OB · OBFRONT · FTD)', accent: false }
  };

  function buildSidebarHtml() {
    if (!isSidebarOpen || !selectedTaskKey) return '';
    const task = tasks.find((t) => t.key === selectedTaskKey);
    if (!task) return '';

    const isTaskLoading = loadingSidebarTaskKey === selectedTaskKey;

    if (isTaskLoading) {
      return `
        <div class="ozon-ext-resizer-bar" id="ozon-ext-sidebar-resizer" title="Потяните для изменения ширины сайдбара"></div>
        <aside class="ozon-ext-sidebar" id="ozon-ext-sidebar-panel" style="width:${sidebarWidth}px;">
          <div class="ozon-ext-sidebar-header">
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="ozon-ext-spinner"></span>
              <strong class="ozon-mono" style="color:#005BFF;font-size:13px;">${escapeHtml(task.key)}</strong>
              <span style="color:#64748B;font-size:11.5px;">Загрузка описания, приоритета и связей из Jira...</span>
            </div>
            <button type="button" class="ozon-ext-btn ozon-ext-btn-negative" id="ozon-ext-sidebar-close">✕</button>
          </div>
          <div class="ozon-ext-sidebar-body">
            <div>
              <div class="ozon-ext-skeleton" style="width:120px;height:11px;margin-bottom:6px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:30px;border-radius:8px;"></div>
            </div>
            <div class="ozon-ext-section-card" style="padding:12px;display:flex;flex-direction:column;gap:8px;">
              <div class="ozon-ext-skeleton" style="width:140px;height:13px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:64px;border-radius:8px;"></div>
            </div>
            <div class="ozon-ext-section-card" style="padding:12px;display:flex;flex-direction:column;gap:10px;">
              <div class="ozon-ext-skeleton" style="width:180px;height:14px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:26px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:26px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:26px;"></div>
              <div class="ozon-ext-skeleton" style="width:100%;height:26px;"></div>
            </div>
          </div>
        </aside>
      `;
    }

    const taskProjKey = getIssueProjectKey(task.key);
    const taskProjComponents = getComponentsForProject(taskProjKey);
    const editableSprints = getEditableSprintOptions();
    const statusList = getStatusOptionsForTask(task);
    const priorityList = getPriorityOptionsForTask(task);
    const issueTypeList = getProjectIssueTypeOptions(task);
    const currentIssueType = task.issueTypeName || 'Задача';
    const taskTransitions = issueTransitionsByKey[task.key] || [];
    const epicMap = getAllEpicOptions();
    const statusCat = getStatusCategoryClass(task.status);
    const prioBadgeClass = getPriorityBadgeClass(task.priority);

    const statusOptions = statusList
      .map((st) => {
        const matchedTr = taskTransitions.find(
          (tr) => ((tr.to && tr.to.name) || tr.name || '').toLowerCase() === st.toLowerCase()
        );
        const trAttr = matchedTr && matchedTr.id ? `data-tr-id="${escapeHtml(matchedTr.id)}"` : '';
        return `<option value="${escapeHtml(st)}" ${trAttr} ${st === task.status ? 'selected' : ''}>${escapeHtml(st)}</option>`;
      })
      .join('');

    const priorityOptions = priorityList
      .map((pr) => `<option value="${escapeHtml(pr)}" ${pr === task.priority ? 'selected' : ''}>${escapeHtml(pr)}</option>`)
      .join('');

    const issueTypeOptions = issueTypeList
      .map((itName) => `<option value="${escapeHtml(itName)}" ${itName === currentIssueType ? 'selected' : ''}>${escapeHtml(itName)}</option>`)
      .join('');

    const statusSearchOptions = statusList.map((st) => {
      const matchedTr = taskTransitions.find((tr) => ((tr.to && tr.to.name) || tr.name || '').toLowerCase() === st.toLowerCase());
      return { value: st, label: st, transitionId: matchedTr && matchedTr.id ? String(matchedTr.id) : '' };
    });
    const issueTypeSearchOptions = issueTypeList.map((name) => ({ value: name, label: name }));
    const prioritySearchOptions = priorityList.map((name) => ({ value: name, label: name }));
    const sidebarSprintSearchOptions = Array.from(new Set([...editableSprints, task.sprint].filter(Boolean))).map((name) => ({ value: name, label: formatSprintWithStateText(name) }));

    const transitionsChipsHtml =
      taskTransitions.length > 0
        ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:5px;">
             ${taskTransitions
               .map((tr) => {
                 const targetSt = (tr.to && tr.to.name) || tr.name;
                 const isCurrent = String(targetSt).toLowerCase() === String(task.status).toLowerCase();
                 if (isCurrent) return '';
                 return `<button type="button" class="ozon-ext-status-chip ozon-ext-badge-${getStatusCategoryClass(targetSt)}" data-action="quick-transition" data-tr-id="${escapeHtml(tr.id)}" data-target-status="${escapeHtml(targetSt)}">${escapeHtml(targetSt)}</button>`;
               })
               .join('')}
           </div>`
        : '';

    const sprintOptions = buildSprintSelectOptionsHtml(editableSprints, task.sprint, '');

    const isInBacklog = !task.sprint || task.sprint.toLowerCase().includes('бэклог') || task.sprint.toLowerCase().includes('backlog');
    const sprintQuickChipsHtml = `
      <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:5px;">
        ${editableSprints
          .filter((sp) => {
            const code = getSprintStateCode(sp);
            return code === 'ACTIVE' || code === 'FUTURE';
          })
          .map((sp) => {
            const isCurr = sp === task.sprint;
            return `<button type="button" class="ozon-ext-btn ${isCurr ? '' : 'ozon-ext-btn-surface'}" data-action="quick-sprint-chip" data-sprint="${escapeHtml(sp)}" style="padding:2px 7px;height:21px;font-size:10px;${isCurr ? 'border:1px solid #005BFF;' : ''}">${isCurr ? '✓ ' : ''}${escapeHtml(formatSprintWithStateText(sp))}</button>`;
          })
          .join('')}
        ${
          !isInBacklog
            ? `<button type="button" class="ozon-ext-btn ozon-ext-btn-negative" data-action="quick-sprint-chip" data-sprint="Бэклог FCRM" style="padding:2px 7px;height:21px;font-size:10px;" title="Удалить задачу из спринта в Бэклог FCRM">✕ Удалить из спринта</button>`
            : ''
        }
      </div>
    `;

    const epicKeys = Object.keys(epicMap);
    const currentEpicCleanTitle =
      (task.epicKey && epicNameByKey[task.epicKey]) ||
      (!isBogusEpicTitle(task.epicName, task.epicKey) ? task.epicName : '');
    const currentEpicStatus = task.epicKey ? epicStatusByKey[task.epicKey] || ((umbCatalog.find((item) => item.key === task.epicKey) || {}).status || '') : '';
    const obprojectSourceKey = isEpicIssueType(task.issueTypeName) ? task.key : task.epicKey;
    const currentObprojectEpic = obprojectSourceKey ? epicObprojectByFcrmEpicKey[obprojectSourceKey] : null;
    const obprojectEpicHtml = !obprojectSourceKey
      ? '<span style="color:#94A3B8;">—</span>'
      : currentObprojectEpic && currentObprojectEpic.loading && !currentObprojectEpic.key
        ? '<span style="color:#64748B;">Загружаю эпик OBPROJECT…</span>'
        : currentObprojectEpic && currentObprojectEpic.key
          ? '<a href="/browse/' + encodeURIComponent(currentObprojectEpic.key) + '" target="_blank" class="ozon-mono" style="color:#005BFF;font-weight:700;text-decoration:none;">' + escapeHtml(currentObprojectEpic.key) + '</a><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;">' + escapeHtml(currentObprojectEpic.summary || currentObprojectEpic.key) + '</span>' + (currentObprojectEpic.status ? getStatusBadgeHtml(currentObprojectEpic.status) : '')
          : '<span style="color:#64748B;">' + (currentObprojectEpic && currentObprojectEpic.error ? 'Не удалось загрузить эпик OBPROJECT' : 'Не указан') + '</span>';

    // Фильтрация для Input-Select эпика (проект FCRM)
    const sbEpicQ = sbEpicSearchQuery.trim().toLowerCase();
    const filteredSbEpics = epicKeys.filter((k) => {
      if (!sbEpicQ) return true;
      const nm = (epicMap[k] || '').toLowerCase();
      return k.toLowerCase().includes(sbEpicQ) || nm.includes(sbEpicQ);
    });

    // Фильтрация для Input-Select компонента задачи
    const sbCompQ = sbCompSearchQuery.trim().toLowerCase();
    const filteredSbComps = taskProjComponents.filter((c) => !sbCompQ || c.toLowerCase().includes(sbCompQ));

    const umbQ = umbSearchQuery.trim().toLowerCase();
    const taskComponents = Array.isArray(task.components) ? task.components.map((c) => typeof c === 'string' ? c : c && c.name).filter(Boolean) : String(task.component || '').split(',').map((c) => c.trim()).filter((c) => c && c !== 'Без компонента');
    const matchingUmb = umbCatalog.filter((u) => !isCanceledStatus(u.status) && u.key !== task.key).filter((u) => {
      const components = Array.isArray(u.components) ? u.components : String(u.component || '').split(',').map((c) => c.trim()).filter((c) => c && c !== 'Без компонента');
      return taskComponents.length ? components.some((c) => taskComponents.includes(c)) : !components.length;
    });
    const umbByKey = new Map(matchingUmb.map((u) => [u.key, u]));
    const visibleUmb = new Set();
    const pendingUmb = matchingUmb.filter((u) => !umbQ || (u.key + ' ' + u.summary).toLowerCase().includes(umbQ)).map((u) => u.key);
    while (pendingUmb.length) { const key = pendingUmb.pop(); if (visibleUmb.has(key)) continue; visibleUmb.add(key); ((umbByKey.get(key) || {}).parents || []).forEach((parent) => { if (umbByKey.has(parent)) pendingUmb.push(parent); }); }
    const umbChildren = new Map();
    const umbRoots = [];
    matchingUmb.forEach((u) => { if (!visibleUmb.has(u.key)) return; const parents = (u.parents || []).filter((key) => key !== u.key && visibleUmb.has(key) && umbByKey.has(key)); if (!parents.length) umbRoots.push(u.key); parents.forEach((key) => { if (!umbChildren.has(key)) umbChildren.set(key, []); umbChildren.get(key).push(u.key); }); });
    const filteredUmb = [];
    const coveredUmb = new Set();
    function appendUmbTree(key, depth, ancestors) { if (ancestors.has(key)) return; const next = new Set(ancestors); next.add(key); coveredUmb.add(key); filteredUmb.push({ item: umbByKey.get(key), depth }); (umbChildren.get(key) || []).forEach((child) => appendUmbTree(child, depth + 1, next)); }
    umbRoots.forEach((key) => appendUmbTree(key, 0, new Set()));
    matchingUmb.forEach((u) => { if (visibleUmb.has(u.key) && !coveredUmb.has(u.key)) appendUmbTree(u.key, 0, new Set()); });

    const isDescCollapsed = Boolean(collapsedSidebarSections['desc']);
    const isParamsCollapsed = Boolean(collapsedSidebarSections['params']);
    const isPtCollapsed = Boolean(collapsedSidebarSections['pt']);
    const isPtQuickCollapsed = collapsedSidebarSections['pt_quick'] !== false;
    const isIpCollapsed = Boolean(collapsedSidebarSections['ip']);
    const isOtherCollapsed = Boolean(collapsedSidebarSections['other']);

    const isBlockLoadingForTask = sidebarBlockLoading && sidebarBlockLoading.taskKey === task.key;
    const isDescBlockLoading = Boolean(isBlockLoadingForTask && sidebarBlockLoading.desc);
    const isParamsBlockLoading = Boolean(isBlockLoadingForTask && sidebarBlockLoading.params);
    const isLinksBlockLoading = Boolean(isBlockLoadingForTask && sidebarBlockLoading.links);
    const isIpMetaBlockLoading = Boolean(isBlockLoadingForTask && sidebarBlockLoading.ipMeta);
    const miniBlockSpinnerHtml = '<span class="ozon-ext-spinner" style="width:11px;height:11px;border-width:1.8px;margin-left:4px;" title="Догрузка актуальных данных блока из Jira..."></span>';

    const descLinesCount = Math.max(4, Math.min(22, (task.description || '').split('\n').length + 1));
    const sbComboItemStyle = 'padding:5px 8px;margin-bottom:2px;border-radius:6px;line-height:1.35;min-height:24px;display:flex;align-items:center;gap:6px;cursor:pointer;';

    const visiblePtLinks = (task.projectTaskLinks || []).filter((lnk) => !isCanceledStatus(lnk.status));
    const visibleIpLinks = (task.inProjectLinks || []).filter((lnk) => !isCanceledStatus(lnk.status));
    const visibleOtherLinks = task.otherLinks || [];

    const createModalHtml = issueCreateDraft ? (() => {
      const query = String(issueCreateDraft.componentQuery || '').trim().toLowerCase();
      const components = issueCreateDraft.components || [];
      const favorites = ['CS', 'CRM_BO', 'CRM_CORE', 'crm support'];
      const filtered = components.filter((component) => !query || String(component.name).toLowerCase().includes(query));
      const selected = components.find((component) => String(component.id) === String(issueCreateDraft.componentId));
      const renderComponent = (component) => '<button type="button" class="ozon-ext-create-component ' + (selected && String(selected.id) === String(component.id) ? 'active' : '') + '" data-action="pick-create-component" data-component-id="' + escapeHtml(component.id) + '">' + escapeHtml(component.name) + '</button>';
      const favoriteComponents = filtered.filter((component) => favorites.some((name) => name.toLowerCase() === String(component.name).toLowerCase()));
      const otherComponents = filtered.filter((component) => !favorites.some((name) => name.toLowerCase() === String(component.name).toLowerCase()));
      return '<div class="ozon-ext-create-overlay" data-action="close-create-issue">' +
        '<form class="ozon-ext-create-dialog" id="ozon-create-issue-form">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div><strong>' + (issueCreateDraft.kind === 'epic' ? 'Создать тематику' : 'Создать задачу — ' + (issueCreateDraft.kind === 'front' ? 'Фронт' : 'Бэк')) + '</strong><div style="font-size:11px;color:#64748B;margin-top:3px;">Проект ' + escapeHtml(issueCreateDraft.projectKey) + '</div></div><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="close-create-issue">✕</button></div>' +
          '<label>Название<input id="ozon-create-issue-summary" type="text" value="' + escapeHtml(issueCreateDraft.summary || '') + '" placeholder="Введите название" autocomplete="off" /></label>' +
          (issueCreateDraft.kind === 'epic' ? '' : '<label>Описание<textarea id="ozon-create-issue-description" rows="4" placeholder="Введите описание задачи">' + escapeHtml(issueCreateDraft.description || '') + '</textarea></label>') +
          '<div><label>Компонент <span style="color:#64748B;font-weight:400;">' + (selected ? '· ' + escapeHtml(selected.name) : '') + '</span></label><input id="ozon-create-issue-component-search" type="search" value="' + escapeHtml(issueCreateDraft.componentQuery || '') + '" placeholder="Поиск компонента проекта ' + escapeHtml(issueCreateDraft.projectKey) + '..." autocomplete="off" /><div class="ozon-ext-create-components">' +
            (issueCreateLoading ? '<div style="padding:10px;color:#64748B;font-size:12px;">Загружаю список компонентов…</div>' : '') +
            (favoriteComponents.length ? '<div class="ozon-ext-create-caption">Быстрый доступ</div>' + favoriteComponents.map(renderComponent).join('') : '') +
            (otherComponents.length ? '<div class="ozon-ext-create-caption">Все компоненты</div>' + otherComponents.map(renderComponent).join('') : '') +
            (!filtered.length ? '<div style="padding:10px;color:#64748B;font-size:12px;">Компоненты не найдены</div>' : '') +
          '</div></div>' +
          (issueCreateDraft.kind === 'epic' ? '<div class="ozon-ext-create-note">Тип Epic, метка <code>fcrm_umb_epic</code>; поле названия эпика будет заполнено тем же названием.</div>' : '') +
          (issueCreateDraft.error ? '<div class="ozon-ext-create-error">' + escapeHtml(issueCreateDraft.error) + '</div>' : '') +
          '<div class="ozon-ext-create-actions"><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="close-create-issue">Отмена</button><button type="submit" class="ozon-ext-btn" ' + (issueCreateBusy || issueCreateLoading ? 'disabled' : '') + '>' + (issueCreateLoading ? 'Загружаю…' : issueCreateBusy ? 'Создаю…' : 'Создать и связать') + '</button></div>' +
        '</form></div>';
    })() : '';
    const linkTypes = {inProject:'В проекте', projectTask:'Задача проекта', duplicates:'Дублирует', linkedTask:'Связанная задача', web:'Связанная ссылка'};
    const linkModalHtml = linkCreateDraft ? '<div class="ozon-ext-create-overlay" data-action="close-link-create"><form class="ozon-ext-create-dialog" id="ozon-link-create-form" role="dialog" aria-label="Новая связь">' +
      '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div><strong>Новая связь</strong><div class="ozon-ext-create-note">' + escapeHtml(linkTypes[linkCreateDraft.kind]) + '</div></div><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="close-link-create" aria-label="Закрыть">✕</button></div>' +
      (linkCreateDraft.kind === 'web' ? '<label>Ссылка<input id="ozon-link-create-url" type="url" placeholder="https://…" required /></label><label>Название ссылки<input id="ozon-link-create-title" type="text" placeholder="Например, обсуждение задачи" required /></label>' : '<label>Ключ задачи<input id="ozon-link-create-key" type="text" placeholder="Например, FCRM-1234" required autocomplete="off" /></label>') +
      '<div id="ozon-link-create-message" class="ozon-ext-create-error" role="alert" hidden></div><div class="ozon-ext-create-actions"><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="close-link-create">Отмена</button><button type="submit" class="ozon-ext-btn">Связать</button></div></form></div>' : '';

    // Группируем задачи «В проекте» по OB (Бэкенд), OBFRONT (Фронтенд), FTD (Дизайн), FCRM
    const ipGroupsMap = {};
    (task.inProjectLinks || []).forEach((lnk, originalIdx) => {
      if (isCanceledStatus(lnk.status)) return;
      const meta = getLinkedProjectGroupMeta(lnk.key, false);
      if (!ipGroupsMap[meta.id]) {
        ipGroupsMap[meta.id] = { meta: meta, items: [] };
      }
      ipGroupsMap[meta.id].items.push({ lnk: lnk, idx: originalIdx });
    });
    const sortedIpGroups = Object.values(ipGroupsMap).sort((a, b) => a.meta.order - b.meta.order);

    return `
      <div class="ozon-ext-resizer-bar" id="ozon-ext-sidebar-resizer" title="Потяните для изменения ширины сайдбара"></div>
      <aside class="ozon-ext-sidebar" id="ozon-ext-sidebar-panel" style="width:${sidebarWidth}px;">
        <div class="ozon-ext-sidebar-header">
          <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;flex-wrap:wrap;">
            <a href="/browse/${escapeHtml(task.key)}" target="_blank" class="ozon-mono" style="color:#005BFF;font-weight:700;font-size:13px;text-decoration:none;flex-shrink:0;">
              ${escapeHtml(task.key)}
            </a>
            <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-copy-task-link" title="Копировать ссылку и название" aria-label="Копировать ссылку и название" style="width:26px;height:26px;padding:4px;flex-shrink:0;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4H4v12h4"/></svg></button>
            <span style="color:#64748B;font-size:10px;white-space:nowrap;" title="Создана: ${escapeHtml(task.createdAt || '—')}">Создана: ${escapeHtml(task.createdAt || '—')}</span>
            <span style="color:#64748B;font-size:10px;white-space:nowrap;" title="Автор: ${escapeHtml(task.author && task.author.name || '—')}">Автор: ${escapeHtml(task.author && task.author.name || '—')}</span>
            ${getIssueTypeBadgeHtml(currentIssueType, true)}
          </div>
          <div style="display:flex;align-items:center;gap:5px;flex-shrink:0;">
            <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-ext-sidebar-refresh" title="Обновить все" aria-label="Обновить все">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 11a8 8 0 0 0-14.9-3L4 10"/><path d="M4 4v6h6"/><path d="M4 13a8 8 0 0 0 14.9 3L20 14"/><path d="M20 20v-6h-6"/></svg>
            </button>
            <button type="button" class="ozon-ext-btn ozon-ext-btn-negative" id="ozon-ext-sidebar-close" title="Закрыть сайдбар">
              ✕
            </button>
          </div>
            <div class="ozon-ext-title-line">
              <input type="text" aria-label="Название задачи" id="ozon-sb-summary" value="${escapeHtml(sidebarDraft(task.key).summary ?? task.summary)}" style="flex:1;font-weight:600;font-size:12.5px;" />
              <button type="button" class="ozon-ext-btn" id="ozon-sb-save-summary" title="Сохранить название задачи" ${sidebarDraft(task.key).summary === undefined ? 'style="display:none" disabled' : ''}>Сохранить название</button>
            </div>

        </div>

        <div class="ozon-ext-sidebar-body">
<div class="ozon-ext-workflow"><div class="ozon-ext-workflow-current"><span class="ozon-ext-workflow-label">Статус</span>${getStatusBadgeHtml(task.status)}</div>
${taskTransitions.length ? '<span class="ozon-ext-workflow-label">Перевести в:</span>' : ''}${transitionsChipsHtml}</div>
          <!-- АККОРДЕОН 2: ПАРАМЕТРЫ ЗАДАЧИ -->
          <div class="ozon-ext-section-card" id="ozon-sb-params-card">
            <div class="ozon-ext-section-head ${isParamsCollapsed ? 'collapsed' : ''}" data-action="toggle-sb-section" data-sec="params">
              <div style="display:flex;align-items:center;gap:6px;">
                <span style="color:#005BFF;font-size:10px;">${isParamsCollapsed ? '▾' : '▾'}</span>
                <span>Атрибуты задачи</span>
                ${isParamsBlockLoading ? miniBlockSpinnerHtml : ''}
              </div>
              ${sidebarRefreshButton(task.key, 'params')}
            </div>
            ${
              !isParamsCollapsed
                ? `<div style="padding:10px 12px;" class="ozon-ext-field-grid">
                    <!-- Тип задачи (доступный в проекте FCRM) -->
                    <div class="ozon-ext-field-label">Тип задачи</div>
                    <div style="display:flex;align-items:center;gap:7px;">
                      ${renderSearchSelect('sidebar-issuetype', currentIssueType, issueTypeSearchOptions, 'Поиск типа задачи...')}
                    </div>

                    <!-- Приоритет со стандартной SVG-иконкой Jira -->
                    <div class="ozon-ext-field-label">Приоритет</div>
                    <div style="display:flex;align-items:center;gap:7px;">
                      ${renderSearchSelect('sidebar-priority', task.priority, prioritySearchOptions, 'Поиск приоритета...')}
                    </div>

                    <!-- Спринт + быстрые чипсы спринтов доски FCRM и кнопка «Удалить из спринта» -->
                    <div class="ozon-ext-field-label">Спринт</div>
                    <div>
                      ${renderSearchSelect('sidebar-sprint', task.sprint, sidebarSprintSearchOptions, 'Поиск спринта...')}
                    </div>

                    <!-- Компонент (Input-Select с поиском по компонентам проекта задачи) -->
                    <div class="ozon-ext-field-label">Компонент</div>
                    <div class="ozon-ext-sb-combo">
                      <div class="ozon-ext-sb-combo-trigger" id="ozon-sb-comp-trigger" title="Нажмите для поиска компонента проекта ${escapeHtml(taskProjKey)}">
                        <span style="font-weight:600;color:#071026;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(task.component || 'Без компонента')}</span>
                        <span style="color:#64748B;font-size:10px;flex-shrink:0;">⌕ ${escapeHtml(taskProjKey)} ▾</span>
                      </div>
                      ${
                        sbCompComboOpen
                          ? `<div class="ozon-ext-combo-popover" style="width:100%;padding:6px;display:flex;flex-direction:column;gap:5px;">
                               <input type="search" id="ozon-sb-comp-search" placeholder="Поиск компонента в проекте ${escapeHtml(taskProjKey)}..." value="${escapeHtml(sbCompSearchQuery)}" autocomplete="off" />
                               <div class="ozon-ext-combo-list" id="ozon-sb-comp-list" style="display:flex;flex-direction:column;gap:2px;">
                                 ${
                                   filteredSbComps.length > 0
                                     ? filteredSbComps
                                         .map(
                                           (c) => `
                                             <div class="ozon-ext-combo-item ${c === task.component ? 'active' : ''}" style="${sbComboItemStyle}" data-action="pick-sb-comp" data-comp="${escapeHtml(c)}">
                                               <span style="overflow:hidden;text-overflow:ellipsis;color:#071026;font-weight:${c === task.component ? '700' : '500'};">${escapeHtml(c)}</span>
                                             </div>
                                           `
                                         )
                                         .join('')
                                     : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Компоненты не найдены</div>'
                                 }
                               </div>
                             </div>`
                          : ''
                      }
                    </div>

                    <!-- Эпик (Input-Select с поиском СТРОГО по эпикам проекта FCRM + сохранение в Jira) -->
                    <div class="ozon-ext-field-label">Эпик FCRM</div>
                    <div style="display:flex;flex-direction:column;gap:5px;">
                      <div class="ozon-ext-sb-combo">
                        <div class="ozon-ext-sb-combo-trigger" id="ozon-sb-epic-trigger" title="Нажмите для поиска эпика в проекте FCRM">
                          <div style="display:flex;align-items:center;gap:6px;overflow:hidden;min-width:0;">
                            ${
                              task.epicKey
                                ? `<a href="/browse/${encodeURIComponent(task.epicKey)}" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation();" class="ozon-mono" style="color:#005BFF;font-weight:700;flex-shrink:0;text-decoration:none;">${escapeHtml(task.epicKey)}</a>
                                   <span style="color:#071026;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(currentEpicCleanTitle || task.epicKey)}</span>`
                                : '<span style="color:#94A3B8;">Без эпика (нажмите для поиска в FCRM)</span>'
                            }
                          </div>
                          <span style="display:flex;align-items:center;gap:5px;flex-shrink:0;">${currentEpicStatus ? getStatusBadgeHtml(currentEpicStatus) : ''}<span style="color:#64748B;font-size:10px;">⌕ FCRM ▾</span></span>
                        </div>
                        ${
                          sbEpicComboOpen
                            ? `<div class="ozon-ext-combo-popover" style="width:100%;padding:6px;display:flex;flex-direction:column;gap:5px;">
                                 <input type="search" id="ozon-sb-epic-search" placeholder="Поиск эпика в проекте FCRM (код или название)..." value="${escapeHtml(sbEpicSearchQuery)}" autocomplete="off" />
                                 <div class="ozon-ext-combo-list" id="ozon-sb-epic-list" style="display:flex;flex-direction:column;gap:2px;">
                                   <div class="ozon-ext-combo-item ${!task.epicKey ? 'active' : ''}" style="${sbComboItemStyle}" data-action="pick-sb-epic" data-epic-key="" data-epic-name="">
                                     <span style="color:#94A3B8;">✕ Без эпика (отвязать эпик)</span>
                                   </div>
                                   ${
                                     filteredSbEpics.length > 0
                                       ? filteredSbEpics
                                           .slice(0, 50)
                                           .map(
                                             (k) => `
                                               <div class="ozon-ext-combo-item ozon-ext-epic-option ${k === task.epicKey ? 'active' : ''}" style="${sbComboItemStyle}" data-action="pick-sb-epic" data-epic-key="${escapeHtml(k)}" data-epic-name="${escapeHtml(epicMap[k] || '')}">
                                                 ${renderEpicOption(k, epicMap[k] || '')}
                                               </div>
                                             `
                                           )
                                           .join('')
                                       : '<div style="padding:6px 8px;color:#64748B;font-size:11px;">Эпики FCRM не найдены — продолжайте ввод для поиска в Jira</div>'
                                   }
                                 </div>
                               </div>`
                            : ''
                        }
                      </div>
                    </div>

                    <div class="ozon-ext-field-label">Эпик OBPROJECT</div>
                    <div class="ozon-ext-obproject-value" style="display:flex;align-items:center;gap:7px;min-width:0;min-height:30px;width:100%;">${obprojectEpicHtml}</div>

                    <div class="ozon-ext-field-label">Метки</div>
                    <div class="ozon-sb-labels" id="ozon-sb-labels">${(task.labels || []).length ? task.labels.map(label => '<span class="ozon-ext-badge ozon-ext-badge-todo ozon-sb-label-chip">' + escapeHtml(label) + '<button type="button" class="ozon-sb-label-remove" data-sb-remove-label="' + escapeHtml(label) + '" aria-label="Удалить метку ' + escapeHtml(label) + '">×</button></span>').join('') : '<span style="color:#64748B;">Нет меток</span>'}<form class="ozon-sb-label-form" id="ozon-sb-label-form"><input id="ozon-sb-label-input" type="text" aria-label="Новая метка" placeholder="Новая метка" autocomplete="off" /><button type="submit" class="ozon-ext-btn ozon-ext-btn-surface">Добавить</button></form><span class="ozon-sb-label-error" id="ozon-sb-label-error" role="alert" hidden></span></div>

                    <!-- Исполнитель с живым поиском по пользователям Jira (оформлено аналогично Заказчик/Owner) -->
                    <div class="ozon-ext-field-label">Исполнитель</div>
                    <div style="display:flex;flex-direction:column;gap:4px;">
                      <div style="display:flex;gap:5px;">
                        <input type="search" id="ozon-sb-user-search" value="${escapeHtml(task.assignee.name)}" placeholder="🔍 Поиск Исполнителя по ФИО или логину..." style="flex:1;" />
                      </div>
                      <div id="ozon-sb-user-results">
                        ${renderUserSearchResultsHtml(searchedUsersResults)}
                      </div>
                    </div>

                    <!-- Заказчик/Owner с живым поиском по пользователям Jira -->
                    <div class="ozon-ext-field-label">Заказчик/Owner</div>
                    <div style="display:flex;flex-direction:column;gap:4px;">
                      <div style="display:flex;gap:5px;">
                        <input type="search" id="ozon-sb-customer" value="${escapeHtml(task.customer.name)}" placeholder="🔍 Поиск Заказчик/Owner по ФИО или логину..." style="flex:1;" />
                      </div>
                      <div id="ozon-sb-customer-results">
                        ${renderCustomerSearchResultsHtml(searchedCustomerResults)}
                      </div>
                    </div>

                  </div>`
                : ''
            }
          <!-- АККОРДЕОН 1: ОПИСАНИЕ ЗАДАЧИ (с поддержкой форматирования Jira Wiki / Markdown и режимом редактирования) -->
          <div class="ozon-ext-section-card" id="ozon-sb-description-card">
            <div class="ozon-ext-section-head ${isDescCollapsed ? 'collapsed' : ''}" data-action="toggle-sb-section" data-sec="desc">
              <div style="display:flex;align-items:center;gap:6px;">
                <span style="color:#005BFF;font-size:10px;">${isDescCollapsed ? '▾' : '▾'}</span>
                <span>Описание задачи</span>
                ${isDescBlockLoading ? miniBlockSpinnerHtml : ''}
              </div>
              <div style="display:flex;align-items:center;gap:5px;" onclick="event.stopPropagation();">
                <button type="button" class="ozon-ext-btn ${isEditingDescription ? '' : 'ozon-ext-btn-surface'}" id="ozon-sb-toggle-edit-desc" style="height:21px;padding:1px 8px;font-size:10px;">
                  ${isEditingDescription ? '👁 Просмотр' : '✎ Редактировать'}
                </button>
                ${
                  isEditingDescription
                    ? '<button type="button" class="ozon-ext-btn" id="ozon-sb-save-description" style="height:21px;padding:1px 8px;font-size:10px;">Сохранить описание</button>'
                    : ''
                }
              </div>
            </div>
            ${
              !isDescCollapsed
                ? isEditingDescription
                  ? `<div style="padding:8px 10px;display:flex;flex-direction:column;gap:6px;">
                       <textarea id="ozon-sb-description" rows="${descLinesCount}" placeholder="Введите текст описания (поддерживается разметка *Заголовок*, h2., списки, ссылки)..." style="width:100%;resize:vertical;min-height:90px;max-height:680px;overflow-y:auto;font-size:12px;line-height:1.45;">${escapeHtml(sidebarDraft(task.key).description ?? task.description ?? '')}</textarea>
                       <div style="display:flex;justify-content:flex-end;gap:6px;">
                         <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-sb-cancel-description" style="height:23px;padding:2px 10px;font-size:10.5px;">Отмена</button>
                         <button type="button" class="ozon-ext-btn" id="ozon-sb-save-description-bottom" style="height:23px;padding:2px 10px;font-size:10.5px;">✓ Сохранить в Jira</button>
                       </div>
                     </div>`
                  : isDescBlockLoading && !task.description
                  ? `<div style="padding:10px 12px;display:flex;flex-direction:column;gap:6px;">
                       <div class="ozon-ext-skeleton" style="width:45%;height:12px;"></div>
                       <div class="ozon-ext-skeleton" style="width:100%;height:48px;border-radius:6px;"></div>
                     </div>`
                  : `<div class="ozon-sb-description-preview ${(task.description || '').length > 500 && !expandedSidebarDescriptions.has(task.key) ? 'is-compact' : ''}" style="padding:10px 12px;" id="ozon-sb-desc-preview" title="Двойной клик — перейти к редактированию описания">
                       ${formatJiraDescriptionHtml(task.description)}
                     </div>${(task.description || '').length > 500 ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface ozon-sb-description-more" data-action="toggle-description-length" aria-expanded="' + expandedSidebarDescriptions.has(task.key) + '">' + (expandedSidebarDescriptions.has(task.key) ? 'Свернуть описание' : 'Показать описание полностью') + '</button>' : ''}`
                : ''
            }
          </div>

          </div>

          <!-- АККОРДЕОН 3: СВЯЗИ «ЗАДАЧА ПРОЕКТА» -->
          <div class="ozon-ext-section-card">
            <div class="ozon-ext-section-head ${isPtCollapsed ? 'collapsed' : ''}" data-action="toggle-sb-section" data-sec="pt">
              <div style="display:flex;align-items:center;gap:6px;">
                <span style="color:#005BFF;font-size:10px;">${isPtCollapsed ? '▾' : '▾'}</span>
                <span>Связи: «Задача проекта» (${visiblePtLinks.length})</span>
                ${visiblePtLinks.length === 0 ? getMissingProjectTaskWarnSvg() : ''}
                ${isLinksBlockLoading ? miniBlockSpinnerHtml : ''}
              </div>
              <div style="display:flex;align-items:center;gap:6px;">
            <button type="button" class="ozon-ext-btn ozon-ext-btn-surface ozon-sb-link-add" data-action="start-create-link" data-link-kind="projectTask">+ Связать</button>
            <details class="ozon-sidebar-more" onclick="event.stopPropagation()"><summary aria-label="Другие действия со связями">⋯</summary><div class="ozon-sidebar-more-menu">
            <button type="button" class="ozon-ext-btn ozon-ext-inner-ctrl" data-action="generate-links" data-task-keys="${escapeHtml(task.key)}" ${generatingLinkKeys.has(task.key) ? 'disabled aria-busy="true"' : ''} aria-label="Сгенерировать связи" title="Сгенерировать связи">${generatingLinkKeys.has(task.key) ? '<span class="ozon-ext-spinner"></span>' : generationIconHtml()} Сгенерировать связи</button>
              ${sidebarRefreshButton(task.key, 'pt')}
              <a href="/issues/?jql=labels%20%3D%20fcrm_umb_epic" target="_blank" class="ozon-mono" onclick="event.stopPropagation();" style="color:#005BFF;font-size:10.5px;text-decoration:none;">
                JQL: fcrm_umb_epic ↗
              </a></div></details>
              </div>
            </div>
            ${
              !isPtCollapsed
                ? `<div>
                    ${
                      visiblePtLinks.length > 0
                        ? visiblePtLinks
                            .map((lnk, ptIdx) => {
                              const gMeta = getLinkedProjectGroupMeta(lnk.key, true);
                              return `
                                <div class="ozon-ext-link-compact-row ozon-ext-pt-level2">
                                  <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">
                                    <div style="display:flex;align-items:center;gap:5px;overflow:hidden;min-width:0;">
                                      <span class="ozon-mono" style="color:#94A3B8;font-weight:700;font-size:11px;">↳</span>
                                      <span class="ozon-ext-link-icon-box" style="background:${gMeta.bg};color:${gMeta.color};">${gMeta.iconSvg}</span>
                                      <a href="/browse/${escapeHtml(lnk.key)}" target="_blank" class="ozon-mono" style="color:#005BFF;font-weight:700;font-size:11px;text-decoration:none;flex-shrink:0;">${escapeHtml(lnk.key)}</a>
                                      ${getIssueTypeBadgeHtml(lnk.issueTypeName || 'Задача', true)}
                                      <button type="button" class="ozon-dev-priority-edit ozon-ext-inner-ctrl" data-priority-key="${escapeHtml(lnk.key)}" title="Изменить приоритет: ${escapeHtml(lnk.priority || 'Не указан')}" aria-label="Изменить приоритет ${escapeHtml(lnk.key)}">${getJiraPriorityIconSvg(lnk.priority || 'Medium')}</button>
                                      <span style="font-weight:600;color:#071026;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(lnk.summary)}">${escapeHtml(lnk.summary)}</span>
                                    </div>
                                    <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
                                      ${getStatusBadgeHtml(lnk.status)}
                                      ${renderLinkActions(lnk, 'projectTask')}
                                    </div>
                                  </div>
                                </div>
                              `;
                            })
                            .join('')
                        : '<div style="padding:8px 12px 8px 26px;border-left:3px solid #F59E0B;color:#D97706;background:#FFFBEB;font-size:11px;font-weight:600;display:flex;align-items:center;gap:6px;">' +
                          getMissingProjectTaskWarnSvg() +
                          '<span>Внимание: у задачи нет привязанной «Задачи проекта» (labels = fcrm_umb_epic)</span></div>'
                    }

                    <!-- Быстрый выбор из фильтра labels = fcrm_umb_epic (по умолчанию свёрнут под аккордеон, Уровень 2 -> Уровень 3) -->
                    <div style="border-top:1px solid #E2E8F0;background:#F8FAFC;">
                      <div class="ozon-ext-link-group-header" data-action="toggle-sb-section" data-sec="pt_quick">
                        <div style="display:flex;align-items:center;gap:6px;font-size:10.5px;font-weight:700;color:#334155;">
                          <span style="color:#005BFF;font-size:9.5px;">${isPtQuickCollapsed ? '▾' : '▾'}</span>
                          <span>Быстрый выбор (${filteredUmb.length})</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px;flex:0 0 auto;">
                          <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="start-create-issue" data-create-kind="epic" style="height:21px;padding:1px 7px;font-size:10px;">+ Создать тематику</button>
                          <span style="font-size:10px;color:#64748B;">${isPtQuickCollapsed ? 'Развернуть' : 'Свернуть'}</span>
                        </div>
                      </div>
                      ${
                        !isPtQuickCollapsed
                          ? `<div style="padding:7px 12px 7px 42px;border-top:1px solid #EEF2F6;border-left:3px solid #E2E8F0;background:#FFFFFF;">
                               <input type="search" id="ozon-sb-umb-search" value="${escapeHtml(umbSearchQuery)}" placeholder="Поиск по ключу или названию в fcrm_umb_epic..." style="width:100%;margin-bottom:5px;background:#F8FAFC !important;height:24px !important;" />
                               <div style="max-height:135px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:7px;">
                                 ${filteredUmb
                                   .map(({item: u, depth}) => {
                                     const alreadyLinked = visiblePtLinks.some((l) => l.key === u.key);
                                     return `
                                       <div style="padding:4px 8px 4px ${8 + Math.min(depth, 8) * 18}px;border-bottom:1px solid #EEF2F6;display:flex;align-items:center;justify-content:space-between;gap:6px;font-size:11px;">
                                         <a href="/browse/${encodeURIComponent(u.key)}" target="_blank" rel="noopener noreferrer" style="display:block;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-decoration:none;">
                                           <strong class="ozon-mono" style="color:#005BFF;margin-right:5px;">${escapeHtml(u.key)}</strong>
                                           <span style="color:#071026;">${depth ? '↳ ' : ''}${escapeHtml(u.summary)}</span> <span class="ozon-ext-badge ozon-ext-badge-todo">${escapeHtml(u.component || 'Без компонента')}</span>
                                         </a>
                                         <button type="button" class="ozon-ext-btn" data-action="toggle-umb-link" data-umb-key="${escapeHtml(u.key)}" style="padding:1px 7px;height:20px;font-size:10px;flex-shrink:0;">
                                           ${alreadyLinked ? '✓ Привязана' : '+ Выбрать'}
                                         </button>
                                       </div>
                                     `;
                                   })
                                   .join('') || '<div style="padding:10px;color:#64748B;">Для компонента задачи тематики не найдены</div>'}
                               </div>
                             </div>`
                          : ''
                      }
                    </div>
                  </div>`
                : ''
            }
          </div>

          <!-- АККОРДЕОН 4: СВЯЗИ «В ПРОЕКТЕ» (Чёткая лесенка отступов: Аккордеон (12px) → Группа направления (26px) → Задача (42px) → Поля задачи (64px)) -->
          <div class="ozon-ext-section-card">
            <div class="ozon-ext-section-head ${isIpCollapsed ? 'collapsed' : ''}" data-action="toggle-sb-section" data-sec="ip">
              <div style="display:flex;align-items:center;gap:6px;">
                <span style="color:#005BFF;font-size:10px;">${isIpCollapsed ? '▾' : '▾'}</span>
                <span>Связи: «В проекте» (${visibleIpLinks.length})</span>
                ${isLinksBlockLoading || isIpMetaBlockLoading ? miniBlockSpinnerHtml : ''}
              </div>
              <div style="display:flex;align-items:center;gap:6px;flex:0 0 auto;">
                <span style="font-size:10px;color:#64748B;">${isLinksBlockLoading ? 'Обновление связей...' : isIpMetaBlockLoading ? 'Догрузка спринтов/компонентов...' : ''}</span>
                <details class="ozon-sidebar-more" onclick="event.stopPropagation()"><summary aria-label="Другие действия со связями">⋯</summary><div class="ozon-sidebar-more-menu">${sidebarRefreshButton(task.key, 'ip')}<span style="color:#64748b">OB · OBFRONT · FTD</span></div></details>
                <button type="button" class="ozon-ext-btn ozon-ext-btn-surface ozon-sb-link-add" data-action="start-create-link" data-link-kind="inProject">+ Связать</button>
                <div style="position:relative;">
                  <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="toggle-create-in-project-menu" style="height:24px;padding:2px 8px;font-size:10px;">+ Создать</button>
                  ${createInProjectMenuOpen ? '<div class="ozon-ext-create-menu"><button type="button" data-action="start-create-issue" data-create-kind="front">Фронт · OBFRONT</button><button type="button" data-action="start-create-issue" data-create-kind="back">Бэк · OB</button><button type="button" data-action="start-create-issue" data-create-kind="design">Дизайн · FTD</button><button type="button" data-action="start-create-link" data-link-kind="inProject">Новая связь</button></div>' : ''}
                </div>
              </div>
            </div>
            ${
              !isIpCollapsed
                ? `<div>
                    ${
                      sortedIpGroups.length > 0
                        ? sortedIpGroups
                            .map((grp) => {
                              const grpCollapsed = false;
                              return `
                                <div class="ozon-ext-link-group-header" data-action="toggle-ip-group" data-grp-id="${escapeHtml(grp.meta.id)}">
                                  <div style="display:flex;align-items:center;gap:6px;">
                                    <span style="color:#005BFF;font-size:9px;">${grpCollapsed ? '▾' : '▾'}</span>
                                    <span class="ozon-ext-link-icon-box" style="background:${grp.meta.bg};color:${grp.meta.color};">${grp.meta.iconSvg}</span>
                                    <strong style="font-size:11px;color:#071026;">${escapeHtml(grp.meta.label)}</strong>
                                    <span class="ozon-ext-badge ozon-ext-badge-progress ozon-mono" style="font-size:9.5px;padding:0 5px;">${grp.items.length}</span>
                                  </div>
                                  <span style="font-size:10px;color:#64748B;">${grpCollapsed ? 'Развернуть' : 'Свернуть'}</span>
                                </div>
                                ${
                                  !grpCollapsed
                                    ? grp.items
                                        .map(({ lnk, idx: lIdx }) => {
                                          const lnkProjKey = getIssueProjectKey(lnk.key);
                                          const realCompVal = (lnk.component && String(lnk.component).trim()) || 'Без компонента';
                                          const realSprintVal = (lnk.sprint && String(lnk.sprint).trim()) || 'Не в спринте';
                                          const projComps = getComponentsForProject(lnkProjKey);
                                          const linkCompOptionList = Array.from(new Set([realCompVal, ...projComps]));
                                          const linkSprintOptionList = getSprintsForLinkedIssue(lnk).slice().sort((a, b) => a.localeCompare(b, 'ru', { sensitivity: 'base' }));
                                          const filteredLinkSprints = linkSprintOptionList.filter(sp => !sbIpSprintSearchQuery.trim() || sp.toLowerCase().includes(sbIpSprintSearchQuery.trim().toLowerCase()));
                                          const isThisIpCompOpen = sbIpCompOpenIdx === lIdx;
                                          const ipCompQ = sbIpCompSearchQuery.trim().toLowerCase();
                                          const filteredIpComps = linkCompOptionList.filter((c) => !ipCompQ || c.toLowerCase().includes(ipCompQ));
                                          const lnkEpicClean =
                                            (lnk.epicKey && epicNameByKey[lnk.epicKey]) ||
                                            (!isBogusEpicTitle(lnk.epicName, lnk.epicKey) ? lnk.epicName : '');
                                          const designRelation = frontDesignLinksByKey[lnk.key];
                                          const designCandidates = visibleIpLinks.filter((candidate) => /^FTD-/i.test(String(candidate.key || '')));
                                          const linkedDesigns = designCandidates.filter(candidate => designRelation?.keys?.includes(candidate.key));
                                          const designColor = !designRelation?.keys?.length ? 'absent' : linkedDesigns.length === designRelation.keys.length && linkedDesigns.every(candidate => /^(готово|закрыт[ао]?|done|closed)$/i.test(candidate.status || '')) ? 'done' : 'active';
                                          const designLabel = designRelation?.loading ? 'Проверяю связь с дизайном' : designRelation?.error ? 'Не удалось проверить связь с дизайном' : designRelation?.keys?.length ? 'Дизайн: ' + designRelation.keys.join(', ') : 'Нет связи с дизайном';
                                          const designIcon = /^OBFRONT-/i.test(String(lnk.key || '')) ? '<button type="button" class="ozon-dev-indicator ' + designColor + '" data-action="toggle-front-design" aria-label="' + escapeHtml(designLabel) + '" title="' + escapeHtml(designLabel) + '" aria-expanded="false" style="border:0;cursor:pointer;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20c2 0 2-2 1-3s-1-3 1-3h2a6 6 0 0 0 6-6c0-4-5-8-10-8Z"/><circle cx="7" cy="10" r="1"/><circle cx="10" cy="6" r="1"/><circle cx="16" cy="7" r="1"/></svg></button>' : '';
                                          const designLinkHtml = /^OBFRONT-/i.test(String(lnk.key || ''))
                                            ? '<div data-front-design-details hidden style="padding:2px 0 2px 28px;font-size:10px;color:#64748B;">' +
                                              (designRelation && designRelation.loading ? 'Проверяю связь с дизайном…' :
                                                designRelation && designRelation.keys.length ? 'Дизайн: ' + designRelation.keys.map((key) => '<a href="/browse/' + encodeURIComponent(key) + '" target="_blank" style="color:#005BFF;text-decoration:none;font-weight:650;">' + escapeHtml(key) + '</a>').join(', ') :
                                                  designCandidates.length ? 'Нет связи с дизайном · ' + designCandidates.map((candidate) => '<button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="link-front-design" data-front-key="' + escapeHtml(lnk.key) + '" data-design-key="' + escapeHtml(candidate.key) + '" style="height:19px;padding:1px 6px;font-size:9.5px;margin-left:3px;">Связать ' + escapeHtml(candidate.key) + '</button>').join('') :
                                                    designRelation && designRelation.error ? 'Не удалось проверить связь с дизайном' : 'Задача дизайна FTD пока не привязана к этой FCRM-задаче') +
                                              '</div>' : '';

                                          return `
                                            <div class="ozon-ext-link-compact-row">
                                              <div style="display:flex;align-items:center;justify-content:space-between;gap:5px;">
                                                <div style="display:flex;align-items:center;gap:5px;overflow:hidden;min-width:0;flex:1;">
                                                  <span class="ozon-mono" style="color:#94A3B8;font-weight:700;font-size:11px;flex-shrink:0;">↳</span>
                                                  <span class="ozon-ext-link-icon-box" style="background:${grp.meta.bg};color:${grp.meta.color};">${grp.meta.iconSvg}</span>
                                                  <a href="/browse/${escapeHtml(lnk.key)}" target="_blank" class="ozon-mono" style="color:#005BFF;font-weight:700;font-size:11px;text-decoration:none;flex-shrink:0;">${escapeHtml(lnk.key)}</a>
                                                  ${getIssueTypeBadgeHtml(lnk.issueTypeName || 'Задача', true)}
                                                  <button type="button" class="ozon-dev-priority-edit ozon-ext-inner-ctrl" data-priority-key="${escapeHtml(lnk.key)}" title="Изменить приоритет: ${escapeHtml(lnk.priority || 'Не указан')}" aria-label="Изменить приоритет ${escapeHtml(lnk.key)}">${getJiraPriorityIconSvg(lnk.priority || 'Medium')}</button>
                                                  ${lnk.storyPoints != null ? '<span class="ozon-ext-badge ozon-ext-badge-todo" title="Story Points">' + escapeHtml(String(lnk.storyPoints)) + ' SP</span>' : ''}
                                                  <span style="font-weight:600;color:#071026;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(lnk.summary)}">${escapeHtml(lnk.summary)}</span>
                                                  ${designIcon}
                                                  ${
                                                    lnk.epicKey
                                                      ? `<span class="ozon-mono" style="font-size:9.5px;color:#005BFF;background:#E5F0FF;padding:0 4px;border-radius:4px;flex-shrink:0;" title="Эпик: ${escapeHtml(lnk.epicKey + (lnkEpicClean ? ' — ' + lnkEpicClean : ''))}">${escapeHtml(lnk.epicKey)}</span>`
                                                      : ''
                                                  }
                                                </div>
                                                <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
                                                  ${getStatusBadgeHtml(lnk.status)}
                                                  ${renderLinkActions(lnk, 'inProject')}
                                                </div>
                                              </div>
                                              ${designLinkHtml}

                                              <!-- Уровень 4: Компактная строка Компонента и Спринта (с дополнительным отступом вправо под заголовком задачи) -->
                                              <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;align-items:center;padding-left:22px;">
                                                <div class="ozon-ext-sb-combo">
                                                  <button type="button" class="ozon-ext-search-select-trigger" aria-expanded="${isThisIpCompOpen}" data-action="open-ip-comp-combo" data-link-idx="${lIdx}" data-proj="${escapeHtml(lnkProjKey)}" style="min-height:22px;padding:1px 7px;font-size:10.5px;" title="Компонент проекта ${escapeHtml(lnkProjKey)}">
                                                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#071026;font-weight:600;">Комп. (${escapeHtml(lnkProjKey)}): ${escapeHtml(realCompVal)}</span>
                                                    <span style="color:#64748B;font-size:9px;flex-shrink:0;">⌕▾</span>
                                                  </button>
                                                  ${
                                                    isThisIpCompOpen
                                                      ? `<div class="ozon-ext-combo-popover" style="width:100%;min-width:210px;">
                                                           <input type="search" id="ozon-sb-ip-comp-search" placeholder="Поиск компонента в проекте ${escapeHtml(lnkProjKey)}..." value="${escapeHtml(sbIpCompSearchQuery)}" autocomplete="off" />
                                                           <div class="ozon-ext-combo-list" id="ozon-sb-ip-comp-list">
                                                             ${
                                                               filteredIpComps.length > 0
                                                                 ? filteredIpComps
                                                                     .map(
                                                                       (c) => `
                                                                         <div class="ozon-ext-combo-item ${c === realCompVal ? 'active' : ''}" data-action="pick-ip-comp" data-link-idx="${lIdx}" data-link-key="${escapeHtml(lnk.key)}" data-comp="${escapeHtml(c)}">
                                                                           <span style="overflow:hidden;text-overflow:ellipsis;color:#071026;">${escapeHtml(c)}</span>
                                                                         </div>
                                                                       `
                                                                     )
                                                                     .join('')
                                                                 : '<div style="padding:5px 8px;color:#64748B;font-size:10.5px;">Компоненты не найдены</div>'
                                                             }
                                                           </div>
                                                         </div>`
                                                      : ''
                                                  }
                                                </div>
                                                <div class="ozon-ext-sb-combo" style="position:relative;min-width:0;">
                                                  <button type="button" class="ozon-ext-search-select-trigger" aria-expanded="${sbIpSprintOpenIdx === lIdx}" data-action="open-ip-sprint-combo" data-link-idx="${lIdx}" title="Спринт: ${escapeHtml(realSprintVal)}"><span class="ozon-ext-search-select-value">${escapeHtml(realSprintVal.replace(/\s*\((Активный|Будущий|Прошедший)\)$/, ""))}</span>${getSprintStateBadgeHtml(realSprintVal)}<span class="ozon-ext-search-select-caret" aria-hidden="true"></span></button>
                                                  ${sbIpSprintOpenIdx === lIdx ? '<div class="ozon-ext-combo-popover" style="width:100%;min-width:240px;max-height:280px;overflow:auto;"><input type="search" id="ozon-sb-ip-sprint-search" placeholder="Поиск спринта..." value="' + escapeHtml(sbIpSprintSearchQuery) + '" autocomplete="off" />' + (ipSprintLoadProgress[lnk.key] ? '<div class="ozon-ext-sprint-load">Загружаю...<div class="ozon-ext-sprint-load-track"><div class="ozon-ext-sprint-load-fill" style="--sprint-load:' + ipSprintLoadProgress[lnk.key] + '%"></div></div></div>' : '') + (filteredLinkSprints.length ? filteredLinkSprints.map(sp => '<div class="ozon-ext-combo-item ' + (sp === realSprintVal ? 'active' : '') + '" data-action="pick-ip-sprint" data-link-idx="' + lIdx + '" data-link-key="' + escapeHtml(lnk.key) + '" data-sprint="' + escapeHtml(sp) + '"><span>' + escapeHtml(sp.replace(/\s*\((Активный|Будущий|Прошедший)\)$/, '')) + '</span>' + getSprintStateBadgeHtml(sp) + '</div>').join('') : '<div style="padding:6px 8px;color:#64748b;font-size:11px">Спринты не найдены</div>') + '</div>' : ''}
                                                </div>
                                              </div>
                                            </div>
                                          `;
                                        })
                                        .join('')
                                    : ''
                                }
                              `;
                            })
                            .join('')
                        : '<div style="padding:10px 12px 10px 26px;color:#64748B;font-size:11.5px;">Нет связанных задач в блоке «В проекте»</div>'
                    }

                  </div>`
                : ''
            }
          </div>
          <div class="ozon-ext-section-card">
            <div class="ozon-ext-section-head ${isOtherCollapsed ? 'collapsed' : ''}" data-action="toggle-sb-section" data-sec="other">
              <div style="display:flex;align-items:center;gap:6px;"><span style="color:#005BFF;font-size:10px;">▾</span><span>Другие связи (${visibleOtherLinks.length})</span></div>
              <div style="position:relative;"><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="toggle-other-link-menu" style="height:24px;padding:2px 8px;font-size:10px;">+ Связать</button>${otherLinkMenuOpen ? '<div class="ozon-ext-create-menu ozon-ext-other-link-menu">' + Object.entries(linkTypes).map(([kind,label]) => '<button type="button" data-action="start-create-link" data-link-kind="' + kind + '">' + label + '</button>').join('') + '</div>' : ''}</div>
            </div>
            ${!isOtherCollapsed ? (visibleOtherLinks.length
              ? '<div style="padding:6px 12px;">' + visibleOtherLinks.map((link) => {
                  const relation = link.linkDirection || link.linkType || (link.url ? 'Веб-ссылка' : 'Связанная задача');
                  const isIssue = /^[A-Z][A-Z0-9]*-[0-9]+$/i.test(String(link.key || ''));
                  const status = isIssue ? getStatusBadgeHtml(link.status || 'Статус недоступен') : '';
                  const target = link.url || ('/browse/' + encodeURIComponent(link.key));
                  const moveButton = isIssue ? renderLinkActions(link, '') : (link.id && /^remote-\d+$/.test(String(link.id)) ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-negative" data-action="delete-remote-link" data-remote-id="' + escapeHtml(String(link.id).slice(7)) + '" aria-label="Удалить веб-ссылку">✕</button>' : '');
                  return '<div style="display:flex;align-items:center;gap:6px;padding:6px 2px;border-bottom:1px solid #EEF2F6;min-width:0;"><span style="font-size:10px;color:#64748B;flex:0 0 auto;">' + escapeHtml(relation) + '</span>' + (isIssue ? '<a class="ozon-mono" href="' + escapeHtml(target) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(link.key) + '</a><span class="ozon-other-summary" style="min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + escapeHtml(link.summary || link.key) + '</span>' : '<a href="' + escapeHtml(target) + '" target="_blank" rel="noopener noreferrer" style="min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + escapeHtml(link.summary || link.key) + '</a>') + status + moveButton + '</div>';
                }).join('') + '</div>'
              : '<div style="padding:10px 12px;color:#64748B;font-size:11.5px;">Других связей нет</div>') : ''}
          </div>
          ${renderTicketSearchSection(task.key, 'fcrm')}
          ${renderTicketSearchSection(task.key, 'threads')}
          ${createModalHtml}
          ${linkModalHtml}
        </div>
      </aside>
    `;
  }

  function matchesSprintState(spState) {
      if ((filterSprintState === 'open_future' || filterSprintState === 'open_future_backlog') && spState === 'CLOSED') return false;
      if (filterSprintState === 'open_future' && spState === 'BACKLOG') return false;
      if (filterSprintState === 'ACTIVE' && spState !== 'ACTIVE') return false;
      if (filterSprintState === 'FUTURE' && spState !== 'FUTURE') return false;
      if (filterSprintState === 'CLOSED' && spState !== 'CLOSED') return false;
      if (filterSprintState === 'BACKLOG' && spState !== 'BACKLOG') return false;
    return true;
  }

  function isDoneTask(task) {
    return doneByStatus.get(task.status) ?? /^(done|closed|resolved|готово|выполнено|закрыт|закрыто|закрыта|завершено)$/i.test(task.status);
  }

  function doneToggleLabel(count) {
    return (hideDone ? "Показать выполненные" : "Скрыть выполненные") + " (" + count + ")";
  }

  function renderEpicOption(key, title) {
    const status = epicStatusByKey[key];
    return '<span style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;"><span class="ozon-mono" style="color:#005BFF;font-weight:700;">' + escapeHtml(key) + '</span>' + (status ? getStatusBadgeHtml(status) : '<span style="color:#94A3B8;font-size:10px;">Статус недоступен</span>') + '</span><span class="ozon-ext-epic-option-title">' + escapeHtml(title) + '</span>';
  }

  function renderEpicProjectTag(epicKey) {
    return '';
  }

  function renderToolbarFilter(id, title, value, options, placeholder) {
    const current = options.find(option => option.value === value);
    const open = activeToolbarFilter === id;
    const query = toolbarFilterSearch.trim().toLowerCase();
    const matches = options.filter(option => !query || option.label.toLowerCase().includes(query));
    if (id === 'epic' && /^fcrm-\d+$/i.test(query) && !matches.some(option => String(option.value).toLowerCase() === query)) matches.push({value:query.toUpperCase(),label:query.toUpperCase()});
    return '<div class="ozon-ext-toolbar-combo">' +
      '<button type="button" class="ozon-ext-toolbar-trigger" data-action="toggle-toolbar-filter" data-filter="' + id + '" ' + ((id === 'sprint' && isInitialBoardLoading) || (['component','epic','status','issue-type'].includes(id) && (!productDashboardLoaded || isInitialBoardLoading)) ? 'disabled ' : '') + 'aria-expanded="' + open + '">' +
      '<span class="ozon-ext-toolbar-label">' + escapeHtml(current ? current.label : id === 'epic' && value !== 'all' ? 'Эпик: ' + value : title) + '</span><span class="ozon-ext-toolbar-chevron" aria-hidden="true"></span></button>' +
      (open ? '<div class="ozon-ext-combo-popover ozon-ext-toolbar-popover ' + (id === 'epic' ? 'ozon-ext-epic-filter-popover ozon-dev-epic-filter-sidebar' : '') + '">' + (id === 'epic' ? '<div class="ozon-dev-editor-head"><strong>Фильтр по эпику</strong><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="toggle-toolbar-filter" data-filter="epic" aria-label="Закрыть">✕</button></div>' : '') + '<input type="search" id="ozon-toolbar-filter-search" placeholder="' + escapeHtml(placeholder || 'Поиск...') + '" value="' + escapeHtml(toolbarFilterSearch) + '" autocomplete="off" />' +
        '<div class="ozon-dev-filter-list">' + (matches.length ? matches.map(option => '<button type="button" class="ozon-ext-combo-item ' + (option.value === value ? 'active' : '') + '" data-action="pick-toolbar-filter" data-filter="' + id + '" data-value="' + escapeHtml(option.value) + '">' + escapeHtml(option.label) + '</button>').join('') : '<div class="ozon-ext-toolbar-empty">Ничего не найдено</div>') + '</div></div>' : '') +
      '</div>';
  }

  function applyTableTreeLevel(level) {
    tableTreeLevel = level;
    treeLevelApplied = true;
    expandedSprints = {};
    expandedComponents = {};
    expandedSubRows = {};
    productExpandedGroups = {};
    if (level === 'sprints') return;
    getAllSprintOptions().forEach(sprint => { expandedSprints[sprint] = true; });
    tasks.forEach(task => {
      const sprint = task.sprint || 'Бэклог FCRM';
      expandedSprints[sprint] = true;
      if (level === 'tasks' || level === 'links') (task.components?.length ? task.components : [task.component || 'Без компонента']).forEach((name) => { expandedComponents[sprint + '::' + name] = true; });
      if (level === 'links') expandedSubRows[task.key] = true;
    });
  }

  function renderStatusSummary(items) {
    const counts = new Map();
    items.forEach(item => {
      const status = item.status || 'Открыто';
      counts.set(status, (counts.get(status) || 0) + 1);
    });
    return '<span class="ozon-ext-status-summary" aria-label="Сводка по статусам">' + Array.from(counts.entries()).sort((a,b) => a[0].localeCompare(b[0], 'ru')).map(([status, count]) => '<span class="ozon-ext-status-count">' + escapeHtml(status) + ' · ' + count + '</span>').join('') + '</span>';
  }

  function renderSearchSelect(id, value, options, placeholder, className, buttonClass) {
    const current = options.find(option => String(option.value) === String(value));
    const open = activeSearchSelectId === id;
    const query = open ? searchSelectQuery.trim().toLowerCase() : '';
    const filtered = options.filter(option => !query || String(option.label).toLowerCase().includes(query));
    const safeId = escapeHtml(id);
    const renderLabel = (option) => {
      const label = escapeHtml(option.label);
      let icon = '';
      let badge = '';
      let text = label;
      if (id === 'sidebar-issuetype') icon = getJiraIssueTypeIconSvg(option.value);
      if (id === 'sidebar-priority') icon = getJiraPriorityIconSvg(option.value);
      if (id === 'sidebar-sprint' || id.startsWith('table-sprint-')) {
        text = escapeHtml(option.value);
        badge = getSprintStateBadgeHtml(option.value);
      }
      if (!icon && !badge) return label;
      return '<span class="ozon-ext-select-content">' + icon + '<span class="ozon-ext-select-text">' + text + '</span>' + badge + '</span>';
    };
    return '<div class="ozon-ext-search-select ' + ((id === 'sidebar-sprint' || id.startsWith('table-sprint-')) ? 'ozon-ext-sprint-select ' : '') + (className || '') + '">' +
      '<button type="button" class="ozon-ext-search-select-trigger ' + (buttonClass || '') + '" data-action="toggle-search-select" data-select-id="' + safeId + '" aria-expanded="' + open + '">' +
      '<span class="ozon-ext-search-select-value">' + renderLabel(current || { value: value || '', label: value || 'Выберите значение' }) + '</span><span class="ozon-ext-search-select-caret" aria-hidden="true"></span></button>' +
      (open ? '<div class="ozon-ext-combo-popover ozon-ext-search-select-popover"><input type="search" id="ozon-search-select-search" placeholder="' + escapeHtml(placeholder || 'Поиск...') + '" value="' + escapeHtml(searchSelectQuery) + '" autocomplete="off" />' +
        '<div class="ozon-ext-combo-list">' + (filtered.length ? filtered.map(option => '<button type="button" class="ozon-ext-combo-item ozon-ext-search-select-option ' + (String(option.value) === String(value) ? 'active' : '') + '" data-action="pick-search-select" data-select-id="' + safeId + '" data-value="' + escapeHtml(option.value) + '" data-transition-id="' + escapeHtml(option.transitionId || '') + '">' + renderLabel(option) + '</button>').join('') : '<div class="ozon-ext-search-select-empty">Ничего не найдено</div>') + '</div></div>' : '') +
      '</div>';
  }

  function getFilteredTasks() {
    if (!productDashboardLoaded) return {filtered:[],doneCount:0};
    const q = searchQuery.trim().toLowerCase();
    const matching = tasks.filter((t) => {
      if (isCanceledStatus(t.status)) return false;
      if (filterIssueType !== 'all' && (t.issueTypeName || 'Задача') !== filterIssueType) return false;
      if (filterComponent !== 'all' && !(Array.isArray(t.components) && t.components.length ? t.components : [t.component || 'Без компонента']).includes(filterComponent)) return false;
      if (filterEpic !== 'all' && t.epicKey !== filterEpic) return false;
      if (filterStatus !== 'all' && t.status !== filterStatus) return false;
      if (filterSprintState !== 'all' && !matchesSprintState(getSprintStateCode(t.sprint || 'Бэклог FCRM'))) return false;
      if (!q) return true;
      return (
        t.key.toLowerCase().includes(q) ||
        t.summary.toLowerCase().includes(q) ||
        t.component.toLowerCase().includes(q) ||
        (t.issueTypeName && t.issueTypeName.toLowerCase().includes(q)) ||
        (t.epicKey && t.epicKey.toLowerCase().includes(q)) ||
        (t.epicName && t.epicName.toLowerCase().includes(q)) ||
        (t.assignee && t.assignee.name.toLowerCase().includes(q)) ||
        (t.customer && t.customer.name.toLowerCase().includes(q)) ||
        (t.sprint && t.sprint.toLowerCase().includes(q))
      );
    });
    return { filtered: hideDone ? matching.filter(t => !isDoneTask(t)) : matching, doneCount: matching.filter(isDoneTask).length };
  }

  function captureAllScrollPositions() {
    const root = document.getElementById('ozon-structure-root');
    const workspace = root ? root.querySelector('.ozon-ext-workspace') : null;
    const tablePane = document.getElementById('ozon-ext-table-pane');
    const sidebarPanel = document.getElementById('ozon-ext-sidebar-panel');
    const sidebarBody = sidebarPanel ? sidebarPanel.querySelector('.ozon-ext-sidebar-body') : null;
    return {
      rootTop: root ? root.scrollTop : 0,
      workspaceTop: workspace ? workspace.scrollTop : 0,
      tableTop: tablePane ? tablePane.scrollTop : 0,
      tableLeft: tablePane ? tablePane.scrollLeft : 0,
      sidebarTop: sidebarPanel ? sidebarPanel.scrollTop : 0,
      sidebarBodyTop: sidebarBody ? sidebarBody.scrollTop : 0,
      winY: window.scrollY || document.documentElement.scrollTop || 0,
      winX: window.scrollX || document.documentElement.scrollLeft || 0
    };
  }

  function restoreAllScrollPositions(saved) {
    if (!saved) return;
    const apply = () => {
      const root = document.getElementById('ozon-structure-root');
      if (root && saved.rootTop > 0) root.scrollTop = saved.rootTop;
      const workspace = root ? root.querySelector('.ozon-ext-workspace') : null;
      if (workspace && saved.workspaceTop > 0) workspace.scrollTop = saved.workspaceTop;
      const tablePane = document.getElementById('ozon-ext-table-pane');
      if (tablePane) {
        tablePane.scrollTop = saved.tableTop;
        tablePane.scrollLeft = saved.tableLeft;
      }
      const sidebarPanel = document.getElementById('ozon-ext-sidebar-panel');
      if (sidebarPanel) {
        sidebarPanel.scrollTop = saved.sidebarTop;
      }
      const sidebarBody = sidebarPanel ? sidebarPanel.querySelector('.ozon-ext-sidebar-body') : null;
      if (sidebarBody && saved.sidebarBodyTop > 0) {
        sidebarBody.scrollTop = saved.sidebarBodyTop;
      }
      if ((window.scrollY || 0) !== saved.winY || (window.scrollX || 0) !== saved.winX) {
        window.scrollTo(saved.winX, saved.winY);
      }
    };
    apply();
    if (typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(apply);
    }
  }

  function prepareNavigationLink(anchor) {
    const href = (anchor.getAttribute('href') || '').trim();
    if (!href || href.startsWith('#') || /^(?:javascript|mailto|tel):/i.test(href)) return;
    let url;
    try { url = new URL(href, window.location.href); } catch (_) { return; }
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
    anchor.setAttribute('target', '_blank');
    const rel = new Set((anchor.getAttribute('rel') || '').split(' ').filter(Boolean));
    rel.add('noopener'); rel.add('noreferrer');
    anchor.setAttribute('rel', Array.from(rel).join(' '));
  }

  function decorateIssueCopyButtons(root) {
    root.querySelectorAll('a[href]').forEach(prepareNavigationLink);
    root.querySelectorAll('.ozon-ext-search-select-trigger span,.ozon-ext-cell-combo-trigger span,#ozon-sb-comp-trigger span,#ozon-sb-epic-trigger span').forEach(span => {
      if (!span.children.length && /[⌕▾]/.test(span.textContent)) {
        const label = span.textContent.replace(/[⌕▾]/g,'').trim();
        span.style.display='inline-flex'; span.style.alignItems='center'; span.style.gap='5px'; span.style.fontSize='11px'; span.style.flexShrink='0';
        span.innerHTML='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg>' + escapeHtml(label) + '<span class="ozon-ext-search-select-caret" aria-hidden="true"></span>';
      }
    });
    const references = new Map();
    tasks.forEach(task => {
      references.set(task.key,task.summary);
      if (task.epicKey) references.set(task.epicKey,task.epicName || epicNameByKey[task.epicKey]);
      [...(task.projectTaskLinks || []),...(task.inProjectLinks || []),...(task.otherLinks || [])].forEach(link => references.set(link.key,link.summary));
    });
    if (activeDashboardView === 'development') developmentDashboard.copyReferences().forEach((title,key) => references.set(key,title));
    root.querySelectorAll('a[href*="/browse/"]').forEach(anchor => {
      const match = /[/]browse[/]([A-Z][A-Z0-9]*-[0-9]+)/i.exec(anchor.getAttribute('href') || '');
      if (!match || anchor.closest('.ozon-strategy-key') || anchor.nextElementSibling?.classList.contains('ozon-ext-copy-ref') || anchor.parentElement.querySelector('#ozon-copy-task-link')) return;
      const key = match[1].toUpperCase();
      const title = references.get(key) || anchor.getAttribute('title') || anchor.textContent.replace(key,'').trim();
      const button = document.createElement('button'); button.type = 'button'; button.className = 'ozon-ext-copy-ref'; button.title = 'Копировать ссылку и название'; button.setAttribute('aria-label','Копировать ' + key);
      button.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/></svg>';
      button.addEventListener('click',async event => {
        event.preventDefault(); event.stopPropagation(); const url = 'https://jit.o3.ru/browse/' + key;
        const text = '[' + key + '](' + url + ') ' + (title || '');
        try {
          if (window.ClipboardItem && navigator.clipboard.write) {
            try { await navigator.clipboard.write([new ClipboardItem({'text/plain':new Blob([text],{type:'text/plain'}),'text/html':new Blob(['<a href="' + url + '">' + key + '</a> ' + escapeHtml(title || '')],{type:'text/html'})})]); }
            catch (_) { await navigator.clipboard.writeText(text); }
          } else await navigator.clipboard.writeText(text);
          showSaveToast('✓ Ссылка и название скопированы');
        } catch (_) { showSaveToast('Не удалось скопировать ссылку: проверьте доступ к буферу обмена'); }
      });
      anchor.after(button);
    });
  }

  function closeSidebarPickers() {
    if(!sbEpicComboOpen && !sbCompComboOpen && sbIpCompOpenIdx === null && sbIpSprintOpenIdx === null && !activeSearchSelectId)return;
    sbEpicComboOpen=false;sbCompComboOpen=false;sbIpCompOpenIdx=null;sbIpSprintOpenIdx=null;activeSearchSelectId='';renderStructure();
  }
  function positionSidebarPickers(root) {
    const body=root.querySelector('#ozon-ext-sidebar-panel');
    if(body && body.dataset.pickerPositionBound!=='true') {body.dataset.pickerPositionBound='true';body.addEventListener('scroll',event=>{if(!event.target.closest?.('.ozon-ext-combo-popover'))positionSidebarPickers(root);},true);}
    root.querySelectorAll('#ozon-ext-sidebar-panel .ozon-ext-combo-popover').forEach(popover => {
      const owner=popover.parentElement;
      const trigger=owner.querySelector('.ozon-ext-search-select-trigger,.ozon-ext-sb-combo-trigger');
      if(!trigger)return;
      const anchor=trigger.getBoundingClientRect();
      const width=Math.min(Math.max(anchor.width,320),window.innerWidth-24);
      const height=Math.min(360,window.innerHeight-24);
      const left=Math.max(12,Math.min(anchor.left,window.innerWidth-width-12));
      const below=window.innerHeight-anchor.bottom-12,above=anchor.top-12;
      const useBelow=below>=Math.min(height,240) || below>=above;
      const available=Math.max(100,Math.min(height,useBelow?below:above));
      popover.style.setProperty('position','fixed','important');popover.style.setProperty('left',left+'px','important');popover.style.setProperty('right','auto','important');popover.style.setProperty('width',width+'px','important');popover.style.setProperty('min-width','0','important');popover.style.setProperty('max-height',available+'px','important');popover.style.setProperty('overflow','auto','important');popover.style.setProperty('z-index','2147483000','important');
      popover.style.setProperty('top',(useBelow?anchor.bottom+4:Math.max(12,anchor.top-Math.min(popover.scrollHeight,available)-4))+'px','important');
      if(popover.querySelector('[data-picker-close]'))return;
      const close=document.createElement('button');close.setAttribute('data-picker-close','true');close.type='button';close.className='ozon-ext-btn ozon-ext-btn-surface';close.textContent='✕';close.setAttribute('aria-label','Закрыть список');close.style.cssText='position:sticky;top:0;margin-left:auto;display:block;width:26px;min-height:26px;z-index:2;';close.addEventListener('click',event=>{event.stopPropagation();closeSidebarPickers();});popover.prepend(close);
    });
  }

  function layoutTaskAttributes(root) {
    const grid=root.querySelector('#ozon-sb-params-card > .ozon-ext-field-grid');
    if(!grid || grid.classList.contains('ozon-ext-attributes-columns'))return;
    const children=Array.from(grid.children); if(children.length!==18)return;
    const fields=[];
    for(let index=0;index<children.length;index+=2) {
      const field=document.createElement('div');field.className='ozon-ext-attribute-field';
      field.append(children[index],children[index+1]); fields.push(field);
    }
    grid.replaceChildren(...[0,3,1,4,2,5,7,8,6].map(index=>fields[index]));
    fields[6].classList.add('ozon-ext-attribute-labels');
    grid.classList.add('ozon-ext-attributes-columns');
  }

  function compactInProjectLinkRows(root) {
    const header = root.querySelector('#ozon-ext-sidebar-panel [data-sec="ip"]');
    const section = header && header.closest('.ozon-ext-section-card');
    const body = header && header.nextElementSibling;
    if (!section || !body || body.classList.contains('ozon-ext-ip-table-viewport')) return;
    body.classList.add('ozon-ext-ip-table-viewport');
    const inner = document.createElement('div'); inner.className = 'ozon-ext-ip-table-body';
    while (body.firstChild) inner.appendChild(body.firstChild);
    body.appendChild(inner);
    const headings = document.createElement('div'); headings.className = 'ozon-ext-ip-table-head';
    inner.querySelectorAll('.ozon-ext-link-group-header').forEach(group => group.remove());
    headings.innerHTML = '<span>Задача · Приоритет</span><span>Эпик</span><span>Статус</span><span>Компонент</span><span>Спринт</span><span>Действия</span>';
    inner.prepend(headings);
    let widths = [470,90,125,200,245,70];
    try { const saved = JSON.parse(localStorage.getItem('ozon-ip-column-widths-v3') || 'null'); if (Array.isArray(saved) && saved.length === 6 && saved.every(value => Number.isFinite(value) && value >= 60)) widths = saved; } catch (_) {}
    const applyWidths = () => { const weights=[...widths]; weights[0]=Math.max(weights[0],...weights.slice(1).map(value=>value*1.6)); inner.style.setProperty('--ozon-ip-columns',weights.map(value => 'minmax(0,' + value + 'fr)').join(' ')); inner.style.setProperty('--ozon-ip-width','0px'); };
    applyWidths();
    Array.from(headings.children).forEach((cell,index) => {
      const handle = document.createElement('span'); handle.className = 'ozon-ip-column-resizer'; handle.setAttribute('role','separator'); handle.setAttribute('aria-label','Ширина: ' + cell.textContent); handle.tabIndex = 0;
      const save = () => { try { localStorage.setItem('ozon-ip-column-widths-v3',JSON.stringify(widths)); } catch (_) {} };
      handle.addEventListener('pointerdown',event => { event.preventDefault(); event.stopPropagation(); const start = event.clientX, width = widths[index];
        const move = ev => { widths[index] = Math.max(index === 0 ? 180 : 60,width + ev.clientX-start); applyWidths(); };
        const end = () => { document.removeEventListener('pointermove',move); document.removeEventListener('pointerup',end); save(); };
        document.addEventListener('pointermove',move); document.addEventListener('pointerup',end);
      });
      handle.addEventListener('keydown',event => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); widths[index] = Math.max(index === 0 ? 180 : 60,widths[index]+(event.key === 'ArrowRight' ? 10 : -10)); applyWidths(); save(); } });
      cell.appendChild(handle);
    });
    inner.querySelectorAll('.ozon-ext-link-compact-row').forEach(row => {
      const first = row.children[0];
      const detail = Array.from(row.children).find(child => child.querySelector('.ozon-ext-sb-combo'));
      if (!first || !detail) return;
      const left = first.children[0], actions = first.children[1];
      const component = detail.querySelector('.ozon-ext-sb-combo');
      const sprint = detail.querySelector('.ozon-ext-sb-combo:last-child');
      if (!left || !actions || !component || !sprint) return;
      const epic = document.createElement('div'); epic.className='ozon-ext-ip-epic-cell';
      const epicRef = Array.from(left.children).find(child => child.tagName === 'SPAN' && String(child.getAttribute('title') || '').startsWith('Эпик:'));
      if (epicRef) { const key=epicRef.textContent.trim(); const anchor=document.createElement('a'); anchor.href='/browse/'+encodeURIComponent(key); anchor.className='ozon-mono'; anchor.textContent=key; anchor.title=epicRef.title; epic.appendChild(anchor); epicRef.remove(); } else epic.textContent='—';
      const secondary = Array.from(row.children).filter(child => child !== first && child !== detail);
      const status = document.createElement('div'); const badge = actions.querySelector('.ozon-ext-badge');
      if (badge) { status.appendChild(badge); if (/готово|закрыт|done|closed/i.test(badge.textContent)) row.classList.add('completed'); }
      Array.from(left.children).filter(child => child.tagName === 'SPAN' && child.style.textOverflow === 'ellipsis').forEach(child => child.classList.add('ozon-ip-summary'));
      left.classList.add('ozon-ext-ip-task-cell'); actions.classList.add('ozon-ext-ip-action-cell');
      row.classList.add('ozon-ext-ip-table-row'); row.replaceChildren(left,epic,status,component,sprint,actions);
      secondary.forEach(child => { child.classList.add('ozon-ext-ip-table-secondary'); row.appendChild(child); });
      const trigger = component.querySelector('button'); const label = trigger && trigger.querySelector('span');
      if (label) { label.textContent = label.textContent.replace(/^.*?: /, ''); trigger.title = 'Компонент: ' + label.textContent; }
    });
  }

  const taskDetailsSidebar = (function createTaskDetailsSidebar(parts) {
    return {
        html: () => parts.html(),
        bind(root) {
            // The table and sidebar controls are replaced on each render, even when
            // the surrounding dashboard remains mounted.
            parts.bindControls(root);
            const panel = root.querySelector('#ozon-ext-sidebar-panel');
            if (!panel)
                return;
            // Product view keeps the aside but replaces its contents. Bind the new DOM generation.
            const content = panel.firstElementChild;
            if (!content || content.dataset.detailsBound === 'true')
                return;
            content.dataset.detailsBound = 'true';
            parts.enhance(root);
            parts.bindEvents(root);
            parts.bindSearch(root);
            parts.afterBind?.(root);
        }
    };
})({
    html: buildSidebarHtml,
    bindEvents: bindSidebarEvents,
    bindSearch: bindTicketSearchEvents,
    afterBind: positionSidebarPickers,
    bindControls: bindSharedTaskControls,
    enhance: root => { layoutTaskAttributes(root); compactInProjectLinkRows(root); }
  });

  function renderDashboardNavigation() {
    return '<nav class="ozon-ext-view-tabs" role="tablist" aria-label="Представление"><button type="button" role="tab" data-dashboard-view="product" aria-selected="' + (activeDashboardView === 'product') + '">Продуктовый бэклог</button><button type="button" role="tab" data-dashboard-view="development" aria-selected="' + (activeDashboardView === 'development') + '">Команды разработки</button><button type="button" role="tab" data-dashboard-view="strategy" aria-selected="' + (activeDashboardView === 'strategy') + '">Стратегическое планирование</button></nav>';
  }

  function bindDashboardNavigation(root) {
    root.querySelectorAll('[data-dashboard-view]').forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      const view = button.getAttribute('data-dashboard-view');
      if (view === activeDashboardView) return;
      developmentDashboard.cancel();
      activeDashboardView = view;
      activeToolbarFilter = '';
      activeSearchSelectId = '';
      activeTableCombo = null;
      renderStructure();
      if (view === 'strategy') strategicDashboard.prepareFilters();
      if (view === 'product') prepareProductFilters();
    }));
  }

  function renderStructure() {
    let root = document.getElementById('ozon-structure-root');
    if (!isTargetBoardPage() || !isStructureVisible) {
      if (root) root.style.display = 'none';
      return;
    }
    if (!root) {
      root = document.createElement('div');
      root.id = 'ozon-structure-root';
      document.body.appendChild(root);
    }
    root.style.display = 'flex';

    if (activeDashboardView === 'strategy') {
      const sidebarScroll = captureAllScrollPositions();
      const scroll = root.querySelector('.ozon-strategy-scroll');
      const scrollTop = scroll ? scroll.scrollTop : 0;
      const scrollLeft = scroll ? scroll.scrollLeft : 0;
      root.innerHTML = renderDashboardNavigation() + strategicDashboard.html();
      root.querySelector('.ozon-strategy-dashboard')?.insertAdjacentHTML('beforeend',taskDetailsSidebar.html());
      bindDashboardNavigation(root);
      strategicDashboard.bind(root);
      taskDetailsSidebar.bind(root);
      decorateIssueCopyButtons(root);
      restoreAllScrollPositions(sidebarScroll);
      positionSidebarPickers(root);
      const nextScroll = root.querySelector('.ozon-strategy-scroll');
      if (nextScroll) { nextScroll.scrollTop = scrollTop; nextScroll.scrollLeft = scrollLeft; }
      return;
    }

    if (activeDashboardView === 'development') {
      const sidebarScroll = captureAllScrollPositions();
      const tableScroll = root.querySelector('.ozon-dev-table-scroll');
      const scrollTop = tableScroll ? tableScroll.scrollTop : 0;
      const scrollLeft = tableScroll ? tableScroll.scrollLeft : 0;
      root.innerHTML = renderDashboardNavigation() + developmentDashboard.html();
      root.querySelector('.ozon-dev-content').insertAdjacentHTML('beforeend',taskDetailsSidebar.html());
      bindDashboardNavigation(root);
      developmentDashboard.bind(root);
      taskDetailsSidebar.bind(root);
      decorateIssueCopyButtons(root);
      const updatedScroll = root.querySelector('.ozon-dev-table-scroll');
      if (updatedScroll) { updatedScroll.scrollTop = scrollTop; updatedScroll.scrollLeft = scrollLeft; }
      restoreAllScrollPositions(sidebarScroll);
      positionSidebarPickers(root);
      return;
    }

    // Сохраняем позицию скролла ВСЕХ контейнеров до любых изменений DOM
    const savedScroll = captureAllScrollPositions();

    const { filtered, doneCount } = getFilteredTasks();
    const rowsHtml = buildTableRowsHtml(filtered);
    const sidebarHtml = taskDetailsSidebar.html();
    const totalTableW = getTotalTableWidth();

    const allComponents = getAllComponentOptions();
    const epicMap = getAllEpicOptions();
    const epicKeys = Object.keys(epicMap);
    const allStatuses = Array.from(new Set([...projectStatusesList, ...(productDashboardLoaded ? tasks.map((t) => t.status).filter(Boolean) : [])])).filter((s) => !isCanceledStatus(s));
    const componentFilterOptions = [{ value: 'all', label: 'Компонент: Все' }, ...allComponents.map(c => ({ value: c, label: c }))];
    const epicFilterOptions = [{ value: 'all', label: 'Эпик: Все' }, ...epicKeys.map(k => ({ value: k, label: k + ' · ' + (epicMap[k] || '') }))];
    const statusFilterOptions = [{ value: 'all', label: 'Статус: Все' }, ...allStatuses.map(status => ({ value: status, label: status }))];
    const issueTypeFilterOptions = [{ value: 'all', label: 'Тип запроса: Все' }, ...Array.from(new Set([...projectIssueTypesList.map(type => type.name), ...(productDashboardLoaded ? tasks.map(task => task.issueTypeName || 'Задача') : [])])).sort((a,b) => a.localeCompare(b, 'ru')).map(name => ({ value: name, label: name }))];
    const treeLevelOptions = [
      ...(productGroupingOrder.length ? [{ value: 'sprints', label: 'Уровень: ' + (productGroupingOrder[0] === 'sprint' ? 'Спринты' : 'Компоненты') }] : []),
      ...(productGroupingOrder.length > 1 ? [{ value: 'components', label: 'Уровень: ' + (productGroupingOrder[1] === 'sprint' ? 'Спринты' : 'Компоненты') }] : []),
      { value: 'tasks', label: 'Уровень: Задачи' },
      { value: 'links', label: 'Уровень: Все связи' }
    ];
    const sprintFilterOptions = [
      { value: 'open_future_backlog', label: 'Спринты: Активные, будущие и бэклог' },
      { value: 'open_future', label: 'Спринты: Активные и будущие' },
      { value: 'ACTIVE', label: 'Спринты: Только активные' },
      { value: 'FUTURE', label: 'Спринты: Только будущие' },
      { value: 'BACKLOG', label: 'Спринты: Только бэклог' },
      { value: 'CLOSED', label: 'Спринты: Только прошедшие' },
      { value: 'all', label: 'Спринты: Все, включая прошедшие' },
    ];
    const sortFilterOptions = [
      { value: 'default', label: 'Сортировка: По умолчанию' },
      { value: 'priority_desc', label: 'Приоритет: Сначала высокий' },
      { value: 'priority_asc', label: 'Приоритет: Сначала низкий' },
      { value: 'created_desc', label: 'Дата: Сначала новые' },
      { value: 'created_asc', label: 'Дата: Сначала старые' },
    ];

    const activeElId = document.activeElement ? document.activeElement.id : null;
    const selStart = document.activeElement && 'selectionStart' in document.activeElement ? document.activeElement.selectionStart : null;
    const selEnd = document.activeElement && 'selectionEnd' in document.activeElement ? document.activeElement.selectionEnd : null;

    const colOrderPanelHtml = isColOrderPanelOpen
      ? `<div style="padding:0;" onclick="event.stopPropagation();">
           <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
             <strong style="font-size:11px;color:#071026;">Настройка порядка столбцов</strong>
             <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-ext-reset-col-order" style="height:20px;padding:1px 6px;font-size:10px;">По умолчанию</button>
           </div>
           <div style="display:flex;flex-direction:column;gap:3px;max-height:280px;overflow-y:auto;">
             ${columnOrder
               .map((colId, idx) => {
                 const meta = colId === 'task' ? {label: 'Задача (' + [...productGroupingOrder.map((field) => field === 'sprint' ? 'Спринт' : 'Компонент'), 'Задача'].join(' → ') + ')'} : (COLUMN_META[colId] || { label: colId });
                 return `
                   <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;padding:3px 6px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;font-size:11px;">
                     <span style="color:#071026;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${idx + 1}. ${escapeHtml(meta.label)}</span>
                     <div style="display:flex;gap:3px;flex-shrink:0;">
                       <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="move-col-left" data-col-idx="${idx}" ${idx === 0 ? 'disabled style="opacity:0.35;padding:1px 6px;height:20px;"' : 'style="padding:1px 6px;height:20px;"'} title="Сдвинуть левее">◀</button>
                       <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-action="move-col-right" data-col-idx="${idx}" ${idx === columnOrder.length - 1 ? 'disabled style="opacity:0.35;padding:1px 6px;height:20px;"' : 'style="padding:1px 6px;height:20px;"'} title="Сдвинуть правее">▶</button>
                     </div>
                   </div>
                 `;
               })
               .join('')}
           </div>
         </div>`
      : '';

    const topBarsHtml = `
      ${renderDashboardNavigation()}
      <div class="ozon-ext-header-bar">
        <div style="display:flex;align-items:center;gap:20px;">
          <strong style="font-size:13.5px;font-weight:700;color:#071026;font-family:var(--ozon-font-display);letter-spacing:-0.01em;">Ozon Bank · FCRM Structure <small title="Версия установленного расширения" style="margin-left:4px;font:500 11px sans-serif;color:#475569;">v3.5.156</small></strong>
          <a href="#all-sprints" id="ozon-ext-show-all-sprints" style="color:#005BFF;font-size:12px;font-weight:600;text-decoration:none;">Все спринты${productDashboardLoaded ? ' (' + tasks.filter((t) => !isCanceledStatus(t.status)).length + ')' : ''}</a>
          <span style="font-size:11px;color:#64748B;display:inline-flex;align-items:center;gap:4px;" title="Красная скрепка отмечает задачи без привязанной «Задачи проекта»">
            ${getMissingProjectTaskWarnSvg()} <span>— нет «Задачи проекта»</span>
          </span>
          <span style="font-size:11px;color:#64748B;display:inline-flex;align-items:center;gap:4px;" title="Красный человечек отмечает задачи без назначенного Исполнителя">
            ${getMissingAssigneeWarnSvg()} <span>— нет Исполнителя</span>
          </span>
          <span id="ozon-ext-toast" class="ozon-ext-badge ozon-ext-badge-done" style="display:${saveToastText ? 'inline-flex' : 'none'};font-size:11px;padding:2px 8px;">${escapeHtml(saveToastText)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;font-size:11px;color:#64748B;">
          <span>${escapeHtml(statusMessage.replace(/^Спринт → Компонент/, productGroupingOrder.length ? productGroupingOrder.map((field) => field === 'sprint' ? 'Спринт' : 'Компонент').join(' → ') : 'Без группировки'))}</span>
          <button type="button" class="ozon-ext-btn" id="ozon-thread-create">Создать FCRM из треда</button>

        </div>
      </div>

      <div class="ozon-ext-filter-bar">
        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
          <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-ext-toggle-col-order"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 7h16M4 17h16M8 4v6M16 14v6"/></svg> Настройки</button>

          ${renderToolbarFilter("sprint", "Спринты", filterSprintState, sprintFilterOptions, "Поиск режима спринтов...")}
          <button type="button" class="ozon-ext-btn" id="ozon-ext-reload-board" ${isInitialBoardLoading ? 'disabled' : ''}>${isInitialBoardLoading ? 'Загружаем…' : productDashboardLoaded ? 'Обновить задачи' : 'Загрузить задачи'}</button>
          <span class="ozon-product-filter-hint">${isInitialBoardLoading ? 'Загружаем задачи…' : productDashboardLoaded ? 'Фильтры по загруженным задачам' : '1. Выберите спринты → 2. Загрузите задачи'}</span>
          <div class="ozon-product-optional-filters" style="display:contents;">
          <div style="position:relative;width:240px;">
            <input ${!productDashboardLoaded || isInitialBoardLoading ? 'disabled' : ''} id="ozon-ext-search" type="search" value="${escapeHtml(searchQuery)}" placeholder="Поиск по ключу, задаче, типу, Заказчик/Owner..." style="width:100%;height:26px;padding-left:10px;" />
          </div>

          ${renderToolbarFilter("component", "Компонент: Все", filterComponent, componentFilterOptions, "Поиск компонента...")}

          ${renderToolbarFilter("epic", "Эпик: Все", filterEpic, epicFilterOptions, "Поиск эпика по коду или названию...")}

          ${renderToolbarFilter("status", "Статус: Все", filterStatus, statusFilterOptions, "Поиск статуса...")}



          <button type="button" ${!productDashboardLoaded || isInitialBoardLoading ? 'disabled' : ''} id="ozon-ext-toggle-done" aria-pressed="${hideDone}" class="ozon-ext-btn ${hideDone ? '' : 'ozon-ext-btn-surface'}">${doneToggleLabel(doneCount)}</button>
          ${renderToolbarFilter('issue-type', 'Тип запроса: Все', filterIssueType, issueTypeFilterOptions, 'Поиск типа запроса...')}



          ${
            searchQuery || filterComponent !== 'all' || filterEpic !== 'all' || filterStatus !== 'all' || filterSprintState !== 'open_future_backlog' || hideDone || filterIssueType !== 'all' || sortByField !== 'default'
              ? '<button type="button" class="ozon-ext-btn ozon-ext-btn-negative" id="ozon-ext-reset-filters">Сбросить</button>'
              : ''
          }
          </div>
        </div>

        ${isColOrderPanelOpen ? `<aside class="ozon-ext-product-settings" role="dialog" aria-label="Настройки таблицы" style="position:fixed;inset:0 0 0 auto;width:390px;max-width:100vw;z-index:2147483645;display:flex;flex-direction:column;gap:16px;padding:20px;background:#fff;box-shadow:-8px 0 32px #07102620;overflow:auto;">
          <div style="display:flex;align-items:center;justify-content:space-between;"><strong>Настройки таблицы</strong><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-ext-close-settings" aria-label="Закрыть">✕</button></div>
          <div><strong>Уровень раскрытия</strong><div style="margin-top:8px;">${renderToolbarFilter('tree', 'Уровень раскрытия', tableTreeLevel, treeLevelOptions, 'Поиск уровня...')}</div></div>
          <div><strong>Сортировка</strong><div style="margin-top:8px;">${renderToolbarFilter("sort", "Сортировка", sortByField, sortFilterOptions, "Поиск варианта сортировки...")}</div></div>
          <div><strong>Группировка</strong><p style="font-size:11px;color:#64748B;margin:7px 0;">Выберите поля и их порядок.</p>${[...productGroupingOrder, ...['sprint','component'].filter((field) => !productGroupingOrder.includes(field))].map((field) => { const i = productGroupingOrder.indexOf(field); const label = field === 'sprint' ? 'Спринт' : 'Компонент'; return '<div style="display:flex;align-items:center;gap:8px;padding:5px 0"><label style="display:flex;align-items:center;gap:8px;flex:1;cursor:pointer"><input type="checkbox" data-product-group="' + field + '" ' + (i >= 0 ? 'checked' : '') + '><span>' + label + '</span></label><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-product-move="' + field + '" data-direction="-1" aria-label="Переместить ' + label + ' выше" ' + (i <= 0 ? 'disabled' : '') + '>↑</button><button type="button" class="ozon-ext-btn ozon-ext-btn-surface" data-product-move="' + field + '" data-direction="1" aria-label="Переместить ' + label + ' ниже" ' + (i < 0 || i === productGroupingOrder.length - 1 ? 'disabled' : '') + '>↓</button></div>'; }).join('')}</div>
          <div><strong>Столбцы</strong><p style="font-size:11px;color:#64748B;">Ширину можно менять за границу заголовка таблицы.</p>${colOrderPanelHtml}</div>
          <button type="button" class="ozon-ext-btn ozon-ext-btn-surface" id="ozon-ext-reset-cols">Сбросить ширину</button>
          <button type="button" class="ozon-ext-btn" id="ozon-ext-done-settings">Готово</button>
        </aside>` : ''}
      </div>
    `;

    const colgroupHtml = columnOrder
      .map((colId) => {
        const w = Number(colWidths[colId]) || 130;
        return `<col data-col="${escapeHtml(colId)}" style="width:${w}px" />`;
      })
      .join('');

    const theadRowHtml = columnOrder
      .map((colId) => {
        const w = Number(colWidths[colId]) || 130;
        const meta = colId === 'task' ? { label: 'Задача (' + [...productGroupingOrder.map((field) => field === 'sprint' ? 'Спринт' : 'Компонент'), 'Задача'].join(' → ') + ')', accent: false } : (COLUMN_META[colId] || { label: colId, accent: false });
        return `<th data-col="${escapeHtml(colId)}" draggable="true" title="Перетащите заголовок для изменения порядка столбцов" style="width:${w}px;min-width:${w}px;max-width:${w}px;cursor:grab;${meta.accent ? 'color:#005BFF !important;' : ''}">${escapeHtml(meta.label)}<div class="ozon-ext-col-resizer" data-col="${escapeHtml(colId)}"></div></th>`;
      })
      .join('');

    const existingTablePane = document.getElementById('ozon-ext-table-pane');
    const existingTopBars = document.getElementById('ozon-ext-top-bars');
    const existingWorkspace = document.getElementById('ozon-ext-workspace');

    // Если каркас уже создан — обновляем ТОЛЬКО внутренние узлы, НЕ уничтожая скролл-контейнеры (#ozon-ext-table-pane и #ozon-ext-sidebar-panel)!
    if (existingTablePane && existingTopBars && existingWorkspace) {
      existingTopBars.innerHTML = topBarsHtml;

      const mainTable = document.getElementById('ozon-ext-main-table');
      if (mainTable) {
        mainTable.style.setProperty('width', 'max(100%, ' + totalTableW + 'px)', 'important');
        mainTable.style.setProperty('min-width', totalTableW + 'px', 'important');
        mainTable.style.setProperty('max-width', 'none', 'important');
      }
      const colgroupEl = document.getElementById('ozon-ext-colgroup');
      if (colgroupEl) colgroupEl.innerHTML = colgroupHtml;
      const theadTrEl = document.getElementById('ozon-ext-thead-tr');
      if (theadTrEl) theadTrEl.innerHTML = theadRowHtml;
      const tbodyEl = document.getElementById('ozon-ext-tbody');
      if (tbodyEl) tbodyEl.innerHTML = rowsHtml;

      const existingSbPanel = document.getElementById('ozon-ext-sidebar-panel');
      const existingSbResizer = document.getElementById('ozon-ext-sidebar-resizer');

      if (!sidebarHtml) {
        if (existingSbResizer) existingSbResizer.remove();
        if (existingSbPanel) existingSbPanel.remove();
      } else if (existingSbPanel) {
        // Обновляем внутренности существующего <aside id="ozon-ext-sidebar-panel"> без пересоздания самого скролл-элемента!
        const currentImproveButton = existingSbPanel.querySelector('.o3ds-btn');
        const keepImproveButton = currentImproveButton && currentImproveButton.getAttribute('data-issue-key') === selectedTaskKey;
        if (keepImproveButton) currentImproveButton.remove();
        const tmp = document.createElement('div');
        tmp.innerHTML = sidebarHtml;
        const parsedAside = tmp.querySelector('#ozon-ext-sidebar-panel');
        if (parsedAside) {
          existingSbPanel.style.width = sidebarWidth + 'px';
          existingSbPanel.innerHTML = parsedAside.innerHTML;
          const refreshedSummaryInput = existingSbPanel.querySelector('#ozon-sb-summary');
          if (keepImproveButton && refreshedSummaryInput) {
            refreshedSummaryInput.dataset.o3dsMounted = '1';
            refreshedSummaryInput.insertAdjacentElement('afterend', currentImproveButton);
          }
        }
      } else {
        const tmp = document.createElement('div');
        tmp.innerHTML = sidebarHtml;
        while (tmp.firstChild) {
          existingWorkspace.appendChild(tmp.firstChild);
        }
      }
    } else {
      root.innerHTML = `
        <div id="ozon-ext-top-bars" style="flex-shrink:0;">
          ${topBarsHtml}
        </div>
        <div class="ozon-ext-workspace" id="ozon-ext-workspace">
          <div class="ozon-ext-table-pane" id="ozon-ext-table-pane">
            <table class="ozon-ext-table" id="ozon-ext-main-table" style="width:max(100%, ${totalTableW}px) !important;min-width:${totalTableW}px !important;max-width:none !important;">
              <colgroup id="ozon-ext-colgroup">
                ${colgroupHtml}
              </colgroup>
              <thead>
                <tr id="ozon-ext-thead-tr">
                  ${theadRowHtml}
                </tr>
              </thead>
              <tbody id="ozon-ext-tbody">
                ${rowsHtml}
              </tbody>
            </table>
          </div>
          ${sidebarHtml}
        </div>
      `;
    }

    // Восстанавливаем позицию прокрутки левой панели задач и правого сайдбара
    restoreAllScrollPositions(savedScroll);

    decorateIssueCopyButtons(root);
    bindStructureEvents(root);
    bindDashboardNavigation(root);

    // Автоматически подстраиваем высоту описания под текст (если открыт режим редактирования)
    const descEl = document.getElementById('ozon-sb-description');
    if (descEl) {
      descEl.style.height = 'auto';
      descEl.style.height = Math.max(90, descEl.scrollHeight) + 'px';
    }

    if (activeElId) {
      const restored = document.getElementById(activeElId);
      if (restored) {
        try {
          restored.focus({ preventScroll: true });
        } catch (e) {
          restored.focus();
        }
        if (selStart !== null && 'setSelectionRange' in restored) {
          try {
            restored.setSelectionRange(selStart, selEnd);
          } catch (e) {}
        }
      }
    }

    restoreAllScrollPositions(savedScroll);
    positionSidebarPickers(root);
  }

  async function refreshLinksWithoutSkeleton(sourceKey) {
    const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(sourceKey) + '?fields=' + getBoardFieldsParam(), { credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'} });
    if (!response.ok) throw new Error('Связь сохранена, но не удалось обновить список.');
    const raw = await response.json();
    await syncStrategyLinks(raw);
    syncStrategyIssue(raw);
    const [enriched, remoteLinks] = await Promise.all([normalizeAndEnrichJiraIssues([raw]), loadRemoteIssueLinks(sourceKey)]);
    if (!enriched[0]) throw new Error('Связь сохранена, но не удалось обновить список.');
    const updated = enriched[0];
    tasks = tasks.map((item) => item.key === sourceKey ? Object.assign({}, item, {projectTaskLinks:updated.projectTaskLinks, inProjectLinks:updated.inProjectLinks, otherLinks:[...(updated.otherLinks || []), ...remoteLinks]}) : item);
    renderStructure();
  }

  function bindTicketSearchEvents(root) {
    root.querySelectorAll('[data-thread-link-url]').forEach(button => {
      button.addEventListener('click', async () => {
        const source = button.getAttribute('data-issue-key');
        const url = button.getAttribute('data-thread-link-url');
        try {
          if (!source || !url || !['http:', 'https:'].includes(new URL(url).protocol)) throw new Error('Некорректная ссылка на сообщение');
          button.disabled = true;
          const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(source) + '/remotelink', {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({object:{url,title:'Сообщение chatZone'}})});
          if (!response.ok) throw new Error('Jira вернула ошибку ' + response.status);
          try { await refreshLinksWithoutSkeleton(source); } catch (error) { showSaveToast(error.message); return; }
          showSaveToast('✓ Ссылка на сообщение добавлена');
        } catch (error) { button.disabled = false; showSaveToast('Не удалось добавить ссылку: ' + (error.message || error)); }
      });
    });
    root.querySelectorAll('[data-similar-link]').forEach(button => {
      button.addEventListener('click', async () => {
        const source = button.getAttribute('data-issue-key');
        const target = button.getAttribute('data-similar-link');
        if (!source || !target || source === target) { showSaveToast('Выберите другую задачу'); return; }
        button.disabled = true;
        try {
          const linked = await createIssueLinkInJira(source, target, 'linkedTask', true, true);
          if (linked) { try { await refreshLinksWithoutSkeleton(source); } catch (error) { showSaveToast(error.message); return; } showSaveToast('Связь создана'); }
          else button.disabled = false;
        } catch (error) { button.disabled = false; showSaveToast('Не удалось создать связь: ' + (error.message || error)); }
      });
    });
    root.querySelectorAll('[data-ticket-search-toggle]').forEach(button => {
      button.addEventListener('click', () => {
        const state = getTicketSearchState(button.getAttribute('data-issue-key'), button.getAttribute('data-ticket-search-toggle'));
        state.open = !state.open;
        renderStructure();
      });
    });
    root.querySelectorAll('[data-ticket-search-channels]').forEach(input => {
      input.addEventListener('input', () => {
        getTicketSearchState(input.getAttribute('data-ticket-search-channels'), 'threads').channels = input.value;
      });
    });
    root.querySelectorAll('[data-ticket-search-run]').forEach(button => {
      button.addEventListener('click', async () => {
        const key = button.getAttribute('data-issue-key');
        const kind = button.getAttribute('data-ticket-search-run');
        const state = getTicketSearchState(key, kind);
        if (state.loading) return;
        state.error = '';
        if (kind === 'threads') {
          try {
            addThreadChannels(state);
            const queue = state.choices.filter(choice => choice.checked).map(choice => choice.url);
            if (!queue.length) throw new Error('Выберите хотя бы один канал');
            state.queue = queue;
            state.index = 0;
            state.history = [];
            state.reply = '';
            await runThreadChannelStep(key);
          } catch (error) {
            state.error = String(error.message || error);
            renderStructure();
          }
          return;
        }
        state.loading = true;
        state.items = null;
        state.errors = [];
        state.raw = '';
        renderStructure();
        try {
          const text = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) { reject(new Error('Поиск доступен в установленном расширении Chrome')); return; }
            chrome.runtime.sendMessage({type:'o3ds:chat', mode:'search_fcrm', issueKey:key, approvedDescription:'{}'}, response => {
              const error = chrome.runtime.lastError;
              if (error || !response?.ok) reject(new Error(error?.message || response?.error || 'Нет ответа DeepSeek'));
              else resolve(response.text || '');
            });
          });
          try {
            const result = parseTicketSearchResponse(String(text), kind, key);
            state.items = result.items;
            state.errors = result.errors;
          } catch (error) {
            state.error = String(error.message || error);
            state.raw = String(text);
          }
        } catch (error) {
          state.error = String(error.message || error);
        } finally {
          state.loading = false;
          if (selectedTaskKey === key) renderStructure();
        }
      });
    });
    root.querySelectorAll('[data-thread-channel-check]').forEach(input => {
      input.addEventListener('change', () => {
        const state = getTicketSearchState(input.getAttribute('data-issue-key'), 'threads');
        if (state.loading || state.queue.length) return;
        state.choices[Number(input.getAttribute('data-thread-channel-check'))].checked = input.checked;
      });
    });
    root.querySelectorAll('[data-thread-channel-move]').forEach(button => {
      button.addEventListener('click', () => {
        const state = getTicketSearchState(button.getAttribute('data-issue-key'), 'threads');
        if (state.loading || state.queue.length) return;
        const from = Number(button.getAttribute('data-thread-channel-move'));
        const to = from + Number(button.getAttribute('data-direction'));
        if (to < 0 || to >= state.choices.length) return;
        const [choice] = state.choices.splice(from, 1);
        state.choices.splice(to, 0, choice);
        renderStructure();
      });
    });
    root.querySelectorAll('[data-thread-channel-row]').forEach(row => {
      row.addEventListener('dragstart', event => {
        const key = row.getAttribute('data-issue-key');
        const state = getTicketSearchState(key, 'threads');
        if (state.loading || state.queue.length) { event.preventDefault(); return; }
        draggedThreadChannel = { key, index: Number(row.getAttribute('data-thread-channel-row')) };
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', String(draggedThreadChannel.index));
      });
      row.addEventListener('dragover', event => {
        if (!draggedThreadChannel || draggedThreadChannel.key !== row.getAttribute('data-issue-key')) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
      });
      row.addEventListener('drop', event => {
        event.preventDefault();
        const key = row.getAttribute('data-issue-key');
        const state = getTicketSearchState(key, 'threads');
        if (!draggedThreadChannel || draggedThreadChannel.key !== key || state.loading || state.queue.length) return;
        const [choice] = state.choices.splice(draggedThreadChannel.index, 1);
        state.choices.splice(Number(row.getAttribute('data-thread-channel-row')), 0, choice);
        draggedThreadChannel = null;
        renderStructure();
      });
      row.addEventListener('dragend', () => { draggedThreadChannel = null; });
    });
    root.querySelectorAll('[data-thread-channels-add]').forEach(button => {
      button.addEventListener('click', () => {
        const state = getTicketSearchState(button.getAttribute('data-issue-key'), 'threads');
        if (state.loading || state.queue.length) return;
        try { addThreadChannels(state); state.error = ''; }
        catch (error) { state.error = String(error.message || error); }
        renderStructure();
      });
    });
    root.querySelectorAll('[data-thread-search-next]').forEach(button => {
      button.addEventListener('click', () => {
        const key = button.getAttribute('data-issue-key');
        const state = getTicketSearchState(key, 'threads');
        if (state.loading || state.index + 1 >= state.queue.length) return;
        state.index++;
        runThreadChannelStep(key);
      });
    });
    root.querySelectorAll('[data-thread-search-retry]').forEach(button => {
      button.addEventListener('click', () => {
        const key = button.getAttribute('data-issue-key');
        const index = Number(button.getAttribute('data-thread-search-retry'));
        if (!Number.isInteger(index) || index < 0) return;
        runThreadChannelStep(key, '', index);
      });
    });
    root.querySelectorAll('[data-thread-search-reset]').forEach(button => {
      button.addEventListener('click', () => {
        const state = getTicketSearchState(button.getAttribute('data-issue-key'), 'threads');
        if (state.loading) return;
        state.queue = [];
        state.index = -1;
        state.error = '';
        renderStructure();
      });
    });
    root.querySelectorAll('[data-thread-search-reply]').forEach(input => {
      input.addEventListener('input', () => {
        const key = input.getAttribute('data-thread-search-reply');
        const state = getTicketSearchState(key, 'threads');
        state.reply = input.value;
        const button = root.querySelector('[data-thread-search-answer][data-issue-key="' + key + '"]');
        if (button) button.disabled = state.loading || !state.reply.trim();
      });
    });
    root.querySelectorAll('[data-thread-search-answer]').forEach(button => {
      button.addEventListener('click', () => {
        const key = button.getAttribute('data-issue-key');
        const state = getTicketSearchState(key, 'threads');
        if (state.loading || !state.reply.trim()) return;
        runThreadChannelStep(key, state.reply.trim());
      });
    });
  }

  function bindSharedTaskControls(root) {
    root.querySelectorAll('[data-action="generate-links"]').forEach(button => {
      button.addEventListener('click', async event => {
        event.stopPropagation();
        const keys = Array.from(new Set((button.getAttribute('data-task-keys') || '').split(',').filter(key => key && !generatingLinkKeys.has(key))));
        if (!keys.length) {
          showLinksSnackbar('Эти задачи уже обрабатываются');
          return;
        }
        keys.forEach(key => generatingLinkKeys.add(key));
        const results = [];
        const updateSnackbar = showLinksSnackbar('Генерирую связи для ' + keys.length + ' задач. Можно продолжать работу.');
        renderStructure();
        try {
          for (let i = 0; i < keys.length; i++) {
            const key = keys[i];
            try {
              const text = await new Promise((resolve, reject) => {
                if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
                  reject(new Error('Генерация доступна в установленном расширении Chrome'));
                  return;
                }
                chrome.runtime.sendMessage({ type: 'o3ds:chat', mode: 'links', issueKey: key }, response => {
                  const error = chrome.runtime.lastError;
                  if (error || !response?.ok) reject(new Error(error?.message || response?.error || 'Нет ответа DeepSeek'));
                  else resolve(response.text || 'DeepSeek вернул пустой ответ');
                });
              });
              results.push(key + '\n' + text);
              await refreshGeneratedTaskLinks(key);
            } catch (error) {
              results.push(key + ' · Ошибка: ' + String(error.message || error));
            } finally {
              generatingLinkKeys.delete(key);
              updateSnackbar(results.map(result => renderStructuredAnswer(result, 'links', renderAnswerMarkup)).join(''), true);
              renderStructure();
            }
          }
        } finally {
          keys.forEach(key => generatingLinkKeys.delete(key));
        }
      });
    });

    root.querySelectorAll('[data-action="toggle-search-select"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        const id = button.getAttribute('data-select-id') || '';
        activeSearchSelectId = activeSearchSelectId === id ? '' : id;
        searchSelectQuery = '';
        activeToolbarFilter = '';
        sbEpicComboOpen = false;
        sbCompComboOpen = false;
        sbIpCompOpenIdx = null;
        sbIpSprintOpenIdx = null;
        renderStructure();
        if (activeSearchSelectId) document.getElementById('ozon-search-select-search')?.focus();
      });
    });
    const searchSelectInput = document.getElementById('ozon-search-select-search');
    if (searchSelectInput) {
      searchSelectInput.addEventListener('click', (event) => event.stopPropagation());
      searchSelectInput.addEventListener('input', (event) => {
        searchSelectQuery = event.target.value;
        renderStructure();
      });
    }
    root.querySelectorAll('[data-action="pick-search-select"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        const id = button.getAttribute('data-select-id') || '';
        const value = button.getAttribute('data-value') || '';
        if (id.startsWith('table-sprint-')) {
          const key = id.slice('table-sprint-'.length);
          tasks = tasks.map(task => task.key === key ? Object.assign({}, task, { sprint: value }) : task);
          saveTaskOverride(key, { sprint: value });
          issueSprintOverrideMap[key] = value;
          updateIssueSprintInJira(key, value);
        } else if (selectedTaskKey) {
          const key = selectedTaskKey;
          if (id === 'sidebar-status') {
            tasks = tasks.map(task => task.key === key ? Object.assign({}, task, { status: value }) : task);
            saveTaskOverride(key, { status: value });
            transitionIssueStatusInJira(key, value, button.getAttribute('data-transition-id') || null);
          } else if (id === 'sidebar-issuetype') {
            const typeId = issueTypeIdByName[value] || issueTypeIdByName[String(value).toLowerCase()] || '';
            tasks = tasks.map(task => task.key === key ? Object.assign({}, task, { issueTypeName: value, issueTypeId: typeId }) : task);
            saveTaskOverride(key, { issueTypeName: value, issueTypeId: typeId });
            updateIssueTypeInJira(key, value);
          } else if (id === 'sidebar-priority') {
            tasks = tasks.map(task => task.key === key ? Object.assign({}, task, { priority: value }) : task);
            saveTaskOverride(key, { priority: value });
            fetch('/rest/api/2/issue/' + encodeURIComponent(key), {
              method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ fields: { priority: { name: value } } })
            }).catch(() => {});
            showSaveToast('✓ Приоритет ' + key + ' → ' + value);
          } else if (id === 'sidebar-sprint') {
            tasks = tasks.map(task => task.key === key ? Object.assign({}, task, { sprint: value }) : task);
            saveTaskOverride(key, { sprint: value });
            issueSprintOverrideMap[key] = value;
            updateIssueSprintInJira(key, value);
          }
        }
        activeSearchSelectId = '';
        searchSelectQuery = '';
        renderStructure();
      });
    });

  }

  function bindStructureEvents(root) {
    root.querySelector('#ozon-thread-create')?.addEventListener('click', openThreadCreationSidebar);
    root.querySelectorAll('[data-action="toggle-toolbar-filter"]').forEach((button) => {
      button.addEventListener('click', () => {
        const id = button.getAttribute('data-filter');
        activeToolbarFilter = activeToolbarFilter === id ? '' : id;
        toolbarFilterSearch = '';
        renderStructure();
        if (activeToolbarFilter) document.getElementById('ozon-toolbar-filter-search')?.focus();
      });
    });
    const toolbarFilterSearchEl = document.getElementById('ozon-toolbar-filter-search');
    if (toolbarFilterSearchEl) {
      toolbarFilterSearchEl.addEventListener('input', (event) => {
        const caretStart = event.target.selectionStart, caretEnd = event.target.selectionEnd;
        toolbarFilterSearch = event.target.value;
        renderStructure();
        const nextSearch = document.getElementById('ozon-toolbar-filter-search');
        if (nextSearch) { nextSearch.focus({preventScroll:true}); if (caretStart != null && caretEnd != null) nextSearch.setSelectionRange(caretStart, caretEnd); }
      });
    }
    root.querySelectorAll('[data-action="pick-toolbar-filter"]').forEach((button) => {
      button.addEventListener('click', () => {
        const filter = button.getAttribute('data-filter');
        const value = button.getAttribute('data-value');
        if (filter === 'component') filterComponent = value;
        if (filter === 'epic') filterEpic = value;
        if (filter === 'status') filterStatus = value;
        if (filter === 'sprint') filterSprintState = value;
        if (filter === 'sort') sortByField = value;
        if (filter === 'issue-type') filterIssueType = value;
        if (filter === 'tree') applyTableTreeLevel(value);
        activeToolbarFilter = '';
        toolbarFilterSearch = '';
        if (filter === 'sprint' && productDashboardLoaded) { const covered = {all:['all','CLOSED','ACTIVE','FUTURE','BACKLOG','open_future','open_future_backlog'],open_future_backlog:['open_future_backlog','open_future','ACTIVE','FUTURE','BACKLOG'],open_future:['open_future','ACTIVE','FUTURE'],ACTIVE:['ACTIVE'],FUTURE:['FUTURE'],BACKLOG:['BACKLOG'],CLOSED:['CLOSED']}; statusMessage = (covered[loadedSprintMode] || []).includes(value) ? '' : 'Для выбранных спринтов нажмите «Обновить задачи»'; }
        renderStructure();
      });
    });

    const searchEl = document.getElementById('ozon-ext-search');
    if (searchEl) {
      searchEl.addEventListener('input', (e) => {
        searchQuery = e.target.value;
        treeLevelApplied = false;
        tableTreeLevel = 'manual';
        const tbody = document.getElementById('ozon-ext-tbody');
        if (tbody) {
          const saved = captureAllScrollPositions();
          const { filtered, doneCount } = getFilteredTasks();
          tbody.innerHTML = buildTableRowsHtml(filtered);
          document.getElementById("ozon-ext-toggle-done").textContent = doneToggleLabel(doneCount);
          bindTableBodyEvents(tbody);
          restoreAllScrollPositions(saved);
        }
      });
    }

    const showAllSprintsLink = document.getElementById('ozon-ext-show-all-sprints');
    if (showAllSprintsLink) {
      showAllSprintsLink.addEventListener('click', (e) => {
        e.preventDefault();
        activeToolbarFilter = '';
        toolbarFilterSearch = '';
        expandedSprints = {};
        expandedComponents = {};
        searchQuery = '';
        filterComponent = 'all';
        filterEpic = 'all';
        filterStatus = 'all';
        filterSprintState = 'open_future_backlog';
        hideDone = false;
        filterIssueType = 'all';
        sortByField = 'default';
        renderStructure();
      });
    }

    const filterCompEl = document.getElementById('ozon-ext-filter-comp');
    if (filterCompEl) {
      filterCompEl.addEventListener('change', (e) => {
        filterComponent = e.target.value;
        renderStructure();
      });
    }

    const filterEpicEl = document.getElementById('ozon-ext-filter-epic');
    if (filterEpicEl) {
      filterEpicEl.addEventListener('change', (e) => {
        filterEpic = e.target.value;
        renderStructure();
      });
    }

    const filterStatusEl = document.getElementById('ozon-ext-filter-status');
    if (filterStatusEl) {
      filterStatusEl.addEventListener('change', (e) => {
        filterStatus = e.target.value;
        renderStructure();
      });
    }

    const filterSprintStateEl = document.getElementById('ozon-ext-filter-sprint-state');
    if (filterSprintStateEl) {
      filterSprintStateEl.addEventListener('change', (e) => {
        filterSprintState = e.target.value;
        renderStructure();
      });
    }

    document.getElementById("ozon-ext-toggle-done").onclick = () => {
      hideDone = !hideDone;
      renderStructure();
    };
    const sortByEl = document.getElementById('ozon-ext-sort-by');
    if (sortByEl) {
      sortByEl.addEventListener('change', (e) => {
        sortByField = e.target.value;
        renderStructure();
      });
    }

    const resetFiltersBtn = document.getElementById('ozon-ext-reset-filters');
    if (resetFiltersBtn) {
      resetFiltersBtn.addEventListener('click', () => {
        searchQuery = '';
        filterComponent = 'all';
        filterEpic = 'all';
        filterStatus = 'all';
        filterSprintState = 'open_future_backlog';
        hideDone = false;
        filterIssueType = 'all';
        sortByField = 'default';
        activeToolbarFilter = '';
        toolbarFilterSearch = '';
        renderStructure();
      });
    }

    ['ozon-ext-close-settings', 'ozon-ext-done-settings'].forEach((id) => {
      document.getElementById(id)?.addEventListener('click', (event) => { event.stopPropagation(); isColOrderPanelOpen = false; activeToolbarFilter = ''; renderStructure(); });
    });

    const saveProductGrouping = () => { localStorage.setItem(productGroupingStorage, JSON.stringify(productGroupingOrder)); groupByComponentInsideSprint = productGroupingOrder.length > 1; productExpandedGroups = {}; expandedSprints = {}; expandedComponents = {}; tableTreeLevel = 'sprints'; treeLevelApplied = false; renderStructure(); };
    root.querySelectorAll('[data-product-group]').forEach((input) => input.addEventListener('change', () => { const field = input.getAttribute('data-product-group'); productGroupingOrder = input.checked ? [...productGroupingOrder, field] : productGroupingOrder.filter((value) => value !== field); saveProductGrouping(); }));
    root.querySelectorAll('[data-product-move]').forEach((button) => button.addEventListener('click', () => { const index = productGroupingOrder.indexOf(button.getAttribute('data-product-move')); const next = index + Number(button.getAttribute('data-direction')); if (index < 0 || next < 0 || next >= productGroupingOrder.length) return; [productGroupingOrder[index], productGroupingOrder[next]] = [productGroupingOrder[next], productGroupingOrder[index]]; saveProductGrouping(); }));

    const toggleColOrderBtn = document.getElementById('ozon-ext-toggle-col-order');
    if (toggleColOrderBtn) {
      toggleColOrderBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        isColOrderPanelOpen = !isColOrderPanelOpen;
        renderStructure();
      });
    }

    const resetColOrderBtn = document.getElementById('ozon-ext-reset-col-order');
    if (resetColOrderBtn) {
      resetColOrderBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        columnOrder = [...DEFAULT_COLUMN_ORDER];
        localStorage.removeItem(STORAGE_KEY_COL_ORDER);
        renderStructure();
      });
    }

    root.querySelectorAll('button[data-action="move-col-left"]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = Number(btn.getAttribute('data-col-idx'));
        if (idx > 0) {
          const next = [...columnOrder];
          const tmp = next[idx - 1];
          next[idx - 1] = next[idx];
          next[idx] = tmp;
          columnOrder = next;
          try {
            localStorage.setItem(STORAGE_KEY_COL_ORDER, JSON.stringify(columnOrder));
          } catch (err) {}
          renderStructure();
        }
      });
    });

    root.querySelectorAll('button[data-action="move-col-right"]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = Number(btn.getAttribute('data-col-idx'));
        if (idx < columnOrder.length - 1) {
          const next = [...columnOrder];
          const tmp = next[idx + 1];
          next[idx + 1] = next[idx];
          next[idx] = tmp;
          columnOrder = next;
          try {
            localStorage.setItem(STORAGE_KEY_COL_ORDER, JSON.stringify(columnOrder));
          } catch (err) {}
          renderStructure();
        }
      });
    });

    // Drag & Drop заголовков столбцов <th>
    let draggedColId = null;
    root.querySelectorAll('th[data-col]').forEach((th) => {
      th.addEventListener('dragstart', (e) => {
        draggedColId = th.getAttribute('data-col');
        if (e.dataTransfer) {
          e.dataTransfer.effectAllowed = 'move';
        }
      });
      th.addEventListener('dragover', (e) => {
        e.preventDefault();
      });
      th.addEventListener('drop', (e) => {
        e.preventDefault();
        const targetColId = th.getAttribute('data-col');
        if (!draggedColId || !targetColId || draggedColId === targetColId) return;
        const fromIdx = columnOrder.indexOf(draggedColId);
        const toIdx = columnOrder.indexOf(targetColId);
        if (fromIdx < 0 || toIdx < 0) return;
        const next = [...columnOrder];
        next.splice(fromIdx, 1);
        next.splice(toIdx, 0, draggedColId);
        columnOrder = next;
        try {
          localStorage.setItem(STORAGE_KEY_COL_ORDER, JSON.stringify(columnOrder));
        } catch (err) {}
        showSaveToast('✓ Порядок столбцов обновлён');
        renderStructure();
      });
    });

    const reloadBoardBtn = document.getElementById('ozon-ext-reload-board');
    if (reloadBoardBtn) {
      reloadBoardBtn.addEventListener('click', () => {
        loadBoardIssuesFromJira();
      });
    }

    const resetColsBtn = document.getElementById('ozon-ext-reset-cols');
    if (resetColsBtn) {
      resetColsBtn.addEventListener('click', () => {
        colWidths = Object.assign({}, defaultColWidths);
        localStorage.removeItem(STORAGE_KEY_COL_WIDTHS);
        renderStructure();
      });
    }

    root.querySelectorAll('.ozon-ext-col-resizer').forEach((handle) => {
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const colKey = handle.getAttribute('data-col');
        const startX = e.clientX;
        const startW = Number(colWidths[colKey]) || 150;
        handle.classList.add('active');

        function onMove(moveEv) {
          const delta = moveEv.clientX - startX;
          const nextW = Math.max(70, Math.min(950, startW + delta));
          colWidths[colKey] = nextW;

          const colEl = root.querySelector('col[data-col="' + colKey + '"]');
          if (colEl) {
            colEl.style.width = nextW + 'px';
          }
          const thEl = root.querySelector('th[data-col="' + colKey + '"]');
          if (thEl) {
            thEl.style.setProperty('width', nextW + 'px', 'important');
            thEl.style.setProperty('min-width', nextW + 'px', 'important');
            thEl.style.setProperty('max-width', nextW + 'px', 'important');
          }
          const totalW = getTotalTableWidth();
          const tableEl = document.getElementById('ozon-ext-main-table');
          if (tableEl) {
            tableEl.style.setProperty('width', 'max(100%, ' + totalW + 'px)', 'important');
            tableEl.style.setProperty('min-width', totalW + 'px', 'important');
            tableEl.style.setProperty('max-width', 'none', 'important');
          }
        }

        function onUp() {
          handle.classList.remove('active');
          try {
            localStorage.setItem(STORAGE_KEY_COL_WIDTHS, JSON.stringify(colWidths));
          } catch (err) {}
          window.removeEventListener('mousemove', onMove);
          window.removeEventListener('mouseup', onUp);
        }

        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
      });
    });

    const tbody = document.getElementById('ozon-ext-tbody');
    if (tbody) {
      bindTableBodyEvents(tbody);
    }

    taskDetailsSidebar.bind(root);
  }

  function bindTableBodyEvents(tbody) {
    tbody.querySelectorAll('.ozon-ext-product-group').forEach((row) => row.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); const key = row.getAttribute('data-group-key'); if (!key) return; const depth = JSON.parse(key).length - 1; const defaultExpanded = treeLevelApplied && (tableTreeLevel === 'tasks' || tableTreeLevel === 'links' || (tableTreeLevel === 'components' && depth === 0)); const current = Object.prototype.hasOwnProperty.call(productExpandedGroups, key) ? productExpandedGroups[key] : (defaultExpanded || (!treeLevelApplied && Boolean(searchQuery.trim()))); productExpandedGroups[key] = !current; renderStructure(); }));
    tbody.querySelectorAll('.ozon-ext-sprint-row').forEach((row) => {
      if (row.classList.contains('ozon-ext-product-group')) return;
      row.addEventListener('click', (e) => {
        e.preventDefault();
        const sp = row.getAttribute('data-sprint');
        if (!sp) return;
        tableTreeLevel = 'manual';
        const wasExpanded = Boolean(expandedSprints[sp]);
        expandedSprints[sp] = !wasExpanded;
        if (!wasExpanded) {
          reloadSingleSprintFromJira(sp);
        } else {
          renderStructure();
        }
      });
    });

    tbody.querySelectorAll('.ozon-ext-comp-group-row').forEach((row) => {
      if (row.classList.contains('ozon-ext-product-group')) return;
      row.addEventListener('click', (e) => {
        e.preventDefault();
        const cg = row.getAttribute('data-comp-group');
        if (!cg) return;
        tableTreeLevel = 'manual';
        const wasExpanded = Boolean(expandedComponents[cg]);
        expandedComponents[cg] = !wasExpanded;
        if (!wasExpanded) {
          const parts = cg.split('::');
          const spName = parts[0] || '';
          const cName = parts.slice(1).join('::') || '';
          reloadSingleComponentFromJira(spName, cName);
        } else {
          renderStructure();
        }
      });
    });

    // По клику на саму строку задачи — разворачиваем/сворачиваем список связей
    tbody.querySelectorAll('.ozon-ext-task-row').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('.ozon-ext-inner-ctrl')) return;
        const key = row.getAttribute('data-key');
        if (!key) return;
        activeTableCombo = null;
        expandedSubRows[key] = !expandedSubRows[key];
        renderStructure();
      });
    });

    // По клику на отдельную кнопку «◨ Детали» — открываем/закрываем боковую панель деталей задачи
    tbody.querySelectorAll('button[data-action="open-sidebar"]').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const key = btn.getAttribute('data-key');
        if (!key) return;
        if (isSidebarOpen && !await confirmSidebarExit()) return;
        activeTableCombo = null;
        if (selectedTaskKey === key && isSidebarOpen) {
          isSidebarOpen = false;
          renderStructure();
        } else {
          selectedTaskKey = key;
          isSidebarOpen = true;
          isEditingDescription = false;
          collapsedSidebarSections.pt = true;
          reloadSingleTaskFromJira(key);
        }
      });
    });

    tbody.querySelectorAll('button[data-action="toggle-subrow"]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const key = btn.getAttribute('data-key');
        expandedSubRows[key] = !expandedSubRows[key];
        renderStructure();
      });
    });

    // Открытие кастомного поповера Статуса в таблице
    tbody.querySelectorAll('[data-action="open-table-status-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.ozon-ext-combo-popover')) return;
        const key = trigger.getAttribute('data-key');
        if (activeTableCombo && activeTableCombo.type === 'status' && activeTableCombo.taskKey === key) {
          activeTableCombo = null;
          renderStructure();
          return;
        }
        activeTableCombo = { type: 'status', taskKey: key, query: '' };
        renderStructure();
        if (key && !issueTransitionsByKey[key]) {
          fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '/transitions', {
            credentials: 'same-origin',
            headers: { Accept: 'application/json' }
          })
            .then((r) => (r.ok ? r.json() : null))
            .then((d) => {
              if (d && Array.isArray(d.transitions)) {
                issueTransitionsByKey[key] = d.transitions;
                if (activeTableCombo && activeTableCombo.type === 'status' && activeTableCombo.taskKey === key) {
                  renderStructure();
                }
              }
            })
            .catch(() => {});
        }
      });
    });

    tbody.querySelectorAll('[data-action="pick-table-status"]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const key = item.getAttribute('data-key');
        const newStatus = item.getAttribute('data-status');
        const explicitTrId = item.getAttribute('data-tr-id') || null;
        if (!key || !newStatus) return;
        activeTableCombo = null;
        tasks = tasks.map((t) => (t.key === key ? Object.assign({}, t, { status: newStatus }) : t));
        saveTaskOverride(key, { status: newStatus });
        transitionIssueStatusInJira(key, newStatus, explicitTrId);
        renderStructure();
      });
    });

    tbody.querySelectorAll('[data-action="close-table-epic"]').forEach(button => {
      button.addEventListener('click', event => { event.stopPropagation(); activeTableCombo = null; renderStructure(); });
    });
    // Открытие выбора эпика FCRM
    tbody.querySelectorAll('[data-action="open-table-epic-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.ozon-ext-combo-popover')) return;
        const key = trigger.getAttribute('data-key');
        if (activeTableCombo && activeTableCombo.type === 'epic' && activeTableCombo.taskKey === key) {
          activeTableCombo = null;
        } else {
          activeTableCombo = { type: 'epic', taskKey: key, query: '' };
        }
        renderStructure();
        const inp = document.getElementById('ozon-table-combo-input');
        if (inp) inp.focus({ preventScroll: true });
      });
    });

    // Открытие Input-Select для Компонента прямо в ячейке таблицы
    tbody.querySelectorAll('[data-action="open-table-comp-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.ozon-ext-combo-popover')) return;
        const key = trigger.getAttribute('data-key');
        const pk = getIssueProjectKey(key);
        loadExternalProjectComponents(pk);
        if (activeTableCombo && activeTableCombo.type === 'component' && activeTableCombo.taskKey === key) {
          activeTableCombo = null;
        } else {
          activeTableCombo = { type: 'component', taskKey: key, query: '' };
        }
        renderStructure();
        const inp = document.getElementById('ozon-table-combo-input');
        if (inp) inp.focus({ preventScroll: true });
      });
    });

    // Открытие Input-Select для Исполнителя в ячейке таблицы (с поиском по людям в Jira)
    tbody.querySelectorAll('[data-action="open-table-assignee-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.ozon-ext-combo-popover')) return;
        const key = trigger.getAttribute('data-key');
        tableUserSearchResults = [];
        if (activeTableCombo && activeTableCombo.type === 'assignee' && activeTableCombo.taskKey === key) {
          activeTableCombo = null;
        } else {
          activeTableCombo = { type: 'assignee', taskKey: key, query: '' };
        }
        renderStructure();
        const inp = document.getElementById('ozon-table-combo-input');
        if (inp) inp.focus({ preventScroll: true });
      });
    });

    // Открытие Input-Select для Заказчик/Owner в ячейке таблицы (с поиском по людям в Jira)
    tbody.querySelectorAll('[data-action="open-table-customer-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.ozon-ext-combo-popover')) return;
        const key = trigger.getAttribute('data-key');
        tableUserSearchResults = [];
        if (activeTableCombo && activeTableCombo.type === 'customer' && activeTableCombo.taskKey === key) {
          activeTableCombo = null;
        } else {
          activeTableCombo = { type: 'customer', taskKey: key, query: '' };
        }
        renderStructure();
        const inp = document.getElementById('ozon-table-combo-input');
        if (inp) inp.focus({ preventScroll: true });
      });
    });

    const tableComboInput = document.getElementById('ozon-table-combo-input');
    if (tableComboInput && activeTableCombo) {
      tableComboInput.addEventListener('click', (e) => e.stopPropagation());
      tableComboInput.addEventListener('input', (e) => {
        const val = e.target.value;
        activeTableCombo.query = val;
        if (activeTableCombo.type === 'epic') {
          if (epicSearchTimer) clearTimeout(epicSearchTimer);
          if (val.trim().length >= 2) {
            epicSearchTimer = setTimeout(async () => {
              await searchFcrmEpicsInJira(val.trim());
              renderStructure();
            }, 220);
          }
        } else if (activeTableCombo.type === 'assignee' || activeTableCombo.type === 'customer') {
          if (tableUserSearchTimer) clearTimeout(tableUserSearchTimer);
          const q = val.trim();
          if (q.length >= 1) {
            const currentTaskKey = activeTableCombo.taskKey;
            tableUserSearchTimer = setTimeout(async () => {
              const found = await searchJiraUsers(q, currentTaskKey);
              tableUserSearchResults = found.filter((u) => isRealHumanJiraUser(u));
              renderStructure();
            }, 180);
          } else {
            tableUserSearchResults = [];
          }
        }
        renderStructure();
      });

      tableComboInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && activeTableCombo) {
          e.preventDefault();
          const val = tableComboInput.value.trim();
          const key = activeTableCombo.taskKey;
          if (activeTableCombo.type === 'customer' && val) {
            const firstMatch = tableUserSearchResults[0];
            const chosenDisplay = firstMatch ? firstMatch.displayName : val;
            const chosenLogin = firstMatch ? firstMatch.name : null;
            activeTableCombo = null;
            tableUserSearchResults = [];
            tasks = tasks.map((t) =>
              t.key === key ? Object.assign({}, t, { customer: Object.assign({}, t.customer, { name: chosenDisplay }) }) : t
            );
            saveTaskOverride(key, { customer: { name: chosenDisplay, department: 'FCRM' } });
            updateIssueCustomerInJira(key, chosenDisplay, chosenLogin);
            renderStructure();
          } else if (activeTableCombo.type === 'assignee' && val) {
            const firstMatch = tableUserSearchResults[0];
            const chosenDisplay = firstMatch ? firstMatch.displayName : val;
            const chosenLogin = firstMatch ? firstMatch.name : null;
            activeTableCombo = null;
            tableUserSearchResults = [];
            tasks = tasks.map((t) =>
              t.key === key ? Object.assign({}, t, { assignee: Object.assign({}, t.assignee, { name: chosenDisplay }) }) : t
            );
            saveTaskOverride(key, { assignee: { name: chosenDisplay, login: chosenLogin || '', role: 'Ozon Банк' } });
            updateIssueAssigneeInJira(key, chosenDisplay, chosenLogin);
            renderStructure();
          }
        }
      });
    }

    tbody.querySelectorAll('[data-action="pick-table-epic"]').forEach((item) => {
      item.addEventListener('click', async (e) => {
        e.stopPropagation();
        const key = item.getAttribute('data-key');
        const epKey = item.getAttribute('data-epic-key') || '';
        const epName = item.getAttribute('data-epic-name') || (epKey ? epicNameByKey[epKey] || epKey : 'Без эпика');
        activeTableCombo = null;
        tasks = tasks.map((t) => (t.key === key ? Object.assign({}, t, { epicKey: epKey, epicName: epName }) : t));
        saveTaskOverride(key, { epicKey: epKey, epicName: epName });
        renderStructure();
        await updateIssueEpicInJira(key, epKey);
        renderStructure();
      });
    });

    tbody.querySelectorAll('[data-action="pick-table-comp"]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const key = item.getAttribute('data-key');
        const newComp = item.getAttribute('data-comp') || 'Без компонента';
        activeTableCombo = null;
        tasks = tasks.map((t) => (t.key === key ? Object.assign({}, t, { component: newComp, components: newComp && newComp !== 'Без компонента' ? [newComp] : [] }) : t));
        saveTaskOverride(key, { component: newComp, components: newComp && newComp !== 'Без компонента' ? [newComp] : [] });

        const compsPayload = newComp && newComp !== 'Без компонента' ? [{ name: newComp }] : [];
        fetch('/rest/api/2/issue/' + encodeURIComponent(key), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fields: { components: compsPayload } })
        }).catch(() => {});
        showSaveToast('✓ Компонент ' + key + ' → ' + newComp);
        renderStructure();
      });
    });

    tbody.querySelectorAll('[data-action="pick-table-assignee"]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const key = item.getAttribute('data-key');
        const uLogin = item.getAttribute('data-user-login') || '';
        const uDisplay = item.getAttribute('data-user-display') || 'Не назначен';
        activeTableCombo = null;
        tableUserSearchResults = [];
        tasks = tasks.map((t) =>
          t.key === key ? Object.assign({}, t, { assignee: { name: uDisplay, login: uLogin, role: 'Ozon Банк' } }) : t
        );
        saveTaskOverride(key, { assignee: { name: uDisplay, login: uLogin, role: 'Ozon Банк' } });
        updateIssueAssigneeInJira(key, uDisplay, uLogin || null);
        renderStructure();
      });
    });

    tbody.querySelectorAll('[data-action="pick-table-customer"]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const key = item.getAttribute('data-key');
        const uLogin = item.getAttribute('data-user-login') || '';
        const uDisplay = item.getAttribute('data-user-display') || 'Не указан';
        activeTableCombo = null;
        tableUserSearchResults = [];
        tasks = tasks.map((t) =>
          t.key === key ? Object.assign({}, t, { customer: { name: uDisplay, department: 'FCRM' } }) : t
        );
        saveTaskOverride(key, { customer: { name: uDisplay, department: 'FCRM' } });
        updateIssueCustomerInJira(key, uDisplay, uLogin || null);
        renderStructure();
      });
    });

    tbody.querySelectorAll('select[data-action="change-sprint"]').forEach((sel) => {
      sel.addEventListener('click', (e) => e.stopPropagation());
      sel.addEventListener('change', (e) => {
        const key = sel.getAttribute('data-key');
        const newSp = e.target.value;
        tasks = tasks.map((t) => (t.key === key ? Object.assign({}, t, { sprint: newSp }) : t));
        issueSprintOverrideMap[key] = newSp;
        saveTaskOverride(key, { sprint: newSp });
        updateIssueSprintInJira(key, newSp);
        renderStructure();
      });
    });
  }

  function bindUserPickerClicks(container, task, updateCurrentTask) {
    if (!container) return;
    container.querySelectorAll('[data-action="pick-jira-user"]').forEach((opt) => {
      opt.addEventListener('click', () => {
        const uLogin = opt.getAttribute('data-user-login');
        const uDisplay = opt.getAttribute('data-user-display');
        assigneeSearchQuery = '';
        searchedUsersResults = [];
        updateCurrentTask({
          assignee: { name: uDisplay, login: uLogin || '', role: 'Ozon Банк' }
        });
        updateIssueAssigneeInJira(selectedTaskKey, uDisplay, uLogin);
        renderStructure();
      });
    });
  }

  function bindCustomerPickerClicks(container, task, updateCurrentTask) {
    if (!container) return;
    container.querySelectorAll('[data-action="pick-jira-customer"]').forEach((opt) => {
      opt.addEventListener('click', () => {
        const uLogin = opt.getAttribute('data-user-login');
        const uDisplay = opt.getAttribute('data-user-display');
        customerSearchQuery = '';
        searchedCustomerResults = [];
        updateCurrentTask({
          customer: { name: uDisplay, department: 'FCRM' }
        });
        updateIssueCustomerInJira(selectedTaskKey, uDisplay, uLogin);
        renderStructure();
      });
    });
  }

  let designTaskEventBound = false;
  function bindSidebarEvents(root) {
    if (!designTaskEventBound) {
      designTaskEventBound = true;
      document.addEventListener('ozon-fcrm-create-design-task-request', async (event) => {
        let detail = event && event.detail || {};
        if (typeof detail === 'string') { try { detail = JSON.parse(detail); } catch { detail = {}; } }
        if (!detail.issueKey || !detail.summary || !detail.description) return;
        try {
          const created = await createDesignIssueFromSidebar(detail.issueKey, detail.summary, detail.description);
          document.dispatchEvent(new CustomEvent('ozon-fcrm-design-task-result', {
            detail: JSON.stringify({ issueKey: detail.issueKey, ok: true, key: created.key, linked: created.linked })
          }));
        } catch (error) {
          document.dispatchEvent(new CustomEvent('ozon-fcrm-design-task-result', {
            detail: JSON.stringify({ issueKey: detail.issueKey, ok: false, error: error && error.message ? error.message : 'Не удалось создать задачу FTD' })
          }));
        }
      });
    }
    if (!isSidebarOpen || !selectedTaskKey) return;
    const task = tasks.find((t) => t.key === selectedTaskKey);
    if (!task) return;

    const sbResizer = document.getElementById('ozon-ext-sidebar-resizer');
    const sbPanel = document.getElementById('ozon-ext-sidebar-panel');
    if (sbResizer && sbPanel) {
      sbResizer.style.right = sidebarWidth + 'px';
      sbResizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        sbResizer.classList.add('active');

        function onMove(moveEv) {
          const nextW = Math.max(340, window.innerWidth - moveEv.clientX);
          sidebarWidth = nextW;
          sbPanel.style.width = nextW + 'px';
          sbResizer.style.right = nextW + 'px';
        }

        function onUp() {
          sbResizer.classList.remove('active');
          try {
            localStorage.setItem(STORAGE_KEY_SIDEBAR_W, String(sidebarWidth));
          } catch (err) {}
          window.removeEventListener('mousemove', onMove);
          window.removeEventListener('mouseup', onUp);
        }

        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
      });
    }

    const closeBtn = document.getElementById('ozon-ext-sidebar-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', async () => {
        if (!await confirmSidebarExit()) return;
        isSidebarOpen = false;
        isEditingDescription = false;
        renderStructure();
      });
    }

    const refreshBtn = document.getElementById('ozon-ext-sidebar-refresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        reloadSingleTaskFromJira(selectedTaskKey, true, true);
      });
    }

    root.querySelectorAll('[data-action="refresh-sidebar-section"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        refreshSidebarSection(task.key, button.getAttribute('data-section'));
      });
    });

    document.getElementById('ozon-copy-task-link')?.addEventListener('click', async () => {
      const url = 'https://jit.o3.ru/browse/' + encodeURIComponent(task.key);
      const text = '[' + task.key + '](' + url + ') ' + task.summary;
      try {
        await navigator.clipboard.writeText(text);
        showSaveToast('✓ Ссылка и название скопированы');
      } catch (_) {
        showSaveToast('Не удалось скопировать ссылку: доступ к буферу обмена запрещён');
      }
    });

    root.querySelectorAll('[data-action="move-other-to-ip"]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation();
        const sourceKey = task.key;
        const targetKey = button.getAttribute('data-link-key');
        const linkId = button.getAttribute('data-jira-link-id');
        button.disabled = true;
        try {
          // Save the new relation before deleting the old one, so a failed POST never loses it.
          if (!await createIssueLinkInJira(sourceKey, targetKey, 'inProject', true)) throw new Error('Не удалось создать связь «В проекте». Исходная связь сохранена.');
          if (!await deleteIssueLinkInJira(sourceKey, targetKey, linkId)) throw new Error('Связь «В проекте» создана, но исходную связь удалить не удалось');
          await reloadSingleTaskFromJira(sourceKey, true);
          showSaveToast('✓ Тип связи с ' + targetKey + ' изменён на «В проекте»');
        } catch (error) {
          showSaveToast(error.message);
          button.disabled = false;
        }
      });
    });

    root.querySelectorAll('[data-action="change-link-type"], [data-action="delete-link"]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation();
        const sourceKey = task.key, targetKey = button.getAttribute('data-link-key');
        const linkId = button.getAttribute('data-jira-link-id');
        const category = button.getAttribute('data-link-type');
        const message = button.closest('.ozon-link-actions-menu')?.querySelector('.ozon-link-action-message');
        if (!/^\d+$/.test(String(linkId || ''))) { if (message) message.textContent = 'Не удалось определить связь в Jira. Обновите задачу.'; return; }
        button.disabled = true;
        if (message) { message.style.color = '#64748B'; message.textContent = 'Сохраняем…'; }
        try {
          if (category && !await createIssueLinkInJira(sourceKey, targetKey, category, true, true)) throw new Error('Не удалось создать выбранный тип связи. Исходная связь сохранена.');
          if (!await deleteIssueLinkInJira(sourceKey, targetKey, linkId)) throw new Error(category ? 'Новая связь создана, но исходную удалить не удалось.' : 'Не удалось удалить связь.');
          await refreshLinksWithoutSkeleton(sourceKey);
        } catch (error) { if (message) { message.style.color = '#D92D20'; message.textContent = error.message; } showSaveToast(error.message); button.disabled = false; }
      });
    });
    root.querySelectorAll('.ozon-link-actions').forEach((details) => {
      details.addEventListener('toggle', () => {
        if (!details.open) return;
        root.querySelectorAll('.ozon-link-actions[open]').forEach((other) => { if (other !== details) other.open = false; });
        const menu = details.querySelector('.ozon-link-actions-menu');
        const rect = details.getBoundingClientRect();
        if (menu) {
          const width = menu.offsetWidth, height = menu.offsetHeight;
          menu.style.left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8)) + 'px';
          menu.style.top = Math.max(8, Math.min(rect.bottom + 4, window.innerHeight - height - 8)) + 'px';
          menu.style.right = 'auto';
        }
      });
    });
    root.querySelectorAll('[data-action="delete-remote-link"]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation(); button.disabled = true;
        try {
          const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(task.key) + '/remotelink/' + encodeURIComponent(button.getAttribute('data-remote-id')), {method:'DELETE',credentials:'same-origin'});
          if (!response.ok) throw new Error('Не удалось удалить веб-ссылку');
          await refreshLinksWithoutSkeleton(task.key);
        } catch (error) { showSaveToast(error.message); button.disabled = false; }
      });
    });

    const expandBtn = document.getElementById('ozon-ext-sidebar-expand');
    if (expandBtn) {
      expandBtn.addEventListener('click', () => {
        sidebarWidth = sidebarWidth < 620 ? 740 : 480;
        localStorage.setItem(STORAGE_KEY_SIDEBAR_W, String(sidebarWidth));
        renderStructure();
      });
    }

    // Сворачивание / разворачивание секций-аккордеонов в сайдбаре (с сохранением позиции скролла!)
    root.querySelectorAll('[data-action="toggle-description-length"]').forEach((button) => {
      button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); expandedSidebarDescriptions.has(task.key) ? expandedSidebarDescriptions.delete(task.key) : expandedSidebarDescriptions.add(task.key); renderStructure(); });
    });
    root.querySelectorAll('[data-action="toggle-sb-section"]').forEach((head) => {
      head.addEventListener('click', (e) => {
        if (e.target.closest('button') || e.target.closest('a')) return;
        e.preventDefault();
        e.stopPropagation();
        const sec = head.getAttribute('data-sec');
        if (!sec) return;
        collapsedSidebarSections[sec] = !collapsedSidebarSections[sec];
        renderStructure();
        if (sec === 'pt_quick' && collapsedSidebarSections[sec] === false && !umbCatalogReady && !umbCatalogRequest) {
          umbCatalogRequest = loadUmbEpicTasksFromJira().finally(() => { umbCatalogRequest = null; if (isSidebarOpen) renderStructure(); });
        }
      });
    });

    // Сворачивание / разворачивание групп OB / OBFRONT / FTD в связях «В проекте» (с сохранением позиции скролла!)
    root.querySelectorAll('[data-action="toggle-ip-group"]').forEach((grpHead) => {
      grpHead.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const gid = grpHead.getAttribute('data-grp-id');
        if (!gid) return;
        collapsedIpGroups[gid] = !collapsedIpGroups[gid];
        renderStructure();
      });
    });

    function updateCurrentTask(patch) {
      if (Object.prototype.hasOwnProperty.call(patch, 'component')) patch.components = patch.component && patch.component !== 'Без компонента' ? [patch.component] : [];
      tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, patch) : t));
      saveTaskOverride(selectedTaskKey, patch);
    }

    async function saveSummaryNow() {
      const sumInput = document.getElementById('ozon-sb-summary');
      if (!sumInput) return;
      const val = sumInput.value.trim();
      if (!val) return;
      const key = selectedTaskKey;
      const button = document.getElementById('ozon-sb-save-summary');
      if (button) button.disabled = true;
      try {
      await saveSidebarFields(key, {summary: val});
      showSaveToast('✓ Название ' + key + ' сохранено');
      if (selectedTaskKey === key) renderStructure();
      } catch (error) {
        showSaveToast('Не удалось сохранить название: ' + (error.message || 'ошибка запроса'));
        if (button) button.disabled = false;
      }
    }

    const sumInput = document.getElementById('ozon-sb-summary');
    if (sumInput) {
      sumInput.addEventListener('input', () => {
        const draft = sidebarDraft(selectedTaskKey);
        const original = tasks.find((task) => task.key === selectedTaskKey)?.summary || '';
        if (sumInput.value === original) delete draft.summary; else draft.summary = sumInput.value;
        const button = document.getElementById('ozon-sb-save-summary');
        if (button) { button.disabled = !sumInput.value.trim() || sumInput.value.trim() === original.trim(); button.style.display = button.disabled ? 'none' : ''; }
      });
      sumInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          saveSummaryNow();
        }
      });
    }

    const saveSumBtn = document.getElementById('ozon-sb-save-summary');
    if (saveSumBtn) {
      saveSumBtn.addEventListener('click', saveSummaryNow);
    }

    const labelForm = document.getElementById('ozon-sb-label-form');
    const labelInput = document.getElementById('ozon-sb-label-input');
    bindLabelSuggestions(labelInput);
    async function changeSidebarLabel(label, operation) {
      const key = selectedTaskKey;
      const container = document.getElementById('ozon-sb-labels');
      const errorEl = document.getElementById('ozon-sb-label-error');
      if (!container || container.dataset.busy === '1') return;
      if (!label || /\s/.test(label)) {
        if (errorEl) { errorEl.hidden = false; errorEl.textContent = 'Метка не должна быть пустой или содержать пробелы.'; }
        return;
      }
      if (errorEl) errorEl.hidden = true;
      container.dataset.busy = '1';
      container.querySelectorAll('button, input').forEach((el) => { el.disabled = true; });
      try {
        const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), {
          method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ update: { labels: [{ [operation]: label }] } })
        });
        if (!response.ok) throw new Error('Ошибка Jira: ' + response.status);
        const fresh = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=labels', { credentials: 'same-origin', cache: 'no-store' });
        if (!fresh.ok) throw new Error('Не удалось проверить сохранение меток');
        const data = await fresh.json();
        const labels = data.fields && Array.isArray(data.fields.labels) ? data.fields.labels : null;
        if (!labels || labels.includes(label) !== (operation === 'add')) throw new Error('Jira не подтвердила изменение метки');
        tasks = tasks.map((t) => t.key === key ? Object.assign({}, t, { labels }) : t);
        const strategyIssue = strategicDashboard.getState().issues.find((issue) => issue.key === key);
        if (strategyIssue && strategyIssue.fields) { strategyIssue.fields.labels = labels; strategicDashboard.invalidateGraph(); }
        saveTaskOverride(key, { labels });
        if (selectedTaskKey === key) renderStructure();
      } catch (error) {
        if (errorEl && selectedTaskKey === key) { errorEl.hidden = false; errorEl.textContent = error.message || 'Не удалось изменить метку'; }
      } finally {
        container.dataset.busy = '0';
        container.querySelectorAll('button, input').forEach((el) => { el.disabled = false; });
      }
    }
    if (labelForm) labelForm.addEventListener('submit', (event) => {
      event.preventDefault();
      changeSidebarLabel(labelInput ? labelInput.value.trim() : '', 'add');
    });
    root.querySelectorAll('[data-sb-remove-label]').forEach((button) => {
      button.addEventListener('click', () => changeSidebarLabel(button.getAttribute('data-sb-remove-label') || '', 'remove'));
    });

    // Переключение режима Просмотр / Редактирование описания задачи
    const toggleEditDescBtn = document.getElementById('ozon-sb-toggle-edit-desc');
    if (toggleEditDescBtn) {
      toggleEditDescBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        isEditingDescription = !isEditingDescription;
        collapsedSidebarSections['desc'] = false;
        renderStructure();
      });
    }

    const descPreviewEl = document.getElementById('ozon-sb-desc-preview');
    if (descPreviewEl) {
      descPreviewEl.addEventListener('dblclick', (e) => {
        if (e.target.closest('a')) return;
        isEditingDescription = true;
        renderStructure();
      });
    }

    const cancelDescBtn = document.getElementById('ozon-sb-cancel-description');
    if (cancelDescBtn) {
      cancelDescBtn.addEventListener('click', (e) => {
        e.preventDefault();
        delete sidebarDraft(selectedTaskKey).description;
        isEditingDescription = false;
        renderStructure();
      });
    }

    // Автоматическое увеличение высоты поля «Описание задачи» при вводе текста
    const descArea = document.getElementById('ozon-sb-description');
    if (descArea) {
      descArea.addEventListener('input', () => {
        const draft = sidebarDraft(selectedTaskKey);
        const original = tasks.find((task) => task.key === selectedTaskKey)?.description || '';
        if (descArea.value === original) delete draft.description; else draft.description = descArea.value;
        descArea.style.height = 'auto';
        descArea.style.height = Math.max(90, descArea.scrollHeight) + 'px';
      });
    }

    async function saveDescriptionNow() {
      const descEl = document.getElementById('ozon-sb-description');
      if (!descEl) return;
      const val = descEl.value;
      const key = selectedTaskKey;
      const buttons = [document.getElementById('ozon-sb-save-description'), document.getElementById('ozon-sb-save-description-bottom')].filter(Boolean);
      buttons.forEach((button) => { button.disabled = true; });
      try {
        await saveSidebarFields(key, {description: val});
        showSaveToast('✓ Описание ' + key + ' сохранено в Jira');
        if (selectedTaskKey === key) { isEditingDescription = false; renderStructure(); }
      } catch (error) {
        showSaveToast('Не удалось сохранить описание: ' + (error.message || 'ошибка запроса'));
        buttons.forEach((button) => { button.disabled = false; });
      }
    }

    const saveDescBtn = document.getElementById('ozon-sb-save-description');
    if (saveDescBtn) {
      saveDescBtn.addEventListener('click', saveDescriptionNow);
    }
    const saveDescBottomBtn = document.getElementById('ozon-sb-save-description-bottom');
    if (saveDescBottomBtn) {
      saveDescBottomBtn.addEventListener('click', saveDescriptionNow);
    }

    function handleStatusSelectChange(selEl) {
      const newStatus = selEl.value;
      const selectedOpt = selEl.options[selEl.selectedIndex];
      const explicitTrId = selectedOpt ? selectedOpt.getAttribute('data-tr-id') : null;
      updateCurrentTask({ status: newStatus });
      transitionIssueStatusInJira(selectedTaskKey, newStatus, explicitTrId);
      renderStructure();
    }

    const headerStatusSelect = document.getElementById('ozon-sb-header-status');
    if (headerStatusSelect) {
      headerStatusSelect.addEventListener('change', () => handleStatusSelectChange(headerStatusSelect));
    }

    const statusSelect = document.getElementById('ozon-sb-status');
    if (statusSelect) {
      statusSelect.addEventListener('change', () => handleStatusSelectChange(statusSelect));
    }

    const issueTypeSelect = document.getElementById('ozon-sb-issuetype');
    if (issueTypeSelect) {
      issueTypeSelect.addEventListener('change', (e) => {
        const newIssueType = e.target.value;
        const matchedTypeId = issueTypeIdByName[newIssueType] || issueTypeIdByName[String(newIssueType).toLowerCase()] || '';
        updateCurrentTask({
          issueTypeName: newIssueType,
          issueTypeId: matchedTypeId
        });
        updateIssueTypeInJira(selectedTaskKey, newIssueType);
        renderStructure();
      });
    }

    const prioSelect = document.getElementById('ozon-sb-priority');
    if (prioSelect) {
      prioSelect.addEventListener('change', (e) => {
        const newPriority = e.target.value;
        updateCurrentTask({ priority: newPriority });
        fetch('/rest/api/2/issue/' + encodeURIComponent(selectedTaskKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fields: { priority: { name: newPriority } } })
        }).catch(() => {});
        showSaveToast('✓ Приоритет ' + selectedTaskKey + ' → ' + newPriority);
        renderStructure();
      });
    }

    root.querySelectorAll('button[data-action="quick-transition"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const trId = btn.getAttribute('data-tr-id');
        const targetSt = btn.getAttribute('data-target-status');
        if (!targetSt) return;
        updateCurrentTask({ status: targetSt });
        transitionIssueStatusInJira(selectedTaskKey, targetSt, trId);
        renderStructure();
      });
    });

    const spSelect = document.getElementById('ozon-sb-sprint');
    if (spSelect) {
      spSelect.addEventListener('change', (e) => {
        const newSp = e.target.value;
        issueSprintOverrideMap[selectedTaskKey] = newSp;
        updateCurrentTask({ sprint: newSp });
        updateIssueSprintInJira(selectedTaskKey, newSp);
        renderStructure();
      });
    }

    // Быстрые чипсы спринтов и кнопка «✕ Удалить из спринта»
    root.querySelectorAll('button[data-action="quick-sprint-chip"]').forEach((chip) => {
      chip.addEventListener('click', () => {
        const targetSp = chip.getAttribute('data-sprint') || 'Бэклог FCRM';
        issueSprintOverrideMap[selectedTaskKey] = targetSp;
        updateCurrentTask({ sprint: targetSp });
        updateIssueSprintInJira(selectedTaskKey, targetSp);
        renderStructure();
      });
    });

    // Input-Select Компонента основной задачи в сайдбаре
    const sbCompTrigger = document.getElementById('ozon-sb-comp-trigger');
    if (sbCompTrigger) {
      sbCompTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        const pk = getIssueProjectKey(selectedTaskKey);
        loadExternalProjectComponents(pk);
        sbCompComboOpen = !sbCompComboOpen;
        sbEpicComboOpen = false;
        sbIpCompOpenIdx = null;
        if (sbCompComboOpen) sbCompSearchQuery = '';
        renderStructure();
        const sInp = document.getElementById('ozon-sb-comp-search');
        if (sInp) sInp.focus();
      });
    }

    const sbCompSearch = document.getElementById('ozon-sb-comp-search');
    if (sbCompSearch) {
      sbCompSearch.addEventListener('click', (e) => e.stopPropagation());
      sbCompSearch.addEventListener('input', (e) => {
        sbCompSearchQuery = e.target.value;
        renderStructure();
      });
    }

    root.querySelectorAll('[data-action="pick-sb-comp"]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const newComp = item.getAttribute('data-comp') || 'Без компонента';
        sbCompComboOpen = false;
        sbCompSearchQuery = '';
        updateCurrentTask({ component: newComp });
        const compsPayload = newComp && newComp !== 'Без компонента' ? [{ name: newComp }] : [];
        fetch('/rest/api/2/issue/' + encodeURIComponent(selectedTaskKey), {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fields: { components: compsPayload } })
        }).catch(() => {});
        showSaveToast('✓ Компонент ' + selectedTaskKey + ' → ' + newComp);
        renderStructure();
      });
    });

    // Input-Select Эпика (проект FCRM) в сайдбаре
    const sbEpicTrigger = document.getElementById('ozon-sb-epic-trigger');
    if (sbEpicTrigger) {
      sbEpicTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        sbEpicComboOpen = !sbEpicComboOpen;
        sbCompComboOpen = false;
        sbIpCompOpenIdx = null;
        if (sbEpicComboOpen) sbEpicSearchQuery = '';
        renderStructure();
        const eInp = document.getElementById('ozon-sb-epic-search');
        if (eInp) eInp.focus();
      });
    }

    const sbEpicSearch = document.getElementById('ozon-sb-epic-search');
    if (sbEpicSearch) {
      sbEpicSearch.addEventListener('click', (e) => e.stopPropagation());
      sbEpicSearch.addEventListener('input', (e) => {
        sbEpicSearchQuery = e.target.value;
        renderStructure();
        if (epicSearchTimer) clearTimeout(epicSearchTimer);
        if (sbEpicSearchQuery.trim().length >= 2) {
          epicSearchTimer = setTimeout(async () => {
            await searchFcrmEpicsInJira(sbEpicSearchQuery.trim());
            renderStructure();
          }, 220);
        }
      });
    }

    root.querySelectorAll('[data-action="pick-sb-epic"]').forEach((item) => {
      item.addEventListener('click', async (e) => {
        e.stopPropagation();
        const epKey = item.getAttribute('data-epic-key') || '';
        const epName = item.getAttribute('data-epic-name') || (epKey ? epicNameByKey[epKey] || epKey : 'Без эпика');
        sbEpicComboOpen = false;
        sbEpicSearchQuery = '';
        updateCurrentTask({ epicKey: epKey, epicName: epName });
        const obprojectSourceKey = isEpicIssueType(task.issueTypeName) ? selectedTaskKey : epKey;
        if (obprojectSourceKey) loadEpicObprojectDetails(obprojectSourceKey);
        renderStructure();
        await updateIssueEpicInJira(selectedTaskKey, epKey);
        renderStructure();
      });
    });

    function saveAssigneeNow() {
      const userSearchInput = document.getElementById('ozon-sb-user-search');
      if (!userSearchInput) return;
      const val = userSearchInput.value.trim() || 'Не назначен';
      if (val === task.assignee.name) return;
      const firstMatch = searchedUsersResults[0];
      const chosenDisplay = val === 'Не назначен' ? 'Не назначен' : firstMatch ? firstMatch.displayName : val;
      const chosenLogin = val === 'Не назначен' ? null : firstMatch ? firstMatch.name : null;
      assigneeSearchQuery = '';
      searchedUsersResults = [];
      updateCurrentTask({ assignee: { name: chosenDisplay, login: chosenLogin || '', role: 'Ozon Банк' } });
      updateIssueAssigneeInJira(selectedTaskKey, chosenDisplay, chosenLogin);
      renderStructure();
    }

    const userSearchInput = document.getElementById('ozon-sb-user-search');
    const userResultsContainer = document.getElementById('ozon-sb-user-results');
    if (userResultsContainer) {
      bindUserPickerClicks(userResultsContainer, task, updateCurrentTask);
    }

    if (userSearchInput) {
      userSearchInput.addEventListener('input', (e) => {
        assigneeSearchQuery = e.target.value;
        if (userSearchTimer) clearTimeout(userSearchTimer);
        const q = assigneeSearchQuery.trim();
        if (!q || q === 'Не назначен') {
          searchedUsersResults = [];
          const resBox = document.getElementById('ozon-sb-user-results');
          if (resBox) resBox.innerHTML = '';
          return;
        }
        userSearchTimer = setTimeout(async () => {
          const found = await searchJiraUsers(q, selectedTaskKey);
          searchedUsersResults = found.slice(0, 10);
          const resBox = document.getElementById('ozon-sb-user-results');
          if (resBox) {
            resBox.innerHTML = renderUserSearchResultsHtml(searchedUsersResults);
            bindUserPickerClicks(resBox, task, updateCurrentTask);
          }
        }, 200);
      });

      userSearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          saveAssigneeNow();
        }
      });
      userSearchInput.addEventListener('blur', () => setTimeout(() => {
        if (document.getElementById('ozon-sb-user-search')) saveAssigneeNow();
      }, 160));
    }

    function saveCustomerNow() {
      const customerInput = document.getElementById('ozon-sb-customer');
      if (!customerInput) return;
      const val = customerInput.value.trim() || 'Не указан';
      if (val === task.customer.name) return;
      searchedCustomerResults = [];
      updateCurrentTask({ customer: Object.assign({}, task.customer, { name: val }) });
      updateIssueCustomerInJira(selectedTaskKey, val, null);
      renderStructure();
    }

    const customerInput = document.getElementById('ozon-sb-customer');
    const customerResultsBox = document.getElementById('ozon-sb-customer-results');
    if (customerResultsBox) {
      bindCustomerPickerClicks(customerResultsBox, task, updateCurrentTask);
    }

    if (customerInput) {
      customerInput.addEventListener('input', (e) => {
        customerSearchQuery = e.target.value;
        if (custSearchTimer) clearTimeout(custSearchTimer);
        const q = customerSearchQuery.trim();
        if (!q || q === 'Не указан') {
          searchedCustomerResults = [];
          const box = document.getElementById('ozon-sb-customer-results');
          if (box) box.innerHTML = '';
          return;
        }
        custSearchTimer = setTimeout(async () => {
          const found = await searchJiraUsers(q, selectedTaskKey);
          searchedCustomerResults = found.slice(0, 10);
          const box = document.getElementById('ozon-sb-customer-results');
          if (box) {
            box.innerHTML = renderCustomerSearchResultsHtml(searchedCustomerResults);
            bindCustomerPickerClicks(box, task, updateCurrentTask);
          }
        }, 200);
      });

      customerInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          saveCustomerNow();
        }
      });
      customerInput.addEventListener('blur', () => setTimeout(() => {
        if (document.getElementById('ozon-sb-customer')) saveCustomerNow();
      }, 160));
    }

    const umbSearch = document.getElementById('ozon-sb-umb-search');
    if (umbSearch) {
      umbSearch.addEventListener('input', (e) => {
        umbSearchQuery = e.target.value;
        renderStructure();
        if (umbSearchTimer) clearTimeout(umbSearchTimer);
        if (umbSearchQuery.trim().length >= 2) {
          umbSearchTimer = setTimeout(async () => {
            await loadUmbEpicTasksFromJira(umbSearchQuery.trim());
            renderStructure();
          }, 250);
        }
      });
    }

    root.querySelectorAll('button[data-action="toggle-umb-link"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const uKey = btn.getAttribute('data-umb-key');
        const uItem = umbCatalog.find((u) => u.key === uKey);
        if (!uItem) return;
        const existingLink = task.projectTaskLinks.find((l) => l.key === uKey);

        if (existingLink) {
          const nextLinks = task.projectTaskLinks.filter((l) => l.key !== uKey);
          tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { projectTaskLinks: nextLinks }) : t));
          renderStructure();
          await deleteIssueLinkInJira(selectedTaskKey, uKey, existingLink.jiraLinkId || existingLink.id);
        } else {
          const nextLinks = [
            ...task.projectTaskLinks,
            {
              id: 'pt-' + Date.now(),
              key: uItem.key,
              summary: uItem.summary,
              status: uItem.status || 'Открыто',
              component: uItem.component || 'Без компонента',
              sprint: 'Не в спринте'
            }
          ];
          tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { projectTaskLinks: nextLinks }) : t));
          renderStructure();
          await createIssueLinkInJira(selectedTaskKey, uItem.key, 'projectTask');
        }
      });
    });

    root.querySelectorAll('button[data-action="move-pt-to-ip"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.getAttribute('data-pt-idx'));
        const item = task.projectTaskLinks[idx];
        if (!item) return;
        const nextPt = task.projectTaskLinks.filter((_, i) => i !== idx);
        const nextIp = [
          ...task.inProjectLinks,
          Object.assign({}, item, {
            component: item.component || 'Без компонента',
            sprint: item.sprint || 'Не в спринте'
          })
        ];
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { projectTaskLinks: nextPt, inProjectLinks: nextIp }) : t));
        showSaveToast('✓ ' + item.key + ' перенесена в «В проекте»');
        renderStructure();
      });
    });

    root.querySelectorAll('button[data-action="move-ip-to-pt"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.getAttribute('data-link-idx'));
        const item = task.inProjectLinks[idx];
        if (!item) return;
        const nextIp = task.inProjectLinks.filter((_, i) => i !== idx);
        const nextPt = [...task.projectTaskLinks, item];
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { projectTaskLinks: nextPt, inProjectLinks: nextIp }) : t));
        showSaveToast('✓ ' + item.key + ' перенесена в «Задача проекта»');
        renderStructure();
      });
    });

    root.querySelectorAll('button[data-action="remove-pt-link"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const lKey = btn.getAttribute('data-link-key');
        const jiraLinkId = btn.getAttribute('data-jira-link-id');
        const nextLinks = task.projectTaskLinks.filter((l) => l.key !== lKey);
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { projectTaskLinks: nextLinks }) : t));
        renderStructure();
        await deleteIssueLinkInJira(selectedTaskKey, lKey, jiraLinkId);
      });
    });

    // Input-Select Компонента для связанной задачи в «В проекте» (с подгрузкой компонентов соответствующего проекта OB / OBFRONT / FTD)
    root.querySelectorAll('[data-action="open-ip-comp-combo"]').forEach((trig) => {
      trig.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = Number(trig.getAttribute('data-link-idx'));
        const proj = trig.getAttribute('data-proj') || CONFIG.projectKey;
        if (sbIpCompOpenIdx === idx) {
          sbIpCompOpenIdx = null;
          renderStructure();
        } else {
          developmentDashboard.dismissEditor();
        sbIpCompOpenIdx = idx;
          sbIpCompSearchQuery = '';
          sbEpicComboOpen = false;
          sbCompComboOpen = false;
          renderStructure();
          await loadExternalProjectComponents(proj);
          renderStructure();
          const inp = document.getElementById('ozon-sb-ip-comp-search');
          if (inp) inp.focus();
        }
      });
    });

    const sbIpCompSearch = document.getElementById('ozon-sb-ip-comp-search');
    if (sbIpCompSearch) {
      sbIpCompSearch.addEventListener('click', (e) => e.stopPropagation());
      sbIpCompSearch.addEventListener('input', (e) => {
        sbIpCompSearchQuery = e.target.value;
        renderStructure();
      });
    }

    root.querySelectorAll('[data-action="pick-ip-comp"]').forEach((item) => {
      item.addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = Number(item.getAttribute('data-link-idx'));
        const lKey = item.getAttribute('data-link-key');
        const newComp = item.getAttribute('data-comp') || 'Без компонента';
        sbIpCompOpenIdx = null;
        sbIpCompSearchQuery = '';
        const nextIp = task.inProjectLinks.map((it, i) => (i === idx ? Object.assign({}, it, { component: newComp }) : it));
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { inProjectLinks: nextIp }) : t));
        if (lKey) {
          const compsPayload = newComp && newComp !== 'Без компонента' ? [{ name: newComp }] : [];
          fetch('/rest/api/2/issue/' + encodeURIComponent(lKey), {
            method: 'PUT',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fields: { components: compsPayload } })
          }).catch(() => {});
        }
        showSaveToast('✓ Компонент ' + (lKey || '') + ' → ' + newComp);
        renderStructure();
        // Available sprints are fetched when the sprint selector is opened.
      });
    });

    root.querySelectorAll('[data-action="open-ip-sprint-combo"]').forEach((trigger) => {
      trigger.addEventListener('click', async (event) => {
        event.stopPropagation();
        const idx = Number(trigger.getAttribute('data-link-idx'));
        if (sbIpSprintOpenIdx === idx) { sbIpSprintOpenIdx = null; renderStructure(); return; }
        developmentDashboard.dismissEditor();
        sbIpSprintOpenIdx = idx;
        renderStructure();
        const link = task.inProjectLinks[idx];
        if (link) { await loadSprintsForLinkedIssue(link); renderStructure(); }
      });
    });
    const sprintSearch = document.getElementById('ozon-sb-ip-sprint-search');
    if (sprintSearch) { sprintSearch.addEventListener('click', e => e.stopPropagation()); sprintSearch.addEventListener('input', e => { sbIpSprintSearchQuery = e.target.value; renderStructure(); }); }
    root.querySelectorAll('[data-action="pick-ip-sprint"]').forEach((item) => {
      item.addEventListener('click', (event) => {
        event.stopPropagation();
        const idx = Number(item.getAttribute('data-link-idx'));
        const linkKey = item.getAttribute('data-link-key');
        const sprint = item.getAttribute('data-sprint');
        const nextIp = task.inProjectLinks.map((link, i) => i === idx ? Object.assign({}, link, { sprint }) : link);
        tasks = tasks.map(t => t.key === selectedTaskKey ? Object.assign({}, t, { inProjectLinks: nextIp }) : t);
        sbIpSprintOpenIdx = null;
        sbIpSprintSearchQuery = '';
        updateIssueSprintInJira(linkKey, sprint);
        renderStructure();
      });
    });

    root.querySelectorAll('select[data-action="change-ip-sprint"]').forEach((sel) => {
      sel.addEventListener('focus', async () => {
        const idx = Number(sel.getAttribute('data-link-idx'));
        const lnk = task.inProjectLinks[idx];
        if (!lnk) return;
        await loadSprintsForLinkedIssue(lnk);
        const opts = getSprintsForLinkedIssue(lnk);
        const realSpVal = (lnk.sprint && String(lnk.sprint).trim()) || 'Не в спринте';
        sel.innerHTML = buildSprintSelectOptionsHtml(opts, realSpVal, 'Спринт: ');
      });
      sel.addEventListener('change', (e) => {
        const idx = Number(sel.getAttribute('data-link-idx'));
        const lKey = sel.getAttribute('data-link-key');
        const newSp = e.target.value;
        const nextIp = task.inProjectLinks.map((item, i) => (i === idx ? Object.assign({}, item, { sprint: newSp }) : item));
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { inProjectLinks: nextIp }) : t));
        if (lKey) {
          updateIssueSprintInJira(lKey, newSp);
        }
        renderStructure();
      });
    });

    root.querySelectorAll('button[data-action="remove-ip-link"]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const idx = Number(btn.getAttribute('data-link-idx'));
        const lKey = btn.getAttribute('data-link-key');
        const jiraLinkId = btn.getAttribute('data-jira-link-id');
        const nextIp = task.inProjectLinks.filter((_, i) => i !== idx);
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { inProjectLinks: nextIp }) : t));
        renderStructure();
        if (lKey) {
          await deleteIssueLinkInJira(selectedTaskKey, lKey, jiraLinkId);
        }
      });
    });

    root.querySelectorAll('[data-action="toggle-front-design"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        const details = button.closest('.ozon-ext-link-compact-row')?.querySelector('[data-front-design-details]');
        if (!details) return;
        details.hidden = !details.hidden;
        button.setAttribute('aria-expanded', String(!details.hidden));
      });
    });
    root.querySelectorAll('[data-action="link-front-design"]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const frontKey = button.getAttribute('data-front-key');
        const designKey = button.getAttribute('data-design-key');
        button.disabled = true;
        const linked = await createIssueLinkInJira(frontKey, designKey, 'linkedTask');
        if (linked) {
          delete frontDesignLinksByKey[frontKey];
          await loadFrontDesignRelation(frontKey);
          renderStructure();
        } else {
          button.disabled = false;
          showSaveToast('Не удалось связать фронтовую задачу с дизайном');
        }
      });
    });

    root.querySelectorAll('[data-action="toggle-create-in-project-menu"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        createInProjectMenuOpen = !createInProjectMenuOpen;
        otherLinkMenuOpen = false;
        renderStructure();
      });
    });
    root.querySelectorAll('[data-action="toggle-other-link-menu"]').forEach((button) => {
      button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); otherLinkMenuOpen = !otherLinkMenuOpen; createInProjectMenuOpen = false; renderStructure(); });
    });
    root.querySelectorAll('[data-action="start-create-link"]').forEach((button) => {
      button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); linkCreateDraft = {kind:button.getAttribute('data-link-kind'), sourceKey:task.key}; createInProjectMenuOpen = false; otherLinkMenuOpen = false; renderStructure(); });
    });
    root.querySelectorAll('[data-action="close-link-create"]').forEach((button) => {
      button.addEventListener('click', (event) => { if (event.target !== button) return; event.preventDefault(); event.stopPropagation(); linkCreateDraft = null; renderStructure(); });
    });
    const linkCreateForm = root.querySelector('#ozon-link-create-form');
    linkCreateForm?.addEventListener('submit', async (event) => {
      event.preventDefault(); event.stopPropagation();
      if (!linkCreateDraft) return;
      const draft = linkCreateDraft;
      const message = linkCreateForm.querySelector('#ozon-link-create-message');
      const submit = linkCreateForm.querySelector('[type="submit"]');
      const fail = (text) => { message.textContent = text; message.hidden = false; submit.disabled = false; submit.textContent = 'Связать'; };
      const key = String(linkCreateForm.querySelector('#ozon-link-create-key')?.value || '').trim().toUpperCase();
      const url = String(linkCreateForm.querySelector('#ozon-link-create-url')?.value || '').trim();
      const title = String(linkCreateForm.querySelector('#ozon-link-create-title')?.value || '').trim();
      if (draft.kind !== 'web' && !/^[A-Z][A-Z0-9]*-\d+$/.test(key)) { fail('Введите ключ задачи, например FCRM-1234.'); return; }
      if (draft.kind === 'web') { try { if (!['http:', 'https:'].includes(new URL(url).protocol) || !title) throw new Error(); } catch (_) { fail('Укажите ссылку http или https и её название.'); return; } }
      submit.disabled = true; submit.textContent = 'Сохраняем…'; message.hidden = true;
      try {
        if (draft.kind === 'web') {
          const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(draft.sourceKey) + '/remotelink', {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({object:{url,title}})});
          if (!response.ok) throw new Error('Не удалось добавить ссылку в Jira (HTTP ' + response.status + ').');
        } else if (!await createIssueLinkInJira(draft.sourceKey, key, draft.kind, true, true)) throw new Error('Не удалось создать связь в Jira. Проверьте ключ и доступный тип связи.');
        if (linkCreateDraft === draft) linkCreateDraft = null;
        await refreshLinksWithoutSkeleton(draft.sourceKey);
        showSaveToast('✓ Связь добавлена');
      } catch (error) { if (linkCreateDraft === draft) fail(error.message || 'Не удалось добавить связь.'); else showSaveToast(error.message); }
    });

    root.querySelectorAll('[data-action="start-create-issue"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const kind = button.getAttribute('data-create-kind');
        if (kind === 'design') {
          createInProjectMenuOpen = false;
          renderStructure();
          document.dispatchEvent(new CustomEvent('ozon-fcrm-start-design-task', { detail: JSON.stringify({ issueKey: selectedTaskKey }) }));
        } else {
          beginSidebarIssueCreate(kind);
        }
      });
    });

    root.querySelectorAll('[data-action="close-create-issue"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        issueCreateDraft = null;
        issueCreateBusy = false;
        issueCreateLoading = false;
        renderStructure();
      });
    });

    const createSummaryInput = document.getElementById('ozon-create-issue-summary');
    if (createSummaryInput) createSummaryInput.addEventListener('input', (event) => { if (issueCreateDraft) issueCreateDraft.summary = event.target.value; });
    const createDescriptionInput = document.getElementById('ozon-create-issue-description');
    if (createDescriptionInput) createDescriptionInput.addEventListener('input', (event) => { if (issueCreateDraft) issueCreateDraft.description = event.target.value; });
    const createComponentSearch = document.getElementById('ozon-create-issue-component-search');
    if (createComponentSearch) createComponentSearch.addEventListener('input', (event) => {
      if (!issueCreateDraft) return;
      issueCreateDraft.componentQuery = event.target.value;
      renderStructure();
    });
    root.querySelectorAll('[data-action="pick-create-component"]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!issueCreateDraft) return;
        issueCreateDraft.componentId = button.getAttribute('data-component-id');
        issueCreateDraft.error = '';
        renderStructure();
      });
    });
    const createIssueForm = document.getElementById('ozon-create-issue-form');
    if (createIssueForm) {
      createIssueForm.addEventListener('click', (event) => event.stopPropagation());
      createIssueForm.addEventListener('submit', (event) => {
        event.preventDefault();
        submitSidebarIssueCreate();
      });
    }

    const addIpBtn = document.getElementById('ozon-add-ip-btn');
    if (addIpBtn) {
      addIpBtn.addEventListener('click', async () => {
        const kEl = document.getElementById('ozon-new-ip-key');
        const sEl = document.getElementById('ozon-new-ip-summary');
        const keyVal = kEl && kEl.value.trim().toUpperCase();
        if (!keyVal) {
          showSaveToast('Введите код задачи Jira (например OB-311121 или FCRM-2273)');
          return;
        }
        const sumVal = (sEl && sEl.value.trim()) || keyVal;

        const nextIp = [
          ...task.inProjectLinks,
          {
            id: 'ip-' + Date.now(),
            key: keyVal,
            summary: sumVal,
            status: 'Открыто',
            component: 'Без компонента',
            sprint: 'Не в спринте'
          }
        ];
        tasks = tasks.map((t) => (t.key === selectedTaskKey ? Object.assign({}, t, { inProjectLinks: nextIp }) : t));
        renderStructure();
        await createIssueLinkInJira(selectedTaskKey, keyVal, 'inProject');
      });
    }
  }

  function injectToggleButton() {
    if (!isTargetBoardPage()) return;
    if (document.getElementById('ozon-structure-toggle-btn')) return;
    const headerTarget =
      document.querySelector('#ghx-modes-tools') ||
      document.querySelector('#ghx-header') ||
      document.querySelector('.aui-header-primary .aui-nav') ||
      document.body;

    const btn = document.createElement('button');
    btn.id = 'ozon-structure-toggle-btn';
    btn.className = 'active';
    btn.textContent = 'Ozon Structure FCRM';
    btn.addEventListener('click', () => {
      isStructureVisible = !isStructureVisible;
      btn.classList.toggle('active', isStructureVisible);
      renderStructure();
    });

    headerTarget.appendChild(btn);
  }

  function init() {
    if (!isTargetBoardPage()) return;
    document.addEventListener('click', (event) => {
      const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (anchor && anchor.closest('#ozon-structure-root, .ozon-component-editor, #ozon-thread-sidebar')) prepareNavigationLink(anchor);
    }, true);
    ensureGoogleFontsLoaded();
    injectToggleButton();
    renderStructure();
    function addEditorTaskContext(panel, key) {
      const task = tasks.find((item) => item.key === key);
      const issue = strategicDashboard.getState().issues.find((item) => item.key === key);
      const summary = task?.summary || issue?.fields?.summary || '';
      if (summary) panel.querySelector('.component-editor-head')?.insertAdjacentHTML('afterend', '<div class="component-editor-context" title="' + escapeHtml(summary) + '">' + escapeHtml(summary) + '</div>');
    }
    let priorityEditor = null;
    async function openPriorityEditor(key) {
      if (!key) return;
      priorityEditor?.remove();
      const panel = document.createElement('aside'); priorityEditor = panel;
      panel.className = 'ozon-component-editor ozon-priority-editor'; panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-label', 'Приоритет задачи ' + key);
      panel.style.cssText = 'position:fixed;z-index:2147483646;right:0;top:0;bottom:0;height:100vh;width:min(500px,100vw);background:#fff;box-shadow:-8px 0 24px #0f172a22;padding:20px;display:flex;flex-direction:column;gap:12px;box-sizing:border-box;font:13px Arial,sans-serif;color:#071026';
      panel.innerHTML = '<div class="component-editor-head"><strong>Приоритет задачи · ' + escapeHtml(key) + '</strong><button type="button" class="component-editor-close" data-close aria-label="Закрыть">✕</button></div><div role="status">Загружаем приоритеты…</div>';
      document.body.appendChild(panel);
      panel.querySelector('[data-close]').onclick = () => panel.remove();
      panel.addEventListener('pointerdown', event => event.stopPropagation());
      panel.addEventListener('click', event => event.stopPropagation());
      try {
        const [response, options] = await Promise.all([fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=priority', {credentials:'same-origin',headers:{Accept:'application/json'},cache:'no-store'}), jiraPriorityService.options(key)]);
        if (!response.ok) throw new Error('Не удалось загрузить приоритет: HTTP ' + response.status);
        const issue = await response.json(); if (!panel.isConnected) return;
        const current = issue.fields?.priority || {};
        const isCurrent = option => option.value?.id && current.id ? String(option.value.id) === String(current.id) : option.label === current.name;
        panel.innerHTML = '<div class="component-editor-head"><strong>Приоритет задачи · ' + escapeHtml(key) + '</strong><button type="button" class="component-editor-close" data-close aria-label="Закрыть">✕</button></div><div class="ozon-sprint-current"><span>Текущий приоритет</span><strong>' + jiraPriorityService.icon(current.name || '') + ' ' + escapeHtml(current.name || 'Не указан') + '</strong></div><div class="component-editor-caption">Выберите приоритет</div><div class="component-editor-list">' + options.map((option,index) => '<button type="button" class="component-editor-option ' + (isCurrent(option) ? 'is-selected' : '') + '" data-index="' + index + '" aria-pressed="' + Boolean(isCurrent(option)) + '">' + jiraPriorityService.icon(option.label) + '<span>' + escapeHtml(option.label) + '</span></button>').join('') + '</div><div data-error role="alert" style="color:#d92d20"></div>';
        addEditorTaskContext(panel, key);
        panel.querySelector('[data-close]').onclick = () => panel.remove();
        panel.querySelectorAll('[data-index]').forEach(button => button.addEventListener('click', async () => {
          const option = options[Number(button.getAttribute('data-index'))]; if (!option) return;
          panel.querySelectorAll('[data-index]').forEach(item => { item.disabled = true; });
          try {
            const priority = await jiraPriorityService.save(key, option.value);
            tasks = tasks.map(task => { const updated = task.key === key ? Object.assign({}, task, {priority:priority.name}) : task; const next = Object.assign({}, updated); ['projectTaskLinks','inProjectLinks','otherLinks'].forEach(field => { if (Array.isArray(updated[field])) next[field] = updated[field].map(link => link.key === key ? Object.assign({}, link, {priority:priority.name}) : link); }); return next; });
            if (tasks.some(task => task.key === key)) saveTaskOverride(key, {priority:priority.name});
            const strategicIssue = strategicDashboard.getState().issues.find(item => item.key === key); if (strategicIssue?.fields) { strategicIssue.fields.priority = priority; strategicDashboard.invalidateGraph(); }
            developmentDashboard.getState().groups.forEach(group => group.issues.forEach(item => { if (item.key === key) item.priority = priority.name; if (item.epicKey === key) item.epicPriority = priority.name; (item.links || []).forEach(link => { if (link.key === key) link.priority = priority.name; }); }));
            panel.remove(); renderStructure(); showSaveToast('Приоритет ' + key + ' сохранён');
          } catch (error) { if (panel.isConnected) { panel.querySelector('[data-error]').textContent = error.message || 'Не удалось изменить приоритет'; panel.querySelectorAll('[data-index]').forEach(item => { item.disabled = false; }); } }
        }));
      } catch (error) { if (panel.isConnected) panel.querySelector('[role="status"]').textContent = error.message || 'Не удалось загрузить приоритет'; }
    }
    document.addEventListener('click', event => {
      const button = event.target instanceof Element ? event.target.closest('[data-priority-key], [data-dev-action="edit-priority"], [data-strategy-action="priority"]') : null;
      if (!button || !button.closest('#ozon-structure-root')) return;
      event.preventDefault(); event.stopImmediatePropagation();
      openPriorityEditor(button.getAttribute('data-priority-key') || button.getAttribute('data-key'));
    }, true);
    document.addEventListener('pointerdown', event => { if (priorityEditor?.isConnected && event.target instanceof Element && !priorityEditor.contains(event.target)) { priorityEditor.remove(); priorityEditor = null; } }, true);
    // Общий редактор компонентов для таблиц и связей во всех представлениях.
    let componentEditor = null;
    async function openComponentEditor(key) {
      if (!key) return;
      componentEditor?.remove();
      const panel = document.createElement('aside');
      componentEditor = panel;
      panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-label', 'Компоненты задачи ' + key);
      panel.className = 'ozon-component-editor';
      panel.style.cssText = 'position:fixed;z-index:2147483646;right:0;top:0;left:auto;bottom:0;height:100vh;width:min(500px,100vw);background:#fff;box-shadow:-8px 0 24px #0f172a22;padding:20px;display:flex;flex-direction:column;gap:12px;box-sizing:border-box;font:13px Arial,sans-serif;color:#071026;';
      panel.innerHTML = '<div class="component-editor-head"><strong>Компоненты задачи · ' + escapeHtml(key) + '</strong><button type="button" class="component-editor-close" data-close aria-label="Закрыть">✕</button></div><div role="status">Загружаем компоненты…</div>';
      document.body.appendChild(panel);
      panel.addEventListener('pointerdown', (event) => event.stopPropagation());
      panel.addEventListener('click', (event) => event.stopPropagation());
      panel.querySelector('[data-close]').onclick = () => panel.remove();
      try {
        const project = getIssueProjectKey(key);
        const [issueResponse, optionsResponse] = await Promise.all([
          fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=components', {credentials:'same-origin',cache:'no-store'}),
          fetch('/rest/api/2/project/' + encodeURIComponent(project) + '/components', {credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}})
        ]);
        if (!issueResponse.ok || !optionsResponse.ok) throw new Error('Не удалось загрузить компоненты из Jira');
        const issue = await issueResponse.json();
        const records = await optionsResponse.json();
        if (!Array.isArray(records)) throw new Error('Jira вернула некорректный список компонентов');
        const options = records.filter((item) => item && item.id && item.name && item.archived !== true && item.deleted !== true && (!item.project || String(item.project).toUpperCase() === project));
        if (window.__ozonPreviewApi) {
          const visible = tasks.find((item) => item.key === key);
          const display = String(visible?.component || '').trim();
          if (display && display !== 'Без компонента') {
            const byName = new Map(options.map((item) => [String(item.name), item]));
            let rest = display;
            const resolved = [];
            const ordered = [...byName.keys()].sort((a,b) => b.length - a.length);
            while (rest) {
              const match = ordered.find((name) => rest === name || rest.startsWith(name + ', '));
              if (!match) { resolved.length = 0; break; }
              resolved.push(byName.get(match));
              rest = rest.slice(match.length).replace(/^, /, '');
            }
            if (resolved.length) issue.fields.components = resolved;
          } else if (visible && display === 'Без компонента') issue.fields.components = [];
        }
        if (!panel.isConnected) return;
        const currentComponents = issue.fields?.components || [];
        const matchOption = (c) => options.find((option) => (c.id && String(option.id) === String(c.id)) || (c.name && option.name === c.name));
        const selected = new Set(currentComponents.map((c) => { const option = matchOption(c); return String(option?.id || option?.name || c.id || c.name); }));
        const unavailable = currentComponents.filter((c) => !matchOption(c)).map((c) => Object.assign({}, c, {unavailable:true}));
        const allOptions = [...unavailable, ...options];
        panel.innerHTML = '<div class="component-editor-head"><strong>Компоненты задачи · ' + escapeHtml(key) + '</strong><button type="button" class="component-editor-close" data-close aria-label="Закрыть">✕</button></div><div class="component-editor-search"><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5.5" stroke="currentColor" stroke-width="1.7"/><path d="m13 13 4 4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><input type="search" data-search placeholder="Поиск компонента…" aria-label="Поиск компонента"></div><div class="component-editor-caption"><span>Выберите компоненты</span><span data-count></span></div><div data-list class="component-editor-list"></div><div data-error role="alert" style="color:#d92d20"></div><div class="component-editor-footer"><button type="button" data-cancel class="component-editor-button">Отмена</button><button type="button" data-save class="component-editor-button primary">Сохранить</button></div>';
        addEditorTaskContext(panel, key);
        const list = panel.querySelector('[data-list]');
        const search = panel.querySelector('[data-search]');
        function renderOptions() {
          const query = search.value.trim().toLowerCase();
          const filtered = allOptions.filter((c) => (!c.unavailable || selected.has(String(c.id || c.name))) && String(c.name || '').toLowerCase().includes(query))
            .sort((a, b) => Number(selected.has(String(b.id || b.name))) - Number(selected.has(String(a.id || a.name))));
          panel.querySelector('[data-count]').textContent = 'Выбрано: ' + selected.size;
          list.innerHTML = filtered.length ? filtered.map((c) => '<label class="component-editor-option ' + (selected.has(String(c.id || c.name)) ? 'is-selected' : '') + '"><input type="checkbox" data-component-id="' + escapeHtml(String(c.id || c.name)) + '" ' + (selected.has(String(c.id || c.name)) ? 'checked' : '') + '><span>' + escapeHtml(c.name || '') + (c.unavailable ? ' <span style="color:#71839b;font-size:11px;font-weight:400">· недоступен для добавления</span>' : '') + '</span></label>').join('') : '<div style="padding:12px 10px;color:#64748b">Компоненты не найдены</div>';
        }
        search.addEventListener('input', renderOptions);
        list.addEventListener('change', (event) => { const id = event.target.getAttribute('data-component-id'); if (!id) return; if (event.target.checked) selected.add(id); else selected.delete(id); const scrollTop = list.scrollTop; renderOptions(); list.scrollTop = scrollTop; [...list.querySelectorAll('[data-component-id]')].find((input) => input.getAttribute('data-component-id') === id)?.focus({preventScroll:true}); });
        panel.querySelector('[data-close]').onclick = panel.querySelector('[data-cancel]').onclick = () => panel.remove();
        panel.querySelector('[data-save]').onclick = async (event) => {
          const save = event.currentTarget; save.disabled = true;
          try {
            const chosen = allOptions.filter((c) => selected.has(String(c.id || c.name)));
            const response = await fetch('/rest/api/2/issue/' + encodeURIComponent(key), {method:'PUT',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({fields:{components:chosen.map((c) => c.id ? {id:String(c.id)} : {name:c.name})}})});
            if (!response.ok) throw new Error('Не удалось сохранить компоненты: ' + response.status);
            const verify = await fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=components', {credentials:'same-origin',cache:'no-store'});
            if (!verify.ok) throw new Error('Не удалось проверить сохранение компонентов');
            const fresh = await verify.json(); const actual = fresh.fields?.components || [];
            const actualIds = actual.map((c) => String(c.id || c.name)).sort(); const expectedIds = chosen.map((c) => String(c.id || c.name)).sort();
            if (JSON.stringify(actualIds) !== JSON.stringify(expectedIds)) throw new Error('Jira не подтвердила выбранные компоненты');
            const names = actual.map((c) => c.name).filter(Boolean); const component = names.join(', ') || 'Без компонента';
            umbCatalog = umbCatalog.map((item) => item.key === key ? Object.assign({}, item, {component, components:names}) : item);
            tasks = tasks.map((task) => { const updated = task.key === key ? Object.assign({}, task, {component,components:names}) : task; return Object.assign({}, updated, {inProjectLinks:(updated.inProjectLinks || []).map((link) => link.key === key ? Object.assign({}, link, {component,components:names}) : link)}); });
            if (tasks.some((task) => task.key === key)) saveTaskOverride(key, {component,components:names});
            const strategyIssue = strategicDashboard.getState().issues.find((item) => item.key === key); if (strategyIssue?.fields) { strategyIssue.fields.components = actual; strategicDashboard.invalidateGraph(); }
            developmentDashboard.getState().groups.forEach((group) => group.issues.forEach((item) => { if (item.key === key) { item.component = component; item.componentNames = names; item.componentId = actual[0]?.id || ''; } if (item.epicKey === key) item.epicComponent = component; (item.links || []).forEach((link) => { if (link.key === key) link.component = component; }); }));
            panel.remove(); renderStructure(); showSaveToast('Компоненты ' + key + ' сохранены');
          } catch (error) { panel.querySelector('[data-error]').textContent = error.message || 'Ошибка сохранения'; save.disabled = false; }
        };
        renderOptions();
      } catch (error) { if (panel.isConnected) panel.querySelector('[role="status"]').textContent = error.message || 'Не удалось загрузить компоненты'; }
    }
    document.addEventListener('click', (event) => {
      const target = event.target instanceof Element ? event.target.closest('#ozon-sb-comp-trigger, [data-action="open-table-comp-combo"], [data-action="open-ip-comp-combo"], [data-dev-action="edit-component"], [data-strategy-action="edit-component"]') : null;
      if (!target || !target.closest('#ozon-structure-root')) return;
      event.preventDefault(); event.stopImmediatePropagation();
      let key = target.getAttribute('data-key') || '';
      if (target.id === 'ozon-sb-comp-trigger') key = selectedTaskKey;
      if (target.getAttribute('data-action') === 'open-ip-comp-combo') { const task = tasks.find((item) => item.key === selectedTaskKey); key = task?.inProjectLinks?.[Number(target.getAttribute('data-link-idx'))]?.key || ''; }
      openComponentEditor(key);
    }, true);
    document.addEventListener('pointerdown', (event) => { if (componentEditor?.isConnected && event.target instanceof Element && !componentEditor.contains(event.target)) { componentEditor.remove(); componentEditor = null; event.stopImmediatePropagation(); } }, true);
    let sprintEditor = null;
    async function openSprintEditor(key, linkedIssue) {
      if (!key) return;
      sprintEditor?.remove();
      const task = tasks.find((item) => item.key === key) || linkedIssue || {};
      const current = String(task.sprint || 'Бэклог FCRM');
      const panel = document.createElement('aside'); sprintEditor = panel;
      panel.className = 'ozon-component-editor'; panel.setAttribute('role','dialog');
      panel.setAttribute('aria-label','Спринт задачи ' + key);
      panel.style.cssText = 'position:fixed;z-index:2147483646;right:0;top:0;bottom:0;height:100vh;width:min(500px,100vw);background:#fff;box-shadow:-8px 0 24px #0f172a22;padding:20px;display:flex;flex-direction:column;box-sizing:border-box';
      panel.innerHTML = '<div class="component-editor-head"><strong>Спринт задачи · ' + escapeHtml(key) + '</strong><button type="button" class="component-editor-close" data-close aria-label="Закрыть">✕</button></div><div class="ozon-sprint-current"><span>Текущий спринт</span><strong>' + escapeHtml(current) + '</strong></div><div class="component-editor-search"><input type="search" data-search placeholder="Поиск спринта…" aria-label="Поиск спринта" style="padding-left:10px"></div><div data-list class="component-editor-list" role="status">Загружаем спринты…</div><div data-error role="alert" style="color:#d92d20"></div>';
      addEditorTaskContext(panel, key);
      document.body.appendChild(panel);
      panel.querySelector('[data-close]').onclick = () => panel.remove();
      panel.addEventListener('pointerdown', (event) => event.stopPropagation());
      panel.addEventListener('click', (event) => event.stopPropagation());
      try {
        const options = linkedIssue ? await loadSprintsForLinkedIssue(linkedIssue) : getEditableSprintOptions();
        if (!panel.isConnected) return;
        const sprints = [...new Set(['Бэклог FCRM', ...(options || []).filter((sp) => sp && !/^(Бэклог|Не в спринте)/i.test(sp))])];
        const list = panel.querySelector('[data-list]'); list.removeAttribute('role');
        const search = panel.querySelector('[data-search]');
        const render = () => { const q=search.value.trim().toLowerCase(); const found=sprints.filter((sp)=>sp.toLowerCase().includes(q)); list.innerHTML=found.length ? found.map((sp)=>'<button type="button" class="component-editor-option ' + (sp === current ? 'is-selected' : '') + '" data-sprint="' + escapeHtml(sp) + '"><span>' + escapeHtml(sp) + '</span>' + getSprintStateBadgeHtml(sp) + '</button>').join('') : '<div>Спринты не найдены</div>'; };
        search.addEventListener('input',render); render();
        list.addEventListener('click',async (event) => { const button=event.target.closest('[data-sprint]'); if (!button) return; const name=button.getAttribute('data-sprint'); const backlog=/^(Бэклог|Не в спринте)/i.test(name); const id=sprintIdByName[name];
          if (!backlog && !id) { panel.querySelector('[data-error]').textContent='Не удалось определить спринт в Jira'; return; }
          button.disabled=true; panel.querySelector('[data-error]').textContent='';
          try { const response=await fetch(backlog ? '/rest/agile/1.0/backlog/issue' : '/rest/agile/1.0/sprint/' + encodeURIComponent(id) + '/issue',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({issues:[key]})}); if (!response.ok) throw new Error('Не удалось сохранить спринт: HTTP ' + response.status);
            const value=backlog ? (getIssueProjectKey(key) === CONFIG.projectKey ? 'Бэклог FCRM' : 'Не в спринте') : name; issueSprintOverrideMap[key]=value; tasks=tasks.map((item)=>{const updated=item.key===key ? Object.assign({},item,{sprint:value}) : item; return Object.assign({},updated,{inProjectLinks:(updated.inProjectLinks || []).map((link)=>link.key===key ? Object.assign({},link,{sprint:value}) : link)});}); if(tasks.some((item)=>item.key===key)) saveTaskOverride(key,{sprint:value}); panel.remove(); renderStructure(); void refreshStrategyIssue(key, decodeURIComponent(getBoardFieldsParam())); showSaveToast('Спринт ' + key + ' сохранён');
          } catch(error) { panel.querySelector('[data-error]').textContent=error.message || 'Ошибка сохранения'; button.disabled=false; }
        });
      } catch(error) { if(panel.isConnected) panel.querySelector('[data-list]').textContent=error.message || 'Не удалось загрузить спринты'; }
    }
    document.addEventListener('click',(event)=>{
      const target=event.target instanceof Element ? event.target.closest('[data-action="toggle-search-select"][data-select-id="sidebar-sprint"], [data-action="toggle-search-select"][data-select-id^="table-sprint-"], [data-action="open-ip-sprint-combo"]') : null;
      if(!target || !target.closest('#ozon-structure-root')) return;
      event.preventDefault(); event.stopImmediatePropagation(); const id=target.getAttribute('data-select-id') || ''; let key=id === 'sidebar-sprint' ? selectedTaskKey : id.slice('table-sprint-'.length); let linkedIssue=null;
      if(target.getAttribute('data-action') === 'open-ip-sprint-combo') { linkedIssue=tasks.find((item)=>item.key===selectedTaskKey)?.inProjectLinks?.[Number(target.getAttribute('data-link-idx'))]; key=linkedIssue?.key || ''; }
      openSprintEditor(key,linkedIssue);
    },true);
    document.addEventListener('pointerdown',(event)=>{ if(sprintEditor?.isConnected && event.target instanceof Element && !sprintEditor.contains(event.target)) { sprintEditor.remove(); sprintEditor=null; event.stopImmediatePropagation(); } },true);
    const issueTooltipCache = new Map();
    let issueTooltipTarget = null;
    let issueTooltip = null;
    let issueTooltipTitles = [];
    const renderIssueTooltip = (title, detail) => {
      if (!issueTooltip) return;
      const heading = document.createElement('strong');
      heading.style.cssText = 'display:block;font-size:14px;line-height:1.4;font-weight:700;color:#fff;margin-bottom:8px;';
      heading.textContent = title;
      const body = document.createElement('div');
      body.style.cssText = 'font-size:12px;line-height:1.5;color:#dce6f5;font-weight:400;';
      body.textContent = detail;
      issueTooltip.replaceChildren(heading, body);
    };
    document.addEventListener('mouseover', (event) => {
      const target = event.target instanceof Element ? event.target.closest('.ozon-ip-summary, .ozon-other-summary, #ozon-structure-root a[href*="/browse/"], #o3ds-layer a[href*="/browse/"], #ozon-thread-sidebar a[href*="/browse/"]') : null;
      if (!target || target === issueTooltipTarget) return;
      const row = target.closest('.ozon-ext-link-compact-row, .ozon-ext-section-card, tr, div');
      const anchor = target.matches('a[href*="/browse/"]') ? target : row?.querySelector('a[href*="/browse/"]');
      const match = anchor && /\/browse\/([A-Z][A-Z0-9]*-\d+)/i.exec(anchor.getAttribute('href') || '');
      if (!match) return;
      const key = match[1].toUpperCase();
      const text = target.matches('.ozon-ip-summary, .ozon-other-summary') ? target.textContent.trim() : (anchor.getAttribute('title') || anchor.textContent.trim());
      issueTooltipTitles = [];
      for (let node = target; node && node !== document.body; node = node.parentElement) {
        if (node.hasAttribute('title')) { issueTooltipTitles.push([node,node.getAttribute('title')]); node.removeAttribute('title'); }
      }
      issueTooltipTarget = target;
      if (!issueTooltip) { issueTooltip = document.createElement('div'); issueTooltip.setAttribute('role','tooltip'); issueTooltip.style.cssText = 'position:fixed;z-index:2147483647;max-width:min(420px,90vw);padding:10px 12px;background:#071026;color:white;border-radius:8px;font:12px/1.45 sans-serif;box-shadow:0 4px 16px #07102633;white-space:pre-wrap;overflow-wrap:anywhere;pointer-events:none;'; document.body.appendChild(issueTooltip); }
      const rect = target.getBoundingClientRect();
      issueTooltip.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - Math.min(420, window.innerWidth - 16))) + 'px';
      issueTooltip.style.top = Math.max(8, Math.min(rect.bottom + 6, window.innerHeight - 140)) + 'px';
      renderIssueTooltip(key + ' · ' + text, 'Загрузка описания…');
      if (!issueTooltipCache.has(key)) issueTooltipCache.set(key, fetch('/rest/api/2/issue/' + encodeURIComponent(key) + '?fields=summary,description', {credentials:'same-origin',headers:{Accept:'application/json'}}).then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); }).catch(() => null));
      issueTooltipCache.get(key).then(issue => {
        if (issueTooltipTarget !== target || !issueTooltip) return;
        const description = typeof issue?.fields?.description === 'string' ? issue.fields.description.replace(/\r/g,'').trim() : '';
        const excerpt = description.split('\n').filter(Boolean).slice(0,4).join('\n').slice(0,400);
        renderIssueTooltip(key + ' · ' + (issue?.fields?.summary || text), excerpt || 'Описание отсутствует или недоступно');
      });
    });
    document.addEventListener('mouseout', (event) => {
      if (issueTooltipTarget && !issueTooltipTarget.contains(event.relatedTarget)) { issueTooltipTitles.forEach(([node,title]) => { if (node.isConnected && !node.hasAttribute('title')) node.setAttribute('title',title); }); issueTooltipTitles = []; issueTooltipTarget = null; issueTooltip?.remove(); issueTooltip = null; }
    });
    document.addEventListener('pointerdown', (event) => {
      const target = event.target;
      if (createInProjectMenuOpen && target instanceof Element && !target.closest('.ozon-ext-create-menu, [data-action="toggle-create-in-project-menu"]')) {
        createInProjectMenuOpen = false;
        document.querySelector('.ozon-ext-create-menu')?.remove();
      }
      if (otherLinkMenuOpen && target instanceof Element && !target.closest('.ozon-ext-other-link-menu, [data-action="toggle-other-link-menu"]')) { otherLinkMenuOpen = false; document.querySelector('.ozon-ext-other-link-menu')?.remove(); }
      if (!(target instanceof Element) || target.closest('.ozon-ext-combo-popover, [role="dialog"]:not(#ozon-dev-editor-panel):not(#o3ds-layer), #ozon-ext-sidebar-resizer')) return;
      const panels = ['#o3ds-layer', '#ozon-thread-sidebar:not([hidden])', '.ozon-dev-settings', '#ozon-dev-editor-panel', '#ozon-ext-sidebar-panel'];
      const panel = panels.map(selector => document.querySelector(selector)).find(Boolean);
      if (panel?.id === 'o3ds-layer' && target.closest('#ozon-ext-sidebar-panel, #ozon-ext-sidebar-resizer')) return;
      if (!panel || panel.contains(target)) return;
      const selectedKey = selectedTaskKey;
      setTimeout(() => {
        if (!panel.isConnected) return;
        if (panel.id === 'o3ds-layer') { document.dispatchEvent(new CustomEvent('ozon-close-assistant')); return; }
        if (panel.id === 'ozon-thread-sidebar') { panel.querySelector('[data-thread-close]')?.click(); return; }
        if (panel.matches('.ozon-dev-settings')) { panel.querySelector('[data-dev-action="settings-cancel"]')?.click(); return; }
        if (panel.id === 'ozon-dev-editor-panel') { panel.querySelector('[data-dev-action="close-editor"]')?.click(); return; }
        if (selectedTaskKey === selectedKey) document.getElementById('ozon-ext-sidebar-close')?.click();
      }, 0);
    }, true);
    if (activeDashboardView === 'product') prepareProductFilters();
    if (activeDashboardView === 'strategy') strategicDashboard.prepareFilters();

    document.addEventListener('ozon-fcrm-issue-applied', (event) => {
      const issueKey = event && event.detail && event.detail.issueKey;
      if (issueKey && tasks.some((task) => task.key === issueKey)) {
        reloadSingleTaskFromJira(issueKey, true);
      }
    });

    // Закрытие открытых поповеров по клику вне них
    document.addEventListener('click', (e) => {
      if (
        !e.target.closest('.ozon-ext-combo-popover') &&
        !e.target.closest('.ozon-ext-toolbar-trigger') &&
        !e.target.closest('.ozon-ext-search-select-trigger') &&
        !e.target.closest('.ozon-ext-cell-combo-trigger') &&
        !e.target.closest('.ozon-ext-status-trigger') &&
        !e.target.closest('.ozon-ext-sb-combo-trigger') &&
        !e.target.closest('#ozon-ext-toggle-col-order') &&
        !e.target.closest('.ozon-ext-product-settings')
      ) {
        if (activeTableCombo || sbEpicComboOpen || sbCompComboOpen || sbIpCompOpenIdx !== null || sbIpSprintOpenIdx !== null || isColOrderPanelOpen || activeToolbarFilter || activeSearchSelectId) {
          activeTableCombo = null;
          tableUserSearchResults = [];
          sbEpicComboOpen = false;
          sbCompComboOpen = false;
          sbIpCompOpenIdx = null;
          sbIpSprintOpenIdx = null;
          isColOrderPanelOpen = false;
          activeToolbarFilter = '';
          toolbarFilterSearch = '';
          activeSearchSelectId = '';
          searchSelectQuery = '';
          renderStructure();
        }
      }
    });

    document.addEventListener('keydown',event=>{if(event.key==='Escape')closeSidebarPickers();});
    window.addEventListener('popstate', () => {
      renderStructure();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

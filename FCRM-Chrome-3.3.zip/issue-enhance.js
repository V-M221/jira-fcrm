(() => {
  'use strict';

  if (['https://jit.o3.ru','https://confluence.o3.ru','https://confluence.o3t.ru'].includes(location.origin)) {
    (function bindThreadReferenceReceiver(api, current, validate) {
    api.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message?.type !== 'o3ds:thread-reference' || sender.id !== api.runtime.id || sender.tab ||
            typeof message.endpoint !== 'string' || message.endpoint.length > 4000)
            return;
        let endpoint;
        try {
            endpoint = new URL(message.endpoint);
        }
        catch {
            return;
        }
        if (endpoint.origin !== current.origin || !validate(endpoint))
            return;
        async function read() {
            try {
                const response = await fetch(endpoint.pathname + endpoint.search, {
                    method: 'GET', credentials: 'same-origin', cache: 'no-store', redirect: 'manual',
                    headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(8000),
                });
                if (response.type === 'opaqueredirect' || response.status === 401 || (response.status >= 300 && response.status < 400)) {
                    return { reason: 'Нужно войти в сервис' };
                }
                if (response.status === 403)
                    return { reason: 'Доступ запрещён' };
                if (response.status === 404)
                    return { reason: 'Источник не найден или скрыт правами' };
                if (!response.ok)
                    return { reason: 'Сервис не ответил (HTTP ' + response.status + ')' };
                if (response.headers.get('Content-Type')?.includes('text/html'))
                    return { reason: 'Сервис вернул страницу входа или HTML' };
                const data = await response.json().catch(() => null);
                return data && typeof data === 'object' ? { data } : { reason: 'Сервис вернул неизвестный формат' };
            }
            catch (error) {
                return { reason: error instanceof Error && ['TimeoutError', 'AbortError'].includes(error.name)
                        ? 'Истекло время чтения' : 'Не удалось подключиться' };
            }
        }
        void read().then(sendResponse);
        return true;
    });
})(chrome, location, (function isThreadReferenceEndpoint(url) {
    if (url.username || url.password || url.hash)
        return false;
    const query = url.searchParams;
    const params = [...query.keys()];
    if (url.origin === 'https://jit.o3.ru') {
        return /^\/rest\/api\/2\/issue\/[A-Z][A-Z0-9_]+-[0-9]+$/.test(url.pathname) &&
            params.length === 1 && query.get('fields') === 'summary,description,comment,issuelinks';
    }
    if (url.origin !== 'https://confluence.o3.ru' && url.origin !== 'https://confluence.o3t.ru')
        return false;
    if (query.get('expand') !== 'body.view')
        return false;
    if (/^\/rest\/api\/content\/[0-9]+$/.test(url.pathname))
        return params.length === 1;
    return url.pathname === '/rest/api/content' && params.length === 4 && new Set(params).size === 4 &&
        query.get('type') === 'page' && Boolean(query.get('spaceKey')?.trim()) && Boolean(query.get('title')?.trim());
}));
  }
  if (location.origin === 'https://confluence.o3.ru' || location.origin === 'https://confluence.o3t.ru') return;

  const formatAnswer = function answerMarkup(source, numberedList = false) {
    const escape = (value) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const inline = (value) => value.split(/(\[[^\]\n]+\]\(https?:\/\/[^\s)]+\)|\[[^\]\n]+\|https?:\/\/[^\s\]]+\]|https?:\/\/[^\s<>]+|\*\*[^*\n]+\*\*|\*[^*\n]+\*|`[^`\n]+`)/gi).map(part => {
        const link = /^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/i.exec(part) || /^\[([^\]|\n]+)\|(https?:\/\/[^\s\]]+)\]$/i.exec(part);
        if (link || /^https?:\/\//i.test(part)) {
            return '<a target="_blank" rel="noopener noreferrer" href="' + escape(link ? link[2] : part) + '">' + escape(link ? link[1] : part) + '</a>';
        }
        if (part.startsWith('**') && part.endsWith('**'))
            return '<strong>' + escape(part.slice(2, -2)) + '</strong>';
        if (part.startsWith('*') && part.endsWith('*'))
            return '<strong>' + escape(part.slice(1, -1)) + '</strong>';
        if (part.startsWith('`') && part.endsWith('`'))
            return '<code>' + escape(part.slice(1, -1)) + '</code>';
        return escape(part);
    }).join('');
    if (numberedList) {
        const items = source.split(/\r?\n/)
            .map(line => line.trim().replace(/^(?:\d+[.)]|[-*#•–—])\s+/, ''))
            .filter(Boolean);
        return items.length ? '<ol>' + items.map(item => '<li>' + inline(item) + '</li>').join('') + '</ol>' : '';
    }
    const blocks = [];
    const jiraWiki = /^h[1-6]\.\s/m.test(source);
    let list = '';
    for (const line of source.split(/\r?\n/)) {
        const candidate = /^\s*(?:([-*#])|\d+[.)])\s+(.+)/.exec(line);
        const item = candidate && (candidate[1] !== '#' || jiraWiki) ? candidate : null;
        const next = item ? (item[1] && item[1] !== '#' ? 'ul' : 'ol') : '';
        if (next !== list) {
            if (list)
                blocks.push('</' + list + '>');
            if (next)
                blocks.push('<' + next + '>');
            list = next;
        }
        if (item)
            blocks.push('<li>' + inline(item[2]) + '</li>');
        else if (line.trim()) {
            const heading = /^(?:#{1,6}\s+(.+)|\*\*(.+)\*\*|h[1-6]\.\s+(.+))$/.exec(line.trim());
            blocks.push(heading ? '<h3>' + inline(heading[1] || heading[2] || heading[3]) + '</h3>' : '<p>' + inline(line) + '</p>');
        }
    }
    if (list)
        blocks.push('</' + list + '>');
    return blocks.join('');
};
  const parseJiraDraft = function parseJiraDraft(source, issueKey) {
    const read = (tag) => [...source.matchAll(new RegExp('<' + tag + '>([\\s\\S]*?)</' + tag + '>', 'gi'))].at(-1)?.[1].trim() || '';
    const description = read('jira_description');
    const summary = read('jira_summary');
    const notes = read('jira_notes');
    const links = [];
    const seen = new Set([issueKey]);
    try {
        const data = JSON.parse(read('jira_links') || '[]');
        if (Array.isArray(data))
            for (const item of data) {
                const kind = item?.kind;
                const rawKey = String(item?.key || '');
                const key = kind === 'source' ? rawKey : rawKey.toUpperCase();
                const action = item?.action;
                const replaceKey = String(item?.replaceKey || '').toUpperCase();
                if (seen.has(key) || (kind === 'theme' && links.some(link => link.kind === 'theme')))
                    continue;
                const valid = (kind === 'theme' && /^FCRM-\d+$/.test(key)) ||
                    (kind === 'development' && /^(OB|OBFRONT|FTD|FACS)-\d+$/.test(key)) ||
                    (kind === 'source' && /^https:\/\/(?:chatzone\.o3t?\.ru|confluence\.o3t?\.ru)\/[^\s<>"']+$/i.test(key));
                if (!valid)
                    continue;
                if (action !== undefined && (action !== 'repair' || kind === 'source'))
                    continue;
                if (item.replaceKey !== undefined && (action !== 'repair' || kind !== 'theme' || !/^FCRM-\d+$/.test(replaceKey) || replaceKey === issueKey || replaceKey === key))
                    continue;
                seen.add(key);
                links.push({ kind, key, reason: String(item.reason || '').trim().slice(0, 240), ...(action ? { action } : {}), ...(replaceKey ? { replaceKey } : {}) });
            }
    }
    catch { /* A malformed recommendation never becomes an action. */ }
    return { description, summary, notes, links };
};
  const saveJiraDraft = async function saveJiraDraft(issueKey, draft) {
    if (!/^[A-Z][A-Z0-9]+-\d+$/.test(issueKey) || !draft.description.trim())
        throw new Error('Нет согласованного описания для сохранения.');
    const endpoint = '/rest/api/2/issue/' + encodeURIComponent(issueKey);
    const headers = { Accept: 'application/json', 'Content-Type': 'application/json' };
    const read = async () => {
        const response = await fetch(endpoint + '?fields=' + (draft.summary ? 'description,summary' : 'description'), { headers, credentials: 'same-origin', cache: 'no-store' });
        if (!response.ok)
            throw new Error('Jira не вернула описание (HTTP ' + response.status + ').');
        const data = await response.json();
        if (!data.fields || !('description' in data.fields))
            throw new Error('Jira не вернула поле «Описание».');
        return data.fields;
    };
    const current = await read();
    const approved = draft.description.trim();
    const archive = '\n\nh2. Прежнее описание\n\n';
    const oldDescription = current.description || '';
    const archiveIndex = oldDescription.indexOf(archive);
    const previous = archiveIndex < 0 ? oldDescription : oldDescription.slice(archiveIndex + archive.length);
    const fields = {};
    if (approved !== oldDescription) {
        const description = previous ? approved + archive + previous : approved;
        if (description !== oldDescription)
            fields.description = description;
    }
    if (draft.summary && draft.summary !== current.summary)
        fields.summary = draft.summary;
    if (!Object.keys(fields).length)
        return { changed: false };
    const update = await fetch(endpoint, { method: 'PUT', headers, credentials: 'same-origin', body: JSON.stringify({ fields }) });
    if (!update.ok)
        throw new Error('Jira отклонила сохранение (HTTP ' + update.status + ').');
    const saved = await read();
    if (Object.entries(fields).some(([field, value]) => saved[field] !== value)) {
        throw new Error('Jira ответила на запись, но не подтвердила результат. Обновите задачу перед повтором.');
    }
    return { changed: true };
};
  const jiraDraftLinks = (function createJiraDraftLinkClient() {
    const api = '/rest/api/2/';
    const projectTask = /^(задача проекта|project task)$/i;
    const inProject = /^(в проекте|in project)$/i;
    const relates = /^(связанная задача|relates to|relates)$/i;
    const epic = /^(epic|эпик)$/i;
    const milestone = (summary) => /(?:^|[\s\[])\s*веха\s*(?=[:—–\]-]|$)/i.test(summary);
    const hasTheme = (fields) => fields.labels?.includes('fcrm_umb_epic') === true;
    const inactive = (status) => /cancel|отмен|архив|archiv/i.test(status);
    const differentComponents = (a, b) => !!a.components?.length && !!b.components?.length &&
        !a.components.some(component => b.components?.some(candidate => candidate.name === component.name));
    const request = async (path, method = 'GET', body) => {
        const response = await fetch(api + path, { method, credentials: 'same-origin', cache: 'no-store',
            headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, ...(body ? { body: JSON.stringify(body) } : {}) });
        if (!response.ok)
            throw new Error('Jira вернула HTTP ' + response.status + '.');
        if (method === 'GET')
            return response.json();
    };
    const issuePath = (key) => 'issue/' + encodeURIComponent(key);
    const readIssue = async (key, fields) => {
        const data = await request(issuePath(key) + '?fields=' + encodeURIComponent(fields));
        if (data?.key?.toUpperCase() !== key || !data.fields)
            throw new Error('Jira не подтвердила задачу ' + key + '.');
        return data.fields;
    };
    const readLinks = (fields) => {
        if (!Array.isArray(fields.issuelinks))
            throw new Error('Jira не вернула текущие связи.');
        return fields.issuelinks;
    };
    const linkedKey = (link) => link.inwardIssue?.key || link.outwardIssue?.key || '';
    const description = (link) => String((link.inwardIssue ? link.type?.inward : link.type?.outward) || '').trim();
    const idOf = (link) => String(link.id || '');
    const issueLinkFields = 'summary,labels,components,issuetype,status,issuelinks';
    async function inspectTheme(issueKey, proposal) {
        if (!/^FCRM-\d+$/.test(issueKey) || !/^FCRM-\d+$/.test(proposal.key) || issueKey === proposal.key) {
            throw new Error('Тематическая связь допустима между разными задачами FCRM.');
        }
        const metadata = await request('field');
        const epicField = metadata.find(field => field.schema?.custom === 'com.pyxis.greenhopper.jira:gh-epic-link')?.id ||
            metadata.find(field => /^(epic link|epic связь|ссылка на эпик)$/i.test(field.name?.trim() || ''))?.id;
        if (!epicField)
            throw new Error('Jira не вернула поле Epic Link.');
        const source = await readIssue(issueKey, issueLinkFields + ',' + epicField);
        if (!(epicField in source))
            throw new Error('Jira не вернула значение Epic Link.');
        if (source[epicField] !== null && source[epicField] !== '') {
            const value = source[epicField];
            const key = typeof value === 'string' ? value : value?.key;
            throw new Error('У задачи уже есть Epic Link' + (key ? ' на ' + key : '') + '. Прямая тематика не применяется.');
        }
        if (!source.issuetype?.name || source.issuetype.subtask || !Array.isArray(source.labels)) {
            throw new Error('Для этой задачи не подтверждён уровень тематической связи.');
        }
        const parents = readLinks(source).filter(link => /^FCRM-\d+$/.test(linkedKey(link)) && projectTask.test(description(link)));
        if (parents.some(link => linkedKey(link) !== proposal.key && linkedKey(link) !== proposal.replaceKey)) {
            throw new Error('У задачи уже есть другая прямая связь «Задача проекта».');
        }
        const target = await readIssue(proposal.key, issueLinkFields);
        if (!hasTheme(target) || !epic.test(target.issuetype?.name || '') || !target.status?.name || inactive(target.status.name)) {
            throw new Error('В Jira не подтверждена актуальная тематика ' + proposal.key + '.');
        }
        const thematicSource = hasTheme(source);
        if ((thematicSource && milestone(source.summary || '')) || thematicSource !== milestone(target.summary || '')) {
            throw new Error('Предложенный родитель не соответствует уровню задачи.');
        }
        if (differentComponents(source, target)) {
            throw new Error('У задачи и тематики нет общего компонента.');
        }
        if (proposal.replaceKey && parents.some(link => linkedKey(link) === proposal.replaceKey)) {
            const previous = await readIssue(proposal.replaceKey, 'labels,status,summary,components,issuetype');
            if (!Array.isArray(previous.labels) || !previous.status?.name || !previous.issuetype?.name) {
                throw new Error('Jira не вернула данные для проверки текущей тематики.');
            }
            if (hasTheme(previous) && epic.test(previous.issuetype.name) && !inactive(previous.status.name) &&
                thematicSource === milestone(previous.summary || '') && !differentComponents(source, previous)) {
                throw new Error('Jira не подтверждает, что текущая тематика ' + proposal.replaceKey + ' устарела. Проверьте замену вручную.');
            }
        }
        return { source, target };
    }
    async function themeWarning(issueKey, proposal) {
        try {
            await inspectTheme(issueKey, proposal);
            return '';
        }
        catch (error) {
            return error instanceof Error ? error.message : 'Не удалось проверить тематику в Jira.';
        }
    }
    async function apply(issueKey, proposal) {
        if (!/^[A-Z][A-Z0-9]+-\d+$/.test(issueKey))
            throw new Error('Некорректный ключ исходной задачи.');
        if (proposal.kind === 'source') {
            if (!/^https:\/\/(?:chatzone\.o3t?\.ru|confluence\.o3t?\.ru)\/[^\s<>"']+$/i.test(proposal.key))
                throw new Error('Некорректный адрес веб-ссылки.');
            const path = issuePath(issueKey) + '/remotelink';
            const hasUrl = async () => (await request(path)).some((link) => link.object?.url === proposal.key);
            if (await hasUrl())
                return 'Уже есть в Jira';
            const title = /^https:\/\/chatzone\./i.test(proposal.key) ? 'Обсуждение в ChatZone' : 'Документ в Confluence';
            await request(path, 'POST', { object: { url: proposal.key, title } });
            if (!await hasUrl())
                throw new Error('Jira не подтвердила веб-ссылку.');
            return 'Добавлена';
        }
        if (!/^FCRM-\d+$/.test(issueKey))
            throw new Error('Выбранные связи с задачами применяются к FCRM.');
        const theme = proposal.kind === 'theme';
        if (!theme && !/^(OB|OBFRONT|FTD|FACS)-\d+$/.test(proposal.key))
            throw new Error('Некорректный ключ задачи разработки.');
        const expected = theme ? projectTask : inProject;
        const reverse = theme ? inProject : projectTask;
        const [source, target] = theme ? await inspectTheme(issueKey, proposal).then(({ source, target }) => [source, target]) :
            await Promise.all([readIssue(issueKey, 'issuetype,issuelinks'), readIssue(proposal.key, 'issuelinks')]);
        if (!theme && (!source.issuetype?.name || epic.test(source.issuetype.name))) {
            throw new Error('Связь «В проекте» с разработкой допустима для конечной задачи FCRM.');
        }
        const current = readLinks(source);
        const samePair = current.filter(link => linkedKey(link) === proposal.key);
        const old = proposal.action === 'repair' ? (proposal.replaceKey
            ? current.filter(link => linkedKey(link) === proposal.replaceKey && expected.test(description(link)))
            : samePair.filter(link => reverse.test(description(link)) || (!theme && relates.test(description(link))))) : [];
        if (old.some(link => !/^\d+$/.test(idOf(link))))
            throw new Error('Jira не вернула ID исправляемой связи.');
        const confirmed = (a, b) => readLinks(a).some(link => linkedKey(link) === proposal.key && expected.test(description(link)) && !!idOf(link) &&
            readLinks(b).some(other => linkedKey(other) === issueKey && reverse.test(description(other)) && idOf(other) === idOf(link)));
        const already = confirmed(source, target);
        if (proposal.replaceKey && old.length !== 1 && !(old.length === 0 && already)) {
            throw new Error('Старая тематика изменилась после согласования.');
        }
        if (!already) {
            if (samePair.some(link => expected.test(description(link))))
                throw new Error('Jira не подтвердила связь с обеих сторон.');
            if (!old.length && samePair.some(link => reverse.test(description(link))))
                throw new Error('Уже есть обратная связь. Нужен черновик её исправления.');
            const { issueLinkTypes } = await request('issueLinkType');
            const types = issueLinkTypes.filter((type) => (expected.test(type.inward) && reverse.test(type.outward)) || (expected.test(type.outward) && reverse.test(type.inward)));
            if (types.length !== 1)
                throw new Error('В Jira не удалось однозначно определить тип «Задача проекта» / «В проекте».');
            const type = types[0];
            const inward = expected.test(type.inward);
            await request('issueLink', 'POST', { type: { name: type.name },
                inwardIssue: { key: inward ? proposal.key : issueKey }, outwardIssue: { key: inward ? issueKey : proposal.key } });
            const [updatedSource, updatedTarget] = await Promise.all([readIssue(issueKey, 'issuelinks'), readIssue(proposal.key, 'issuelinks')]);
            if (!confirmed(updatedSource, updatedTarget))
                throw new Error('Jira не подтвердила новую связь с обеих сторон.');
        }
        if (old.length) {
            try {
                for (const link of old)
                    await request('issueLink/' + idOf(link), 'DELETE');
                const remaining = readLinks(await readIssue(issueKey, 'issuelinks'));
                if (remaining.some(link => old.some(previous => idOf(previous) === idOf(link))))
                    throw new Error();
            }
            catch {
                throw new Error('Правильная связь подтверждена, удаление прежней связи не подтверждено.');
            }
        }
        return old.length ? 'Исправлена' : already ? 'Уже есть в Jira' : 'Добавлена';
    }
    return { themeWarning, apply };
})();
  const MESSAGE_TYPE = "o3ds:chat";
  const NATIVE_SELECTORS = [
    '#summary-val',
    '#issue-content h1',
    '[data-testid="issue.views.issue-base.foundation.summary.heading"]',
    '#ghx-detail-view .ghx-summary',
    '.ghx-detail-summary'
  ];

  const session = {
    issueKey: '',
    kind: 'description',
    phase: 'idle',
    preview: '',
    success: '',
    designProposal: null,
    error: ''
  };
  let requestSerial = 0;

  function issueKeyFromText(value) {
    const match = String(value || '').toUpperCase().match(/\b([A-Z][A-Z0-9]+-\d+)\b/);
    return match ? match[1] : '';
  }

  function issueKeyNear(el) {
    const scope = el.closest('#ozon-ext-sidebar-panel, #issue-content, #ghx-detail-view, #jira') || document.body;
    const link = scope.querySelector('a[href*="/browse/"]');
    if (link) {
      const fromHref = issueKeyFromText(link.getAttribute('href') || '');
      if (fromHref) return fromHref;
      const fromText = issueKeyFromText(link.textContent || '');
      if (fromText) return fromText;
    }
    const keyVal = document.getElementById('key-val');
    if (keyVal) {
      const fromKey = issueKeyFromText(keyVal.textContent || '');
      if (fromKey) return fromKey;
    }
    const selected = new URLSearchParams(window.location.search).get('selectedIssue');
    if (selected) {
      const fromQuery = issueKeyFromText(selected);
      if (fromQuery) return fromQuery;
    }
    return issueKeyFromText(window.location.pathname);
  }

  function ensureStyles() {
    if (document.getElementById('o3ds-styles')) return;
    const style = document.createElement('style');
    style.id = 'o3ds-styles';
    style.textContent = [
      '.o3ds-btn{display:inline-flex!important;align-items:center!important;gap:5px!important;height:28px!important;margin:0 0 0 8px!important;padding:0 10px!important;border:1px solid #005BFF!important;border-radius:7px!important;background:#E5F0FF!important;color:#005BFF!important;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif!important;font-size:12px!important;font-weight:700!important;line-height:1!important;letter-spacing:0!important;cursor:pointer!important;vertical-align:middle!important;box-shadow:0 1px 2px rgba(7,16,38,.08)!important;text-decoration:none!important;}',
      '.o3ds-btn:hover{background:#d5e7ff!important;border-color:#004bd1!important;}',
      '.o3ds-btn:disabled{opacity:.55!important;cursor:default!important;}',
      '.o3ds-btn svg{display:block!important;width:14px!important;height:14px!important;flex:0 0 auto!important;}',
      '#o3ds-layer{position:fixed!important;top:0!important;bottom:0!important;right:0!important;width:min(640px,100vw)!important;display:flex!important;flex-direction:column!important;z-index:2147483000!important;overflow:auto!important;background:#FFFFFF!important;color:#071026!important;border:0!important;border-left:1px solid #D7E0EC!important;border-radius:0!important;box-shadow:-8px 0 24px rgba(7,16,38,.10)!important;padding:16px!important;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,sans-serif!important;font-size:12px!important;line-height:1.45!important;box-sizing:border-box!important;}',
      '@keyframes o3ds-panel-enter{from{opacity:0;transform:translateX(18px)}to{opacity:1;transform:translateX(0)}}',
      '@media(prefers-reduced-motion:no-preference){#o3ds-layer{animation:o3ds-panel-enter 220ms cubic-bezier(.2,.7,.2,1) both}}',
      '#o3ds-layer *{box-sizing:border-box!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,sans-serif!important;}',
      '#o3ds-layer h2{margin:0 0 4px!important;font-size:14px!important;line-height:1.25!important;font-weight:700!important;color:#071026!important;}',
      '#o3ds-layer .o3ds-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px;}#o3ds-layer .o3ds-header .o3ds-key{margin-bottom:0!important;}#o3ds-layer .o3ds-header-close{width:28px!important;height:28px!important;flex:0 0 28px!important;padding:0!important;border:0!important;border-radius:8px!important;background:#f1f5f9!important;color:#334155!important;font-size:16px!important;}',
      '#o3ds-layer .o3ds-key{margin:0 0 12px!important;color:#626F86!important;font-size:12px!important;font-weight:600!important;}',
      '#o3ds-layer .o3ds-skel{height:12px!important;margin:0 0 8px!important;border-radius:3px!important;background:linear-gradient(90deg,#F4F5F7 25%,#EBECF0 37%,#F4F5F7 63%)!important;background-size:400% 100%!important;animation:o3ds-shimmer 1.2s ease infinite!important;}',
      '#o3ds-layer .o3ds-skel.short{width:62%!important;}',
      '@keyframes o3ds-shimmer{0%{background-position:100% 0}100%{background-position:0 0}}',
      '#o3ds-layer .o3ds-answer{margin:0 0 12px!important;white-space:pre-wrap!important;word-break:break-word!important;font-family:inherit!important;font-size:14px!important;line-height:1.6!important;color:#172B4D!important;background:#F7F8F9!important;border:1px solid #DFE1E6!important;border-radius:3px!important;padding:10px!important;flex:1 1 auto!important;min-height:0!important;max-height:none!important;overflow:auto!important;}',
      '#o3ds-layer .o3ds-actions{display:flex!important;gap:8px!important;}',
      '#o3ds-layer button{height:32px!important;padding:0 12px!important;border-radius:3px!important;font-size:14px!important;font-weight:600!important;cursor:pointer!important;}',
      '#o3ds-layer .o3ds-primary{background:#005BFF!important;color:#FFFFFF!important;border:1px solid #005BFF!important;border-radius:7px!important;}',
      '#o3ds-layer .o3ds-primary:hover{background:#004bd1!important;}',
      '#o3ds-layer .o3ds-primary:disabled{opacity:.55!important;cursor:default!important;}',
      '#o3ds-layer .o3ds-subtle{background:#FFFFFF!important;color:#334155!important;border:1px solid #D7E0EC!important;border-radius:7px!important;}',
      '#o3ds-layer .o3ds-subtle:hover{background:#F7F8F9!important;}',
      '#o3ds-layer .o3ds-error{margin:0 0 12px!important;color:#AE2E24!important;font-size:13px!important;}',
      '#o3ds-layer .o3ds-ok{margin:0 0 8px!important;color:#216E4E!important;font-size:13px!important;font-weight:650!important;}'
      ,'body:has(> #o3ds-layer) #ozon-structure-root #ozon-ext-sidebar-panel{right:min(640px,50vw)!important;max-width:calc(100vw - min(640px,50vw))!important;}',
      'body:has(> #o3ds-layer) #ozon-structure-root #ozon-ext-sidebar-resizer{display:none!important;}',
      'body:has(#ozon-structure-root #ozon-ext-sidebar-panel) > #o3ds-layer{width:min(640px,50vw)!important;}',
      '#o3ds-layer .o3ds-answer,#o3ds-layer{scrollbar-width:thin!important;scrollbar-color:#a8b5c5 transparent!important;color-scheme:light;}',
      '#o3ds-layer .o3ds-answer h3{font-size:15px;font-weight:700;margin:12px 0 4px}#o3ds-layer .o3ds-answer p{margin:0 0 6px}#o3ds-layer .o3ds-answer ul,#o3ds-layer .o3ds-answer ol{padding-left:22px}#o3ds-layer .o3ds-answer a{color:#005bff;text-decoration:underline}',
      '#o3ds-layer .o3ds-draft{flex:1 1 0;min-height:min(140px,28vh);overflow:auto;padding:4px 4px 10px 0}#o3ds-layer .o3ds-draft .o3ds-answer{overflow:visible!important;background:#fff!important;border:1px solid #d7e0ec!important;border-radius:10px!important;padding:14px!important}#o3ds-layer .o3ds-draft h3:first-child{margin-top:0}',
      '#o3ds-layer .o3ds-draft-heading{display:block;font-size:13px;font-weight:700;margin:0 0 7px;color:#071026}#o3ds-layer .o3ds-draft-name{margin:0 0 12px;color:#334155}',
      '#o3ds-layer .o3ds-draft-notes .o3ds-answer{background:#f4f7fb!important}#o3ds-layer .o3ds-draft-notes ol{list-style:decimal outside!important;margin:0!important;padding:0 0 0 22px!important}#o3ds-layer .o3ds-draft-notes li{display:list-item!important;list-style:inherit!important;font-size:inherit!important;line-height:inherit!important;margin:0;padding:0 0 0 3px}#o3ds-layer .o3ds-draft-notes li+li{margin-top:6px}',
      '#o3ds-layer .o3ds-theme-notice{margin:0 0 12px;padding:9px 12px;border-radius:8px;background:#f4f7fb;color:#334155}#o3ds-layer .o3ds-link-outcomes{margin:0 0 12px;padding:0;list-style:none}#o3ds-layer .o3ds-link-outcomes li{padding:7px 0;overflow-wrap:anywhere}#o3ds-layer .o3ds-link-outcomes a{color:#005bff}',
      '#o3ds-layer .o3ds-draft-links{margin:0 0 12px;padding:10px 12px;border:1px solid #d7e0ec;border-radius:8px;min-width:0}#o3ds-layer .o3ds-draft-link{display:flex;gap:8px;padding:6px 0;align-items:flex-start;cursor:pointer}#o3ds-layer .o3ds-draft-link input{width:15px;height:15px;margin-top:2px;flex:none;accent-color:#005bff}#o3ds-layer .o3ds-draft-link span{min-width:0;overflow-wrap:anywhere}#o3ds-layer .o3ds-draft-link small{display:block;color:#626f86}',
      '#o3ds-layer .o3ds-draft-footer{padding-top:12px;border-top:1px solid #d7e0ec;background:#fff;flex:none}#o3ds-layer .o3ds-draft-footer .o3ds-actions{justify-content:flex-start}#o3ds-layer .o3ds-draft-refine{margin-bottom:10px}#o3ds-layer .o3ds-draft-refine summary{cursor:pointer;color:#005bff;width:max-content}#o3ds-layer .o3ds-draft-refine[open] summary{margin-bottom:8px}',
      '@media(max-width:800px){body:has(#ozon-structure-root #ozon-ext-sidebar-panel) > #o3ds-layer{width:min(480px,100vw)!important;}}',
      '#o3ds-layer textarea{box-sizing:border-box;width:100%;min-height:76px!important;padding:10px;resize:vertical;border:1px solid #D7E0EC;border-radius:8px;font:inherit;margin-bottom:8px;background:#fff;color:#071026;}#o3ds-layer textarea:focus{outline:none;border-color:#005BFF;box-shadow:0 0 0 3px rgba(0,91,255,.12)}',
      '#o3ds-layer .o3ds-actions{flex-wrap:wrap;}'
    ].join('');
    document.documentElement.appendChild(style);
  }

  function sparkleSvg() {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 16 16');
    svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML = '<path fill="currentColor" d="M8 1.2l1.05 3.35L12.4 5.6 9.05 6.65 8 10 6.95 6.65 3.6 5.6l3.35-1.05L8 1.2zm4.2 7.1.55 1.75 1.75.55-1.75.55-.55 1.75-.55-1.75-1.75-.55 1.75-.55.55-1.75zM3.1 9.2l.7 1.9 1.9.7-1.9.7-.7 1.9-.7-1.9-1.9-.7 1.9-.7.7-1.9z"/>';
    return svg;
  }

  function syncButtons() {
    const busy = session.phase === 'loading' || session.phase === 'applying' || session.phase === 'design-creating';
    document.querySelectorAll('.o3ds-btn').forEach((node) => {
      const button = node;
      const sameIssue = button.getAttribute('data-issue-key') === session.issueKey;
      button.disabled = busy && sameIssue;
    });
  }

  function openSession(issueKey) {
    ++requestSerial;
    session.kind = 'description';
    session.reply = '';
    session.additionalContext = '';
    session.issueKey = issueKey;
    session.phase = 'context';
    session.preview = '';
    session.success = '';
    session.error = '';
    renderLayer();
  }

  function startDescriptionAnalysis() {
    const issueKey = session.issueKey;
    session.phase = 'loading';
    session.error = '';
    renderLayer();
    const serial = ++requestSerial;
    ask('analyze', issueKey)
      .then(async (text) => {
        if (serial !== requestSerial) return;
        const warning = await themeWarning(issueKey, text);
        if (serial !== requestSerial) return;
        session.phase = 'preview';
        session.preview = text;
        session.themeWarning = warning;
        renderLayer();
      })
      .catch((err) => {
        if (serial !== requestSerial) return;
        session.phase = 'error';
        session.error = err && err.message ? err.message : 'Не удалось улучшить описание';
        renderLayer();
      });
  }

  function parseDesignProposal(text) {
    const summary = /<ftd_summary>([\s\S]*?)<\/ftd_summary>/i.exec(String(text || ''))?.[1]?.trim();
    const description = /<ftd_description>([\s\S]*?)<\/ftd_description>/i.exec(String(text || ''))?.[1]?.trim();
    if (!summary || !description) throw new Error('Не удалось разобрать тему и описание дизайн-задачи. Попросите DeepSeek подготовить черновик заново.');
    return { summary, description };
  }

  function themeWarning(issueKey, preview) {
    const theme = parseJiraDraft(preview, issueKey).links.find(link => link.kind === 'theme');
    return theme ? jiraDraftLinks.themeWarning(issueKey, theme) : '';
  }

  function openDesignSession(issueKey) {
    if (!issueKey) return;
    session.kind = 'design';
    session.reply = '';
    session.issueKey = issueKey;
    session.phase = 'loading';
    session.preview = '';
    session.success = '';
    session.designProposal = null;
    session.error = '';
    renderLayer();
    const serial = ++requestSerial;
    ask('design', issueKey)
      .then((text) => {
        if (serial !== requestSerial) return;
        session.preview = text;
        session.designProposal = parseDesignProposal(text);
        session.phase = 'preview';
        renderLayer();
      })
      .catch((err) => {
        if (serial !== requestSerial) return;
        session.phase = 'error';
        session.error = err && err.message ? err.message : 'Не удалось подготовить дизайн-задачу';
        renderLayer();
      });
  }

  function requestDesignCreation() {
    if (session.kind !== 'design' || !session.designProposal) return;
    session.phase = 'design-creating';
    session.error = '';
    renderLayer();
    document.dispatchEvent(new CustomEvent('ozon-fcrm-create-design-task-request', {
      detail: JSON.stringify({ issueKey: session.issueKey, summary: session.designProposal.summary, description: session.designProposal.description })
    }));
  }

  function showDesignResult(detail) {
    if (session.kind !== 'design' || !detail || detail.issueKey !== session.issueKey) return;
    if (detail.ok) {
      session.phase = 'design-created';
      session.success = detail.key || '';
      session.designLinked = detail.linked !== false;
      session.error = '';
    } else {
      session.phase = 'design-confirm';
      session.error = detail.error || 'Не удалось создать задачу FTD';
    }
    renderLayer();
  }

  async function applySession(draft, selectedLinks) {
    if (session.phase !== 'preview' || !session.issueKey) return;
    const issueKey = session.issueKey;
    const serial = ++requestSerial;
    session.phase = 'applying';
    session.saveIncludesLinks = selectedLinks.length > 0;
    session.error = '';
    renderLayer();
    let saved;
    try {
      saved = await saveJiraDraft(issueKey, draft);
    } catch (err) {
      if (serial !== requestSerial) return;
      session.phase = 'preview';
      session.error = err && err.message ? err.message : 'Не удалось сохранить описание';
      renderLayer();
      return;
    }
    if (serial !== requestSerial) return;
    const outcomes = [];
    for (const link of selectedLinks) {
      try {
        outcomes.push({link, status:await jiraDraftLinks.apply(issueKey, link)});
      } catch (err) {
        outcomes.push({link, status:err?.message || 'Jira не подтвердила связь.', failed:true});
      }
    }
    document.dispatchEvent(new CustomEvent('ozon-fcrm-issue-applied', { detail: { issueKey } }));
    if (serial !== requestSerial) return;
    session.savedText = saved.changed ? 'Описание сохранено в Jira' : 'Описание уже актуально в Jira';
    session.linkOutcomes = outcomes;
    session.phase = 'success';
    renderLayer();
  }

  function closeSession() {
    requestSerial += 1;
    session.phase = 'idle';
    session.preview = '';
    session.success = '';
    session.reply = '';
    session.error = '';
    session.kind = 'description';
    session.designProposal = null;
    renderLayer();
  }
  document.addEventListener('ozon-close-assistant', closeSession);

  function ask(mode, issueKey, approvedDescription, clarification) {
    return new Promise((resolve, reject) => {
      if (!chrome.runtime || !chrome.runtime.sendMessage) {
        reject(new Error('Нет доступа к background service worker'));
        return;
      }
      chrome.runtime.sendMessage({ type: MESSAGE_TYPE, mode, issueKey, approvedDescription: approvedDescription || '', clarification, additionalContext: session.kind === 'description' ? session.additionalContext || '' : '' }, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        if (!response || !response.ok) {
          reject(new Error((response && response.error) || 'Пустой ответ DeepSeek'));
          return;
        }
        resolve(response.text || '');
      });
    });
  }

  function actionButton(label, className, onClick, disabled) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = label;
    button.disabled = Boolean(disabled);
    button.addEventListener('click', onClick);
    return button;
  }

  function renderLayer() {
    syncButtons();
    let layer = document.getElementById('o3ds-layer');
    if (session.phase === 'idle') {
      if (layer) layer.remove();
      return;
    }
    if (!layer) {
      layer = document.createElement('aside');
      layer.id = 'o3ds-layer';
      layer.setAttribute('role', 'dialog');
      layer.setAttribute('aria-label', 'Улучшение описания');
      document.body.appendChild(layer);
    }
    layer.replaceChildren();

    const title = document.createElement('h2');
    title.textContent = session.kind === 'design' ? 'Подготовить дизайн-задачу FTD' : 'Улучшить описание';
    const keyLine = document.createElement('p');
    keyLine.className = 'o3ds-key';
    keyLine.textContent = session.kind === 'design' ? session.issueKey + ' · черновик для проекта FTD' : session.issueKey;
    const header = document.createElement('div');
    header.className = 'o3ds-header';
    const heading = document.createElement('div');
    heading.append(title, keyLine);
    const close = actionButton('✕', 'o3ds-header-close', closeSession, session.phase === 'applying');
    close.setAttribute('aria-label', 'Закрыть помощника');
    header.append(heading, close);
    layer.appendChild(header);

    if (session.phase === 'context') {
      const hint = document.createElement('p');
      hint.className = 'o3ds-key';
      hint.textContent = 'Одной фразы достаточно. Можно оставить поле пустым.';
      const label = document.createElement('label');
      label.htmlFor = 'o3ds-additional-context';
      label.textContent = 'Дополнительный контекст';
      label.style.fontWeight = '600';
      label.style.marginBottom = '6px';
      const context = document.createElement('textarea');
      context.id = 'o3ds-additional-context';
      context.rows = 5;
      context.placeholder = 'Например: для кого нужна доработка, что важно учесть и какой результат ожидается';
      context.value = session.additionalContext || '';
      context.addEventListener('input', () => {
        session.additionalContext = context.value;
        context.style.height = 'auto';
        context.style.height = Math.min(Math.max(context.scrollHeight, 120), 300) + 'px';
        context.style.overflowY = context.scrollHeight > 300 ? 'auto' : 'hidden';
      });
      const actions = document.createElement('div');
      actions.className = 'o3ds-actions';
      actions.append(
        actionButton('Улучшить описание', 'o3ds-primary', startDescriptionAnalysis, false),
        actionButton('Отмена', 'o3ds-subtle', closeSession, false)
      );
      layer.append(hint, label, context, actions);
      return;
    }

    if (session.phase === 'loading' || session.phase === 'applying' || session.phase === 'design-creating') {
      const caption = document.createElement('p');
      caption.className = 'o3ds-key';
      caption.setAttribute('role', 'status');
      caption.textContent = session.phase === 'design-creating' ? 'Создаю задачу FTD и связываю с исходной…' : session.phase === 'applying'
        ? (session.saveIncludesLinks ? 'Сохраняю описание и выбранные связи в Jira…' : 'Сохраняю описание в Jira…')
        : 'Готовлю черновик на основе задачи и нужных источников…';
      layer.appendChild(caption);
      for (let i = 0; i < 4; i += 1) {
        const bone = document.createElement('div');
        bone.className = i === 2 ? 'o3ds-skel short' : 'o3ds-skel';
        layer.appendChild(bone);
      }
      if (session.phase === 'loading') {
        layer.appendChild(actionButton('Отмена', 'o3ds-subtle', closeSession, false));
      }
      return;
    }

    if (session.error) {
      const error = document.createElement('p');
      error.className = 'o3ds-error';
      error.textContent = session.error;
      layer.appendChild(error);
    }

    if (session.phase === 'error') {
      const actions = document.createElement('div');
      actions.className = 'o3ds-actions';
      actions.append(
        actionButton('Повторить', 'o3ds-primary', () => session.kind === 'design' ? openDesignSession(session.issueKey) : startDescriptionAnalysis(), false),
        actionButton('Закрыть', 'o3ds-subtle', closeSession, false)
      );
      if (session.kind === 'description') actions.insertBefore(actionButton('Добавить контекст', 'o3ds-subtle', () => {
        session.error = '';
        session.phase = 'context';
        renderLayer();
      }, false), actions.lastChild);
      layer.appendChild(actions);
      return;
    }

    if (session.phase === 'design-confirm') {
      const note = document.createElement('p');
      note.className = 'o3ds-key';
      note.textContent = 'Будет создана задача в проекте FTD, тип «Задача», компонент «bank crm», без Epic. Продолжить?';
      const proposal = document.createElement('div');
      proposal.className = 'o3ds-answer';
      const proposalData = session.designProposal || parseDesignProposal(session.preview);
      proposal.innerHTML = formatAnswer('**Тема**\n' + proposalData.summary + '\n\n**Описание**\n' + proposalData.description);
      const actions = document.createElement('div');
      actions.className = 'o3ds-actions';
      actions.append(
        actionButton('Подтвердить и создать', 'o3ds-primary', requestDesignCreation, false),
        actionButton('Назад к черновику', 'o3ds-subtle', () => { session.phase = 'preview'; session.error = ''; renderLayer(); }, false),
        actionButton('Отмена', 'o3ds-subtle', closeSession, false)
      );
      layer.append(note, proposal, actions);
      return;
    }

    if (session.phase === 'design-created') {
      const note = document.createElement('p');
      note.className = 'o3ds-ok';
      note.textContent = session.designLinked === false
        ? 'Задача FTD создана (' + session.success + '), но Jira не подтвердила связь с исходной задачей.'
        : 'Задача FTD создана и связана с исходной: ' + session.success;
      const actions = document.createElement('div');
      actions.className = 'o3ds-actions';
      actions.append(actionButton('Закрыть', 'o3ds-primary', closeSession, false));
      layer.append(note, actions);
      return;
    }

    if (session.phase === 'success') {
      const ok = document.createElement('p');
      ok.className = 'o3ds-ok';
      ok.setAttribute('role', 'status');
      ok.textContent = session.savedText;
      layer.append(ok);
      if (session.linkOutcomes.length) {
        const list = document.createElement('ul');
        list.className = 'o3ds-link-outcomes';
        for (const outcome of session.linkOutcomes) {
          const item = document.createElement('li');
          const target = document.createElement('a');
          target.href = outcome.link.kind === 'source' ? outcome.link.key : '/browse/' + encodeURIComponent(outcome.link.key);
          target.target = '_blank';
          target.rel = 'noopener noreferrer';
          target.textContent = outcome.link.key;
          const status = document.createElement('span');
          status.textContent = outcome.failed ? ' · Требует внимания. ' + outcome.status : ' · ' + outcome.status;
          if (outcome.failed) status.className = 'o3ds-error';
          item.append(target, status);
          list.append(item);
        }
        layer.append(list);
      }
      const actions = document.createElement('div');
      actions.className = 'o3ds-actions';
      actions.append(actionButton('Закрыть', 'o3ds-subtle', closeSession, false));
      layer.append(actions);
      return;
    }

    const pre = document.createElement('div');
    pre.className = 'o3ds-answer';
    if (session.kind === 'design' && session.designProposal) {
      pre.innerHTML = formatAnswer('**Тема**\n' + session.designProposal.summary + '\n\n**Описание**\n' + session.designProposal.description);
    }
    const reply = document.createElement('textarea');
    reply.placeholder = session.kind === 'design' ? 'Уточнение к дизайн-задаче или ответ на вопросы DeepSeek' : 'Факты или правки для черновика';
    reply.setAttribute('aria-label', reply.placeholder);
    reply.rows = 2;
    reply.style.resize = 'none';
    reply.style.overflowY = 'hidden';
    reply.style.minHeight = '76px';
    reply.style.maxHeight = '180px';
    reply.style.height = '76px';
    reply.value = session.reply || '';
    const send = actionButton(session.kind === 'design' ? 'Отправить ответ' : 'Обновить черновик', 'o3ds-subtle', async () => {
      if (!reply.value.trim() || session.phase !== 'preview') return;
      const serial = ++requestSerial;
      session.phase = 'loading';
      session.error = '';
      renderLayer();
      try {
        const issueKey = session.issueKey;
        const updated = await ask(session.kind === 'design' ? 'design' : 'analyze', issueKey, '', { preview: session.preview, reply: session.reply });
        if (serial !== requestSerial) return;
        const warning = session.kind === 'description' ? await themeWarning(issueKey, updated) : '';
        if (serial !== requestSerial) return;
        session.preview = updated;
        session.themeWarning = warning;
        session.designProposal = session.kind === 'design' ? parseDesignProposal(updated) : null;
        session.reply = '';
      } catch (err) {
        if (serial !== requestSerial) return;
        session.error = err.message || 'Не удалось отправить ответ';
      }
      session.phase = 'preview';
      renderLayer();
    }, !reply.value.trim());
    reply.oninput = () => {
      session.reply = reply.value;
      reply.style.height = '76px';
      reply.style.height = Math.min(reply.scrollHeight, 180) + 'px';
      reply.style.overflowY = reply.scrollHeight > 180 ? 'auto' : 'hidden';
      send.disabled = !reply.value.trim();
    };
    const actions = document.createElement('div');
    actions.className = 'o3ds-actions';
    const cancel = actionButton('Отмена', 'o3ds-subtle', closeSession, false);
    if (session.kind === 'design') {
      actions.append(send, actionButton('Перейти к подтверждению', 'o3ds-primary', () => { session.phase = 'design-confirm'; renderLayer(); }, false), cancel);
      layer.append(pre, reply, actions);
      return;
    }

    const draft = parseJiraDraft(session.preview, session.issueKey);
    const content = document.createElement('div');
    content.className = 'o3ds-draft';
    pre.innerHTML = formatAnswer(draft.description);
    const draftHeading = document.createElement('strong');
    draftHeading.className = 'o3ds-draft-heading';
    draftHeading.textContent = 'Черновик описания';
    content.append(draftHeading, pre);
    let approveTitle;
    if (draft.summary) {
      const proposedName = document.createElement('label');
      proposedName.className = 'o3ds-draft-name o3ds-draft-link';
      approveTitle = document.createElement('input');
      approveTitle.type = 'checkbox';
      const titleText = document.createElement('span');
      titleText.textContent = 'Применить предложенное название — ' + draft.summary;
      proposedName.append(approveTitle, titleText);
      content.append(proposedName);
    }

    const selected = new Map();
    const save = actionButton('Сохранить описание', 'o3ds-primary', () => applySession({
      description:draft.description, summary:approveTitle?.checked ? draft.summary : undefined
    }, [...selected.values()]), !draft.description);
    const proposals = draft.links.filter(link => link.kind !== 'theme' || !session.themeWarning);
    if (proposals.length) {
      const group = document.createElement('fieldset');
      group.className = 'o3ds-draft-links';
      const legend = document.createElement('legend');
      legend.textContent = 'Предложенные связи';
      group.append(legend);
      for (const link of proposals) {
        const label = document.createElement('label');
        label.className = 'o3ds-draft-link';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.onchange = () => {
          if (checkbox.checked) selected.set(link.key, link);
          else selected.delete(link.key);
          save.textContent = selected.size ? 'Сохранить и применить связи (' + selected.size + ')' : 'Сохранить описание';
        };
        const text = document.createElement('span');
        const type = link.kind === 'theme' ? 'Задача проекта' : link.kind === 'development' ? 'В проекте' : 'Веб-ссылка';
        text.textContent = link.replaceKey
          ? 'Заменить тематику ' + link.replaceKey + ' → ' + link.key
          : (link.action === 'repair' ? 'Исправить связь · ' : '') + type + ' · ' + link.key;
        if (link.reason) {
          const reason = document.createElement('small');
          reason.textContent = link.reason;
          text.append(reason);
        }
        label.append(checkbox, text);
        group.append(label);
      }
      content.append(group);
    }
    if (session.themeWarning) {
      const notice = document.createElement('p');
      notice.className = 'o3ds-theme-notice';
      const theme = draft.links.find(link => link.kind === 'theme');
      notice.textContent = 'Тематика ' + theme.key + ' пропущена. ' + session.themeWarning;
      content.append(notice);
    }
    if (draft.notes) {
      const notes = document.createElement('section');
      notes.className = 'o3ds-draft-notes';
      const title = document.createElement('strong');
      title.className = 'o3ds-draft-heading';
      title.textContent = 'Что требует уточнения';
      const questions = document.createElement('div');
      questions.className = 'o3ds-answer';
      questions.innerHTML = formatAnswer(draft.notes, true);
      notes.append(title, questions);
      content.append(notes);
    }
    const footer = document.createElement('footer');
    footer.className = 'o3ds-draft-footer';
    const refine = document.createElement('details');
    refine.className = 'o3ds-draft-refine';
    const refineLabel = document.createElement('summary');
    refineLabel.textContent = 'Добавить контекст';
    refine.open = Boolean(session.reply);
    refine.append(refineLabel, reply, send);
    actions.append(save, cancel);
    footer.append(refine, actions);
    layer.append(content, footer);
  }

  function mountNear(summaryEl) {
    if (!summaryEl || summaryEl.dataset.o3dsMounted === '1') return;
    const issueKey = issueKeyNear(summaryEl);
    if (!issueKey) return;
    summaryEl.dataset.o3dsMounted = '1';

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'o3ds-btn';
    button.setAttribute('data-issue-key', issueKey);
    button.title = 'Улучшить описание через DeepSeek';
    button.append(sparkleSvg(), document.createTextNode('Улучшить'));
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (session.phase === 'loading' || session.phase === 'applying') return;
      openSession(issueKey);
    });
    summaryEl.insertAdjacentElement('afterend', button);
    syncButtons();
  }

  function scan() {
    ensureStyles();
    const summaryInput = document.getElementById('ozon-sb-summary');
    if (summaryInput) mountNear(summaryInput);
    NATIVE_SELECTORS.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => mountNear(node));
    });
  }

  let queued = false;
  function scheduleScan() {
    if (queued) return;
    queued = true;
    window.setTimeout(() => {
      queued = false;
      scan();
    }, 200);
  }

  ensureStyles();
  scan();
  document.addEventListener('ozon-fcrm-start-design-task', (event) => {
    let detail = event && event.detail;
    if (typeof detail === 'string') { try { detail = JSON.parse(detail); } catch { detail = null; } }
    if (detail && detail.issueKey) openDesignSession(detail.issueKey);
  });
  document.addEventListener('ozon-fcrm-design-task-result', (event) => {
    let detail = event && event.detail;
    if (typeof detail === 'string') { try { detail = JSON.parse(detail); } catch { detail = null; } }
    showDesignResult(detail);
  });
  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && session.phase !== 'idle' && session.phase !== 'applying') {
      closeSession();
    }
  });
})();

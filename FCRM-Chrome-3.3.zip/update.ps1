﻿param(
    [string]$ArchivePath
)
$ErrorActionPreference = 'Stop'
$target = $PSScriptRoot
$releaseBaseUrl = 'https://raw.githubusercontent.com/V-M221/jira-fcrm/main/'
$files = @('manifest.json', 'background.js', 'content.js', 'issue-enhance.js', 'styles.css', 'popup.html', 'popup.js', 'options.html', 'options.js')
$optional = @('update.bat', 'update.ps1')
$work = Join-Path $target ('.fcrm-update-' + [guid]::NewGuid().ToString('N'))
$staging = Join-Path $work 'staging'
$backup = Join-Path $work 'backup'
$applied = New-Object System.Collections.Generic.List[string]

function ConvertTo-ChromeVersion($value) {
    if ($value -isnot [string] -or $value -cnotmatch '\A(?:0|[1-9]\d{0,4})(?:\.(?:0|[1-9]\d{0,4})){0,3}\z') { return $null }
    $parts = @($value.Split('.') | ForEach-Object { [int]$_ })
    if (-not ($parts | Where-Object { $_ -gt 0 }) -or ($parts | Where-Object { $_ -gt 65535 })) { return $null }
    $parts += @(0) * (4 - $parts.Count)
    return [version]::new($parts[0], $parts[1], $parts[2], $parts[3])
}

try {
    $existingManifest = Join-Path $target 'manifest.json'
    if (-not (Test-Path -LiteralPath $existingManifest -PathType Leaf)) {
        throw 'Положите update.bat и update.ps1 в папку установленного расширения FCRM.'
    }
    $installed = Get-Content -LiteralPath $existingManifest -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($installed.manifest_version -ne 3 -or $installed.short_name -ne 'Ozon Structure') {
        throw 'Папка не похожа на установленное расширение FCRM.'
    }
    New-Item -ItemType Directory -Path $staging, $backup -Force | Out-Null
    $zipPath = Join-Path $work 'extension.zip'
    if ($ArchivePath) {
        Copy-Item -LiteralPath $ArchivePath -Destination $zipPath
    } else {
        Write-Host 'Загружаю актуальную сборку FCRM с GitHub...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $cacheBust = '?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $archive = 'FCRM-Chrome-3.3.zip'
        $release = $null
        try {
            $response = Invoke-WebRequest -Uri ($releaseBaseUrl + 'extension-version.json' + $cacheBust) -UseBasicParsing
            $release = $response.Content | ConvertFrom-Json
        } catch {
            # Older publications and temporary metadata failures can use the legacy URL.
        }
        if (ConvertTo-ChromeVersion $release.version) {
            $versionedArchive = 'releases/FCRM-Chrome-' + $release.version + '.zip'
            if ($release.archive -is [string] -and $release.archive -ceq $versionedArchive) {
                $archive = $versionedArchive
            }
        } else {
            $release = $null
        }
        Invoke-WebRequest -Uri ($releaseBaseUrl + $archive + $cacheBust) -OutFile $zipPath -UseBasicParsing
        if ($release.sha256 -is [string] -and $release.sha256 -cmatch '\A[0-9a-fA-F]{64}\z') {
            $actualHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
            if ($actualHash -ne $release.sha256) { throw 'Контрольная сумма архива не совпадает с данными GitHub.' }
        }
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        $names = @($zip.Entries | ForEach-Object { $_.FullName })
        foreach ($name in $names) {
            if ($name -cnotin ($files + $optional)) { throw "Неожиданный файл в архиве: $name" }
        }
        foreach ($name in $files) {
            if (@($names | Where-Object { $_ -ceq $name }).Count -ne 1) { throw "В архиве отсутствует файл $name или он повторяется." }
        }
    } finally { $zip.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $staging)
    $manifest = Get-Content -LiteralPath (Join-Path $staging 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $manifest.version -or $manifest.manifest_version -ne 3 -or $manifest.short_name -ne 'Ozon Structure') {
        throw 'В архиве некорректный manifest.json расширения FCRM.'
    }
    if (-not $ArchivePath) {
        $installedVersion = ConvertTo-ChromeVersion $installed.version
        $archiveVersion = ConvertTo-ChromeVersion $manifest.version
        if (-not $installedVersion -or -not $archiveVersion) {
            throw 'Не удалось сравнить версии установленного расширения и архива.'
        }
        if ($archiveVersion -lt $installedVersion) {
            throw 'Скачанный архив старее установленной версии FCRM.'
        }
        if ($release -and $manifest.version -cne $release.version) {
            throw 'Версия архива не совпадает с данными GitHub.'
        }
    }
    foreach ($name in $files) {
        $current = Join-Path $target $name
        if (Test-Path -LiteralPath $current -PathType Leaf) { Copy-Item -LiteralPath $current -Destination (Join-Path $backup $name) }
    }
    foreach ($name in $files) {
        Copy-Item -LiteralPath (Join-Path $staging $name) -Destination (Join-Path $target $name) -Force
        $applied.Add($name)
    }
    Write-Host ('Готово! Версия расширения: ' + $manifest.version)
} catch {
    $message = $_.Exception.Message
    $rollbackErrors = @()
    foreach ($name in $applied) {
        try {
            $saved = Join-Path $backup $name
            $current = Join-Path $target $name
            if (Test-Path -LiteralPath $saved -PathType Leaf) { Copy-Item -LiteralPath $saved -Destination $current -Force }
            elseif (Test-Path -LiteralPath $current -PathType Leaf) { Remove-Item -LiteralPath $current -Force }
        } catch { $rollbackErrors += $name }
    }
    Write-Host ('Ошибка обновления: ' + $message)
    if ($rollbackErrors.Count) {
        Write-Host ('Не удалось восстановить файлы: ' + ($rollbackErrors -join ', ') + '. Резервная копия: ' + $backup)
        exit 1
    }
    Write-Host 'Установленная версия сохранена.'
    exit 1
} finally {
    if (-not $rollbackErrors -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force }
}

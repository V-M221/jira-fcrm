const TOKEN_KEY = "ozon_deepseek_bearer_token";
const PROMPT_KEY = "ozon_deepseek_system_prompt";
const DEFAULT_PROMPT = "Готовь краткое продуктовое описание FCRM на русском для Jira Server. Пиши Jira Wiki (h2. заголовок, * пункт, [название|URL]). Сохраняй подтверждённые ограничения, поля, суммы и сроки. Различай исходное состояние, согласованный объём и отложенные работы. Оставляй технические детали только там, где они влияют на требование или приёмку. Используй списки вместо новых таблиц и сохраняй требования из существующих таблиц. FTD — дизайн, OB — бэкенд, OBFRONT — интерфейс. Сохраняй характер исследования, если решение ещё предстоит выбрать.";
const tokenInput = document.getElementById('token');
const promptInput = document.getElementById('system-prompt');
const statusEl = document.getElementById('status');

function showStatus(text) {
  statusEl.textContent = text;
}

chrome.storage.local.get([TOKEN_KEY, PROMPT_KEY]).then((stored) => {
  const value = stored && stored[TOKEN_KEY] ? String(stored[TOKEN_KEY]) : '';
  tokenInput.value = value;
  promptInput.value = stored && stored[PROMPT_KEY] ? String(stored[PROMPT_KEY]) : DEFAULT_PROMPT;
  showStatus(value ? 'Сохранённый токен подставлен в поле.' : 'Токен не задан: будет использована сессия deepseek.o3t.ru.');
});

document.getElementById('save-prompt').addEventListener('click', () => {
  const value = promptInput.value.trim();
  chrome.storage.local.set({ [PROMPT_KEY]: value }).then(() => {
    showStatus(value ? 'Системный промпт сохранён.' : 'Используется стандартный системный промпт.');
  });
});

document.getElementById('reset-prompt').addEventListener('click', () => {
  promptInput.value = DEFAULT_PROMPT;
  chrome.storage.local.remove(PROMPT_KEY).then(() => {
    showStatus('Возвращён стандартный системный промпт.');
  });
});

document.getElementById('save').addEventListener('click', () => {
  const value = tokenInput.value.trim();
  chrome.storage.local.set({ [TOKEN_KEY]: value }).then(() => {
    showStatus(value ? 'Токен сохранён в расширении.' : 'Поле пустое. Запросы пойдут через сессию deepseek.o3t.ru.');
  });
});

document.getElementById('clear').addEventListener('click', () => {
  tokenInput.value = '';
  chrome.storage.local.remove(TOKEN_KEY).then(() => {
    showStatus('Токен удалён.');
  });
});
